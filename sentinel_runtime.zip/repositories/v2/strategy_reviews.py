"""Admin-only diagnostic cases, separate from executable locked setup plans."""

from __future__ import annotations

from hashlib import sha256

from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load


class StrategyReviewRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def store(self, rows):
        identifiers = []
        with self.engine.transaction() as cursor:
            for row in rows:
                if row.get("state") not in {"NEEDS_REVIEW","ANALYTICAL_OBSERVATION"} or not row.get("symbol"):
                    continue
                identity = [row.get(key) for key in ("engine", "symbol", "timeframe", "ob_source_id", "reason", "profile_id", "thesis_key")]
                key = sha256(json_dump(identity).encode()).hexdigest()[:32]
                cursor.execute("""INSERT INTO s9_strategy_reviews(id,engine,symbol,timeframe,state,created_ms,payload)
                               VALUES(?,?,?,?,?,?,?) ON CONFLICT(id) DO NOTHING""",
                               (key, row["engine"], row["symbol"], row["timeframe"], row['state'],
                                row["available_ms"], json_dump(row)))
                if cursor.rowcount:
                    identifiers.append(key)
        return identifiers

    def list(self, *, symbol=None, timeframe=None, engine=None, limit=100):
        with self.engine.transaction(read_only=True) as cursor:
            rows = cursor.execute("""SELECT * FROM s9_strategy_reviews WHERE (?='' OR symbol=?)
                                  AND (?='' OR timeframe=?) AND (?='' OR engine=?)
                                  ORDER BY created_ms DESC,id LIMIT ?""",
                                  (symbol or "", symbol or "", timeframe or "", timeframe or "",
                                   engine or "", engine or "", max(1, min(200, int(limit))))).fetchall()
        return [{**row, "payload": json_load(row["payload"])} for row in rows]
