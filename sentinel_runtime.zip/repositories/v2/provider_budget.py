"""Atomic rolling-minute/UTC-day credits shared by all Twelve Data callers.

Reservations precede every outgoing attempt and survive restarts in the normal
database. Failed requests still consume credits; no secret is persisted.
"""
from __future__ import annotations

import os
import time
from hashlib import sha256

from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load


class ProviderBudgetExceeded(RuntimeError):
    pass


def _limit(name, default, maximum):
    return max(1, min(maximum, int(os.getenv(name, str(default)))))


def reserve_twelve(params, *, engine=None, now_ms=None):
    params = params or {}
    secret = str(params.get('apikey') or '')
    if not secret:
        raise ProviderBudgetExceeded('TWELVE_DATA_API_KEY_MISSING')
    key = 'twelve_data:' + sha256(secret.encode()).hexdigest()
    cost = max(1, len(str(params.get('symbol') or '').split(',')))
    minute_limit = _limit('TWELVE_DATA_MINUTE_BUDGET', 7, 8)
    day_limit = _limit('TWELVE_DATA_DAILY_BUDGET', 720, 800)
    non_gold_limit = _limit('TWELVE_DATA_NON_GOLD_DAILY_BUDGET', 360, day_limit)
    is_gold = str(params.get('symbol') or '').upper().replace('/', '') == 'XAUUSD'
    now = int(time.time() * 1000) if now_ms is None else int(now_ms)
    day = now // 86400000 * 86400000
    engine = engine or normalized_engine()
    with engine.transaction() as cursor:
        cursor.execute('INSERT INTO s9_provider_budget(id,payload) VALUES(?,?) ON CONFLICT(id) DO NOTHING', (key, '[]'))
        query = ('SELECT payload FROM s9_provider_budget WHERE id=? FOR UPDATE'
                 if engine.dialect.name == 'postgres' else 'SELECT payload FROM s9_provider_budget WHERE id=?')
        row = cursor.execute(query, (key,)).fetchone()
        events = json_load(row['payload'])
        # A backwards clock must not clear an already reserved future event.
        events = [event for event in events if event[0] >= day]
        if sum(event[1] for event in events) + cost > day_limit:
            raise ProviderBudgetExceeded('TWELVE_DATA_DAILY_BUDGET_EXHAUSTED')
        if not is_gold and sum(event[1] for event in events if len(event) < 3 or event[2] != 'gold') + cost > non_gold_limit:
            raise ProviderBudgetExceeded('TWELVE_DATA_NON_GOLD_BUDGET_EXHAUSTED')
        if sum(event[1] for event in events if event[0] > now - 60000) + cost > minute_limit:
            raise ProviderBudgetExceeded('TWELVE_DATA_MINUTE_BUDGET_EXHAUSTED')
        events.append([now, cost, 'gold' if is_gold else 'other'])
        cursor.execute('UPDATE s9_provider_budget SET payload=? WHERE id=?', (json_dump(events), key))


def reserve_streamdata(secret, *, engine=None, now_ms=None):
    """One history call per reservation; account-specific quota may be lower."""
    if not secret:
        raise ProviderBudgetExceeded('STREAMDATA_API_TOKEN_MISSING')
    key = 'streamdata:' + sha256(str(secret).encode()).hexdigest()
    now = int(time.time()*1000) if now_ms is None else int(now_ms)
    day = now//86400000*86400000
    minute_limit = _limit('STREAMDATA_MINUTE_BUDGET',20,30)
    day_limit = _limit('STREAMDATA_DAILY_BUDGET',2000,43200)
    engine = engine or normalized_engine()
    with engine.transaction() as cursor:
        cursor.execute('INSERT INTO s9_provider_budget(id,payload) VALUES(?,?) ON CONFLICT(id) DO NOTHING',(key,'[]'))
        query = ('SELECT payload FROM s9_provider_budget WHERE id=? FOR UPDATE'
                 if engine.dialect.name=='postgres' else 'SELECT payload FROM s9_provider_budget WHERE id=?')
        events = [e for e in json_load(cursor.execute(query,(key,)).fetchone()['payload']) if e[0]>=day]
        if sum(e[1] for e in events)+1>day_limit:
            raise ProviderBudgetExceeded('STREAMDATA_DAILY_BUDGET_EXHAUSTED')
        if sum(e[1] for e in events if e[0]>now-60000)+1>minute_limit:
            raise ProviderBudgetExceeded('STREAMDATA_MINUTE_BUDGET_EXHAUSTED')
        events.append([now,1])
        cursor.execute('UPDATE s9_provider_budget SET payload=? WHERE id=?',(json_dump(events),key))

