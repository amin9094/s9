from __future__ import annotations

import json
import hashlib
import logging
from typing import Any

from config import SETTINGS
from core.storage.engine import DatabaseEngine, normalized_engine
from repositories.v2.common import json_dump, json_load, new_id, utc_iso

logger=logging.getLogger(__name__)

class EventRepository:
    def __init__(self,engine:DatabaseEngine|None=None):
        self.engine=engine or normalized_engine()

    def append(self,user_id:int|str,event_type:str,payload:dict[str,Any]|None=None,*,entity_type:str="",entity_id:str="",idempotency_key:str="")->dict[str,Any]:
        event={"event_id":("idem:" + hashlib.sha256(idempotency_key.encode()).hexdigest()) if idempotency_key else new_id("evt"),"user_id":str(user_id),"event_type":str(event_type),"entity_type":str(entity_type),
               "entity_id":str(entity_id),"created_at":utc_iso(),"payload":payload or {}}
        with self.engine.transaction() as cursor:
            cursor.execute("INSERT INTO v8_events(event_id,user_id,event_type,entity_type,entity_id,created_at,payload) VALUES(?,?,?,?,?,?,?) ON CONFLICT(event_id) DO NOTHING",
                           (event["event_id"],event["user_id"],event["event_type"],event["entity_type"] or None,event["entity_id"] or None,event["created_at"],json_dump(event["payload"])))
            inserted = cursor.rowcount == 1
            row=cursor.execute("SELECT * FROM v8_events WHERE event_id=?",(event["event_id"],)).fetchone()
            if row['user_id'] != event['user_id'] or row['event_type'] != event['event_type']:
                raise ValueError('EVENT_IDEMPOTENCY_CONFLICT')
            event['payload'] = json_load(row.get('payload'), {}) or {}
            event['created_at'] = str(row['created_at'])
        event["sequence"]=int((row or {}).get("sequence") or 0)
        if inserted:
            self._publish_redis(event)
        return event

    def since(self,user_id:int|str,last_sequence:int=0,*,limit:int=200)->list[dict[str,Any]]:
        size=max(1,min(int(limit or 200),1000))
        with self.engine.transaction(read_only=True) as cursor:
            rows=cursor.execute("SELECT * FROM v8_events WHERE user_id IN (?, '*') AND sequence>? ORDER BY sequence LIMIT ?",
                                (str(user_id),int(last_sequence or 0),size)).fetchall()
        return [{"sequence":int(row["sequence"]),"event_id":row["event_id"],"user_id":row["user_id"],
                 "event_type":row["event_type"],"entity_type":row.get("entity_type"),"entity_id":row.get("entity_id"),
                 "created_at":str(row["created_at"]),"payload":json_load(row.get("payload"),{}) or {}} for row in rows]

    def _publish_redis(self,event:dict[str,Any])->None:
        if not SETTINGS.redis_url: return
        try:
            import redis
            user_id = str(event.get("user_id") or "*")
            stream = "sentinel:v8:events:global" if user_id == "*" else f"sentinel:v8:events:user:{user_id}"
            with redis.Redis.from_url(SETTINGS.redis_url, decode_responses=True, socket_timeout=2, socket_connect_timeout=2) as client:
                client.xadd(
                    stream,
                    {"event": json.dumps(event, ensure_ascii=False, separators=(",", ":"))},
                    id=f"{int(event.get('sequence') or 0)}-0",
                    maxlen=100000,
                    approximate=True,
                )
        except Exception:
            logger.warning("Redis event publish failed; durable database event remains available",exc_info=True)
