from __future__ import annotations

from core.storage.engine import normalized_engine
from modules.canonical_market import Candle
from repositories.v2.common import json_dump, json_load




class MarketEvidenceRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def save_candles(self, rows):
        if not rows:
            return 0
        grouped = {}
        for row in rows:
            grouped.setdefault((row.symbol, row.provider, row.timeframe), []).append(row)
        with self.engine.transaction() as cursor:
            for key, group in sorted(grouped.items()):
                if self.engine.dialect.name == "postgres":
                    # Serialize matching markets without holding a session lease.
                    cursor.execute("SELECT pg_advisory_xact_lock(hashtextextended(?,0))", ("sentinel-candles:" + ":".join(key),))
                existing_rows = cursor.execute(
                    "SELECT start_ms,payload FROM s9_candles WHERE symbol=? AND provider=? AND timeframe=? AND start_ms>=? AND start_ms<=?",
                    (*key, min(row.start_ms for row in group), max(row.start_ms for row in group)),
                ).fetchall()
                existing = {row["start_ms"]: Candle.from_dict(json_load(row["payload"])) for row in existing_rows}
                writes = []
                for row in group:
                    old = existing.get(row.start_ms)
                    if old:
                        if (old.venue, old.product, old.volume_kind, old.alignment_offset_ms) != (row.venue, row.product, row.volume_kind, row.alignment_offset_ms):
                            raise ValueError("CANDLE_PROVENANCE_CHANGE_REQUIRES_REVIEW")
                        if old.is_closed:
                            if (old.open, old.high, old.low, old.close, old.volume) != (row.open, row.high, row.low, row.close, row.volume):
                                raise ValueError("CLOSED_CANDLE_CORRECTION_REQUIRES_REVIEW")
                            continue
                        if row.available_ms < old.available_ms:
                            continue
                    writes.append((row.symbol, row.provider, row.timeframe, row.start_ms, row.end_ms, json_dump(row.as_dict())))
                if writes:
                    cursor.executemany(
                        """INSERT INTO s9_candles(symbol,provider,timeframe,start_ms,end_ms,payload)
                        VALUES(?,?,?,?,?,?) ON CONFLICT(symbol,provider,timeframe,start_ms) DO UPDATE SET
                        end_ms=excluded.end_ms,payload=excluded.payload""", writes,
                    )
            cutoff = max(row.available_ms for row in rows) - 180 * 86400000
            cursor.execute("DELETE FROM s9_candles WHERE end_ms < ?", (cutoff,))
        return len(rows)

    def candles(self, symbol, provider, timeframe, *, before_ms=None, limit=500):
        with self.engine.transaction(read_only=True) as cursor:
            records = cursor.execute(
                """SELECT payload FROM s9_candles WHERE symbol=? AND provider=? AND timeframe=?
              AND start_ms < ? ORDER BY start_ms DESC LIMIT ?""",
                (symbol, provider, timeframe, before_ms or 9223372036854775807, max(1, min(int(limit), 5000))),
            ).fetchall()
        return [Candle.from_dict(json_load(row["payload"])) for row in reversed(records)]
