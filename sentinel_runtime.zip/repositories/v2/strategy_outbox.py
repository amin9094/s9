"""Durable per-admin research notices. Uncertain Telegram delivery is not retried."""

from __future__ import annotations

import time
from hashlib import sha256

from core.storage.engine import normalized_engine
from repositories.v2.common import json_dump, json_load


class StrategyOutboxRepository:
    def __init__(self, engine=None):
        self.engine = engine or normalized_engine()

    def enqueue(self, review_ids, admin_ids):
        now = int(time.time() * 1000)
        with self.engine.transaction() as cursor:
            for review_id in review_ids:
                review = cursor.execute("SELECT payload FROM s9_strategy_reviews WHERE id=?", (review_id,)).fetchone()
                if not review:
                    continue
                for admin_id in admin_ids:
                    key = sha256(f"{review_id}:{int(admin_id)}".encode()).hexdigest()[:32]
                    cursor.execute("""INSERT INTO s9_admin_review_outbox(id,review_id,admin_id,status,attempts,updated_ms,payload)
                                   VALUES(?,?,?,'PENDING',0,?,?) ON CONFLICT(review_id,admin_id) DO NOTHING""",
                                   (key, review_id, str(int(admin_id)), now, json_dump({"review": json_load(review["payload"])})))

    def claim(self, limit=2):
        found = []
        with self.engine.transaction() as cursor:
            rows = cursor.execute("SELECT * FROM s9_admin_review_outbox WHERE status='PENDING' AND attempts<3 AND updated_ms<=? ORDER BY updated_ms,id LIMIT ?",
                                  (int(time.time() * 1000), max(1, min(10, int(limit))))).fetchall()
            for row in rows:
                cursor.execute("UPDATE s9_admin_review_outbox SET status='SENDING',attempts=attempts+1,updated_ms=? WHERE id=? AND status='PENDING'",
                               (int(time.time() * 1000), row["id"]))
                if cursor.rowcount:
                    found.append({**row, "payload": json_load(row["payload"])})
        return found

    def finish(self, key, status, *, message_id=None, retry_seconds=0):
        if status not in {"SENT", "PENDING", "FAILED", "UNCERTAIN", "REVOKED"}:
            raise ValueError("STRATEGY_OUTBOX_STATE_INVALID")
        with self.engine.transaction() as cursor:
            row = cursor.execute("SELECT payload,attempts FROM s9_admin_review_outbox WHERE id=? AND status='SENDING'", (key,)).fetchone()
            if not row:
                raise ValueError("STRATEGY_OUTBOX_CLAIM_MISSING")
            payload = json_load(row["payload"])
            if message_id is not None:
                payload["telegram_message_id"] = int(message_id)
            if status == "PENDING" and row["attempts"] >= 3:
                status = "FAILED"
            ready_ms = int(time.time() * 1000) + (max(0, min(3600, float(retry_seconds))) * 1000 if status == "PENDING" else 0)
            cursor.execute("UPDATE s9_admin_review_outbox SET status=?,updated_ms=?,payload=? WHERE id=? AND status='SENDING'",
                           (status, int(ready_ms), json_dump(payload), key))
