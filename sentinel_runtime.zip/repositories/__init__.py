"""Repository facades for scoped SENTINEL data access.

Legacy section repositories remain available for Telegram handlers while the
Mini App uses an explicit read-only boundary that cannot open write
transactions or advance the canonical state version.
"""

from .miniapp_read_repository import MiniAppReadRepository, miniapp_reads
from .sections import DictSectionRepository, ListSectionRepository, repository_metrics

__all__ = [
    "DictSectionRepository",
    "ListSectionRepository",
    "MiniAppReadRepository",
    "miniapp_reads",
    "repository_metrics",
]
