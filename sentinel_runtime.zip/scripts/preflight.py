#!/usr/bin/env python3
from __future__ import annotations

import argparse
import asyncio
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from config import SETTINGS  # noqa: E402
from core.db import database_catalog, load_db, validate_database_payload  # noqa: E402
from core.domain import payment_settings_ready  # noqa: E402
from core.backup_service import create_payload_backup, load_payload_backup, verify_payload_backup  # noqa: E402
from core.sensitive_data import protect_sensitive_payload, unprotect_sensitive_payload  # noqa: E402
from core.shared_cache import shared_cache_healthcheck  # noqa: E402
from modules.receipt_storage import receipt_storage_status  # noqa: E402


def _assert_writable(directory: Path) -> None:
    directory.mkdir(parents=True, exist_ok=True)
    fd, probe = tempfile.mkstemp(prefix=".sentinel-write-", dir=directory)
    try:
        os.write(fd, b"ok")
        os.fsync(fd)
    finally:
        os.close(fd)
        Path(probe).unlink(missing_ok=True)


def _telegram_call(method: str, payload: dict | None = None) -> dict:
    """Call Telegram without ever including the bot token in an exception."""
    import httpx

    url = f"https://api.telegram.org/bot{SETTINGS.bot_token}/{method}"
    try:
        with httpx.Client(timeout=SETTINGS.request_timeout_seconds) as client:
            response = client.post(url, json=payload or {})
            try:
                data = response.json()
            except (ValueError, json.JSONDecodeError) as exc:
                raise RuntimeError(f"Telegram {method} returned an invalid response") from exc
            if response.status_code >= 400:
                description = str(data.get("description") or "request rejected")[:200]
                raise RuntimeError(f"Telegram {method} failed with HTTP {response.status_code}: {description}")
    except httpx.TimeoutException as exc:
        raise RuntimeError(f"Telegram {method} timed out") from exc
    except httpx.RequestError as exc:
        raise RuntimeError(f"Telegram {method} network error ({exc.__class__.__name__})") from exc
    if not isinstance(data, dict) or not data.get("ok"):
        description = str(data.get("description") if isinstance(data, dict) else "unknown error")[:200]
        raise RuntimeError(f"Telegram {method} failed: {description}")
    result = data.get("result")
    if not isinstance(result, dict):
        raise RuntimeError(f"Telegram {method} returned an unexpected result")
    return result




def _cryptography_roundtrip() -> None:
    sample = {"profile": {"phone": "+491234567890", "email": "owner@sentinel.local"}}
    protected = protect_sensitive_payload(sample, SETTINGS.sensitive_data_key)
    if protected == sample or "enc:v1:" not in str(protected):
        raise RuntimeError("field-level sensitive-data encryption did not activate")
    if unprotect_sensitive_payload(protected, SETTINGS.sensitive_data_key) != sample:
        raise RuntimeError("field-level sensitive-data encryption roundtrip failed")
    with tempfile.TemporaryDirectory(prefix="sentinel-preflight-backup-") as directory:
        root = Path(directory)
        backup = create_payload_backup(
            {"schema_version": 1, "users": {}},
            root,
            encryption_key=SETTINGS.backup_encryption_key,
            key_version=SETTINGS.backup_key_version,
        )
        if not verify_payload_backup(
            backup,
            root,
            encryption_key=SETTINGS.backup_encryption_key,
            decryption_keys=SETTINGS.backup_previous_keys,
        ):
            raise RuntimeError("encrypted backup verification failed")
        restored = load_payload_backup(
            backup,
            root,
            encryption_key=SETTINGS.backup_encryption_key,
            decryption_keys=SETTINGS.backup_previous_keys,
        )
        if restored.get("users") != {}:
            raise RuntimeError("encrypted backup restore roundtrip failed")


def _infrastructure_checks() -> list[str]:
    warnings: list[str] = []
    receipt = receipt_storage_status()
    if not receipt.get("healthy"):
        raise RuntimeError("payment receipt storage is not writable/reachable")
    if SETTINGS.webapp_api_enabled and not receipt.get("persistent"):
        raise RuntimeError("payment receipt storage is not persistent")
    cache = asyncio.run(shared_cache_healthcheck(require_redis=bool(SETTINGS.redis_url)))
    if SETTINGS.redis_url and cache.get("backend") != "redis":
        raise RuntimeError("configured Redis is not reachable")
    if not SETTINGS.redis_url:
        warnings.append("Redis is not configured; only single-replica/local rate limiting is available")
    return warnings


def _online_checks() -> list[str]:
    warnings: list[str] = []
    me = _telegram_call("getMe")
    actual_username = str(me.get("username") or "")
    if SETTINGS.bot_username and actual_username.lower() != SETTINGS.bot_username.lower():
        warnings.append(
            f"BOT_USERNAME @{SETTINGS.bot_username} differs from the authenticated bot @{actual_username}; "
            "runtime links will use the authenticated username"
        )
    bot_id = int(me["id"])
    if SETTINGS.run_mode == "webhook":
        webhook = _telegram_call("getWebhookInfo")
        expected = f"{SETTINGS.webhook_url.rstrip('/')}/{SETTINGS.webhook_path.strip('/')}"
        actual = str(webhook.get("url") or "")
        if actual and actual != expected:
            warnings.append(f"Telegram webhook URL differs from expected unified endpoint: {actual}")
    for label, chat_id in (
        ("PUBLIC_CHANNEL_ID", SETTINGS.public_channel_id),
        ("PRIVATE_CHANNEL_ID", SETTINGS.private_channel_id),
    ):
        member = _telegram_call("getChatMember", {"chat_id": chat_id, "user_id": bot_id})
        if member.get("status") not in {"administrator", "creator"}:
            raise RuntimeError(f"Bot is not administrator in {label}")
        if label == "PUBLIC_CHANNEL_ID" and member.get("can_post_messages") is False:
            raise RuntimeError("Bot cannot post messages in PUBLIC_CHANNEL_ID")
        if label == "PRIVATE_CHANNEL_ID":
            if member.get("can_invite_users") is False:
                raise RuntimeError("Bot cannot create invite links in PRIVATE_CHANNEL_ID")
            if member.get("can_restrict_members") is False:
                raise RuntimeError("Bot cannot remove expired users from PRIVATE_CHANNEL_ID")
    return warnings


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--quiet", action="store_true")
    mode = parser.add_mutually_exclusive_group()
    mode.add_argument(
        "--online",
        action="store_true",
        help="validate token and Telegram channel permissions",
    )
    mode.add_argument(
        "--offline",
        action="store_true",
        help="run local configuration/database/write checks only (the default mode)",
    )
    parser.add_argument(
        "--strict-payment",
        action="store_true",
        help="fail when VIP card/owner/price settings are not configured",
    )
    args = parser.parse_args()
    warnings: list[str] = []
    try:
        SETTINGS.validate()
        db: dict = {}
        if SETTINGS.database_url or SETTINGS.db_file.suffix.lower() in {".sqlite", ".sqlite3", ".db"}:
            db = load_db()
        elif SETTINGS.db_file.exists():
            with SETTINGS.db_file.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            db = validate_database_payload(raw)
        _assert_writable(SETTINGS.db_file.parent)
        _assert_writable(SETTINGS.log_dir)
        _assert_writable(SETTINGS.backup_dir)
        _assert_writable(SETTINGS.heartbeat_file.parent)
        if db and (SETTINGS.database_url or SETTINGS.db_file.suffix.lower() in {".sqlite", ".sqlite3", ".db"}):
            catalog = database_catalog()
            if int(catalog.get("relational_storage_version", 0) or 0) < 1:
                raise RuntimeError("categorized database storage is not active")
            if int(catalog.get("section_count", 0) or 0) < 50:
                raise RuntimeError("categorized database migration is incomplete")
        _cryptography_roundtrip()
        warnings.extend(_infrastructure_checks())
        if db and not payment_settings_ready(db):
            message = "VIP payment settings are incomplete; purchases stay disabled until configured in the admin panel"
            if args.strict_payment:
                raise RuntimeError(message)
            warnings.append(message)
        if args.online:
            warnings.extend(_online_checks())
    except Exception as exc:
        if not args.quiet:
            print(f"PREFLIGHT FAILED: {exc}", file=sys.stderr)
        return 1
    if not args.quiet:
        print("PREFLIGHT OK")
        for warning in warnings:
            print(f"WARNING: {warning}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
