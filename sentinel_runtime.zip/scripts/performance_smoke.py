#!/usr/bin/env python3
from __future__ import annotations

import json
import os
import statistics
import sys
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))
os.chdir(ROOT)

os.environ.setdefault("PRIMARY_ADMIN_ID", "999999991")
os.environ.setdefault("ADMIN_IDS", "999999991")
os.environ.setdefault("BOT_TOKEN", str(123456) + ":" + "TEST_TOKEN_FOR_OFFLINE_PERFORMANCE")

from modules.admin_command_os import admin_global_search, invalidate_search_index
from modules.automation_event_bus import dispatch_automation_events_inplace
from modules.automation_v2 import create_automation_rule

OUT = ROOT / "quality-artifacts" / "performance_budgets.json"
OWNER = 999999991


def _milliseconds(start: float) -> float:
    return round((time.perf_counter() - start) * 1000.0, 3)


def search_benchmark() -> dict[str, float | int]:
    db = {
        "users": {
            str(index): {
                "id": str(index),
                "user_id": str(index),
                "username": f"sentinel-member-{index}",
                "first_name": "کاربر",
                "last_name": str(index),
                "updated_at": f"2026-08-03T12:{index % 60:02d}:00+00:00",
            }
            for index in range(15_000)
        }
    }
    invalidate_search_index()
    started = time.perf_counter()
    cold = admin_global_search(db, OWNER, "sentinel-member-14999", limit=10)
    cold_ms = _milliseconds(started)
    warm_samples: list[float] = []
    for _ in range(25):
        started = time.perf_counter()
        result = admin_global_search(db, OWNER, "sentinel-member-14999", limit=10)
        warm_samples.append(_milliseconds(started))
        if not result["items"] or result["items"][0]["id"] != "14999":
            raise RuntimeError("SEARCH_PERFORMANCE_RESULT_INVALID")
    if not cold["items"] or cold["items"][0]["id"] != "14999":
        raise RuntimeError("SEARCH_COLD_RESULT_INVALID")
    return {
        "documents": int(cold["indexed_documents"]),
        "candidates": int(cold["candidate_count"]),
        "cold_ms": cold_ms,
        "warm_median_ms": round(statistics.median(warm_samples), 3),
        "warm_p95_ms": round(sorted(warm_samples)[int(len(warm_samples) * 0.95) - 1], 3),
    }


def automation_benchmark() -> dict[str, float | int]:
    # Large unrelated histories should not be scanned when only registration
    # rules are enabled.
    before: dict = {
        "users": {},
        "vip_orders": [
            {"id": f"O-{index}", "status": "approved", "user_id": str(index)}
            for index in range(25_000)
        ],
        "signals": [
            {"id": f"S-{index}", "status": "closed", "symbol": "XAUUSD"}
            for index in range(25_000)
        ],
        "tickets": [
            {"id": f"T-{index}", "status": "closed", "user_id": str(index)}
            for index in range(10_000)
        ],
    }
    create_automation_rule(
        before,
        name="performance registration",
        trigger="user_registered",
        conditions=[],
        actions=[{"type": "write_log", "payload": {"message": "registered {{user_id}}"}}],
        guards={},
        actor_id=OWNER,
        enabled=True,
    )
    after = dict(before)
    after["users"] = {"42": {"id": "42", "user_id": "42", "created_at": "2026-08-03T12:00:00+00:00"}}
    started = time.perf_counter()
    result = dispatch_automation_events_inplace(before, after)
    elapsed_ms = _milliseconds(started)
    if result.get("events") != 1 or result.get("runs") != 1:
        raise RuntimeError("AUTOMATION_PERFORMANCE_RESULT_INVALID")
    return {
        "unrelated_rows": 60_000,
        "elapsed_ms": elapsed_ms,
        "events": int(result["events"]),
        "runs": int(result["runs"]),
    }


def main() -> int:
    result = {
        "schema_version": 1,
        "search": search_benchmark(),
        "automation_event_bus": automation_benchmark(),
        "budgets_ms": {
            "search_cold": 3000.0,
            "search_warm_p95": 80.0,
            "automation_trigger_aware": 250.0,
        },
    }
    failures: list[str] = []
    if float(result["search"]["cold_ms"]) > 3000.0:
        failures.append("SEARCH_COLD_BUDGET_EXCEEDED")
    if float(result["search"]["warm_p95_ms"]) > 80.0:
        failures.append("SEARCH_WARM_BUDGET_EXCEEDED")
    if float(result["automation_event_bus"]["elapsed_ms"]) > 250.0:
        failures.append("AUTOMATION_EVENT_BUS_BUDGET_EXCEEDED")
    result["passed"] = not failures
    result["failures"] = failures
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["passed"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
