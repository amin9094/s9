"""One coverage scope for Docker, local release proof and finalization."""

CRITICAL_TARGETS = ['core/async_runtime.py', 'core/distributed_jobs.py', 'core/miniapp_server.py', 'core/rate_limit.py', 'core/runtime_watchdog.py', 'core/storage/engine.py', 'core/update_processor.py', 'modules/admin_command_os.py', 'modules/automation_event_bus.py', 'modules/automation_v2.py', 'modules/feature_flags.py', 'modules/gemini_ads.py', 'modules/market_scope.py', 'modules/operations_intelligence.py', 'modules/portfolio.py', 'modules/prices.py', 'modules/prop_rules_v2/engine.py', 'modules/provider_intelligence.py', 'modules/security_sentinel.py', 'modules/trading_coach.py', 'repositories/v2/commerce.py', 'repositories/v2/idempotency.py', 'repositories/v2/journal.py', 'repositories/v2/positions.py', 'repositories/v2/preferences.py', 'repositories/v2/signals.py', 'services/actions_v2/journal.py', 'services/actions_v2/preferences.py', 'services/ai_control_service.py', 'services/automation_v2_dispatcher.py', 'services/live_market_service.py', 'services/miniapp_action_service_v2.py', 'services/miniapp_read_service_v2.py', 'services/vip_entitlement_projection.py']

# Candle-only analysis and shared account credits are financial data boundaries.
CRITICAL_TARGETS += [
    "repositories/v2/provider_budget.py", "services/canonical_market_service.py",
    "services/strategy_analysis_service.py", "services/market_reference_service.py",
    "modules/strategies/observations.py", "modules/strategies/indicators/observer.py",
    "modules/strategies/order_block/observer.py", "modules/strategies/sweep_fvg/observer.py",
    "modules/strategies/fibonacci/observer.py",
    "services/iran_market_data_service.py",
    "services/keyless_market_data_service.py",
    "services/strategy_readiness_service.py",
    "services/iran_equity_service.py", "modules/iran_equities.py", "modules/iran_equity_intraday.py",
    "services/strategy_delivery_service.py", "services/strategy_quote_owner.py",
    "services/biquote_stream_check.py",
    "modules/strategies/common.py", "modules/strategies/identity.py",
    "modules/strategies/indicators/engine.py", "modules/strategies/sweep_fvg/engine.py",
    "modules/strategies/order_block/engine.py", "modules/strategies/fibonacci/engine.py",
    "modules/strategies/fibonacci_pullback/engine.py", "repositories/v2/setup_proposals.py",
]
