#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
from datetime import UTC, datetime
from pathlib import Path

from quality_utils import source_fingerprint

ROOT = Path(__file__).resolve().parents[1]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--proof", type=Path, default=ROOT / "QUALITY_PROOF.json")
    parser.add_argument("--image-digest", required=True)
    parser.add_argument("--commit-sha", required=True)
    parser.add_argument("--candidate", action="store_true", help="Record a Docker-built candidate without promoting it to production")
    args = parser.parse_args()
    proof_path = args.proof if args.proof.is_absolute() else ROOT / args.proof
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    lock_status = json.loads((ROOT / "DEPENDENCY_LOCK_STATUS.json").read_text(encoding="utf-8"))
    if not args.candidate and (not lock_status.get("complete_transitive_lock") or not lock_status.get("hashes_required")):
        raise RuntimeError("production attestation requires a complete transitive hash lock")
    if proof.get("source_sha256") != source_fingerprint(ROOT):
        raise RuntimeError("source changed after quality validation")
    if args.candidate:
        proof["commit_sha"] = str(args.commit_sha)
        proof["docker_image_digest"] = str(args.image_digest)
        proof.setdefault("validation", {})["docker_build_no_cache"] = True
        proof["validation"]["docker_runtime_non_root"] = True
        deferred = proof.get("deferred_validation") if isinstance(proof.get("deferred_validation"), dict) else {}
        deferred.pop("docker_build_no_cache", None)
        deferred.pop("docker_image_digest", None)
        proof["deferred_validation"] = deferred
        proof["candidate_attested_at"] = datetime.now(UTC).isoformat()
        proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
        print(f"CANDIDATE DEPLOYMENT ATTESTATION OK: image={args.image_digest}")
        return 0
    if not str(args.image_digest).startswith("sha256:"):
        raise RuntimeError("image digest must start with sha256:")
    if len(str(args.commit_sha).strip()) < 7:
        raise RuntimeError("commit SHA is invalid")
    if int(proof.get("automated_tests_executed") or 0) < int(proof.get("automated_tests_discovered") or 0):
        raise RuntimeError("not every discovered test was executed")
    if int(proof.get("tests_failed") or 0):
        raise RuntimeError("test failures are present")
    if int(proof.get("line_coverage_percent") or 0) < 40:
        raise RuntimeError("overall coverage is below 40%")
    if int(proof.get("critical_path_coverage_percent") or 0) < 85:
        raise RuntimeError("critical-path coverage is below 85%")
    required = {"application_build", "ruff", "bandit", "pytest", "coverage", "critical_coverage", "javascript"}
    validations = proof.get("validation") if isinstance(proof.get("validation"), dict) else {}
    if not all(validations.get(name) for name in required):
        raise RuntimeError("required production validations are not successful")
    deferred = proof.get("deferred_validation") if isinstance(proof.get("deferred_validation"), dict) else {}
    deferred.pop("docker_build_no_cache", None)
    deferred.pop("docker_image_digest", None)
    if deferred:
        raise RuntimeError(f"unresolved deferred validation remains: {', '.join(sorted(deferred))}")
    proof.update({
        "release_channel": "production",
        "attested_at": datetime.now(UTC).isoformat(),
        "docker_image_digest": str(args.image_digest),
        "commit_sha": str(args.commit_sha),
        "deferred_validation": {},
    })
    proof.setdefault("validation", {})["docker_build_no_cache"] = True
    proof["validation"]["docker_runtime_non_root"] = True
    proof_path.write_text(json.dumps(proof, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"DEPLOYMENT ATTESTATION OK: image={args.image_digest}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
