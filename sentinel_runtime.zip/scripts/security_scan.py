#!/usr/bin/env python3
from __future__ import annotations

import ast
import re
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT / "scripts") not in sys.path:
    sys.path.insert(0, str(ROOT / "scripts"))

from quality_utils import source_files  # noqa: E402

TOKEN_PATTERN = re.compile(r"\b\d{6,12}:[A-Za-z0-9_-]{30,}\b")
PRIVATE_KEY_MARKERS = ("-----BEGIN " + "PRIVATE KEY-----", "-----BEGIN RSA " + "PRIVATE KEY-----")


def _call_name(node: ast.Call) -> str:
    target = node.func
    parts: list[str] = []
    while isinstance(target, ast.Attribute):
        parts.append(target.attr)
        target = target.value
    if isinstance(target, ast.Name):
        parts.append(target.id)
    return ".".join(reversed(parts))


def scan_python(path: Path) -> list[str]:
    failures: list[str] = []
    text = path.read_text(encoding="utf-8", errors="replace")
    if TOKEN_PATTERN.search(text):
        failures.append("embedded Telegram-style token")
    if any(marker in text for marker in PRIVATE_KEY_MARKERS):
        failures.append("embedded private key")
    try:
        tree = ast.parse(text, filename=str(path))
    except SyntaxError as exc:
        return [f"syntax error: {exc}"]
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        name = _call_name(node)
        if name in {"eval", "exec", "pickle.load", "pickle.loads", "marshal.loads"}:
            failures.append(f"unsafe call {name} at line {node.lineno}")
        if name.startswith("subprocess."):
            for keyword in node.keywords:
                if keyword.arg == "shell" and isinstance(keyword.value, ast.Constant) and keyword.value.value is True:
                    failures.append(f"subprocess shell=True at line {node.lineno}")
        if name in {"yaml.load", "yaml.unsafe_load"}:
            failures.append(f"unsafe YAML loader at line {node.lineno}")
    return failures


def main() -> int:
    findings: list[str] = []
    for path in source_files(ROOT):
        if path.suffix != ".py":
            continue
        for issue in scan_python(path):
            findings.append(f"{path.relative_to(ROOT)}: {issue}")
    for env_name in (".env", ".env.local"):
        if (ROOT / env_name).exists():
            findings.append(f"{env_name}: secret-bearing environment file must not ship")
    if findings:
        print("SECURITY SCAN FAILED", file=sys.stderr)
        for finding in findings:
            print(f"- {finding}", file=sys.stderr)
        return 1
    print("SECURITY SCAN OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
