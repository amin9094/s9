from __future__ import annotations

import argparse
import concurrent.futures
import json
import statistics
import tempfile
import time
from pathlib import Path
from typing import Any
import sys

PROJECT_ROOT = Path(__file__).resolve().parents[2]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from core.storage.engine import DatabaseEngine  # noqa: E402
from repositories.v2.accounts import AccountRepository  # noqa: E402
from repositories.v2.idempotency import IdempotencyRepository  # noqa: E402
from repositories.v2.positions import PositionRepository  # noqa: E402
from repositories.v2.signals import SignalRepository  # noqa: E402


def percentile(values: list[float], percentile_value: float) -> float:
    if not values:
        return 0.0
    ordered = sorted(values)
    index = min(len(ordered) - 1, max(0, round((len(ordered) - 1) * percentile_value)))
    return ordered[index]


def run_load_smoke(
    *,
    operations: int = 40,
    workers: int = 8,
    database_url: str = "",
    sqlite_path: Path | None = None,
) -> dict[str, Any]:
    """Exercise independent row-level financial writes concurrently.

    This is intentionally deterministic and does not call Telegram or external
    providers. It catches accidental reintroduction of full-state/global-lock
    writes before a release is built. Production load tests may point this at a
    disposable PostgreSQL database through ``database_url``.
    """
    owned_temp: tempfile.TemporaryDirectory[str] | None = None
    if not database_url and sqlite_path is None:
        owned_temp = tempfile.TemporaryDirectory(prefix="sentinel-load-")
        sqlite_path = Path(owned_temp.name) / "load.sqlite3"
    engine = DatabaseEngine(database_url=database_url, sqlite_path=sqlite_path)
    engine.ensure_schema()

    signals = SignalRepository(engine)
    accounts = AccountRepository(engine)
    positions = PositionRepository(engine)
    idempotency = IdempotencyRepository(engine)
    latencies: list[float] = []
    errors: list[str] = []

    def operation(index: int) -> dict[str, Any]:
        started = time.perf_counter()
        user_id = f"load-user-{index}"
        account_id = f"load-account-{index}"
        signal_id = f"load-signal-{index}"
        request_id = f"load-request-{index}"
        try:
            signals.upsert(
                {
                    "id": signal_id,
                    "symbol": "EURUSD",
                    "side": "BUY",
                    "status": "open",
                    "created_at": "2026-07-21T12:00:00+00:00",
                    "updated_at": "2026-07-21T12:00:00+00:00",
                    "entry": 1.1,
                    "stop": 1.09,
                }
            )
            account = accounts.upsert(
                user_id,
                {
                    "id": account_id,
                    "name": "Load test",
                    "balance": 10_000,
                    "equity": 10_000,
                    "starting_balance": 10_000,
                    "timezone": "UTC",
                },
                account_id=account_id,
            )
            reservation = idempotency.reserve(
                user_id,
                request_id,
                action="open_position",
                fingerprint=f"fingerprint-{index}",
            )
            if reservation.state != "new":
                raise RuntimeError(f"unexpected idempotency state: {reservation.state}")
            position = positions.open(
                {
                    "id": f"load-position-{index}",
                    "user_id": user_id,
                    "account_id": account["id"],
                    "signal_id": signal_id,
                    "symbol": "EURUSD",
                    "side": "BUY",
                    "actual_entry": 1.1,
                    "actual_stop": 1.09,
                    "actual_volume": 0.1,
                    "risk_percent": 1,
                    "risk_money": 100,
                }
            )
            idempotency.complete(
                user_id,
                request_id,
                token=reservation.token,
                response={"position_id": position["id"]},
            )
            replay = idempotency.reserve(
                user_id,
                request_id,
                action="open_position",
                fingerprint=f"fingerprint-{index}",
            )
            if replay.state != "replay":
                raise RuntimeError(f"idempotency replay failed: {replay.state}")
            return {"ok": True, "latency": time.perf_counter() - started}
        except Exception as exc:  # pragma: no cover - collected in report
            return {
                "ok": False,
                "latency": time.perf_counter() - started,
                "error": f"{exc.__class__.__name__}: {exc}",
            }

    started = time.perf_counter()
    try:
        with concurrent.futures.ThreadPoolExecutor(max_workers=max(1, workers)) as executor:
            results = list(executor.map(operation, range(max(1, operations))))
        for result in results:
            latencies.append(float(result["latency"]))
            if not result["ok"]:
                errors.append(str(result.get("error") or "unknown"))
        duration = time.perf_counter() - started
        report = {
            "status": "passed" if not errors else "failed",
            "operations": len(results),
            "workers": max(1, workers),
            "successes": len(results) - len(errors),
            "errors": errors[:20],
            "duration_seconds": round(duration, 4),
            "throughput_per_second": round(len(results) / max(duration, 1e-9), 2),
            "latency_ms": {
                "average": round(statistics.fmean(latencies) * 1000, 2) if latencies else 0.0,
                "p50": round(percentile(latencies, 0.50) * 1000, 2),
                "p95": round(percentile(latencies, 0.95) * 1000, 2),
                "maximum": round(max(latencies, default=0.0) * 1000, 2),
            },
        }
        if errors:
            raise RuntimeError(json.dumps(report, ensure_ascii=False))
        return report
    finally:
        if owned_temp is not None:
            owned_temp.cleanup()


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the SENTINEL normalized-storage concurrency smoke test")
    parser.add_argument("--operations", type=int, default=40)
    parser.add_argument("--workers", type=int, default=8)
    parser.add_argument("--database-url", default="")
    args = parser.parse_args()
    result = run_load_smoke(
        operations=max(1, args.operations),
        workers=max(1, args.workers),
        database_url=str(args.database_url or "").strip(),
    )
    print(json.dumps(result, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
