#!/usr/bin/env python3
"""Generate independent production secrets without writing them to disk."""
from __future__ import annotations

import secrets


def main() -> int:
    values = {
        "WEBAPP_SESSION_SECRET": secrets.token_urlsafe(48),
        "BACKUP_ENCRYPTION_KEY": secrets.token_urlsafe(48),
        "SENSITIVE_DATA_KEY": secrets.token_urlsafe(48),
        "WEBHOOK_SECRET_TOKEN": secrets.token_urlsafe(32),
        "METRICS_TOKEN": secrets.token_urlsafe(32),
    }
    for key, value in values.items():
        print(f"{key}={value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
