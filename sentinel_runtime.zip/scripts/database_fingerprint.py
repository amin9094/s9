#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import os
from urllib.parse import urlsplit


def database_fingerprint(database_url: str) -> str:
    parsed = urlsplit(str(database_url or ""))
    if parsed.scheme not in {"postgres", "postgresql"} or not parsed.hostname:
        raise ValueError("DATABASE_URL must be PostgreSQL")
    database = parsed.path.lstrip("/")
    canonical = f"{parsed.hostname.lower()}:{parsed.port or 5432}/{database}"
    return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:32]


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--database-url", default=os.getenv("DATABASE_URL") or os.getenv("POSTGRES_URL") or "")
    args = parser.parse_args()
    print(database_fingerprint(args.database_url))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
