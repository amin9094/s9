#!/usr/bin/env python3
from __future__ import annotations

import hashlib
import re
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
WEB = ROOT / "webapp"
SRC = WEB / "src"
ASSETS = WEB / "assets"
JS_PARTS = ["core.js", "signals-home.js", "risk-journal.js", "commerce-support.js", "contests.js", "trade-center.js", "experience-v2.js", "shell-events.js", "admin-parity.js", "support-enhanced.js", "workspace.js", "recovery.js", "user-hub.js", "live-chart.js", "iran-equities.js", "bootstrap.js"]


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()[:12]


def main() -> None:
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    if not re.fullmatch(r"[0-9]+\.[0-9]+\.[0-9]+(?:[-+][A-Za-z0-9.-]+)?", version):
        raise RuntimeError("VERSION must be semantic version text")
    core_path = SRC / "core.js"
    core = core_path.read_text(encoding="utf-8")
    core = re.sub(r"const\s+APP_VERSION\s*=\s*'[^']+';", f"const APP_VERSION = '{version}';", core, count=1)
    core_path.write_text(core, encoding="utf-8")
    body = "\n".join((SRC / name).read_text(encoding="utf-8").rstrip() for name in JS_PARTS)
    js = ("(()=>{'use strict';\n" + body + "\n})();\n").encode("utf-8")
    css = (SRC / "styles.css").read_bytes()
    js_name = f"app.{digest(js)}.js"
    css_name = f"app.{digest(css)}.css"
    (ASSETS / js_name).write_bytes(js)
    (ASSETS / css_name).write_bytes(css)
    # Keep exactly one production JS/CSS bundle. Stale hashed assets can be
    # requested by old clients and silently reintroduce fixed defects.
    for candidate in ASSETS.glob("app.*.js"):
        if candidate.name != js_name:
            candidate.unlink()
    for candidate in ASSETS.glob("app.*.css"):
        if candidate.name != css_name:
            candidate.unlink()

    html_path = WEB / "index.html"
    html = html_path.read_text(encoding="utf-8")
    html = re.sub(r'(<link rel="stylesheet" href="\./assets/)app\.[0-9a-f]{12}\.css(">)', rf'\1{css_name}\2', html, count=1)
    html = re.sub(r'(<script src="\./assets/)app\.[0-9a-f]{12}\.js(" defer></script>)', rf'\1{js_name}\2', html, count=1)
    html = re.sub(r'(manifest\.webmanifest\?v=)[^"\s]+', rf'\g<1>{version}', html, count=1)
    html_path.write_text(html, encoding="utf-8")

    sw_path = WEB / "sw.js"
    sw = sw_path.read_text(encoding="utf-8")
    sw = re.sub(r"const VERSION='[^']+'", f"const VERSION='{version}'", sw)
    sw = re.sub(r"\./assets/app\.[0-9a-f]{12}\.css", f"./assets/{css_name}", sw, count=1)
    sw = re.sub(r"\./assets/app\.[0-9a-f]{12}\.js", f"./assets/{js_name}", sw, count=1)
    sw_path.write_text(sw, encoding="utf-8")

    manifest_path = WEB / "manifest.webmanifest"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    manifest["id"] = f"sentinel-v{version}"
    manifest["version"] = version
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(f"built {js_name} {css_name} version={version}")


if __name__ == "__main__":
    main()
