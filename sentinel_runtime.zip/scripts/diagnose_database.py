#!/usr/bin/env python3
"""Read-only DB incident probe. Run inside the failing Railway service."""

from __future__ import annotations

import json
import os
import sys
import time
from pathlib import Path
from urllib.parse import urlsplit

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))


def main() -> int:
    from core.postgres_runtime import error_code, normalize_database_url, redact_error

    result = {"ok": False, "probe": "read_only", "schema_mutated": False}
    start = time.monotonic()
    try:
        url = normalize_database_url(os.getenv("DATABASE_URL") or os.getenv("POSTGRES_URL") or "")
        if not url:
            result["error_code"] = "DATABASE_URL_MISSING"
        else:
            import psycopg

            parsed = urlsplit(url)
            result["endpoint"] = {
                "private_railway_host": (parsed.hostname or "").endswith(".railway.internal"),
                "port": parsed.port or 5432,
                "database_present": bool(parsed.path.lstrip("/")),
                "credentials_present": bool(parsed.username and parsed.password),
            }
            with psycopg.connect(
                url,
                connect_timeout=5,
                autocommit=True,
                options="-c statement_timeout=5000 -c default_transaction_read_only=on",
            ) as connection:
                with connection.cursor() as cursor:
                    cursor.execute(
                        "SELECT 1, has_schema_privilege(current_user,current_schema(),'USAGE'), "
                        "has_schema_privilege(current_user,current_schema(),'CREATE')"
                    )
                    row = cursor.fetchone()
                    result["connection"] = bool(row and row[0] == 1)
                    result["schema_usage"] = bool(row and row[1])
                    result["schema_create"] = bool(row and row[2])
                    cursor.execute(
                        "SELECT to_regclass('v8_meta'), to_regclass('app_state'), to_regclass('telegram_state')"
                    )
                    result["tables_present"] = [bool(value) for value in cursor.fetchone()]
                    result["ok"] = all((result["connection"], result["schema_usage"], result["schema_create"]))
    except Exception as exc:
        result["error_code"] = error_code(exc)
        result["error_type"] = type(exc).__name__
        result["message"] = redact_error(exc)[:800]
    result["duration_ms"] = round((time.monotonic() - start) * 1000)
    print(json.dumps(result, ensure_ascii=False))
    return 0 if result["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
