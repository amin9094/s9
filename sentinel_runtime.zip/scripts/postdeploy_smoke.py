#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import ssl
import sys
from urllib.error import HTTPError, URLError
from urllib.parse import urljoin
from urllib.request import Request, urlopen


def request(base: str, path: str, *, expected: set[int]) -> tuple[int, bytes, dict[str, str]]:
    url = urljoin(base.rstrip('/') + '/', path.lstrip('/'))
    req = Request(url, headers={'User-Agent': 'sentinel-postdeploy-smoke/1'})
    try:
        with urlopen(req, timeout=15, context=ssl.create_default_context()) as response:  # nosec B310
            status = int(response.status)
            body = response.read(2_000_000)
            headers = {k.lower(): v for k, v in response.headers.items()}
    except HTTPError as exc:
        status = int(exc.code)
        body = exc.read(2_000_000)
        headers = {k.lower(): v for k, v in exc.headers.items()}
    except URLError as exc:
        raise RuntimeError(f'cannot reach {url}: {exc.reason}') from exc
    if status not in expected:
        raise RuntimeError(f'{path} returned {status}, expected {sorted(expected)}: {body[:300]!r}')
    return status, body, headers


def json_body(body: bytes, path: str) -> dict:
    try:
        value = json.loads(body.decode('utf-8'))
    except Exception as exc:
        raise RuntimeError(f'{path} did not return JSON') from exc
    if not isinstance(value, dict):
        raise RuntimeError(f'{path} JSON is not an object')
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description='Validate a deployed SENTINEL HTTP surface.')
    parser.add_argument('--base-url', required=True)
    parser.add_argument('--allow-not-ready', action='store_true')
    args = parser.parse_args()
    if not args.base_url.startswith('https://'):
        raise RuntimeError('base URL must use HTTPS')

    _, health_raw, health_headers = request(args.base_url, '/healthz', expected={200})
    health = json_body(health_raw, '/healthz')
    ready_expected = {200, 503} if args.allow_not_ready else {200}
    ready_status, ready_raw, _ = request(args.base_url, '/readyz', expected=ready_expected)
    ready = json_body(ready_raw, '/readyz')
    if ready_status == 200 and ready.get('ready') is not True:
        raise RuntimeError('/readyz returned successful HTTP status without true readiness')
    if ready_status == 503 and ready.get('ready') is not False:
        raise RuntimeError('/readyz returned inconsistent readiness state')
    request(args.base_url, '/metrics', expected={403})
    request(args.base_url, '/api/v1/overview', expected={401})
    _, app_body, app_headers = request(args.base_url, '/app', expected={200})
    if b'SENTINEL' not in app_body:
        raise RuntimeError('/app does not contain SENTINEL shell')
    if 'text/html' not in app_headers.get('content-type', ''):
        raise RuntimeError('/app content type is not HTML')
    if health_headers.get('strict-transport-security') is None:
        raise RuntimeError('HSTS header is missing')
    print(json.dumps({
        'ok': True,
        'health': health,
        'ready_status': ready_status,
        'ready': ready,
        'base_url': args.base_url,
    }, ensure_ascii=False))
    return 0


if __name__ == '__main__':
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f'POSTDEPLOY SMOKE FAILED: {exc}', file=sys.stderr)
        raise SystemExit(1) from exc
