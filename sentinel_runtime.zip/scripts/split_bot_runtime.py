from __future__ import annotations

import ast
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / "bot.py"
PACKAGE = ROOT / "bot_runtime"

RANGES = (
    ("navigation", 0, 2709),
    ("commerce_calculator", 2710, 4181),
    ("market_data", 4182, 6348),
    ("signals_portfolio", 6349, 7999),
    ("account_support", 8000, 10499),
    ("crm_content", 10500, 12999),
    ("admin_operations", 13000, 15999),
    ("growth_campaigns", 16000, 18999),
    ("analytics_governance", 19000, 21999),
    ("runtime_jobs", 22000, 99999),
)


def segment(source: str, node: ast.AST) -> str:
    text = ast.get_source_segment(source, node)
    if text is None:
        raise RuntimeError(f"could not extract node at line {getattr(node, 'lineno', '?')}")
    return text.rstrip() + "\n"


def main() -> None:
    source = SOURCE.read_text(encoding="utf-8")
    tree = ast.parse(source)
    definitions = [node for node in tree.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef))]
    shared_nodes = [
        node for node in tree.body
        if isinstance(node, (ast.Import, ast.ImportFrom, ast.Assign, ast.AnnAssign, ast.Expr))
    ]
    # The only top-level expression is the warning filter. Never carry the old
    # ``if __name__ == '__main__'`` block into shared state.
    PACKAGE.mkdir(parents=True, exist_ok=True)
    shared_text = '"""Shared imports and immutable constants for modular Telegram features."""\n\n'
    for node in shared_nodes:
        shared_text += segment(source, node) + "\n"
    (PACKAGE / "shared.py").write_text(shared_text, encoding="utf-8")

    module_names: list[str] = []
    ownership: dict[str, str] = {}
    all_names: list[str] = []
    for module_name, start, end in RANGES:
        nodes = [node for node in definitions if start <= int(node.lineno) <= end]
        if not nodes:
            continue
        module_names.append(module_name)
        text = (
            f'"""Feature-owned Telegram handlers extracted from the v7 runtime: {module_name}."""\n\n'
            "from bot_runtime import shared as _shared\n"
            "globals().update({name: value for name, value in vars(_shared).items() if not name.startswith('__')})\n\n"
        )
        names: list[str] = []
        for node in nodes:
            text += segment(source, node) + "\n\n"
            names.append(node.name)
            all_names.append(node.name)
            ownership[node.name] = module_name
        text += "\n__feature_exports__ = " + repr(tuple(names)) + "\n"
        (PACKAGE / f"{module_name}.py").write_text(text, encoding="utf-8")

    if len(all_names) != len(definitions):
        missing = [node.name for node in definitions if node.name not in ownership]
        raise RuntimeError(f"unowned definitions: {missing}")

    init_text = '"""Modular Telegram bot runtime for SENTINEL v8."""\n'
    init_text += "FEATURE_MODULES = " + repr(tuple(module_names)) + "\n"
    (PACKAGE / "__init__.py").write_text(init_text, encoding="utf-8")

    facade = '''"""SENTINEL Telegram compatibility facade.

Business handlers are owned by modules under :mod:`bot_runtime`.  This file is
intentionally a small bootstrap/export layer so imports used by Railway and
legacy tests remain stable without preserving a 25k-line monolith.
"""
from __future__ import annotations

from importlib import import_module

from bot_runtime import FEATURE_MODULES
from bot_runtime import shared as _shared

globals().update({name: value for name, value in vars(_shared).items() if not name.startswith("__")})

_feature_modules = [import_module(f"bot_runtime.{name}") for name in FEATURE_MODULES]
_feature_exports: dict[str, object] = {}
for _module in _feature_modules:
    for _name in getattr(_module, "__feature_exports__", ()):
        if _name in _feature_exports:
            raise RuntimeError(f"duplicate Telegram feature export: {_name}")
        _feature_exports[_name] = getattr(_module, _name)

globals().update(_feature_exports)

# Function bodies resolve global names in their owner module. Injecting the
# complete export map after all modules are imported preserves cross-feature
# calls while each definition retains a single physical owner.
_shared_runtime = {name: value for name, value in vars(_shared).items() if not name.startswith("__")}
for _module in _feature_modules:
    _module.__dict__.update(_shared_runtime)
    _module.__dict__.update(_feature_exports)

__all__ = sorted(_feature_exports)
'''
    SOURCE.write_text(facade, encoding="utf-8")
    manifest = {
        "source_functions": len(definitions),
        "modules": {name: sum(1 for owner in ownership.values() if owner == name) for name in module_names},
        "ownership": ownership,
    }
    (PACKAGE / "manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2, sort_keys=True), encoding="utf-8")
    print(json.dumps({"functions": len(definitions), "modules": len(module_names)}, ensure_ascii=False))


if __name__ == "__main__":
    main()
