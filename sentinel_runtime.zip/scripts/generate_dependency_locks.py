#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import importlib.metadata
import json
import os
import subprocess  # nosec B404
import sys
from datetime import UTC, datetime
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
EXPECTED_TOOLCHAIN = {
    "pip": "25.1.1",
    "setuptools": "80.9.0",
    "wheel": "0.45.1",
    "pip-tools": "7.6.1",
}


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def _run(args: list[str]) -> None:
    env = os.environ.copy()
    env.setdefault("PIP_DEFAULT_TIMEOUT", "30")
    env.setdefault("PIP_RETRIES", "3")
    subprocess.run(args, cwd=ROOT, env=env, check=True, timeout=900)  # nosec B603


def main() -> int:
    parser = argparse.ArgumentParser(description="Generate deterministic Python 3.12 dependency locks with hashes.")
    parser.add_argument("--allow-non-312", action="store_true", help="Only for maintaining the generator itself; never for release.")
    args = parser.parse_args()
    version = sys.version_info
    if (version.major, version.minor) != (3, 12) and not args.allow_non_312:
        raise RuntimeError("dependency locks must be generated with CPython 3.12")
    actual_toolchain: dict[str, str] = {}
    for package, expected in EXPECTED_TOOLCHAIN.items():
        try:
            actual = importlib.metadata.version(package)
        except importlib.metadata.PackageNotFoundError as exc:
            raise RuntimeError(f"{package}=={expected} must be installed before generating locks") from exc
        actual_toolchain[package] = actual
        if actual != expected:
            raise RuntimeError(
                f"dependency lock toolchain mismatch for {package}: expected {expected}, got {actual}"
            )
    pip_tools_version = actual_toolchain["pip-tools"]

    common = [
        sys.executable, "-m", "piptools", "compile",
        "--resolver=backtracking", "--generate-hashes", "--strip-extras",
        "--allow-unsafe", "--no-emit-index-url", "--no-emit-trusted-host",
    ]
    _run([*common, "--output-file=requirements.lock.txt", "requirements.in"])
    _run([*common, "--constraint=requirements.lock.txt", "--output-file=requirements-dev.lock.txt", "requirements-dev.in"])
    status = {
        "schema_version": 2,
        "python_target": "3.12",
        "python_runtime": platform_python(),
        "complete_transitive_lock": True,
        "hashes_required": True,
        "generated_by": f"pip-tools=={pip_tools_version}",
        "toolchain": actual_toolchain,
        "generated_at": datetime.now(UTC).isoformat(),
        "production_lock_sha256": _sha(ROOT / "requirements.lock.txt"),
        "development_lock_sha256": _sha(ROOT / "requirements-dev.lock.txt"),
    }
    (ROOT / "DEPENDENCY_LOCK_STATUS.json").write_text(
        json.dumps(status, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    _run([sys.executable, "scripts/verify_dependency_lock.py", "--require-hashes"])
    print(json.dumps(status, ensure_ascii=False))
    return 0


def platform_python() -> str:
    return f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}"


if __name__ == "__main__":
    raise SystemExit(main())
