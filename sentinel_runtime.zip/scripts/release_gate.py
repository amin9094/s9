#!/usr/bin/env python3
from __future__ import annotations

import argparse
import hashlib
import json
import re
import sys
import zipfile
from pathlib import Path
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from scripts.quality_utils import production_acceptance_errors, source_fingerprint


def fail(message: str) -> None:
    raise RuntimeError(message)


def _validate_seed() -> None:
    seed = json.loads((ROOT / "data/database.json").read_text(encoding="utf-8"))
    empty_sections: dict[str, dict[str, Any] | list[Any]] = {"users": {}, "vip_users": {}, "vip_orders": [], "signals": [], "tickets": []}
    for key, empty in empty_sections.items():
        if seed.get(key) != empty:
            fail(f"release seed contains mutable data in {key}")


def _validate_runtime() -> str:
    bundle = ROOT / "sentinel_runtime.zip"
    checksum_file = ROOT / "sentinel_runtime.zip.sha256"
    if not bundle.is_file() or not checksum_file.is_file():
        fail("runtime fallback bundle/checksum is missing")
    forbidden_suffixes = (".sqlite", ".sqlite3", ".db", ".pyc", ".pyo")
    forbidden_names = {".env", ".env.local", "data/heartbeat.json", "data/metrics.json"}
    with zipfile.ZipFile(bundle) as archive:
        members = [name.replace("\\", "/") for name in archive.namelist()]
        leaked = sorted(
            name for name in members
            if name in forbidden_names or name.lower().endswith(forbidden_suffixes) or "/__pycache__/" in f"/{name}"
        )
        if leaked:
            fail(f"runtime or secret file must not ship: {', '.join(leaked[:10])}")
        required = {
            "main.py", "bot.py", "bot_runtime/shared.py", "core/miniapp_server.py",
            "repositories/v2/positions.py", "services/actions_v2/registry.py",
            "webapp/index.html", "scripts/ops/dr_drill.py", "scripts/ops/load_smoke.py",
            "scripts/docker-entrypoint.sh", "scripts/predeploy_migrate.py",
            "pytest.ini", "pyproject.toml", "requirements-dev.lock.txt", "tests/conftest.py",
            "RUNTIME_BUNDLE_CONTRACT.json",
        }
        missing = sorted(required - set(members))
        if missing:
            fail(f"runtime bundle is missing required members: {', '.join(missing)}")
        contract = json.loads(archive.read("RUNTIME_BUNDLE_CONTRACT.json").decode("utf-8"))
        excluded = set(contract.get("excluded_outer_only_tests") or [])
        leaked_outer_tests = sorted(excluded.intersection(members))
        if leaked_outer_tests:
            fail(f"runtime bundle ships outer-only tests: {', '.join(leaked_outer_tests)}")
        bundled_tests = sorted(name for name in members if name.startswith("tests/test_") and name.endswith(".py"))
        if len(bundled_tests) < 40:
            fail(f"runtime bundle contains only {len(bundled_tests)} pytest modules; expected at least 40")
        broken = archive.testzip()
        if broken:
            fail(f"runtime bundle is corrupt at {broken}")
    expected = checksum_file.read_text(encoding="utf-8").split()[0].strip().lower()
    actual = hashlib.sha256(bundle.read_bytes()).hexdigest()
    if expected != actual:
        fail("runtime fallback checksum mismatch")
    return actual


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--production", action="store_true")
    parser.add_argument("--container-quality", action="store_true")
    args = parser.parse_args()

    _validate_seed()
    runtime_digest = _validate_runtime()
    version = (ROOT / "VERSION").read_text(encoding="utf-8").strip()
    if not version:
        fail("VERSION is empty")
    proof_path = ROOT / "QUALITY_PROOF.json"
    manifest_path = ROOT / "RELEASE_MANIFEST.json"
    if not proof_path.is_file() or not manifest_path.is_file():
        fail("quality proof or release manifest is missing")
    proof = json.loads(proof_path.read_text(encoding="utf-8"))
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if str(proof.get("version") or "") != version or str(manifest.get("version") or "") != version:
        fail("quality proof or manifest version mismatch")
    current_source = source_fingerprint(ROOT)
    if str(proof.get("source_sha256") or "") != current_source:
        fail("release source differs from the quality-tested source")
    validations = proof.get("validation") if isinstance(proof.get("validation"), dict) else {}
    if not validations or not all(bool(value) for value in validations.values()):
        fail("quality proof contains a failed validation")
    if str(manifest.get("quality_proof_source_sha256") or "") != current_source:
        fail("release manifest is not bound to the quality proof")
    if str(manifest.get("runtime_sha256") or "") != runtime_digest:
        fail("release manifest runtime digest mismatch")

    deferred = proof.get("deferred_validation") if isinstance(proof.get("deferred_validation"), dict) else {}
    channel = str(proof.get("release_channel") or "candidate")
    if args.production:
        lock_status = json.loads((ROOT / "DEPENDENCY_LOCK_STATUS.json").read_text(encoding="utf-8"))
        if not lock_status.get("complete_transitive_lock") or not lock_status.get("hashes_required"):
            fail("production release requires a complete transitive hash lock")
        if channel != "production":
            fail("production release requires a production quality proof")
        if deferred:
            fail("production release cannot contain deferred validation")
        if not str(proof.get("commit_sha") or "").strip() or proof.get("commit_sha") == "unavailable":
            fail("production release requires commit SHA")
        if not re.fullmatch(r"sha256:[0-9a-f]{64}", str(proof.get("docker_image_digest") or "")):
            fail("production release requires Docker image digest")
        try:
            acceptance = json.loads((ROOT / "quality-artifacts/production_acceptance.json").read_text(encoding="utf-8"))
        except (OSError, ValueError):
            acceptance = {}
        errors = production_acceptance_errors(
            acceptance, version=version, source_sha256=current_source,
            image_digest=str(proof.get("docker_image_digest") or ""),
        )
        if errors:
            fail("; ".join(errors))
    elif args.container_quality:
        # All Docker quality commands are chained before this gate. Reaching
        # this mode proves they passed while still allowing a candidate proof
        # to be turned into a production attestation after the image digest is known.
        markers = (
            ROOT / "quality-artifacts" / "junit.xml",
            ROOT / "artifacts" / "junit.xml",
        )
        if not any(marker.is_file() for marker in markers):
            fail("container quality artifacts are missing")
    print(
        f"RELEASE GATE OK: SENTINEL {version}; channel={channel}; "
        f"runtime_sha256={runtime_digest}; deferred={len(deferred)}"
    )
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"RELEASE GATE FAILED: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
