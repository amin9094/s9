"""Database constraints and append-only evidence for the existing economy.

Called inside the canonical store's committing transaction, never via a second
connection. A failure rolls back balances, attribution and evidence together.
"""
from __future__ import annotations

import json


DDL = (
    "CREATE TABLE IF NOT EXISTS economy_referral_codes (user_id TEXT PRIMARY KEY, code TEXT NOT NULL UNIQUE)",
    "CREATE TABLE IF NOT EXISTS economy_referral_attribution (referred_user TEXT PRIMARY KEY, referrer TEXT NOT NULL, created_at TEXT NOT NULL, CHECK(referred_user <> referrer))",
    "CREATE TABLE IF NOT EXISTS economy_ledger (source TEXT NOT NULL, user_id TEXT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(source,user_id))",
    "CREATE TABLE IF NOT EXISTS signal_deletion_audit (signal_id TEXT PRIMARY KEY, deleted_by TEXT NOT NULL, deleted_at TEXT NOT NULL)",
)


def create_schema(cursor):
    for statement in DDL:
        cursor.execute(statement)


def project_constraints(cursor, before, after, *, postgres=False):
    def execute(sql, params):
        cursor.execute(sql.replace('?', '%s') if postgres else sql, params)
        return cursor

    # Privacy deletion can replace an identity by its permanent pseudonym,
    # but can never transfer attribution to another live user.
    privacy_aliases = {}
    for uid, request in after.get('privacy_requests', {}).items():
        if (request.get('status') == 'completed'
                and before.get('privacy_requests', {}).get(uid, {}).get('status') != 'completed'
                and uid not in after.get('users', {})
                and str(request.get('pseudonym', '')).startswith('deleted:')):
            privacy_aliases[str(uid)] = str(request['pseudonym'])
    for uid, pseudonym in privacy_aliases.items():
        execute('UPDATE economy_referral_attribution SET referrer=? WHERE referrer=?', (pseudonym, uid))
        execute('DELETE FROM economy_referral_codes WHERE user_id=?', (uid,))

    tombstones = after.get('signal_deletion_audit', {})
    new_tombstones = {k: v for k, v in tombstones.items() if k not in before.get('signal_deletion_audit', {})}
    if new_tombstones:
        cursor.execute("SELECT to_regclass('v8_signals')" if postgres else "SELECT name FROM sqlite_master WHERE type='table' AND name='v8_signals'")
        table = cursor.fetchone()
        normalized_exists = bool(table and table[0])
        for key, row in new_tombstones.items():
            execute('INSERT INTO signal_deletion_audit(signal_id,deleted_by,deleted_at) VALUES(?,?,?) ON CONFLICT(signal_id) DO NOTHING', (str(key), str(row['deleted_by']), row['deleted_at']))
            if normalized_exists:
                for statement in (
                    'DELETE FROM v8_signal_outcomes WHERE signal_id=?',
                    'DELETE FROM v8_signal_revisions WHERE signal_id=?',
                    'DELETE FROM v8_signals WHERE id=?',
                ):
                    execute(statement, (str(key),))
        if normalized_exists:
            for row in [*after.get('signals', []), *after.get('signal_archive', [])]:
                if isinstance(row, dict):
                    execute('UPDATE v8_signals SET display_number=? WHERE id=?', (int(row.get('display_number') or row['id']), str(row['id'])))

    if before.get('user_referrals') != after.get('user_referrals'):
        for uid, row in after.get('user_referrals', {}).items():
            code = str(row.get('code') or '').upper()
            if not code:
                continue
            execute('INSERT INTO economy_referral_codes(user_id,code) VALUES(?,?) ON CONFLICT(user_id) DO NOTHING', (str(uid), code))
            found = execute('SELECT code FROM economy_referral_codes WHERE user_id=?', (str(uid),)).fetchone()
            if str(found[0]) != code:
                raise ValueError('REFERRAL_CODE_IMMUTABLE')
    if before.get('users') != after.get('users'):
        for uid, user in after.get('users', {}).items():
            referrer = str(user.get('referred_by') or '')
            old = str(before.get('users', {}).get(uid, {}).get('referred_by') or '')
            if old and referrer != old and privacy_aliases.get(old) != referrer:
                raise ValueError('REFERRAL_ATTRIBUTION_IMMUTABLE')
            if not referrer:
                continue
            execute('INSERT INTO economy_referral_attribution(referred_user,referrer,created_at) VALUES(?,?,?) ON CONFLICT(referred_user) DO NOTHING', (str(uid), referrer, str(user.get('referred_at') or user.get('created_at') or 'legacy')))
            found = execute('SELECT referrer FROM economy_referral_attribution WHERE referred_user=?', (str(uid),)).fetchone()
            if str(found[0]) != referrer:
                raise ValueError('REFERRAL_ATTRIBUTION_IMMUTABLE')
    if before.get('point_history') != after.get('point_history'):
        previous_rows = {str(row.get('id')): row for row in before.get('point_history', [])}
        current_rows = {str(row.get('id')): row for row in after.get('point_history', [])}
        for key, old in previous_rows.items():
            current = current_rows.get(key)
            if current == old:
                continue
            # Privacy may pseudonymize identity, never change economic evidence.
            expected = dict(old)
            alias = privacy_aliases.get(str(old.get('user_id')))
            if alias:
                expected['user_id'] = alias
                expected.pop('privacy_anonymized_at', None)
                current = dict(current or {})
                current.pop('privacy_anonymized_at', None)
            if current != expected:
                raise ValueError('POINT_LEDGER_IMMUTABLE')
        previous = set(previous_rows)
        for row in after.get('point_history', []):
            if str(row.get('id')) in previous:
                continue
            source = str(row.get('source_event') or f"points:{row['id']}")
            payload = json.dumps(row, sort_keys=True, ensure_ascii=False, separators=(',', ':'))
            # A duplicate explicit source with a new balance mutation must fail,
            # even if an upstream caller forgot its idempotency check.
            execute('INSERT INTO economy_ledger(source,user_id,payload) VALUES(?,?,?)', (source, str(row['user_id']), payload))
    if set(before.get('economic_events', {})) - set(after.get('economic_events', {})):
        raise ValueError('ECONOMY_EVENT_IMMUTABLE')
    for key, event in after.get('economic_events', {}).items():
        old = before.get('economic_events', {}).get(key)
        if old is not None:
            if old != event:
                raise ValueError('ECONOMY_EVENT_IMMUTABLE')
            continue
        execute('INSERT INTO economy_ledger(source,user_id,payload) VALUES(?,?,?)',
                (str(key), str(event['user_id']), json.dumps(event, sort_keys=True, ensure_ascii=False)))

    # Refund evidence and normalized projections share this committing cursor.
    # This avoids a successful entitlement clawback followed by a failed ledger.
    new_events=[e for key,e in after.get('economic_events',{}).items() if key not in before.get('economic_events',{})]
    from core.membership_bridge import _table_exists
    for event in new_events:
        meta=event.get('metadata',{})
        if event.get('kind')=='order_refund' and meta.get('normalized'):
            oid=str(meta['order_id'])
            row=execute('SELECT status,updated_at,payload FROM v8_vip_orders WHERE id=?',(oid,)).fetchone()
            if not row or row[0]!='approved' or str(row[1])!=str(meta.get('order_updated_at')):
                from core.db import ConcurrentDatabaseUpdate
                raise ConcurrentDatabaseUpdate('order changed during refund')
            payload=json.loads(row[2]);payload.update(meta['refund']);payload['updated_at']=event['timestamp']
            execute('UPDATE v8_vip_orders SET updated_at=?,payload=? WHERE id=?',
                    (event['timestamp'],json.dumps(payload,ensure_ascii=False),oid))
        if event.get('kind')=='vip_reversal' and _table_exists(cursor,postgres,'v8_vip_entitlements'):
            uid=str(event['user_id'])
            row=execute('SELECT payload FROM v8_vip_entitlements WHERE user_id=?',(uid,)).fetchone()
            if row:
                payload=json.loads(row[0]);payload.update(status=meta['status'],expires_at=meta['expires_at'])
                execute('UPDATE v8_vip_entitlements SET status=?,expires_at=?,updated_at=?,payload=? WHERE user_id=?',
                        (meta['status'],meta['expires_at'],event['timestamp'],json.dumps(payload,ensure_ascii=False),uid))


def economic_event(db, source, user_id, *, kind, value, actor='system', reason='', metadata=None):
    from core.utils import utc_iso
    key = str(source)
    rows = db.setdefault('economic_events', {})
    old = rows.get(key)
    if old:
        if str(old['user_id']) != str(user_id) or old['kind'] != kind or old['value'] != value:
            raise ValueError('ECONOMY_SOURCE_CONFLICT')
        return False
    rows[key] = {'source': key, 'user_id': str(user_id), 'kind': kind, 'value': value,
                 'actor': str(actor), 'reason': reason, 'timestamp': utc_iso(),
                 'status': 'applied', 'reversal': None, 'metadata': metadata or {}}
    return True


def approved_purchase(db, order_id, user_id=None):
    """Resolve status, owner and amount from the server's authoritative order."""
    key = str(order_id)
    row = next((r for r in db.get('vip_orders', []) if str(r.get('order_id')) == key), None)
    if row is None:
        from repositories.v2.commerce import CommerceRepository
        row = CommerceRepository().get(key)
    if not row or row.get('status') != 'approved' or row.get('refund_status') == 'full' or f'order_refund:{key}:full' in db.get('economic_events',{}):
        raise ValueError('APPROVED_ORDER_REQUIRED')
    if user_id is not None and str(row.get('user_id')) != str(user_id):
        raise ValueError('PAYMENT_OWNER_MISMATCH')
    return dict(row)


def verified_referral_activity(db, referrer):
    """Use attribution and approved orders, never cached invitation counters."""
    uid = str(referrer)
    from modules.referral_review import is_qualified
    qualified = {str(key) for key, user in db.get('users', {}).items()
                 if str(user.get('referred_by') or '') == uid and str(key) != uid
                 and not user.get('blocked') and not user.get('banned') and is_qualified(db, key)}
    events = db.get('economic_events', {})
    reversed_sources = {e.get('metadata', {}).get('original_source') for e in events.values()
                        if e.get('kind') == 'referral_purchase_reversal'}
    orders = {str(row.get('order_id') or row.get('id')): row for row in db.get('vip_orders', [])}
    purchases = {}
    for key, row in orders.items():
        if (row.get('status') == 'approved' and row.get('refund_status') != 'full'
                and str(row.get('user_id')) in qualified and f'referral_purchase:{key}' not in reversed_sources):
            purchases[key] = (str(row['user_id']), max(0, int(row.get('amount_toman', row.get('price', 0)) or 0)))
    for source, event in events.items():
        if source in reversed_sources or event.get('kind') != 'verified_purchase' or str(event.get('user_id')) != uid:
            continue
        metadata = event.get('metadata', {})
        referred = str(metadata.get('referred_user'))
        key = str(metadata.get('payment_id'))
        row = orders.get(key)
        if row and (row.get('status') != 'approved' or row.get('refund_status') == 'full'):
            continue
        if referred in qualified:
            purchases[key] = (referred, max(0, int(event['value'])))
    return qualified, purchases
