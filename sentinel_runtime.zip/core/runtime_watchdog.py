from __future__ import annotations

import json
import logging
import os
import threading
import time
from collections.abc import Callable
from datetime import UTC, datetime
from pathlib import Path

logger = logging.getLogger(__name__)

_LOCK = threading.Lock()
_THREAD: threading.Thread | None = None
_STOP = threading.Event()


def _bounded_probe(callback, *, timeout: float):
    """Observe locks and mounted files without waiting indefinitely on them."""
    result = {}

    def probe():
        try:
            result["value"] = callback()
        except BaseException as exc:
            result["error"] = exc

    thread = threading.Thread(target=probe, name="sentinel-watchdog-probe", daemon=True)
    thread.start()
    thread.join(timeout=timeout)
    if thread.is_alive():
        raise TimeoutError("watchdog probe did not return")
    if "error" in result:
        raise result["error"]
    return result["value"]


def _bounded_log(level: int, message: str, *args) -> None:
    # Logging handlers can themselves be stuck on a mounted filesystem.
    try:
        thread = threading.Thread(target=lambda: logger.log(level, message, *args),
                                  name="sentinel-watchdog-log", daemon=True)
        thread.start()
        thread.join(timeout=0.1)
    except Exception:
        return


class DeliveryProgressWatch:
    """Detect stalled work independently of scheduler/heartbeat success."""

    def __init__(self, stall_seconds: float = 180) -> None:
        self.stall_seconds = max(30, float(stall_seconds))
        self.last_progress = None
        self.waiting_since = None

    def check(self, probe: dict, now: float) -> str | None:
        pending = max(0, int(probe.get('pending', 0)))
        progress = probe.get('completed', 0)
        if not pending or progress != self.last_progress:
            self.waiting_since = now if pending else None
        elif self.waiting_since is None:
            self.waiting_since = now
        self.last_progress = progress
        if not probe.get('processor_healthy', True):
            return 'telegram-update-processor-stalled'
        if pending and self.waiting_since is not None and now - self.waiting_since >= self.stall_seconds:
            return f'telegram-delivery-no-progress:{pending}'
        return None


def _truthy(name: str, default: bool = False) -> bool:
    raw = str(os.getenv(name, "true" if default else "false")).strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _heartbeat_age_seconds(path: Path) -> float | None:
    try:
        raw = json.loads(path.read_text(encoding="utf-8"))
        timestamp = datetime.fromisoformat(
            str(raw.get("updated_at") or raw.get("timestamp") or "").replace("Z", "+00:00")
        )
        if timestamp.tzinfo is None:
            timestamp = timestamp.replace(tzinfo=UTC)
        return max(0.0, (datetime.now(UTC) - timestamp.astimezone(UTC)).total_seconds())
    except (OSError, ValueError, TypeError, json.JSONDecodeError):
        return None


def _terminate_for_recovery(reason: str) -> None:
    """Force a non-zero process exit so the platform restart policy can recover it.

    ``os._exit`` is intentional: this watchdog lives outside the asyncio event
    loop specifically so it can recover a process whose loop is deadlocked and
    therefore cannot execute normal shutdown callbacks.
    """
    _bounded_log(logging.CRITICAL, "Runtime watchdog forcing process restart: %s", reason)
    os._exit(70)  # noqa: PLW1510 -- intentional hard recovery from a deadlocked runtime


def _persist_recovery_evidence(reason: str) -> None:
    """Metrics lock/filesystem failure must not prevent the recovery exit."""
    def save() -> None:
        try:
            from core.observability import record_error, persist
            record_error("runtime_watchdog", reason)
            persist()
        except Exception:
            logger.exception("Watchdog evidence could not be persisted")

    thread = threading.Thread(target=save, name="sentinel-watchdog-evidence", daemon=True)
    try:
        thread.start()
        thread.join(timeout=1)
    except Exception:
        return


def start_runtime_watchdog(
    *,
    heartbeat_file: Path,
    heartbeat_max_age_seconds: int,
    application_running: Callable[[], bool],
    health_server_required: bool = True,
    delivery_probe: Callable[[], dict] | None = None,
) -> None:
    global _THREAD, _STOP
    if not _truthy("RUNTIME_WATCHDOG_ENABLED", True):
        logger.info("Runtime watchdog disabled by RUNTIME_WATCHDOG_ENABLED")
        return
    with _LOCK:
        if _THREAD is not None and _THREAD.is_alive():
            return
        # A stopped worker may still be exiting a probe. Each launch owns its
        # stop event so a later launch can never revive the previous worker.
        stop = threading.Event()
        _STOP = stop
        interval = max(5.0, min(60.0, float(os.getenv("RUNTIME_WATCHDOG_INTERVAL_SECONDS", "15") or 15)))
        grace = max(30.0, min(900.0, float(os.getenv("RUNTIME_WATCHDOG_STARTUP_GRACE_SECONDS", "180") or 180)))
        max_age = max(
            45.0,
            float(heartbeat_max_age_seconds),
            float(os.getenv("RUNTIME_WATCHDOG_HEARTBEAT_MAX_AGE_SECONDS", "180") or 180),
        )
        failure_limit = max(2, min(10, int(os.getenv("RUNTIME_WATCHDOG_FAILURE_LIMIT", "3") or 3)))
        started_at = time.monotonic()
        delivery_watch = DeliveryProgressWatch(float(os.getenv('RUNTIME_WATCHDOG_DELIVERY_STALL_SECONDS', '180')))

        def collect_reasons() -> list[str]:
            reasons: list[str] = []
            try:
                app_running = bool(application_running())
            except Exception as exc:  # defensive: watchdog must never die silently
                app_running = False
                reasons.append(f"application-state-error:{exc.__class__.__name__}")
            if not app_running:
                reasons.append("telegram-application-not-running")
            if delivery_probe is not None:
                try:
                    reason = delivery_watch.check(delivery_probe(), time.monotonic())
                    if reason:
                        reasons.append(reason)
                except Exception as exc:
                    reasons.append(f'delivery-probe-error:{exc.__class__.__name__}')

            try:
                from core.miniapp_server import is_running as health_server_running
                if health_server_required and not health_server_running():
                    reasons.append("health-server-thread-not-running")
            except Exception as exc:
                reasons.append(f"health-server-state-error:{exc.__class__.__name__}")

            # A timed-out Python caller cannot stop its underlying thread. Monitor
            # global admission independently, even if Telegram tasks complete.
            try:
                from core.async_runtime import blocking_executor_snapshot
                pool = blocking_executor_snapshot()
                max_blocked = max(120.0, float(os.getenv("BLOCKING_IO_WATCHDOG_MAX_AGE_SECONDS", "240")))
                if pool["outstanding"] >= pool["capacity"] and pool["oldest_seconds"] > max_blocked:
                    reasons.append("blocking-executor-saturated")
            except Exception as exc:
                reasons.append(f"blocking-executor-probe-error:{exc.__class__.__name__}")
            age = _heartbeat_age_seconds(Path(heartbeat_file))
            if age is None:
                reasons.append("heartbeat-missing-or-invalid")
            elif age > max_age:
                reasons.append(f"heartbeat-stale:{age:.1f}s>{max_age:.1f}s")
            return reasons

        def worker() -> None:
            consecutive_failures = 0
            while not stop.wait(interval):
                if time.monotonic() - started_at < grace:
                    continue
                try:
                    reasons = _bounded_probe(collect_reasons, timeout=5)
                except BaseException as exc:
                    reasons = [f"watchdog-probe-failed:{exc.__class__.__name__}"]

                if reasons:
                    consecutive_failures += 1
                    _bounded_log(logging.ERROR,
                        "Runtime watchdog unhealthy pass %s/%s: %s",
                        consecutive_failures,
                        failure_limit,
                        ", ".join(reasons),
                    )
                    if consecutive_failures >= failure_limit:
                        _persist_recovery_evidence(";".join(reasons))
                        _terminate_for_recovery(";".join(reasons))
                else:
                    if consecutive_failures:
                        _bounded_log(logging.INFO, "Runtime watchdog recovered after %s unhealthy pass(es)", consecutive_failures)
                    consecutive_failures = 0

        _THREAD = threading.Thread(target=worker, name="sentinel-runtime-watchdog", daemon=True)
        _THREAD.start()
        _bounded_log(logging.INFO,
            "Runtime watchdog started interval=%ss grace=%ss heartbeat_max_age=%ss failure_limit=%s",
            interval,
            grace,
            max_age,
            failure_limit,
        )


def stop_runtime_watchdog() -> None:
    global _THREAD
    with _LOCK:
        thread = _THREAD
        _THREAD = None
        _STOP.set()
    if thread is not None and thread is not threading.current_thread():
        thread.join(timeout=3)
