from __future__ import annotations

import os
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from config import SETTINGS
from core.storage.engine import DatabaseEngine, normalized_engine


def _cutoff(days: int) -> str:
    return (datetime.now(UTC) - timedelta(days=max(1, int(days)))).isoformat()


def cleanup_normalized_records(engine: DatabaseEngine | None = None) -> dict[str, int]:
    database = engine or normalized_engine()
    audit_days = max(30, min(int(os.getenv("AUDIT_RETENTION_DAYS", "365") or 365), 3650))
    event_days = max(7, min(int(os.getenv("EVENT_RETENTION_DAYS", "90") or 90), 730))
    command_days = max(30, min(int(os.getenv("ADMIN_COMMAND_RETENTION_DAYS", str(audit_days)) or audit_days), 3650))
    deleted = {"audit": 0, "events": 0, "commands": 0, "telegram_updates": 0}
    with database.transaction() as cursor:
        cursor.execute("DELETE FROM v8_audit_log WHERE created_at<?", (_cutoff(audit_days),))
        deleted["audit"] = cursor.rowcount
        cursor.execute("DELETE FROM v8_events WHERE created_at<?", (_cutoff(event_days),))
        deleted["events"] = cursor.rowcount
        cursor.execute(
            "DELETE FROM v8_admin_commands WHERE updated_at<? AND status IN ('completed','failed','cancelled')",
            (_cutoff(command_days),),
        )
        deleted["commands"] = cursor.rowcount
    from core.telegram_update_store import cleanup as cleanup_telegram_updates
    telegram_days = max(1, min(int(os.getenv("TELEGRAM_UPDATE_RETENTION_DAYS", "7") or 7), 365))
    deleted["telegram_updates"] = cleanup_telegram_updates(telegram_days, engine=database)
    return deleted


def cleanup_rotated_logs(log_dir: Path | None = None) -> dict[str, int]:
    root = Path(log_dir or SETTINGS.log_dir).resolve()
    root.mkdir(parents=True, exist_ok=True)
    retention_days = max(1, min(int(os.getenv("LOG_RETENTION_DAYS", "30") or 30), 365))
    cutoff = datetime.now(UTC).timestamp() - retention_days * 86400
    removed = 0
    bytes_removed = 0
    for path in root.glob("*.log.*"):
        try:
            stat = path.stat()
            if stat.st_mtime < cutoff:
                bytes_removed += stat.st_size
                path.unlink()
                removed += 1
        except OSError:
            continue
    return {"removed": removed, "bytes_removed": bytes_removed}


def retention_status() -> dict[str, Any]:
    return {
        "audit_days": max(30, int(os.getenv("AUDIT_RETENTION_DAYS", "365") or 365)),
        "event_days": max(7, int(os.getenv("EVENT_RETENTION_DAYS", "90") or 90)),
        "log_days": max(1, int(os.getenv("LOG_RETENTION_DAYS", "30") or 30)),
        "telegram_update_days": max(1, int(os.getenv("TELEGRAM_UPDATE_RETENTION_DAYS", "7") or 7)),
    }
