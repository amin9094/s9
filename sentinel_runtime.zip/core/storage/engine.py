from __future__ import annotations

import contextlib
import logging
import os
import sqlite3
import threading
import time
import re
import sys
from collections.abc import Iterator, Sequence
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from config import SETTINGS
from core.runtime_topology import replica_count

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class StorageDialect:
    name: str
    json_type: str
    timestamp_type: str
    bool_type: str


SQLITE = StorageDialect("sqlite", "TEXT", "TEXT", "INTEGER")
POSTGRES = StorageDialect("postgres", "JSONB", "TIMESTAMPTZ", "BOOLEAN")


class CursorAdapter:
    """Small qmark-style adapter shared by SQLite and PostgreSQL.

    Repositories use ``?`` placeholders everywhere. PostgreSQL statements are
    translated to ``%s`` at the boundary so business code cannot accidentally
    concatenate user input into SQL.
    """

    def __init__(self, cursor: Any, dialect: StorageDialect):
        self._cursor = cursor
        self.dialect = dialect
        self.modified_tables: set[str] = set()

    def _sql(self, statement: str) -> str:
        if self.dialect.name == "postgres":
            return statement.replace("?", "%s")
        return statement

    @staticmethod
    def _modified_table(statement: str) -> str:
        match = re.match(
            r"\s*(?:INSERT\s+INTO|REPLACE\s+INTO|UPDATE|DELETE\s+FROM)\s+([A-Za-z0-9_]+)",
            str(statement or ""),
            flags=re.IGNORECASE,
        )
        return str(match.group(1)) if match else ""

    def execute(self, statement: str, params: Sequence[Any] | None = None) -> "CursorAdapter":
        self._cursor.execute(self._sql(statement), tuple(params or ()))
        table = self._modified_table(statement)
        if table:
            self.modified_tables.add(table)
        return self

    def executemany(self, statement: str, params: Sequence[Sequence[Any]]) -> "CursorAdapter":
        self._cursor.executemany(self._sql(statement), params)
        table = self._modified_table(statement)
        if table:
            self.modified_tables.add(table)
        return self

    def fetchone(self) -> dict[str, Any] | None:
        row = self._cursor.fetchone()
        if row is None:
            return None
        if isinstance(row, dict):
            return dict(row)
        if hasattr(row, "keys"):
            return {key: row[key] for key in row.keys()}
        description = self._cursor.description or ()
        return {str(column[0]): value for column, value in zip(description, row, strict=False)}

    def fetchall(self) -> list[dict[str, Any]]:
        rows = self._cursor.fetchall()
        if not rows:
            return []
        if isinstance(rows[0], dict):
            return [dict(row) for row in rows]
        if hasattr(rows[0], "keys"):
            return [{key: row[key] for key in row.keys()} for row in rows]
        description = self._cursor.description or ()
        names = [str(column[0]) for column in description]
        return [dict(zip(names, row, strict=False)) for row in rows]

    @property
    def rowcount(self) -> int:
        return int(self._cursor.rowcount or 0)

    @property
    def lastrowid(self) -> int | None:
        value = getattr(self._cursor, "lastrowid", None)
        return int(value) if value is not None else None


class DatabaseEngine:
    """Independent row-level storage engine for the v8 runtime.

    It deliberately does not use ``core.db.with_db``. Mini App writes therefore
    do not materialize the legacy application state, do not acquire the global
    ``state_version`` lock and do not rewrite unrelated business domains.
    """

    def __init__(self, *, database_url: str | None = None, sqlite_path: Path | None = None):
        self.database_url = str(database_url if database_url is not None else SETTINGS.database_url).strip()
        self._primary_database_url = self.database_url
        self.sqlite_path = Path(sqlite_path or SETTINGS.db_file).resolve()
        self.dialect = POSTGRES if self.database_url else SQLITE
        self._google_failover_active = False
        self._google_failover_reason = ""
        self._google_failover_base_checksum = ""
        self._google_failover_last_reconcile_at = 0.0
        self._schema_lock = threading.Lock()
        self._schema_ready = False
        self._pool_lock = threading.Lock()
        self._pool: Any | None = None
        self._unit_of_work = threading.local()

    @contextlib.contextmanager
    def atomic(self) -> Iterator[CursorAdapter]:
        """Share one commit boundary across synchronous repository operations."""
        existing = getattr(self._unit_of_work, "cursor", None)
        if existing is not None:
            try:
                yield existing
            except BaseException:
                self._unit_of_work.rollback_only = True
                raise
            return
        with self.transaction() as cursor:
            self._unit_of_work.cursor = cursor
            self._unit_of_work.rollback_only = False
            try:
                yield cursor
                if self._unit_of_work.rollback_only:
                    raise RuntimeError("ATOMIC_OPERATION_ABORTED")
            finally:
                del self._unit_of_work.cursor
                del self._unit_of_work.rollback_only

    def _sqlite_connection(self) -> sqlite3.Connection:
        self.sqlite_path.parent.mkdir(parents=True, exist_ok=True)
        connection = sqlite3.connect(
            self.sqlite_path,
            timeout=30,
            isolation_level=None,
            check_same_thread=False,
        )
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA busy_timeout=30000")
            connection.execute("PRAGMA synchronous=NORMAL")
            return connection
        except BaseException:
            connection.close()
            raise

    def _postgres_connection(self) -> Any:
        """Return a dedicated connection for session-scoped operations.

        Normal repository transactions use the bounded pool below. Dedicated
        connections are reserved for operations such as PostgreSQL advisory
        locks whose lifetime must span a complete session.
        """
        import psycopg
        from psycopg.rows import dict_row
        from core.postgres_runtime import connection_kwargs, normalize_database_url
        return psycopg.connect(
            normalize_database_url(self.database_url),
            row_factory=dict_row,
            **connection_kwargs(autocommit=False, application_name='sentinel-migration'),
        )

    def _postgres_pool(self) -> Any:
        if self._pool is not None:
            return self._pool
        with self._pool_lock:
            if self._pool is not None:
                return self._pool
            from psycopg.rows import dict_row
            from psycopg_pool import ConnectionPool

            from core.postgres_runtime import connection_kwargs, normalize_database_url, pool_policy
            self._pool = ConnectionPool(
                conninfo=normalize_database_url(self.database_url),
                **pool_policy(),
                open=True,
                kwargs={
                    "row_factory": dict_row,
                    **connection_kwargs(autocommit=False, application_name='sentinel-normalized'),
                },
                check=ConnectionPool.check_connection,
                name="sentinel-v8",
            )
            return self._pool

    def connect(self) -> Any:
        return self._postgres_connection() if self.dialect.name == "postgres" else self._sqlite_connection()

    @staticmethod
    def _is_primary_connectivity_error(error: BaseException) -> bool:
        """Return True only for failures that mean PostgreSQL is unreachable.

        SQL/programming errors and pool saturation must never switch the write
        backend to Google/SQLite because doing so can hide a code defect or
        create split-brain writes.
        """
        current: BaseException | None = error
        seen: set[int] = set()
        while current is not None and id(current) not in seen:
            seen.add(id(current))
            if isinstance(current, (ConnectionError, TimeoutError, OSError)):
                return True
            module = current.__class__.__module__
            name = current.__class__.__name__
            if module.startswith("psycopg") and name in {
                "OperationalError", "InterfaceError", "ConnectionTimeout", "ConnectionException"
            }:
                return True
            if name == "PoolTimeout":
                return False
            current = current.__cause__ or current.__context__
        return False

    @staticmethod
    def _failover_storage_is_durable(path: Path) -> bool:
        if not os.getenv("RAILWAY_ENVIRONMENT"):
            return True
        mount_raw = (
            os.getenv("PERSISTENT_DATA_DIR")
            or os.getenv("RAILWAY_VOLUME_MOUNT_PATH")
            or os.getenv("VOLUME_MOUNT_PATH")
            or ""
        ).strip()
        if not mount_raw:
            return False
        try:
            path.resolve().relative_to(Path(mount_raw).resolve())
            return True
        except ValueError:
            return False

    def _activate_google_failover(self, primary_error: BaseException) -> bool:
        if self._google_failover_active or not self._primary_database_url:
            return self._google_failover_active
        replicas = replica_count()
        allow_multi = str(os.getenv("ALLOW_MULTI_REPLICA_GOOGLE_WRITE_FAILOVER", "")).strip().lower() in {"1", "true", "yes", "on"}
        if replicas > 1 and not allow_multi:
            logger.critical(
                "Refusing normalized writable Google failover with %s replicas to prevent split-brain writes",
                replicas,
            )
            return False
        if not self._is_primary_connectivity_error(primary_error):
            logger.error(
                "Refusing Google failover for non-connectivity database error: %s",
                primary_error.__class__.__name__,
            )
            return False
        try:
            from core import google_sheets_backup
            cfg = google_sheets_backup.config()
            if not google_sheets_backup.is_configured() or not cfg.write_failover:
                return False
            if not self._failover_storage_is_durable(Path(SETTINGS.backup_dir)):
                logger.critical(
                    "Refusing writable Google failover because BACKUP_DIR is not on a persistent Railway Volume"
                )
                return False
            failover_path = google_sheets_backup.build_normalized_failover_sqlite()
            base_checksum = google_sheets_backup.normalized_failover_base_checksum(failover_path)
            if not base_checksum:
                raise RuntimeError("normalized Google failover snapshot is missing its base checksum")
        except Exception:
            logger.exception("Normalized Google Sheets failover activation failed")
            return False
        self.close()
        self.database_url = ""
        self.sqlite_path = Path(failover_path).resolve()
        self.dialect = SQLITE
        self._schema_ready = True
        self._google_failover_active = True
        self._google_failover_base_checksum = base_checksum
        self._google_failover_last_reconcile_at = 0.0
        self._google_failover_reason = f"{primary_error.__class__.__name__}:{str(primary_error)[:500]}"
        logger.critical(
            "Normalized v8 primary database unavailable; switched to Google Sheets restored SQLite failover: %s",
            self._google_failover_reason,
        )
        return True

    @property
    def google_failover_active(self) -> bool:
        return bool(self._google_failover_active)

    @property
    def google_failover_reason(self) -> str:
        return self._google_failover_reason

    def reconcile_google_failover(self) -> dict[str, Any]:
        """Safely write failover changes back only if primary did not diverge."""
        if not self._google_failover_active or not self._primary_database_url:
            return {"active": False, "status": "not_active"}
        interval = max(30.0, min(900.0, float(os.getenv("GOOGLE_SHEETS_RECONCILE_INTERVAL_SECONDS", "60") or 60)))
        now = time.monotonic()
        if now - self._google_failover_last_reconcile_at < interval:
            return {"active": True, "status": "backoff"}
        self._google_failover_last_reconcile_at = now
        from core import google_sheets_backup
        if not google_sheets_backup.config().auto_reconcile:
            return {"active": True, "status": "auto_reconcile_disabled"}

        primary = DatabaseEngine(database_url=self._primary_database_url, sqlite_path=self.sqlite_path)
        try:
            primary.ensure_schema()
            primary_snapshot = google_sheets_backup.export_normalized_tables(primary, google_sheets_backup.NORMALIZED_TABLES)
            primary_checksum = google_sheets_backup.normalized_snapshot_checksum(primary_snapshot)
            base_checksum = str(self._google_failover_base_checksum or "")
            if not base_checksum or primary_checksum != base_checksum:
                logger.error(
                    "Normalized Google failover reconciliation blocked: primary diverged base=%s primary=%s",
                    base_checksum[:12],
                    primary_checksum[:12],
                )
                return {
                    "active": True,
                    "status": "conflict",
                    "base_checksum": base_checksum,
                    "primary_checksum": primary_checksum,
                }
            failover_snapshot = google_sheets_backup.export_normalized_tables(self, google_sheets_backup.NORMALIZED_TABLES)
            failover_checksum = google_sheets_backup.normalized_snapshot_checksum(failover_snapshot)
            google_sheets_backup.restore_normalized_snapshot_to_engine(failover_snapshot, primary)
            verified = google_sheets_backup.export_normalized_tables(primary, google_sheets_backup.NORMALIZED_TABLES)
            verified_checksum = google_sheets_backup.normalized_snapshot_checksum(verified)
            if verified_checksum != failover_checksum:
                raise RuntimeError("normalized primary checksum mismatch after Google failover reconcile")
        except Exception as exc:
            logger.warning("Normalized Google failover reconcile attempt failed: %s", exc, exc_info=True)
            return {"active": True, "status": "unavailable", "error": f"{exc.__class__.__name__}:{str(exc)[:300]}"}
        finally:
            primary.close()

        self.close()
        self.database_url = self._primary_database_url
        self.dialect = POSTGRES
        self._schema_ready = True
        self._google_failover_active = False
        self._google_failover_reason = ""
        self._google_failover_base_checksum = ""
        try:
            google_sheets_backup.mark_normalized_dirty(google_sheets_backup.NORMALIZED_TABLES)
        except Exception:
            logger.exception("Could not queue post-reconcile normalized Google snapshot")
        logger.warning("Normalized v8 Google failover reconciled safely back to PostgreSQL")
        return {"active": False, "status": "reconciled", "checksum": failover_checksum}

    @contextlib.contextmanager
    def transaction(self, *, read_only: bool = False) -> Iterator[CursorAdapter]:
        existing = getattr(self._unit_of_work, "cursor", None)
        if existing is not None:
            try:
                yield existing
            except BaseException:
                self._unit_of_work.rollback_only = True
                raise
            return
        started = time.monotonic()
        pool_context: Any = None
        connection: Any = None
        cursor: Any = None
        try:
            if self.dialect.name == "postgres":
                try:
                    pool_context = self._postgres_pool().connection(
                        timeout=max(1.0, float(os.getenv("DB_POOL_TIMEOUT_SECONDS", "10") or 10))
                    )
                    connection = pool_context.__enter__()
                    cursor = connection.cursor()
                    if read_only:
                        cursor.execute("SET TRANSACTION READ ONLY")
                    statement_timeout_ms = max(100, int(os.getenv("DB_STATEMENT_TIMEOUT_MS", "15000") or 15000))
                    cursor.execute("SELECT set_config('statement_timeout', %s, true)", (str(statement_timeout_ms),))
                    lock_timeout_ms = max(100, int(os.getenv("DB_LOCK_TIMEOUT_MS", "5000") or 5000))
                    cursor.execute("SELECT set_config('lock_timeout', %s, true)", (str(lock_timeout_ms),))
                except Exception as primary_error:
                    if pool_context is not None:
                        with contextlib.suppress(Exception):
                            pool_context.__exit__(*sys.exc_info())
                        pool_context = None
                    connection = None
                    cursor = None
                    if not self._activate_google_failover(primary_error):
                        raise
                    connection = self._sqlite_connection()
                    connection.execute("BEGIN" if read_only else "BEGIN IMMEDIATE")
                    cursor = connection.cursor()
            else:
                connection = self._sqlite_connection()
                connection.execute("BEGIN" if read_only else "BEGIN IMMEDIATE")
                cursor = connection.cursor()
            adapter = CursorAdapter(cursor, self.dialect)
            yield adapter
            if read_only:
                connection.rollback()
            else:
                normalized_dirty_queued = False
                if adapter.modified_tables:
                    try:
                        from core.google_sheets_backup import flush_normalized_pending, mark_normalized_dirty

                        # In writable failover the local SQLite database is the
                        # authoritative durable store until PostgreSQL returns.
                        # Persist the mirror outbox *before* committing SQLite so
                        # a successful caller acknowledgement can never exist
                        # without a durable retry record. If the outbox cannot be
                        # persisted we are still inside the database transaction
                        # and can safely roll back without an ambiguous commit.
                        mark_normalized_dirty(adapter.modified_tables)
                        normalized_dirty_queued = True
                    except Exception:
                        logger.exception("Could not persist normalized Google Sheets outbox")
                        if self._google_failover_active:
                            raise

                connection.commit()

                if adapter.modified_tables and self._google_failover_active and normalized_dirty_queued:
                    try:
                        # Google is a replicated durability target, not the
                        # transaction commit boundary. A network/API failure here
                        # must not turn an already-committed local transaction
                        # into an apparent failure that callers might retry and
                        # double-apply. The pending generation remains queued.
                        flush_normalized_pending(self, sync_version=time.time_ns())
                    except Exception:
                        logger.exception(
                            "Normalized Google mirror unavailable after durable failover commit; queued for retry"
                        )
        except BaseException:
            if connection is not None:
                with contextlib.suppress(Exception):
                    connection.rollback()
            raise
        finally:
            if cursor is not None:
                with contextlib.suppress(Exception):
                    cursor.close()
            if pool_context is not None:
                with contextlib.suppress(Exception):
                    pool_context.__exit__(*sys.exc_info())
            elif connection is not None:
                with contextlib.suppress(Exception):
                    connection.close()
            try:
                from core.metrics_v2 import observe
                observe(f"db_transaction_{self.dialect.name}_{'read' if read_only else 'write'}", time.monotonic() - started)
            except Exception as exc:
                logger.debug("database metrics emission failed: %s", exc)

    def close(self) -> None:
        pool, self._pool = self._pool, None
        if pool is not None:
            with contextlib.suppress(Exception):
                pool.close()

    def ensure_schema(self) -> None:
        if self._schema_ready:
            return
        with self._schema_lock:
            if self._schema_ready:
                return
            from core.storage.schema import apply_schema

            apply_schema(self)
            self._schema_ready = True

    def healthcheck(self) -> bool:
        try:
            self.ensure_schema()
            with self.transaction(read_only=True) as cursor:
                row = cursor.execute("SELECT 1 AS ok").fetchone()
            return bool(row and int(row["ok"]) == 1)
        except Exception:
            logger.exception("v8 normalized database healthcheck failed")
            return False


_ENGINE: DatabaseEngine | None = None
_ENGINE_LOCK = threading.Lock()


def normalized_engine() -> DatabaseEngine:
    global _ENGINE
    if _ENGINE is None:
        with _ENGINE_LOCK:
            if _ENGINE is None:
                _ENGINE = DatabaseEngine()
                _ENGINE.ensure_schema()
    return _ENGINE


def reset_engine_for_tests() -> None:
    global _ENGINE
    with _ENGINE_LOCK:
        engine, _ENGINE = _ENGINE, None
    if engine is not None:
        engine.close()
