"""Additive SENTINEL 9 market evidence schema, shared by both database dialects."""

MARKET_DDL = (
    """CREATE TABLE IF NOT EXISTS s9_provider_budget (
       id TEXT PRIMARY KEY, payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_preparations (
       id TEXT PRIMARY KEY, state TEXT NOT NULL, prepared_ms BIGINT NOT NULL, payload TEXT NOT NULL)""",
    """CREATE TABLE IF NOT EXISTS s9_deliveries (
       id TEXT PRIMARY KEY, setup_id TEXT NOT NULL, plan_version INTEGER NOT NULL, event_id TEXT NOT NULL,
       audience TEXT NOT NULL, target_id TEXT NOT NULL, content_hash TEXT NOT NULL, state TEXT NOT NULL,
       attempts INTEGER NOT NULL DEFAULT 0, ready_ms BIGINT NOT NULL, payload TEXT NOT NULL,
       UNIQUE(setup_id,plan_version,event_id,audience,target_id))""",
    "CREATE INDEX IF NOT EXISTS s9_deliveries_ready ON s9_deliveries(state,ready_ms)",
    """CREATE TABLE IF NOT EXISTS s9_admin_review_outbox (
       id TEXT PRIMARY KEY, review_id TEXT NOT NULL, admin_id TEXT NOT NULL, status TEXT NOT NULL,
       attempts INTEGER NOT NULL DEFAULT 0, updated_ms BIGINT NOT NULL, payload TEXT NOT NULL,
       UNIQUE(review_id,admin_id))""",
    """CREATE TABLE IF NOT EXISTS s9_strategy_reviews (
       id TEXT PRIMARY KEY, engine TEXT NOT NULL, symbol TEXT NOT NULL, timeframe TEXT NOT NULL,
       state TEXT NOT NULL, created_ms BIGINT NOT NULL, payload TEXT NOT NULL)""",
    "CREATE INDEX IF NOT EXISTS s9_reviews_family ON s9_strategy_reviews(engine,symbol,timeframe,created_ms DESC)",
    """CREATE TABLE IF NOT EXISTS s9_candles (
       symbol TEXT NOT NULL, provider TEXT NOT NULL, timeframe TEXT NOT NULL, start_ms BIGINT NOT NULL,
       end_ms BIGINT NOT NULL, payload TEXT NOT NULL, PRIMARY KEY(symbol,provider,timeframe,start_ms))""",
    "CREATE INDEX IF NOT EXISTS s9_candles_range ON s9_candles(symbol,provider,timeframe,start_ms DESC)",
    "CREATE INDEX IF NOT EXISTS s9_candles_retention ON s9_candles(end_ms)",
    """CREATE TABLE IF NOT EXISTS s9_setups (
       id TEXT PRIMARY KEY, thesis_key TEXT NOT NULL, engine TEXT NOT NULL, symbol TEXT NOT NULL,
       timeframe TEXT NOT NULL, plan_version INTEGER NOT NULL, state_version INTEGER NOT NULL,
       phase TEXT NOT NULL, proposed_ms BIGINT NOT NULL, payload TEXT NOT NULL,
       UNIQUE(engine,symbol,timeframe,thesis_key))""",
    """CREATE TABLE IF NOT EXISTS s9_setup_events (
       id TEXT PRIMARY KEY, setup_id TEXT NOT NULL, event_type TEXT NOT NULL, event_ms BIGINT NOT NULL,
       payload TEXT NOT NULL, FOREIGN KEY(setup_id) REFERENCES s9_setups(id))""",
    "CREATE INDEX IF NOT EXISTS s9_events_setup ON s9_setup_events(setup_id,event_ms)",
    """CREATE TABLE IF NOT EXISTS s9_approvals (
       id TEXT PRIMARY KEY, setup_id TEXT NOT NULL, plan_version INTEGER NOT NULL, event_id TEXT NOT NULL,
       audience TEXT NOT NULL, actor TEXT NOT NULL, approved_ms BIGINT NOT NULL, content_hash TEXT NOT NULL,
       FOREIGN KEY(setup_id) REFERENCES s9_setups(id), UNIQUE(setup_id,plan_version,event_id,audience))""",
)
