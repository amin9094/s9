from __future__ import annotations

import asyncio
from weakref import WeakKeyDictionary
import hashlib
import json
import logging
import os
import time
from threading import RLock
from typing import Any

from config import SETTINGS

logger = logging.getLogger(__name__)
_LOCK = RLock()
_LOCAL: dict[str, tuple[float, Any]] = {}
_MAX_LOCAL = 20_000
_REDIS_CLIENTS: WeakKeyDictionary = WeakKeyDictionary()
_REDIS_LOCKS: WeakKeyDictionary = WeakKeyDictionary()
_REDIS_DISABLED_UNTIL = 0.0


def _key(namespace: str, key: str) -> str:
    safe_namespace = "".join(ch for ch in str(namespace).lower() if ch.isalnum() or ch in "_-.")[:40] or "default"
    digest = hashlib.sha256(str(key).encode("utf-8")).hexdigest()
    return f"sentinel:cache:{safe_namespace}:{digest}"


async def _redis_client() -> Any:
    global _REDIS_DISABLED_UNTIL
    if not SETTINGS.redis_url or time.monotonic() < _REDIS_DISABLED_UNTIL:
        return None
    loop = asyncio.get_running_loop()
    with _LOCK:
        guard = _REDIS_LOCKS.setdefault(loop, asyncio.Lock())
    async with guard:
        with _LOCK:
            existing = _REDIS_CLIENTS.get(loop)
        if existing is not None:
            return existing
        candidate = None
        try:
            import redis.asyncio as redis

            timeout = max(0.2, float(os.getenv("REDIS_SOCKET_TIMEOUT_SECONDS", "1.5") or 1.5))
            candidate = redis.Redis.from_url(
                SETTINGS.redis_url, decode_responses=True,
                socket_connect_timeout=timeout, socket_timeout=timeout,
                health_check_interval=30,
                max_connections=max(2, int(os.getenv("REDIS_MAX_CONNECTIONS", "30") or 30)),
                retry_on_timeout=True,
            )
            await candidate.ping()
            with _LOCK:
                _REDIS_CLIENTS[loop] = candidate
            return candidate
        except Exception as exc:
            _REDIS_DISABLED_UNTIL = time.monotonic() + 60
            logger.warning("Redis shared cache unavailable; using local fallback: %s", exc.__class__.__name__)
            return None
        finally:
            if candidate is not None and _REDIS_CLIENTS.get(loop) is not candidate:
                await candidate.aclose()


def _local_get(cache_key: str) -> Any | None:
    now = time.monotonic()
    with _LOCK:
        row = _LOCAL.get(cache_key)
        if row is None:
            return None
        expires_at, value = row
        if expires_at <= now:
            _LOCAL.pop(cache_key, None)
            return None
        return value


def _local_set(cache_key: str, value: Any, ttl_seconds: int) -> None:
    now = time.monotonic()
    with _LOCK:
        _LOCAL[cache_key] = (now + max(1, int(ttl_seconds)), value)
        if len(_LOCAL) > _MAX_LOCAL:
            expired = [key for key, (expiry, _) in _LOCAL.items() if expiry <= now]
            for key in expired:
                _LOCAL.pop(key, None)
            if len(_LOCAL) > _MAX_LOCAL:
                oldest = sorted(_LOCAL.items(), key=lambda item: item[1][0])
                for key, _ in oldest[: len(_LOCAL) - _MAX_LOCAL]:
                    _LOCAL.pop(key, None)


async def cache_get(namespace: str, key: str) -> Any | None:
    cache_key = _key(namespace, key)
    local = _local_get(cache_key)
    if local is not None:
        return local
    client = await _redis_client()
    if client is None:
        return None
    try:
        raw = await client.get(cache_key)
        if raw is None:
            return None
        value = json.loads(raw)
        _local_set(cache_key, value, 5)
        return value
    except Exception as exc:
        logger.warning("Shared cache read failed: %s", exc.__class__.__name__)
        return None


async def cache_set(namespace: str, key: str, value: Any, *, ttl_seconds: int) -> None:
    cache_key = _key(namespace, key)
    ttl = max(1, int(ttl_seconds))
    _local_set(cache_key, value, ttl)
    client = await _redis_client()
    if client is None:
        return
    try:
        raw = json.dumps(value, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
        await client.set(cache_key, raw, ex=ttl)
    except Exception as exc:
        logger.warning("Shared cache write failed: %s", exc.__class__.__name__)


async def cache_delete(namespace: str, key: str) -> None:
    cache_key = _key(namespace, key)
    with _LOCK:
        _LOCAL.pop(cache_key, None)
    client = await _redis_client()
    if client is not None:
        try:
            await client.delete(cache_key)
        except Exception as exc:
            logger.warning("Shared cache delete failed: %s", exc.__class__.__name__)


async def close_shared_cache() -> None:
    loop = asyncio.get_running_loop()
    with _LOCK:
        client = _REDIS_CLIENTS.pop(loop, None)
        _REDIS_LOCKS.pop(loop, None)
    if client is not None:
        await client.aclose()


async def shared_cache_healthcheck(*, require_redis: bool = False) -> dict[str, Any]:
    """Probe the configured shared cache without treating local fallback as Redis."""
    client = await _redis_client()
    if client is None:
        if require_redis:
            raise RuntimeError("Redis is configured as required but is unavailable.")
        return {"backend": "local", "redis_configured": bool(SETTINGS.redis_url), "healthy": True}
    started = time.monotonic()
    await client.ping()
    return {
        "backend": "redis",
        "redis_configured": True,
        "healthy": True,
        "latency_ms": round((time.monotonic() - started) * 1000, 2),
    }


def reset_shared_cache_for_tests() -> None:
    global _REDIS_DISABLED_UNTIL
    with _LOCK:
        _LOCAL.clear()
    _REDIS_CLIENTS.clear()
    _REDIS_LOCKS.clear()
    _REDIS_DISABLED_UNTIL = 0.0


def local_cache_size() -> int:
    with _LOCK:
        return len(_LOCAL)


def trim_local_cache(*, keep_ratio: float = 0.5) -> dict[str, int]:
    """Drop expired entries and, under memory pressure, the soonest-expiring entries."""
    ratio = max(0.0, min(1.0, float(keep_ratio)))
    now = time.monotonic()
    with _LOCK:
        before = len(_LOCAL)
        for key in [key for key, (expiry, _) in _LOCAL.items() if expiry <= now]:
            _LOCAL.pop(key, None)
        target = int(len(_LOCAL) * ratio)
        if len(_LOCAL) > target:
            ordered = sorted(_LOCAL.items(), key=lambda item: item[1][0])
            for key, _ in ordered[: max(0, len(_LOCAL) - target)]:
                _LOCAL.pop(key, None)
        after = len(_LOCAL)
    return {"before": before, "after": after, "removed": before - after}
