from __future__ import annotations

import os
import time
from pathlib import Path
from typing import BinaryIO

_HANDLE: BinaryIO | None = None


def _lock_enabled() -> bool:
    raw = os.getenv("ENABLE_PROCESS_LOCK")
    if raw is not None:
        return raw.strip().lower() not in {"0", "false", "no", "off"}
    # Railway can briefly overlap old/new deployments. Telegram polling already
    # protects against simultaneous consumers and retries until the old instance
    # exits, while a shared file lock would make the new deployment fail instantly.
    return not bool(os.getenv("RAILWAY_ENVIRONMENT") or os.getenv("RAILWAY_PROJECT_ID"))


def acquire_single_instance(lock_file: Path, *, wait_seconds: float = 0) -> bool:
    """Hold an OS file lock, or skip it safely during Railway rolling deploys."""
    global _HANDLE
    if not _lock_enabled():
        return False
    lock_file.parent.mkdir(parents=True, exist_ok=True)
    deadline = time.monotonic() + max(0.0, float(wait_seconds))
    last_exc: BaseException | None = None
    while True:
        handle = lock_file.open("a+b")
        try:
            if os.name == "nt":
                import msvcrt

                handle.seek(0)
                if handle.read(1) == b"":
                    handle.write(b"0")
                    handle.flush()
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(handle.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except (OSError, BlockingIOError) as exc:
            last_exc = exc
            handle.close()
            if time.monotonic() >= deadline:
                raise RuntimeError("Another SENTINEL bot process is already using this database") from last_exc
            time.sleep(1)
            continue
        handle.seek(0)
        handle.truncate()
        handle.write(str(os.getpid()).encode("ascii"))
        handle.flush()
        _HANDLE = handle
        return True
