from __future__ import annotations

import copy
import hashlib
import json
import logging
import os
import re
import shutil
import sqlite3
import tempfile
import time
from collections.abc import Callable, Iterable
from contextlib import closing
from datetime import UTC, datetime
from pathlib import Path
from threading import RLock
from typing import Any, TypeVar

from config import SETTINGS
from core.runtime_topology import replica_count
from core.sensitive_data import encryption_ready, protect_sensitive_payload, unprotect_sensitive_payload
from core.relational_storage import (
    DOMAIN_TABLES,
    RELATIONAL_STORAGE_VERSION,
    USER_ACCOUNT_SECTION,
    USER_MEMBERSHIP_SECTION,
    USER_PREFERENCE_SECTIONS,
    USER_PROFILE_SECTION,
    USER_RECORD_SECTIONS,
    container_type,
    iter_section_records,
    json_text,
    reconstruct_section,
    section_checksum,
    section_domain,
    user_id_from_key_or_payload,
)
from core.relational_storage import (
    display_name as relational_display_name,
)

logger = logging.getLogger(__name__)


class ConcurrentDatabaseUpdate(RuntimeError):
    """A compatibility section changed between optimistic read and commit."""


T = TypeVar("T")
_LOCK = RLock()
_CACHE: dict[str, Any] | None = None
_LAST_BACKUP_DATE: str | None = None
SCHEMA_VERSION = 40

DEFAULT_FAQ_SEED_VERSION = 1
DEFAULT_FAQS: tuple[tuple[str, str], ...] = (
    (
        "چطور اشتراک VIP بخرم؟",
        "از منوی اصلی روی دکمه «خرید اشتراک VIP» بزنید، پلن را انتخاب کنید و مراحل پرداخت را کامل کنید. وضعیت سفارش از بخش حساب من قابل پیگیری است.",
    ),
    (
        "چطور با تتر اشتراک بخرم؟",
        "پس از انتخاب پلن، اگر پرداخت تتر توسط ادمین فعال باشد، روش «پرداخت با تتر» را انتخاب کنید. مقدار USDT، شبکه و آدرس کیف پول نمایش داده می‌شود. پس از واریز، تصویر رسید تراکنش را ارسال کنید؛ بعد از تأیید ادمین، اشتراک فعال و لینک یک‌بارمصرف کانال خصوصی ارسال می‌شود.",
    ),
    (
        "بعد از پرداخت چه زمانی اشتراک فعال می‌شود؟",
        "پس از بررسی و تأیید پرداخت توسط ادمین، اشتراک فعال می‌شود و در صورت تنظیم کانال خصوصی، لینک ورود یک‌بارمصرف برای شما ارسال خواهد شد.",
    ),
    (
        "چطور اشتراک را تمدید کنم؟",
        "از منوی اصلی وارد «خرید/مدیریت اشتراک VIP» شوید. روزهای باقی‌مانده حفظ می‌شوند و مدت تمدید به تاریخ انقضای فعلی اضافه خواهد شد.",
    ),
    (
        "سیگنال‌های کانال را از کجا ببینم؟",
        "در منوی اصلی روی «سیگنال‌های من» بزنید. سیگنال‌های دوره فعلی، وضعیت لحظه‌ای، تارگت‌ها و نتیجه نهایی در همان بخش نمایش داده می‌شوند.",
    ),
    (
        "گزینه سیگنال گرفتم و نگرفتم چه کاربردی دارد؟",
        "با انتخاب «سیگنال گرفتم»، نتیجه آن سیگنال وارد آمار شخصی شما می‌شود. «سیگنال نگرفتم» فقط برای ثبت تصمیم شماست و در برآیند معاملات گرفته‌شده محاسبه نمی‌شود.",
    ),
    (
        "نتیجه سیگنال‌ها چگونه بروزرسانی می‌شود؟",
        "ادمین پس از ورود، لمس تارگت، ریسک‌فری، استاپ، لغو یا خروج دستی، وضعیت را ثبت می‌کند و همان نتیجه در بخش سیگنال‌های شما بروزرسانی می‌شود.",
    ),
    (
        "ماشین‌حساب مدیریت ریسک چگونه کار می‌کند؟",
        "نماد، موجودی حساب، درصد ریسک، قیمت ورود و حد ضرر را وارد کنید تا حجم تقریبی مناسب معامله محاسبه شود. نتیجه صرفاً ابزار کمکی است و جایگزین تصمیم معاملاتی شما نیست.",
    ),
    (
        "قیمت‌های بازار از کجا دریافت می‌شوند؟",
        "قیمت‌ها از سرویس‌های داده بازار دریافت و با کش کوتاه‌مدت نمایش داده می‌شوند. زمان آخرین بروزرسانی و در صورت امکان منبع داده در صفحه قیمت درج می‌شود.",
    ),
    (
        "چطور ارز دیجیتال یا سهام را جستجو کنم؟",
        "از بخش قیمت بازار وارد ارز دیجیتال یا سهام شوید و نام یا نماد دارایی را وارد کنید؛ مانند BTC، Ethereum، AAPL یا Tesla.",
    ),
    (
        "خبرهای اقتصادی چه اطلاعاتی نشان می‌دهند؟",
        "کاربران زمان، ارز، عنوان و درجه اهمیت خبر را می‌بینند. جزئیات تحلیلی و سناریوهای بازار فقط در اختیار ادمین است و در صورت تأیید او در کانال منتشر می‌شود.",
    ),
    (
        "هشدار قیمت چیست؟",
        "می‌توانید برای دارایی‌های پشتیبانی‌شده شرط بالاتر یا پایین‌تر از یک قیمت تعیین کنید. پس از رسیدن قیمت به شرط، ربات برای شما اعلان ارسال می‌کند.",
    ),
    (
        "آموزش‌های رایگان و پولی چه تفاوتی دارند؟",
        "آموزش‌های رایگان برای همه قابل مشاهده‌اند. برای محتوای پولی باید سفارش همان درس تأیید شود؛ خرید یک درس فقط دسترسی همان محتوای خریداری‌شده را فعال می‌کند.",
    ),
    (
        "امتیازها را چگونه دریافت یا خرج کنم؟",
        "امتیازها از مأموریت‌ها، مسابقات، معرفی دوستان یا رویدادهای تعریف‌شده دریافت می‌شوند و در فروشگاه جوایز قابل استفاده‌اند. گردش کامل امتیاز در حساب من نمایش داده می‌شود.",
    ),
    (
        "چطور با پشتیبانی ارتباط بگیرم؟",
        "از منوی اصلی وارد «پشتیبانی» شوید، تیکت جدید بسازید و موضوع را توضیح دهید. پاسخ ادمین در همان تیکت قابل مشاهده است.",
    ),
    (
        "اگر عضویت اجباری تأیید نشد چه کنم؟",
        "ابتدا با همان حساب تلگرام عضو کانال شوید، سپس روی «عضو شدم؛ بررسی کن» بزنید. اگر مشکل ادامه داشت، از بخش پشتیبانی تیکت ثبت کنید.",
    ),
)


def utc_now_iso() -> str:
    return datetime.now(UTC).isoformat()


DEFAULT_DB: dict[str, Any] = {
    "schema_version": SCHEMA_VERSION,
    "referral_milestones": {},
    "referral_milestone_claims": {},
    "reward_shop_claims": {},
    "vip_gifts": {},
    "admin_work_queue": {},
    "experience_schema_revision": 1,
    "users": {},
    "vip_settings": {
        "price": 150000,
        "card_number": "",
        "owner_name": "",
        "duration_days": 30,
        "usdt_enabled": False,
        "usdt_wallet_address": "",
        "usdt_network": "TRC20",
        "usdt_rate_toman": 0,
        "usdt_rate_updated_at": None,
        "usdt_quote_valid_minutes": 30,
        "usdt_verification_enabled": False,
    },
    "vip_users": {},
    "vip_orders": [],
    "discount_codes": {},
    "discount_history": [],
    "discount_events": [],
    "marketing_campaigns": {},
    "campaign_events": [],
    "campaign_audience_snapshots": {},
    "discount_security": {},
    "discount_security_settings": {"window_minutes": 15, "max_failures": 8, "block_minutes": 15},
    "affiliate_commissions": [],
    "affiliate_balances": {},
    "user_points": {},
    "point_history": [],
    "user_activity": [],
    "user_profiles": {},
    "user_referrals": {},
    "reward_requests": [],
    "user_rewards": [],
    "purchase_reward_claims": {},
    "price_alerts": [],
    "price_alert_history": [],
    "user_bans": {},
    "broadcasts": [],
    "broadcast_queue": [],
    "public_channel_links": [],
    "public_channel_link_events": [],
    "public_channel_attribution_users": {},
    "announcements": [],
    "privacy_requests": {},
    "privacy_log": [],
    "operations": {"job_status": {}, "metrics": {}, "last_cleanup_at": None},
    "lessons": [],
    "faq": [],
    "tickets": [],
    "contests": [],
    "chart_contest": {},
    "candle_contest": {},
    "contest_history": [],
    "missions": [
        {"id": 1, "title": "استفاده از ماشین‌حساب ریسک", "reward": 5, "event": "risk_calculator"},
        {"id": 2, "title": "شرکت در مسابقه چارت", "reward": 5, "event": "join_chart_contest"},
        {"id": 3, "title": "برنده‌شدن در مسابقه", "reward": 10, "event": "win_contest"},
    ],
    "user_missions": {},
    "signals": [],
    "signal_archive": [],
    "signal_cycle": {
        "current_id": 1,
        "name": "دوره #1",
        "current_name": "دوره #1",
        "status": "active",
        "current_status": "active",
        "next_number": 1,
        "next_numbers": {"forex": 1, "crypto": 1},
        "started_at": None,
        "started_by": "system",
        "closed_at": None,
        "closed_by": "",
        "periods": [],
        "reset_history": [],
    },
    "user_signal_choices": {},
    "scheduled_signals": [],
    "signal_approvals": [],
    "signal_tracking_proposals": [],
    "signal_versions": {},
    "signal_revisions": [],
    "signal_outcome_events": [],
    "signal_live_cards": {},
    "signal_template_backgrounds": {},
    "kpi_trader_tasks": [],
    "kpi_trader_submissions": [],
    "kpi_trader_score_ledger": [],
    "kpi_business_outcomes": [],
    "kpi_trader_settings": {
        "enabled": True,
        "review_required": True,
        "evidence_required": True,
        "owner_review_only": False,
        "allow_manual_score_adjustment": True,
        "default_due_days": 7,
        "max_task_points": 1000,
        "monthly_points_budget": 100000,
        "reminder_hours": [24, 3],
        "quality_gate_required": True,
        "quality_gate_min_score": 80,
        "max_active_tasks_per_trader": 10,
    },
    "personal_risk_profiles": {},
    "trading_accounts": {},
    "user_positions": {},
    "position_audit": {},
    "position_pnl_events": {},
    "signal_revision_acknowledgements": {},
    "behavioral_insights": {},
    "ai_command_center": {"schema_version": 1, "conversations": [], "usage": {}, "next_conversation_id": 1, "next_proposal_id": 1},
    "ai_audit_log": [],
    "ai_pending_proposals": [],
    "ai_ticket_drafts": [],
    "ai_report_notes": [],
    "security_audit_log": [],
    "next_security_audit_sequence": 1,
    "ai_execution_plans": [],
    "next_ai_execution_plan_id": 1,
    "ai_undo_snapshots": [],
    "signal_team_rules": {},
    "ai_signal_lab": {"strategies": [], "runs": [], "candidates": [], "next_strategy_id": 1, "next_run_id": 1, "next_candidate_id": 1},
    "miniapp_event_stream": [],
    "miniapp_idempotency_records": {},
    "checkout_quotes": {},
    "receipt_uploads": {},
    "miniapp_onboarding": {},
    "signal_replays": {},
    "signal_share_cards": {},
    "market_regime_history": [],
    "shift_handoffs": [],
    "operations_daily_briefs": {},
    "growth_experiments": {},
    "experiment_assignments": {},
    "experiment_events": [],
    "smart_followups": [],
    "incidents": [],
    "incident_settings": {"notify_critical": True, "dedupe_minutes": 15, "retention_days": 180},
    "retention_events": [],
    "retention_settings": {},
    "trust_center": {"enabled": True, "latest": {}, "history": []},
    "provider_health": {},
    "feature_flags": {
        "ops.memory_guardian": True,
        "ops.self_healing": True,
        "ops.smart_logging": True,
        "messaging.priority_queue": True,
        "providers.intelligence": True,
        "trading.coach": True,
        "miniapp.operations_center": True,
        "admin.operations_center": True,
    },
    "feature_flag_audit": [],
    "payment_reconciliations": [],
    "payment_reconciliation_settings": {
        "enabled": True,
        "min_confirmations": {"TRC20": 20, "ERC20": 12, "BEP20": 15},
        "underpayment_tolerance_percent": 0.25,
        "overpayment_requires_review_percent": 10.0,
        "auto_approve_verified": False,
    },
    "runtime_safety": {
        "mode": "production",
        "disaster_mode": False,
        "read_only": False,
        "reason": "",
        "changed_at": None,
        "changed_by": "system",
    },
    "rules_settings": {
        "enabled": True,
        "version": 0,
        "text": "",
        "content_hash": "",
        "updated_at": None,
        "updated_by": None,
        "history": [],
    },
    "rules_acceptances": {},
    "rules_acceptance_history": [],
    "notification_routing_log": [],
    "admin_today_checklists": {},
    "market_session_settings": {"timezone": "UTC"},
    "price_alert_deliveries": [],
    "channel_management": {
        "force_join": {
            "enabled": False,
            "channel_id": 0,
            "invite_link": "",
            "title": "کانال رسمی SENTINEL",
            "channels": [],
            "require_all": True,
            "cache_seconds": 120,
            "failure_policy": "grace",
            "cache_max_entries": 20000,
            "check_concurrency": 8,
        },
        "smart_pin": {
            "enabled": True,
            "public_message_id": None,
            "private_message_id": None,
            "updated_at": None,
        },
        "live_status": {"enabled": True},
    },
    "market_intelligence": {
        "settings": {
            "enabled": True,
            "morning_time": "07:30",
            "destination": "public",
            "auto_generate": True,
            "notify_admins": True,
        },
        "briefings": [],
        "latest_snapshot": {},
        "calendar_publications": [],
        "last_generated_date": None,
    },
    "admin_logs": [],
    "delegated_admins": {},
    "crm_profiles": {},
    "crm_activities": [],
    "crm_automation_log": {},
    "automation_settings": {},
    "automation_log": {},
    "automation_outbox": {},
    "automation_outbox_index": {},
    "automation_contact_log": {},
    "automation_rules_v2": {},
    "automation_v2_idempotency": {},
    "automation_v2_jobs": {},
    "automation_v2_schedule_watermarks": {},
    "automation_v2_dead_letter": [],
    "automation_v2_runs": [],
    "automation_v2_audit": [],
    "automation_v2_event_log": [],
    "automation_tasks": [],
    "automation_ai_drafts": [],
    "automation_custom_log": [],
    "economic_calendar": {"settings": {}},
    "economic_calendar_preferences": {},
    "economic_calendar_notifications": {},
    "approval_settings": {"enabled": False, "operations": [], "expires_minutes": 30},
    "pending_admin_actions": [],
    "admin_shifts": {},
    "education_orders": [],
    "education_access": {},
    "enterprise_control": {},
    "user_notification_preferences": {},
    "notification_defaults": {},
    "league_settings": {},
    "league_seasons": [],
    "league_history": [],
    "support_settings": {},
    "support_canned_replies": [],
    "support_internal_notes": {},
    "faq_feedback": {},
    "user_watchlists": {},
    "trade_journal": {},
    "journal_admin_notes": {},
    "backup_settings": {},
    "health_settings": {},
    "security_settings": {},
    "broadcast_settings": {},
    "referral_settings": {},
    "privacy_settings": {},
    "signal_template_settings": {
        "buy": {
            "font_size": 46,
            "fields": {
                "symbol": {"box": [520, 642, 1133, 710], "font_size": 46},
                "entry": {"box": [520, 751, 1133, 817], "font_size": 46},
                "stop": {"box": [520, 859, 1133, 927], "font_size": 46},
                "tp1": {"box": [520, 968, 1133, 1036], "font_size": 46},
                "tp2": {"box": [520, 1077, 1133, 1145], "font_size": 46},
                "tp3": {"box": [520, 1185, 1133, 1253], "font_size": 46},
                "risk": {"box": [520, 1295, 1133, 1363], "font_size": 43}
            }
        },
        "sell": {
            "font_size": 46,
            "fields": {
                "symbol": {"box": [490, 635, 1094, 700], "font_size": 46},
                "entry": {"box": [490, 748, 1094, 814], "font_size": 46},
                "stop": {"box": [490, 861, 1094, 927], "font_size": 46},
                "tp1": {"box": [490, 973, 1094, 1040], "font_size": 46},
                "tp2": {"box": [490, 1086, 1094, 1152], "font_size": 46},
                "tp3": {"box": [490, 1198, 1094, 1265], "font_size": 46},
                "risk": {"box": [490, 1310, 1094, 1377], "font_size": 43}
            }
        }
    },
    "settings": {
        "rewardItems": [
            {"id": 1, "name": "کد تخفیف ۱۰٪ اشتراک", "points": 60, "discountPct": 10},
            {"id": 2, "name": "کد تخفیف ۲۰٪ اشتراک", "points": 120, "discountPct": 20},
            {"id": 3, "name": "کد تخفیف ۳۰٪ اشتراک", "points": 180, "discountPct": 30},
            {"id": 4, "name": "کد تخفیف ۴۰٪ اشتراک", "points": 240, "discountPct": 40},
            {"id": 5, "name": "کد تخفیف ۵۰٪ اشتراک", "points": 300, "discountPct": 50},
            {"id": 6, "name": "بررسی سبک معاملاتی", "points": 30, "discountPct": 0},
            {"id": 7, "name": "تحلیل درخواستی", "points": 20, "discountPct": 0, "rewardType": "analysis_request"},
        ],
        "levels": [
            {"name": "🥉 برنزی", "minPoints": 0},
            {"name": "🥈 نقره‌ای", "minPoints": 100},
            {"name": "🥇 طلایی", "minPoints": 200},
            {"name": "💎 الماسی", "minPoints": 500},
        ],
        "contestRewards": {"price": 5, "chart": 5, "candle1": 5, "candle2": 3, "candle3": 1},
    },
    "next_ids": {
        "lesson": 1,
        "mission": 4,
        "reward_request": 1,
        "faq": 1,
        "ticket": 1,
        "user_reward": 1,
        "price_alert": 1,
        "signal": 1,
        "admin_approval": 1,
        "education_order": 1,
        "announcement": 1,
        "user_activity": 1,
        "point_transaction": 1,
        "scheduled_signal": 1,
        "signal_outcome_event": 1,
        "payment_reconciliation": 1,
        "kpi_task": 1,
        "kpi_submission": 1,
        "kpi_score": 1,
        "kpi_business_outcome": 1,
    },
}


def _deep_merge(base: dict[str, Any], incoming: dict[str, Any]) -> dict[str, Any]:
    result = copy.deepcopy(base)
    for key, value in incoming.items():
        if isinstance(value, dict) and isinstance(result.get(key), dict):
            result[key] = _deep_merge(result[key], value)
        else:
            result[key] = value
    return result


def _parse_dt(value: Any) -> datetime | None:
    if not value:
        return None
    try:
        dt = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=UTC)
        return dt.astimezone(UTC)
    except (TypeError, ValueError):
        return None


def _normalize_discount(code: str, payload: Any, percent_hint: int | None = None) -> dict[str, Any] | None:
    code = str(code).strip().upper()
    if not code:
        return None
    if isinstance(payload, (int, float)):
        payload = {"percent": int(payload)}
    if not isinstance(payload, dict):
        payload = {}
    try:
        percent = int(payload.get("percent", payload.get("discount", percent_hint or 0)))
    except (TypeError, ValueError):
        return None
    if not 1 <= percent <= 100:
        return None
    status = str(payload.get("status", "active")).lower()
    if payload.get("used") is True:
        status = "used"
    if status not in {"active", "reserved", "used", "disabled", "expired"}:
        status = "active"
    row = dict(payload)
    row.update({
        "code": code,
        "percent": percent,
        "status": status,
        "assigned_to": str(payload.get("assigned_to") or payload.get("user_id") or ""),
        "expires_at": payload.get("expires_at") or payload.get("expire_at"),
        "reserved_order_id": payload.get("reserved_order_id"),
        "created_at": payload.get("created_at") or utc_now_iso(),
        "used_at": payload.get("used_at"),
        "used_by": payload.get("used_by", ""),
        "source": str(payload.get("source") or "legacy"),
        "pool": bool(payload.get("pool") or payload.get("is_pool")),
        "assigned_at": payload.get("assigned_at"),
        "issued_via": payload.get("issued_via"),
    })
    try:
        from modules.discount_campaigns import normalize_campaign_fields
    except ImportError as exc:
        logger.warning("Discount campaign normalizer is unavailable: %s", exc)
    else:
        normalize_campaign_fields(row)
    return row


def _put_newest_vip(vip_users: dict[str, dict[str, Any]], uid: Any, payload: dict[str, Any], source: str) -> None:
    uid_text = str(uid or payload.get("user_id") or payload.get("id") or "").strip()
    if not uid_text:
        return
    expiry_raw = payload.get("expires_at") or payload.get("expire") or payload.get("expiry") or payload.get("end_date")
    expiry = _parse_dt(expiry_raw)
    if not expiry:
        return
    current = vip_users.get(uid_text)
    current_expiry = _parse_dt(current.get("expires_at")) if current else None
    if current_expiry and current_expiry >= expiry:
        return
    now = datetime.now(UTC)
    status = "active" if expiry > now else "expired"
    vip_users[uid_text] = {
        "status": status,
        "expires_at": expiry.isoformat(),
        "invite_link": payload.get("invite_link") or payload.get("invite_url"),
        "source_order_id": payload.get("source_order_id") or payload.get("order_id") or source,
        "updated_at": payload.get("updated_at") or utc_now_iso(),
        "channel_removed_at": payload.get("channel_removed_at"),
        "channel_removal_status": payload.get("channel_removal_status"),
        "channel_removal_phase": payload.get("channel_removal_phase"),
        "channel_removal_attempts": int(payload.get("channel_removal_attempts", 0) or 0),
        "channel_removal_next_retry_at": payload.get("channel_removal_next_retry_at"),
        "channel_removal_last_error": payload.get("channel_removal_last_error"),
    }


def _legacy_lessons(value: Any) -> list[dict[str, Any]]:
    lessons: list[dict[str, Any]] = []
    if isinstance(value, list):
        entries = [("عمومی", item) for item in value]
    elif isinstance(value, dict):
        entries = []
        for category, items in value.items():
            if isinstance(items, list):
                entries.extend((str(category), item) for item in items)
            elif isinstance(items, dict):
                entries.append((str(category), items))
            elif isinstance(items, str):
                entries.append((str(category), {"title": str(category), "text": items}))
    else:
        entries = []
    for category, item in entries:
        if isinstance(item, str):
            item = {"title": item, "text": item}
        if not isinstance(item, dict):
            continue
        title = str(item.get("title") or item.get("name") or "درس قدیمی").strip()
        text = str(item.get("text") or item.get("content") or item.get("body") or "").strip()
        if not text:
            continue
        lessons.append(
            {
                "id": item.get("id"),
                "title": title[:150],
                "category": str(item.get("category") or category or "عمومی")[:60],
                "text": text,
                "vip": bool(item.get("vip") or item.get("is_vip") or item.get("premium")),
                "access_type": str(item.get("access_type") or ("paid" if item.get("paid") else "free")),
                "price": max(0, int(item.get("price", 0) or 0)),
                "views": int(item.get("views", 0) or 0),
                "created_at": item.get("created_at") or utc_now_iso(),
            }
        )
    return lessons


def _legacy_orders(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, dict):
        source = list(value.values())
    elif isinstance(value, list):
        source = value
    else:
        source = []
    result: list[dict[str, Any]] = []
    for index, item in enumerate(source, start=1):
        if not isinstance(item, dict):
            continue
        uid = str(item.get("user_id") or item.get("uid") or item.get("id") or "")
        if not uid:
            continue
        status = str(item.get("status") or "pending").lower()
        status_map = {"waiting": "pending", "paid": "pending", "approve": "approved", "accepted": "approved", "reject": "rejected"}
        status = status_map.get(status, status)
        if status not in {"pending", "approved", "rejected"}:
            status = "pending"
        result.append(
            {
                "order_id": str(item.get("order_id") or item.get("id") or f"LEGACY-{index}"),
                "user_id": uid,
                "status": status,
                "price": int(item.get("price") or item.get("amount") or 0),
                "days": int(item.get("days") or item.get("duration_days") or 30),
                "coupon": str(item.get("coupon") or ""),
                "receipt_file_id": item.get("receipt_file_id") or item.get("file_id"),
                "created_at": item.get("created_at") or utc_now_iso(),
                "expires_at": item.get("expires_at") or item.get("expire"),
                "invite_link": item.get("invite_link") or item.get("invite_url"),
            }
        )
    return result


def migrate_db(raw: dict[str, Any]) -> dict[str, Any]:
    """Convert known v2/v3 layouts into one canonical schema without data loss."""
    raw = raw if isinstance(raw, dict) else {}
    db = _deep_merge(DEFAULT_DB, raw)

    # Legacy VIP settings are imported only when canonical values are absent/empty.
    legacy_settings = raw.get("settings", {}) if isinstance(raw.get("settings"), dict) else {}
    vip_settings = db.setdefault("vip_settings", {})
    if not vip_settings.get("price") and legacy_settings.get("price"):
        vip_settings["price"] = int(legacy_settings["price"])
    if not vip_settings.get("card_number") and legacy_settings.get("cardNumber"):
        vip_settings["card_number"] = legacy_settings["cardNumber"]
    if not vip_settings.get("owner_name") and legacy_settings.get("cardHolder"):
        vip_settings["owner_name"] = legacy_settings["cardHolder"]

    canonical_discounts: dict[str, dict[str, Any]] = {}
    legacy_codes = raw.get("discount_codes", {})
    if isinstance(legacy_codes, dict):
        for code, payload in legacy_codes.items():
            item = _normalize_discount(code, payload)
            if item:
                canonical_discounts[item["code"]] = item
    pools = raw.get("discount_pools", {})
    if isinstance(pools, dict):
        for percent_key, entries in pools.items():
            try:
                percent_hint = int(percent_key)
            except (TypeError, ValueError):
                percent_hint = None
            if not isinstance(entries, list):
                continue
            for entry in entries:
                code = entry.get("code", "") if isinstance(entry, dict) else str(entry)
                item = _normalize_discount(code, entry, percent_hint)
                if item:
                    item["pool"] = True
                    item["source"] = "legacy_pool"
                    canonical_discounts[item["code"]] = item
    settings_codes = legacy_settings.get("discountCodes", {})
    if isinstance(settings_codes, dict):
        for code, payload in settings_codes.items():
            item = _normalize_discount(code, payload)
            if item:
                canonical_discounts[item["code"]] = item
    elif isinstance(settings_codes, list):
        for payload in settings_codes:
            if isinstance(payload, dict):
                item = _normalize_discount(str(payload.get("code", "")), payload)
                if item:
                    canonical_discounts[item["code"]] = item
    db["discount_codes"] = canonical_discounts

    # Normalize the user reward ledger and import previously issued discounts/requests.
    reward_rows = (
        [dict(item) for item in raw.get("user_rewards", []) if isinstance(item, dict)] if isinstance(raw.get("user_rewards"), list) else []
    )
    reward_refs = {str(item.get("reference_id") or "") for item in reward_rows if str(item.get("reference_id") or "")}
    for code, item in canonical_discounts.items():
        assigned = str(item.get("assigned_to") or "").strip()
        if not assigned or code in reward_refs:
            continue
        reward_rows.append(
            {
                "user_id": assigned,
                "title": f"کد تخفیف {int(item.get('percent', 0) or 0)}٪",
                "type": "discount",
                "detail": code,
                "source": str(item.get("issued_via") or item.get("source") or "legacy_discount"),
                "status": "delivered" if item.get("status") != "disabled" else "cancelled",
                "reference_id": code,
                "created_at": item.get("assigned_at") or item.get("created_at") or utc_now_iso(),
                "delivered_at": item.get("assigned_at") or item.get("created_at") or utc_now_iso(),
            }
        )
        reward_refs.add(code)
    for request in db.get("reward_requests", []):
        if not isinstance(request, dict):
            continue
        ref = str(request.get("id") or "")
        if not ref or ref in reward_refs or not str(request.get("user_id") or "").isdigit():
            continue
        completed = str(request.get("status") or "pending") == "completed"
        reward_rows.append(
            {
                "user_id": str(request.get("user_id")),
                "title": str(request.get("reward_name") or "جایزه"),
                "type": "manual",
                "detail": "",
                "source": "legacy_reward_request",
                "status": "delivered" if completed else "pending",
                "reference_id": ref,
                "created_at": request.get("created_at") or utc_now_iso(),
                "delivered_at": request.get("completed_at") if completed else None,
            }
        )
        reward_refs.add(ref)
    used_reward_ids: set[int] = set()
    next_reward_id = 1
    normalized_rewards: list[dict[str, Any]] = []
    for item in reward_rows:
        uid = str(item.get("user_id") or "").strip()
        if not uid.isdigit():
            continue
        try:
            candidate = int(item.get("id", 0) or 0)
        except (TypeError, ValueError):
            candidate = 0
        if candidate <= 0 or candidate in used_reward_ids:
            while next_reward_id in used_reward_ids:
                next_reward_id += 1
            candidate = next_reward_id
        used_reward_ids.add(candidate)
        next_reward_id = max(next_reward_id, candidate + 1)
        normalized_rewards.append(
            {
                "id": candidate,
                "user_id": uid,
                "title": str(item.get("title") or "جایزه")[:200],
                "type": str(item.get("type") or "manual")[:40],
                "detail": str(item.get("detail") or "")[:1000],
                "source": str(item.get("source") or "legacy")[:80],
                "status": str(item.get("status") or "delivered")
                if str(item.get("status") or "delivered") in {"pending", "delivered", "cancelled"}
                else "delivered",
                "reference_id": str(item.get("reference_id") or ""),
                "created_at": item.get("created_at") or utc_now_iso(),
                "delivered_at": item.get("delivered_at"),
                "personal_notification_queued": item.get("personal_notification_queued"),
            }
        )
    db["user_rewards"] = normalized_rewards

    # Import all VIP sources and preserve the newest valid expiry per user.
    vip_users: dict[str, dict[str, Any]] = {}
    if isinstance(raw.get("vip_users"), dict):
        for uid, payload in raw["vip_users"].items():
            if isinstance(payload, dict):
                _put_newest_vip(vip_users, uid, payload, "legacy-vip")
    subscriptions = raw.get("subscriptions", {})
    if isinstance(subscriptions, dict):
        for uid, payload in subscriptions.items():
            if isinstance(payload, dict):
                _put_newest_vip(vip_users, uid, payload, "legacy-subscription")
    elif isinstance(subscriptions, list):
        for payload in subscriptions:
            if isinstance(payload, dict):
                _put_newest_vip(vip_users, payload.get("user_id") or payload.get("id"), payload, "legacy-subscription")

    canonical_orders = (
        [item for item in raw.get("vip_orders", []) if isinstance(item, dict)] if isinstance(raw.get("vip_orders"), list) else []
    )
    legacy_orders = _legacy_orders(raw.get("pending_payments"))
    known_order_ids = {str(item.get("order_id")) for item in canonical_orders}
    for order in legacy_orders:
        if order["order_id"] not in known_order_ids:
            canonical_orders.append(order)
            known_order_ids.add(order["order_id"])
    db["vip_orders"] = canonical_orders
    for order in canonical_orders:
        if str(order.get("status")).lower() == "approved":
            _put_newest_vip(vip_users, order.get("user_id"), order, "approved-order")
    db["vip_users"] = vip_users

    # Import education while retaining canonical lessons and assigning collision-free IDs.
    lessons = [dict(item) for item in raw.get("lessons", []) if isinstance(item, dict)] if isinstance(raw.get("lessons"), list) else []
    lessons.extend(_legacy_lessons(raw.get("education")))
    used_ids: set[int] = set()
    next_lesson_id = 1
    for item in lessons:
        try:
            candidate = int(item.get("id"))
        except (TypeError, ValueError):
            candidate = 0
        if candidate <= 0 or candidate in used_ids:
            while next_lesson_id in used_ids:
                next_lesson_id += 1
            candidate = next_lesson_id
        used_ids.add(candidate)
        next_lesson_id = max(next_lesson_id, candidate + 1)
        item["id"] = candidate
        item.setdefault("category", "عمومی")
        item.setdefault("views", 0)
        item.setdefault("vip", False)
        item.setdefault("created_at", utc_now_iso())
    db["lessons"] = lessons

    refs = copy.deepcopy(raw.get("user_referrals", {})) if isinstance(raw.get("user_referrals"), dict) else {}
    legacy_refs = raw.get("referralLinks", {})
    if isinstance(legacy_refs, dict):
        for uid, payload in legacy_refs.items():
            if isinstance(payload, str):
                payload = {"code": payload}
            if not isinstance(payload, dict):
                continue
            target = refs.setdefault(str(uid), {})
            target.setdefault("code", str(payload.get("code") or payload.get("referral_code") or ""))
            target.setdefault(
                "invited",
                [str(x) for x in payload.get("invited", payload.get("users", []))]
                if isinstance(payload.get("invited", payload.get("users", [])), list)
                else [],
            )
            target.setdefault("awarded_batches", int(payload.get("awarded_batches", 0) or 0))
            target.setdefault("points_awarded", int(payload.get("points_awarded", payload.get("points", 0)) or 0))
    db["user_referrals"] = refs

    # Normalize FAQ records and assign stable IDs for admin management.
    faqs: list[dict[str, Any]] = []
    used_faq_ids: set[int] = set()
    next_faq_id = 1
    source_faq = raw.get("faq", db.get("faq", []))
    if isinstance(source_faq, list):
        for payload in source_faq:
            if not isinstance(payload, dict):
                continue
            question = str(payload.get("q") or payload.get("question") or "").strip()
            answer = str(payload.get("a") or payload.get("answer") or "").strip()
            if not question or not answer:
                continue
            try:
                candidate = int(payload.get("id", 0) or 0)
            except (TypeError, ValueError):
                candidate = 0
            if candidate <= 0 or candidate in used_faq_ids:
                while next_faq_id in used_faq_ids:
                    next_faq_id += 1
                candidate = next_faq_id
            used_faq_ids.add(candidate)
            next_faq_id = max(next_faq_id, candidate + 1)
            faqs.append(
                {
                    "id": candidate,
                    "q": question[:300],
                    "a": answer[:4000],
                    "created_at": payload.get("created_at") or utc_now_iso(),
                    "updated_at": payload.get("updated_at") or payload.get("created_at") or utc_now_iso(),
                }
            )
    settings_for_seed = db.setdefault("settings", {})
    try:
        faq_seed_version = int(settings_for_seed.get("faqSeedVersion", 0) or 0)
    except (TypeError, ValueError):
        faq_seed_version = 0
    if faq_seed_version < DEFAULT_FAQ_SEED_VERSION:
        existing_questions = {str(item.get("q") or "").strip().casefold() for item in faqs}
        for question, answer in DEFAULT_FAQS:
            if question.casefold() in existing_questions:
                continue
            while next_faq_id in used_faq_ids:
                next_faq_id += 1
            candidate = next_faq_id
            used_faq_ids.add(candidate)
            next_faq_id += 1
            now = utc_now_iso()
            faqs.append({"id": candidate, "q": question, "a": answer, "created_at": now, "updated_at": now})
            existing_questions.add(question.casefold())
        settings_for_seed["faqSeedVersion"] = DEFAULT_FAQ_SEED_VERSION
    db["faq"] = faqs[-200:]

    # Import current or archived legacy tickets into the canonical ticket system.
    ticket_sources: list[Any] = []
    if isinstance(raw.get("tickets"), list):
        ticket_sources.extend(raw["tickets"])
    archive_tickets = raw.get("legacy_archive", {}).get("tickets") if isinstance(raw.get("legacy_archive"), dict) else None
    if isinstance(archive_tickets, list):
        ticket_sources.extend(archive_tickets)
    tickets: list[dict[str, Any]] = []
    used_ticket_ids: set[int] = set()
    next_ticket_id = 1
    for payload in ticket_sources:
        if not isinstance(payload, dict):
            continue
        uid = str(payload.get("user_id") or payload.get("uid") or "").strip()
        if not uid:
            continue
        try:
            int(uid)
        except ValueError:
            continue
        try:
            candidate = int(payload.get("id", 0) or 0)
        except (TypeError, ValueError):
            candidate = 0
        if candidate <= 0 or candidate in used_ticket_ids:
            while next_ticket_id in used_ticket_ids:
                next_ticket_id += 1
            candidate = next_ticket_id
        used_ticket_ids.add(candidate)
        next_ticket_id = max(next_ticket_id, candidate + 1)
        status = str(payload.get("status") or "open").lower()
        status = status if status in {"open", "closed"} else "open"
        messages = []
        raw_messages = payload.get("messages", [])
        if isinstance(raw_messages, list):
            for item in raw_messages:
                if not isinstance(item, dict):
                    continue
                body = str(item.get("text") or item.get("message") or "").strip()
                if not body:
                    continue
                sender = str(item.get("sender") or item.get("from") or "user").lower()
                messages.append(
                    {
                        "sender": "admin" if sender == "admin" else "user",
                        "sender_id": str(item.get("sender_id") or item.get("user_id") or uid),
                        "text": body[:4000],
                        "created_at": item.get("created_at") or utc_now_iso(),
                    }
                )
        legacy_body = str(payload.get("text") or payload.get("message") or payload.get("body") or "").strip()
        if legacy_body and not messages:
            messages.append(
                {"sender": "user", "sender_id": uid, "text": legacy_body[:4000], "created_at": payload.get("created_at") or utc_now_iso()}
            )
        if not messages:
            continue
        category = str(payload.get("category") or "general").lower()
        if category not in {"general", "account", "payment", "signal", "education", "technical"}:
            category = "general"
        priority = str(payload.get("priority") or "normal").lower()
        if priority not in {"low", "normal", "high", "urgent"}:
            priority = "normal"
        tickets.append(
            {
                "id": candidate,
                "user_id": uid,
                "subject": str(payload.get("subject") or "پشتیبانی")[:200],
                "status": status,
                "category": category,
                "priority": priority,
                "assigned_admin": str(payload.get("assigned_admin") or ""),
                "waiting_for": str(payload.get("waiting_for") or ("admin" if status == "open" else "closed")),
                "sla_due_at": payload.get("sla_due_at"),
                "first_response_at": payload.get("first_response_at"),
                "satisfaction": payload.get("satisfaction"),
                "satisfaction_at": payload.get("satisfaction_at"),
                "messages": messages[-100:],
                "created_at": payload.get("created_at") or messages[0]["created_at"],
                "updated_at": payload.get("updated_at") or messages[-1]["created_at"],
                "closed_at": payload.get("closed_at"),
            }
        )
    db["tickets"] = tickets[-1000:]
    archive = db.get("legacy_archive")
    if isinstance(archive, dict):
        archive.pop("tickets", None)
        if not archive:
            db.pop("legacy_archive", None)

    next_ids = db.setdefault("next_ids", {})
    lesson_ids = [int(x.get("id", 0)) for x in db.get("lessons", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    mission_ids = [int(x.get("id", 0)) for x in db.get("missions", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    request_ids = [int(x.get("id", 0)) for x in db.get("reward_requests", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    faq_ids = [int(x.get("id", 0)) for x in db.get("faq", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    ticket_ids = [int(x.get("id", 0)) for x in db.get("tickets", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    reward_ids = [int(x.get("id", 0)) for x in db.get("user_rewards", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    alert_ids = [int(x.get("id", 0)) for x in db.get("price_alerts", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    signal_ids = [int(x.get("id", 0)) for x in db.get("signals", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    announcement_ids = [int(x.get("id", 0)) for x in db.get("announcements", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    scheduled_signal_ids = [
        int(x.get("id", 0)) for x in db.get("scheduled_signals", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()
    ]
    approval_ids = [
        int(x.get("id", 0)) for x in db.get("pending_admin_actions", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()
    ]
    education_order_ids = []
    for x in db.get("education_orders", []):
        if not isinstance(x, dict):
            continue
        raw_id = str(x.get("order_id", "")).split("-")[-1]
        if raw_id.isdigit():
            education_order_ids.append(int(raw_id))
    next_ids["lesson"] = max(int(next_ids.get("lesson", 1)), max(lesson_ids, default=0) + 1)
    next_ids["mission"] = max(int(next_ids.get("mission", 1)), max(mission_ids, default=0) + 1)
    next_ids["reward_request"] = max(int(next_ids.get("reward_request", 1)), max(request_ids, default=0) + 1)
    next_ids["faq"] = max(int(next_ids.get("faq", 1)), max(faq_ids, default=0) + 1)
    next_ids["ticket"] = max(int(next_ids.get("ticket", 1)), max(ticket_ids, default=0) + 1)
    next_ids["user_reward"] = max(int(next_ids.get("user_reward", 1)), max(reward_ids, default=0) + 1)
    next_ids["price_alert"] = max(int(next_ids.get("price_alert", 1)), max(alert_ids, default=0) + 1)
    next_ids["signal"] = max(int(next_ids.get("signal", 1)), max(signal_ids, default=0) + 1)
    next_ids["announcement"] = max(int(next_ids.get("announcement", 1)), max(announcement_ids, default=0) + 1)
    next_ids["scheduled_signal"] = max(int(next_ids.get("scheduled_signal", 1)), max(scheduled_signal_ids, default=0) + 1)
    next_ids["admin_approval"] = max(int(next_ids.get("admin_approval", 1)), max(approval_ids, default=0) + 1)
    next_ids["education_order"] = max(int(next_ids.get("education_order", 1)), max(education_order_ids, default=0) + 1)
    incident_ids = [int(x.get("id", 0)) for x in db.get("incidents", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    retention_ids = [int(x.get("id", 0)) for x in db.get("retention_events", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    followup_ids = [int(x.get("id", 0)) for x in db.get("smart_followups", []) if isinstance(x, dict) and str(x.get("id", "")).isdigit()]
    next_ids["incident"] = max(int(next_ids.get("incident", 1)), max(incident_ids, default=0) + 1)
    next_ids["retention_event"] = max(int(next_ids.get("retention_event", 1)), max(retention_ids, default=0) + 1)
    next_ids["smart_followup"] = max(int(next_ids.get("smart_followup", 1)), max(followup_ids, default=0) + 1)
    outcome_event_ids = [
        int(x.get("id", 0))
        for x in db.get("signal_outcome_events", [])
        if isinstance(x, dict) and str(x.get("id", "")).isdigit()
    ]
    reconciliation_ids = [
        int(x.get("id", 0))
        for x in db.get("payment_reconciliations", [])
        if isinstance(x, dict) and str(x.get("id", "")).isdigit()
    ]
    next_ids["signal_outcome_event"] = max(
        int(next_ids.get("signal_outcome_event", 1)),
        max(outcome_event_ids, default=0) + 1,
    )
    next_ids["payment_reconciliation"] = max(
        int(next_ids.get("payment_reconciliation", 1)),
        max(reconciliation_ids, default=0) + 1,
    )

    event_map = {
        "win 1 contest": "win_contest",
        "use risk calculator": "risk_calculator",
        "join chart contest": "join_chart_contest",
    }
    from modules.missions import ALLOWED_EVENTS

    allowed_events = set(ALLOWED_EVENTS)
    for mission in db.get("missions", []):
        if not isinstance(mission, dict):
            continue
        event = str(mission.get("event") or "").strip()
        if not event:
            event = event_map.get(str(mission.get("title", "")).strip().lower(), "manual")
        mission["event"] = event if event in allowed_events else "manual"
        from modules.missions import normalize_mission

        normalize_mission(mission)

    # Preserve unsupported legacy records in an archive after importing supported data.
    legacy_keys = (
        "subscriptions",
        "education",
        "referralLinks",
        "pending_payments",
        "discount_pools",
        "used_discount_codes",
        "saas_config",
        "user_leagues",
        "broadcast_logs",
        "symbols",
        "leaderboard_history",
    )
    archive = db.setdefault("legacy_archive", {})
    for key in legacy_keys:
        value = raw.get(key)
        db.pop(key, None)
        if value not in (None, {}, []):
            archive.setdefault(key, value)
    if not archive:
        db.pop("legacy_archive", None)

    settings = db.setdefault("settings", {})
    for key in ("price", "cardNumber", "cardHolder", "discountCodes"):
        settings.pop(key, None)

    db.setdefault("contest_history", [])
    db.setdefault("user_rewards", [])
    db.setdefault("point_history", [])
    db.setdefault("user_activity", [])
    db.setdefault("user_profiles", {})
    db.setdefault("price_alerts", [])
    db.setdefault("price_alert_history", [])
    db.setdefault("user_bans", {})
    db.setdefault("broadcasts", [])
    db.setdefault("announcements", [])
    db.setdefault("crm_profiles", {})
    db.setdefault("crm_activities", [])
    db.setdefault("crm_automation_log", {})
    db.setdefault("automation_settings", {})
    db.setdefault("automation_log", {})
    db.setdefault("automation_outbox", {})
    db.setdefault("automation_outbox_index", {})
    db.setdefault("automation_contact_log", {})
    db.setdefault("automation_rules_v2", {})
    db.setdefault("automation_v2_idempotency", {})
    db.setdefault("automation_v2_jobs", {})
    db.setdefault("automation_v2_schedule_watermarks", {})
    db.setdefault("automation_v2_dead_letter", [])
    db.setdefault("automation_v2_runs", [])
    db.setdefault("automation_v2_audit", [])
    db.setdefault("automation_v2_event_log", [])
    db.setdefault("automation_tasks", [])
    db.setdefault("automation_ai_drafts", [])
    db.setdefault("automation_custom_log", [])
    db.setdefault("economic_calendar", {"settings": {}})
    db.setdefault("economic_calendar_preferences", {})
    db.setdefault("economic_calendar_notifications", {})
    approval = db.setdefault("approval_settings", {})
    if not isinstance(approval, dict):
        approval = {}
        db["approval_settings"] = approval
    # Persist an explicitly configured policy across reads and restarts.
    # Migration supplies defaults; it must not silently disable approval.
    approval.setdefault("enabled", False)
    approval.setdefault("operations", [])
    db.setdefault("pending_admin_actions", [])
    db.setdefault("admin_shifts", {})
    db.setdefault("education_orders", [])
    db.setdefault("education_access", {})
    db.setdefault("enterprise_control", {})
    db.setdefault("user_notification_preferences", {})
    db.setdefault("notification_defaults", {})
    db.setdefault("league_settings", {})
    db.setdefault("league_seasons", [])
    db.setdefault("league_history", [])
    db.setdefault("support_settings", {})
    db.setdefault("support_canned_replies", [])
    db.setdefault("support_internal_notes", {})
    db.setdefault("faq_feedback", {})
    db.setdefault("user_watchlists", {})
    db.setdefault("trade_journal", {})
    db.setdefault("journal_admin_notes", {})
    db.setdefault("backup_settings", {})
    db.setdefault("health_settings", {})
    db.setdefault("security_settings", {})
    db.setdefault("rules_settings", {})
    db.setdefault("rules_acceptances", {})
    db.setdefault("rules_acceptance_history", [])
    db.setdefault("notification_routing_log", [])
    db.setdefault("admin_today_checklists", {})
    db.setdefault("broadcast_settings", {})
    db.setdefault("referral_settings", {})
    db.setdefault("privacy_settings", {})
    from modules.admin_control_center import ensure_control_center

    ensure_control_center(db)
    db.setdefault("scheduled_signals", [])
    db.setdefault("signal_approvals", [])
    db.setdefault("signal_tracking_proposals", [])
    db.setdefault("signal_versions", {})
    from modules.kpi_trader import ensure_kpi_trader_state

    ensure_kpi_trader_state(db)
    db.setdefault("smart_followups", [])
    db.setdefault("incidents", [])
    db.setdefault("incident_settings", {"notify_critical": True, "dedupe_minutes": 15, "retention_days": 180})
    db.setdefault("retention_events", [])
    db.setdefault("trust_center", {"enabled": True, "latest": {}, "history": []})
    db.setdefault("market_session_settings", {"timezone": "UTC"})
    db.setdefault("price_alert_deliveries", [])
    db.setdefault("signal_archive", [])
    db.setdefault("user_signal_choices", {})
    db.setdefault("trading_accounts", {})
    db.setdefault("user_positions", {})
    db.setdefault("position_audit", {})
    db.setdefault("position_pnl_events", {})
    db.setdefault("signal_revision_acknowledgements", {})
    db.setdefault("behavioral_insights", {})
    db.setdefault("miniapp_event_stream", [])
    records = db.setdefault("miniapp_idempotency_records", {})
    legacy_records = db.setdefault("operations", {}).pop("miniapp_idempotency", None)
    if isinstance(legacy_records, dict):
        for key, value in legacy_records.items():
            records.setdefault(str(key), value)
    db.setdefault("checkout_quotes", {})
    db.setdefault("receipt_uploads", {})
    db.setdefault("miniapp_onboarding", {})
    db.setdefault("signal_replays", {})
    db.setdefault("signal_share_cards", {})
    db.setdefault("security_audit_log", [])
    db.setdefault("next_security_audit_sequence", 1)
    db.setdefault("ai_execution_plans", [])
    db.setdefault("next_ai_execution_plan_id", 1)
    db.setdefault("ai_undo_snapshots", [])
    db.setdefault("signal_team_rules", {})
    signal_lab = db.setdefault("ai_signal_lab", {})
    if not isinstance(signal_lab, dict):
        signal_lab = {}
        db["ai_signal_lab"] = signal_lab
    signal_lab.setdefault("strategies", [])
    signal_lab.setdefault("runs", [])
    signal_lab.setdefault("candidates", [])
    signal_lab.setdefault("next_strategy_id", 1)
    signal_lab.setdefault("next_run_id", 1)
    signal_lab.setdefault("next_candidate_id", 1)
    db.setdefault("market_regime_history", [])
    db.setdefault("shift_handoffs", [])
    db.setdefault("operations_daily_briefs", {})
    db.setdefault("growth_experiments", {})
    db.setdefault("experiment_assignments", {})
    db.setdefault("experiment_events", [])
    channel_management = db.setdefault("channel_management", {})
    if not isinstance(channel_management, dict):
        channel_management = {}
        db["channel_management"] = channel_management
    force_join = channel_management.setdefault("force_join", {})
    if not isinstance(force_join, dict):
        force_join = {}
        channel_management["force_join"] = force_join
    force_join.setdefault("enabled", False)
    force_join.setdefault("channel_id", 0)
    force_join.setdefault("invite_link", "")
    force_join.setdefault("title", "کانال رسمی SENTINEL")
    force_join.setdefault("channels", [])
    force_join.setdefault("require_all", True)
    force_join.setdefault("cache_seconds", 120)
    force_join.setdefault("failure_policy", "grace")
    force_join.setdefault("cache_max_entries", 20000)
    force_join.setdefault("check_concurrency", 8)
    smart_pin = channel_management.setdefault("smart_pin", {})
    if not isinstance(smart_pin, dict):
        smart_pin = {}
        channel_management["smart_pin"] = smart_pin
    smart_pin.setdefault("enabled", True)
    smart_pin.setdefault("public_message_id", None)
    smart_pin.setdefault("private_message_id", None)
    smart_pin.setdefault("updated_at", None)
    live_status = channel_management.setdefault("live_status", {})
    if not isinstance(live_status, dict):
        live_status = {}
        channel_management["live_status"] = live_status
    live_status.setdefault("enabled", True)
    for lesson in db.get("lessons", []):
        if isinstance(lesson, dict):
            lesson.setdefault("access_type", "paid" if lesson.get("paid") else "free")
            lesson.setdefault("price", 0)

    # Normalize the points ledger and reconcile legacy balances exactly once.
    normalized_point_history: list[dict[str, Any]] = []
    point_ids: set[int] = set()
    next_point_id = 1
    for item in db.get("point_history", []):
        if not isinstance(item, dict):
            continue
        uid = str(item.get("user_id") or "").strip()
        if not uid:
            continue
        try:
            amount = int(item.get("amount", 0) or 0)
            candidate = int(item.get("id", 0) or 0)
        except (TypeError, ValueError):
            continue
        if candidate <= 0 or candidate in point_ids:
            while next_point_id in point_ids:
                next_point_id += 1
            candidate = next_point_id
        point_ids.add(candidate)
        next_point_id = max(next_point_id, candidate + 1)
        normalized_point_history.append(
            {
                "id": candidate,
                "user_id": uid,
                "amount": amount,
                "direction": "earned" if amount >= 0 else "spent",
                "balance_after": item.get("balance_after"),
                "source_event": str(item.get("source_event") or f"points:{candidate}"),
                "actor": str(item.get("actor") or "legacy"),
                "reason": str(item.get("reason") or "legacy")[:200],
                "created_at": item.get("created_at") or utc_now_iso(),
            }
        )
    ledger_totals: dict[str, int] = {}
    for item in normalized_point_history:
        ledger_totals[item["user_id"]] = ledger_totals.get(item["user_id"], 0) + int(item["amount"])
    for uid, balance in db.get("user_points", {}).items():
        uid_text = str(uid)
        current = max(0, int(balance or 0))
        delta = current - ledger_totals.get(uid_text, 0)
        if delta:
            normalized_point_history.append(
                {
                    "id": next_point_id,
                    "user_id": uid_text,
                    "amount": delta,
                    "direction": "earned" if delta >= 0 else "spent",
                    "balance_after": current,
                    "reason": "schema_v11_balance_reconciliation",
                    "created_at": utc_now_iso(),
                }
            )
            next_point_id += 1
    db["point_history"] = normalized_point_history
    next_ids["point_transaction"] = max(int(next_ids.get("point_transaction", 1)), next_point_id)

    normalized_activity = [dict(item) for item in db.get("user_activity", []) if isinstance(item, dict)]
    used_activity_ids: set[int] = set()
    next_activity_id = 1
    for item in normalized_activity:
        try:
            candidate = int(item.get("id", 0) or 0)
        except (TypeError, ValueError):
            candidate = 0
        if candidate <= 0 or candidate in used_activity_ids:
            while next_activity_id in used_activity_ids:
                next_activity_id += 1
            candidate = next_activity_id
        used_activity_ids.add(candidate)
        next_activity_id = max(next_activity_id, candidate + 1)
        item["id"] = candidate
        item["user_id"] = str(item.get("user_id") or "")
        item["action"] = str(item.get("action") or "unknown")[:120]
        item["source"] = str(item.get("source") or "bot")[:40]
        item["detail"] = str(item.get("detail") or "")[:500]
        item["metadata"] = item.get("metadata") if isinstance(item.get("metadata"), dict) else {}
        item["created_at"] = item.get("created_at") or utc_now_iso()
    db["user_activity"] = [item for item in normalized_activity if item.get("user_id")][-100000:]
    next_ids["user_activity"] = max(int(next_ids.get("user_activity", 1)), next_activity_id)

    from modules.admin_access import normalize_delegated_admins

    normalize_delegated_admins(db)
    db["contest_history"] = db["contest_history"][-500:]
    # Keep only unsettled price contests plus a small recent closed cache; the
    # complete bounded archive lives in contest_history.
    contests = [item for item in db.get("contests", []) if isinstance(item, dict)]
    unsettled = [item for item in contests if item.get("status") in {"active", "awaiting_result"}]
    closed = [item for item in contests if item.get("status") not in {"active", "awaiting_result"}]
    db["contests"] = unsettled + closed[-20:]
    from modules.user_intelligence import rebuild_all_user_profiles

    rebuild_all_user_profiles(db)
    from modules.signal_portal import ensure_signal_portal

    ensure_signal_portal(db)
    from modules.market_intelligence import ensure_market_intelligence

    ensure_market_intelligence(db)
    from modules.signal_template_editor import (
        default_signal_template_settings,
        sanitize_signal_template_settings,
    )

    current_templates = db.get("signal_template_settings")
    legacy_buy = (
        current_templates.get("buy", {}).get("fields", {}).get("symbol", {}).get("box")
        if isinstance(current_templates, dict)
        else None
    )
    # Schema 22 mapped the owner-approved artwork through coordinates belonging
    # to the previous JPEG. Upgrade only that known legacy layout and preserve
    # any genuinely customized editor layout.
    if legacy_buy == [492, 624, 1092, 704]:
        db["signal_template_settings"] = default_signal_template_settings()
    else:
        db["signal_template_settings"] = sanitize_signal_template_settings(current_templates)
    db.setdefault("broadcast_queue", [])
    db.setdefault("marketing_campaigns", {})
    db.setdefault("campaign_events", [])
    db.setdefault("campaign_audience_snapshots", {})
    db.setdefault("public_channel_links", [])
    db.setdefault("public_channel_link_events", [])
    db.setdefault("public_channel_attribution_users", {})
    for campaign in db["marketing_campaigns"].values():
        if not isinstance(campaign, dict):
            continue
        campaign.setdefault("dispatch_claims", {})
        campaign.setdefault("dispatch_receipts", {})
        campaign.setdefault("touch_index", {})
        campaign.setdefault("previewed_at", None)
        campaign.setdefault("confirmed_at", None)
        campaign.setdefault("confirmed_by", None)
        campaign.setdefault("audience_snapshot_key", "")
        campaign.setdefault("audience_snapshot_count", 0)
        campaign.setdefault("audience_snapshot_sha256", "")
        campaign.setdefault("audience_snapshot_at", None)
        campaign.setdefault("schedule_status", "not_scheduled")
        campaign.setdefault("schedule_priority", 3)
        campaign.setdefault("schedule_attempts", 0)
        campaign.setdefault("schedule_max_attempts", 5)
        campaign.setdefault("schedule_next_attempt_at", campaign.get("scheduled_for"))
        campaign.setdefault("schedule_claimed_at", None)
        campaign.setdefault("schedule_last_error", "")
    for link in db["public_channel_links"]:
        if not isinstance(link, dict):
            continue
        link.setdefault("advertiser", "")
        link.setdefault("source", "")
        link.setdefault("medium", "telegram_invite")
        link.setdefault("creative", "")
        link.setdefault("cost", 0)
    historical_links: dict[str, list[str]] = {}
    for event in db["public_channel_link_events"]:
        if not isinstance(event, dict) or event.get("type") not in {"join", "rejoin"}:
            continue
        uid = str(event.get("user_id") or "")
        link_id = str(event.get("link_id") or "")
        if uid.isdigit() and link_id.isdigit():
            historical_links.setdefault(uid, []).append(link_id)
    for uid, profile in db["public_channel_attribution_users"].items():
        if isinstance(profile, dict):
            profile["link_ids"] = list(
                dict.fromkeys(
                    [
                        *[str(item) for item in profile.get("link_ids", []) if str(item).isdigit()],
                        *historical_links.get(str(uid), []),
                    ]
                )
            )[-100:]
    db.setdefault("privacy_requests", {})
    db.setdefault("privacy_log", [])
    db.setdefault("operations", {"job_status": {}, "metrics": {}, "last_cleanup_at": None})
    if not isinstance(db.get("operations"), dict):
        db["operations"] = {"job_status": {}, "metrics": {}, "last_cleanup_at": None}
    db["operations"].setdefault("job_status", {})
    db["operations"].setdefault("metrics", {})
    for ticket in db.get("tickets", []):
        if not isinstance(ticket, dict):
            continue
        ticket.setdefault("category", "general")
        ticket.setdefault("priority", "normal")
        ticket.setdefault("assigned_admin", "")
        ticket.setdefault("waiting_for", "admin" if ticket.get("status") == "open" else "closed")
        ticket.setdefault("sla_due_at", None)
        ticket.setdefault("satisfaction", None)
    db["schema_version"] = SCHEMA_VERSION
    return db


class DatabaseLoadError(RuntimeError):
    """Raised when the on-disk database cannot be safely loaded or migrated."""


def _validate_canonical_structure(db: dict[str, Any]) -> None:
    dict_sections = (
        "users",
        "vip_settings",
        "vip_users",
        "discount_codes",
        "marketing_campaigns",
        "campaign_audience_snapshots",
        "discount_security",
        "discount_security_settings",
        "affiliate_balances",
        "user_points",
        "user_referrals",
        "user_missions",
        "settings",
        "next_ids",
        "user_bans",
        "delegated_admins",
        "crm_profiles",
        "automation_settings",
        "automation_log",
        "automation_outbox",
        "automation_outbox_index",
        "automation_contact_log",
        "automation_rules_v2",
        "automation_v2_idempotency",
        "automation_v2_jobs",
        "automation_v2_schedule_watermarks",
        "approval_settings",
        "admin_shifts",
        "education_access",
        "user_profiles",
        "channel_management",
        "market_intelligence",
        "signal_cycle",
        "user_signal_choices",
        "privacy_requests",
        "operations",
        "enterprise_control",
        "user_notification_preferences",
        "notification_defaults",
        "league_settings",
        "support_settings",
        "support_internal_notes",
        "faq_feedback",
        "user_watchlists",
        "trade_journal",
        "journal_admin_notes",
        "backup_settings",
        "health_settings",
        "security_settings",
        "broadcast_settings",
        "referral_settings",
        "privacy_settings",
        "personal_risk_profiles",
        "trading_accounts",
        "user_positions",
        "position_audit",
        "position_pnl_events",
        "signal_revision_acknowledgements",
        "behavioral_insights",
        "checkout_quotes",
        "receipt_uploads",
        "miniapp_onboarding",
        "signal_replays",
        "signal_share_cards",
        "operations_daily_briefs",
        "growth_experiments",
        "experiment_assignments",
        "signal_live_cards",
        "retention_settings",
        "provider_health",
        "payment_reconciliation_settings",
        "runtime_safety",
        "rules_settings",
        "rules_acceptances",
        "admin_today_checklists",
        "public_channel_attribution_users",
        "kpi_trader_settings",
        "miniapp_idempotency_records",
    )
    list_sections = (
        "vip_orders",
        "discount_history",
        "discount_events",
        "campaign_events",
        "affiliate_commissions",
        "reward_requests",
        "user_rewards",
        "price_alerts",
        "price_alert_history",
        "broadcasts",
        "broadcast_queue",
        "public_channel_links",
        "public_channel_link_events",
        "privacy_log",
        "lessons",
        "faq",
        "tickets",
        "contests",
        "contest_history",
        "missions",
        "signals",
        "admin_logs",
        "automation_v2_runs",
        "automation_v2_audit",
        "automation_v2_event_log",
        "automation_v2_dead_letter",
        "automation_tasks",
        "automation_ai_drafts",
        "automation_custom_log",
        "pending_admin_actions",
        "education_orders",
        "point_history",
        "user_activity",
        "scheduled_signals",
        "signal_approvals",
        "signal_archive",
        "signal_revisions",
        "signal_outcome_events",
        "kpi_trader_tasks",
        "kpi_trader_submissions",
        "kpi_trader_score_ledger",
        "payment_reconciliations",
        "league_seasons",
        "league_history",
        "support_canned_replies",
        "rules_acceptance_history",
        "notification_routing_log",
        "miniapp_event_stream",
        "market_regime_history",
        "shift_handoffs",
        "experiment_events",
    )
    for key in dict_sections:
        if not isinstance(db.get(key), dict):
            raise ValueError(f"database section {key!r} must be an object")
    for key in list_sections:
        if not isinstance(db.get(key), list):
            raise ValueError(f"database section {key!r} must be an array")

    for uid, user in db["users"].items():
        if not isinstance(user, dict):
            raise ValueError(f"user record {uid!r} must be an object")
    for uid, admin in db["delegated_admins"].items():
        if not isinstance(admin, dict):
            raise ValueError(f"delegated admin record {uid!r} must be an object")
        try:
            if int(uid) <= 0:
                raise ValueError
        except (TypeError, ValueError) as exc:
            raise ValueError(f"delegated admin id {uid!r} is invalid") from exc
        permissions = admin.get("permissions", [])
        if not isinstance(permissions, list):
            raise ValueError(f"delegated admin permissions for {uid!r} must be an array")
    for uid, vip in db["vip_users"].items():
        if not isinstance(vip, dict):
            raise ValueError(f"VIP record {uid!r} must be an object")
    for order in db["vip_orders"]:
        if not isinstance(order, dict):
            raise ValueError("VIP order entries must be objects")
        order_id = str(order.get("order_id") or "").strip()
        user_id = str(order.get("user_id") or "").strip()
        status = str(order.get("status") or "").lower()
        if not order_id or not user_id:
            raise ValueError("VIP orders require order_id and user_id")
        try:
            int(user_id)
            order["price"] = max(0, int(str(order.get("price", 0) or 0).replace(",", "")))
            order["base_price"] = max(0, int(str(order.get("base_price", order["price"]) or 0).replace(",", "")))
            order["discount_percent"] = min(100, max(0, int(order.get("discount_percent", 0) or 0)))
            order["discount_configured_percent"] = min(100, max(0, int(order.get("discount_configured_percent", order["discount_percent"]) or 0)))
            order["discount_amount"] = max(0, int(str(order.get("discount_amount", max(0, order["base_price"] - order["price"])) or 0).replace(",", "")))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"VIP order {order_id!r} contains invalid numeric fields") from exc
        if status not in {"pending", "approving", "approved", "rejected", "cancelled", "expired"}:
            raise ValueError(f"VIP order {order_id!r} has invalid status")
        order["order_id"] = order_id
        order["user_id"] = int(user_id)
        order["status"] = status
        method = str(order.get("payment_method") or "card").strip().lower()
        if method not in {"card", "usdt"}:
            raise ValueError(f"VIP order {order_id!r} has invalid payment method")
        order["payment_method"] = method
        if method == "usdt":
            order["payment_network"] = str(order.get("payment_network") or "TRC20").strip().upper()[:32]
            order["payment_wallet"] = str(order.get("payment_wallet") or "").strip()[:160]
            order["payment_amount_usdt"] = str(order.get("payment_amount_usdt") or "0")[:32]
            try:
                order["payment_rate_toman"] = max(0.0, float(order.get("payment_rate_toman", 0) or 0))
            except (TypeError, ValueError) as exc:
                raise ValueError(f"VIP order {order_id!r} has invalid USDT rate") from exc
            txid = str(order.get("transaction_hash") or "").strip().lower().removeprefix("0x")
            if txid and not re.fullmatch(r"[0-9a-f]{64}", txid):
                raise ValueError(f"VIP order {order_id!r} has invalid transaction hash")
            order["transaction_hash"] = txid
            order["verification_status"] = str(order.get("verification_status") or ("manual_review" if txid else "not_submitted"))[:32]
            order["verification_provider"] = str(order.get("verification_provider") or "")[:80]
            order["verification_reason"] = str(order.get("verification_reason") or "")[:500]
            order["quote_expires_at"] = order.get("quote_expires_at")

    settings = db["vip_settings"]
    try:
        settings["price"] = max(0, int(settings.get("price", 0) or 0))
        settings["duration_days"] = max(1, int(settings.get("duration_days", 30) or 30))
        settings["usdt_rate_toman"] = max(0.0, float(settings.get("usdt_rate_toman", 0) or 0))
    except (TypeError, ValueError) as exc:
        raise ValueError("vip_settings contains invalid numeric values") from exc
    settings["usdt_enabled"] = bool(settings.get("usdt_enabled", False))
    settings["usdt_wallet_address"] = str(settings.get("usdt_wallet_address") or "").strip()[:160]
    settings["usdt_network"] = str(settings.get("usdt_network") or "TRC20").strip().upper()[:32] or "TRC20"
    settings["usdt_rate_updated_at"] = settings.get("usdt_rate_updated_at")
    settings["usdt_quote_valid_minutes"] = max(5, min(1440, int(settings.get("usdt_quote_valid_minutes", 30) or 30)))
    settings["usdt_verification_enabled"] = bool(settings.get("usdt_verification_enabled", False))
    seen_txids: set[str] = set()
    for order in db["vip_orders"]:
        txid = str(order.get("transaction_hash") or "")
        if not txid:
            continue
        if txid in seen_txids:
            raise ValueError(f"duplicate USDT transaction hash: {txid}")
        seen_txids.add(txid)

    for uid, value in list(db["user_points"].items()):
        try:
            db["user_points"][str(uid)] = max(0, int(value or 0))
        except (TypeError, ValueError) as exc:
            raise ValueError(f"points for user {uid!r} are invalid") from exc
        if str(uid) != uid:
            db["user_points"].pop(uid, None)


def validate_database_payload(raw: Any) -> dict[str, Any]:
    """Return a canonical JSON-safe database or raise without modifying any file.

    Relational storage already persists the current canonical schema section by
    section. Re-running the full legacy migration on every mutation deep-copied
    the complete database (including every user) before validation. For an
    already-current payload we can safely validate it in place and reserve the
    expensive migration path for old/incomplete snapshots loaded from legacy
    storage or backups.
    """
    if not isinstance(raw, dict):
        raise ValueError("database root must be an object")
    try:
        current_schema = int(raw.get("schema_version", 0) or 0) == SCHEMA_VERSION
    except (TypeError, ValueError):
        current_schema = False
    has_current_shape = current_schema and all(key in raw for key in DEFAULT_DB)
    migrated = raw if has_current_shape else migrate_db(raw)
    _validate_canonical_structure(migrated)
    json.dumps(migrated, ensure_ascii=False, allow_nan=False)
    return migrated


class JsonStore:
    def __init__(self, path: Path, backup_dir: Path):
        self.path = path
        self.backup_dir = backup_dir

    def _read(self) -> dict[str, Any]:
        """Read and migrate the database, failing closed on any corruption.

        A production bot must never silently replace malformed user/VIP/order data
        with an empty database. The original file remains untouched so an operator
        can restore a backup or repair it deliberately.
        """
        if not self.path.exists():
            return copy.deepcopy(DEFAULT_DB)
        try:
            with self.path.open("r", encoding="utf-8") as handle:
                raw = json.load(handle)
            return validate_database_payload(unprotect_sensitive_payload(raw, SETTINGS.sensitive_data_key))
        except Exception as exc:
            logger.exception("Database read or migration failed; startup is blocked to protect existing data")
            raise DatabaseLoadError(
                f"Database validation failed for {self.path}. The file was left unchanged; restore a backup or repair it."
            ) from exc

    def _backup_if_needed(self) -> None:
        global _LAST_BACKUP_DATE
        if not self.path.exists():
            return
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        if _LAST_BACKUP_DATE == today:
            return
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        target = self.backup_dir / f"database-{today}.json"
        if not target.exists():
            shutil.copy2(self.path, target)
        _LAST_BACKUP_DATE = today
        backups = sorted(self.backup_dir.glob("database-*.json"), reverse=True)
        for old in backups[7:]:
            old.unlink(missing_ok=True)

    def write(self, data: dict[str, Any]) -> None:
        canonical = validate_database_payload(data)
        protected = protect_sensitive_payload(canonical, SETTINGS.sensitive_data_key)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._backup_if_needed()
        fd, temp_name = tempfile.mkstemp(prefix=f".{self.path.name}.", suffix=".tmp", dir=self.path.parent)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(protected, handle, ensure_ascii=False, indent=2, allow_nan=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp_name, self.path)
            try:
                os.chmod(self.path, 0o600)
            except OSError:
                pass
        finally:
            if os.path.exists(temp_name):
                os.unlink(temp_name)


def next_id(db: dict[str, Any], namespace: str) -> int:
    ids = db.setdefault("next_ids", {})
    value = int(ids.get(namespace, 1))
    ids[namespace] = value + 1
    return value


_INDEX_SOURCE_KEYS = (
    "users",
    "vip_users",
    "user_points",
    "vip_orders",
    "education_orders",
    "signals",
    "tickets",
)


def _secure_transaction_index(value: Any) -> str:
    normalized = str(value or "").strip().lower().removeprefix("0x")
    if not normalized:
        return ""
    if not encryption_ready(SETTINGS.sensitive_data_key):
        return normalized
    return f"sha256:{hashlib.sha256(normalized.encode('utf-8')).hexdigest()}"


def _index_source_snapshot(data: dict[str, Any]) -> dict[str, Any]:
    """Copy only canonical sections that feed relational search indexes."""
    return {key: copy.deepcopy(data.get(key)) for key in _INDEX_SOURCE_KEYS}


def _index_sources_changed(before: dict[str, Any], after: dict[str, Any]) -> bool:
    return any(before.get(key) != after.get(key) for key in _INDEX_SOURCE_KEYS)


class SQLiteStore:
    """SQLite WAL-backed canonical store with normalized read indexes.

    The application still receives the established dictionary schema, so existing
    handlers remain compatible. Writes are serialized by SQLite across processes,
    while mirror tables make operational queries and future PostgreSQL migration
    straightforward.
    """

    def __init__(self, path: Path, backup_dir: Path, legacy_json: Path | None = None):
        self.path = path
        self.backup_dir = backup_dir
        self.legacy_json = legacy_json
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._initialize()
        from core.economy_integrity import create_schema
        with closing(self._connect()) as connection:
            create_schema(connection.cursor())

    def _connect(self) -> sqlite3.Connection:
        connection = sqlite3.connect(self.path, timeout=30, isolation_level=None)
        try:
            connection.row_factory = sqlite3.Row
            connection.execute("PRAGMA journal_mode=WAL")
            connection.execute("PRAGMA synchronous=NORMAL")
            connection.execute("PRAGMA foreign_keys=ON")
            connection.execute("PRAGMA busy_timeout=30000")
            return connection
        except BaseException:
            connection.close()
            raise

    def _initialize(self) -> None:
        with closing(self._connect()) as connection:
            connection.executescript(
                """
                CREATE TABLE IF NOT EXISTS app_state (
                    id INTEGER PRIMARY KEY CHECK (id = 1),
                    version INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS schema_migrations (
                    version INTEGER PRIMARY KEY,
                    applied_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS users_index (
                    user_id TEXT PRIMARY KEY,
                    username TEXT,
                    display_name TEXT,
                    vip_active INTEGER NOT NULL DEFAULT 0,
                    points INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT
                );
                CREATE TABLE IF NOT EXISTS orders_index (
                    order_id TEXT PRIMARY KEY,
                    kind TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    amount INTEGER NOT NULL DEFAULT 0,
                    payment_method TEXT,
                    transaction_hash TEXT,
                    verification_status TEXT,
                    created_at TEXT,
                    updated_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_orders_user_status
                    ON orders_index(user_id, status);
                CREATE TABLE IF NOT EXISTS signals_index (
                    signal_id INTEGER PRIMARY KEY,
                    symbol TEXT NOT NULL,
                    side TEXT,
                    status TEXT NOT NULL,
                    cycle_id INTEGER,
                    created_at TEXT,
                    updated_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_signals_symbol_status
                    ON signals_index(symbol, status);
                CREATE TABLE IF NOT EXISTS tickets_index (
                    ticket_id INTEGER PRIMARY KEY,
                    user_id TEXT NOT NULL,
                    status TEXT NOT NULL,
                    priority TEXT,
                    category TEXT,
                    assigned_admin TEXT,
                    updated_at TEXT
                );
                CREATE INDEX IF NOT EXISTS idx_tickets_status_priority
                    ON tickets_index(status, priority, updated_at);

                CREATE TABLE IF NOT EXISTS storage_meta (
                    key TEXT PRIMARY KEY,
                    value TEXT NOT NULL,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS section_registry (
                    section_key TEXT PRIMARY KEY,
                    domain TEXT NOT NULL,
                    container_type TEXT NOT NULL,
                    checksum TEXT NOT NULL,
                    record_count INTEGER NOT NULL DEFAULT 0,
                    updated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS legacy_state_archive (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    source_version INTEGER NOT NULL,
                    payload TEXT NOT NULL,
                    migrated_at TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS user_accounts (
                    user_id TEXT PRIMARY KEY,
                    username TEXT,
                    first_name TEXT,
                    last_name TEXT,
                    display_name TEXT,
                    language_code TEXT,
                    created_at TEXT,
                    last_seen_at TEXT,
                    updated_at TEXT,
                    payload TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_user_accounts_username ON user_accounts(username);
                CREATE INDEX IF NOT EXISTS idx_user_accounts_last_seen ON user_accounts(last_seen_at);
                CREATE TABLE IF NOT EXISTS user_profiles_rel (
                    user_id TEXT PRIMARY KEY,
                    phone TEXT,
                    email TEXT,
                    source TEXT,
                    company TEXT,
                    preferred_market TEXT,
                    preferred_contact TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    payload TEXT NOT NULL
                );
                CREATE TABLE IF NOT EXISTS user_memberships (
                    user_id TEXT PRIMARY KEY,
                    status TEXT,
                    plan_id TEXT,
                    starts_at TEXT,
                    expires_at TEXT,
                    updated_at TEXT,
                    payload TEXT NOT NULL
                );
                CREATE INDEX IF NOT EXISTS idx_user_memberships_status_expiry
                    ON user_memberships(status, expires_at);
                CREATE TABLE IF NOT EXISTS user_preferences (
                    section_key TEXT NOT NULL,
                    user_id TEXT NOT NULL,
                    payload TEXT NOT NULL,
                    updated_at TEXT NOT NULL,
                    PRIMARY KEY(section_key, user_id)
                );
                CREATE INDEX IF NOT EXISTS idx_user_preferences_user ON user_preferences(user_id);
                CREATE TABLE IF NOT EXISTS user_records (
                    section_key TEXT NOT NULL,
                    record_key TEXT NOT NULL,
                    position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT,
                    status TEXT,
                    created_at TEXT,
                    updated_at TEXT,
                    payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE INDEX IF NOT EXISTS idx_user_records_user_section
                    ON user_records(user_id, section_key);
                CREATE INDEX IF NOT EXISTS idx_user_records_status
                    ON user_records(section_key, status);

                CREATE TABLE IF NOT EXISTS commerce_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS signal_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS crm_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS market_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS channel_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS content_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS support_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS security_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE TABLE IF NOT EXISTS system_records (
                    section_key TEXT NOT NULL, record_key TEXT NOT NULL, position INTEGER NOT NULL DEFAULT 0,
                    user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload TEXT NOT NULL,
                    PRIMARY KEY(section_key, record_key)
                );
                CREATE INDEX IF NOT EXISTS idx_commerce_records_user_status ON commerce_records(user_id, status);
                CREATE INDEX IF NOT EXISTS idx_signal_records_status ON signal_records(section_key, status);
                CREATE INDEX IF NOT EXISTS idx_crm_records_user_status ON crm_records(user_id, status);
                CREATE INDEX IF NOT EXISTS idx_market_records_user_status ON market_records(user_id, status);
                CREATE INDEX IF NOT EXISTS idx_channel_records_status ON channel_records(section_key, status);
                CREATE INDEX IF NOT EXISTS idx_content_records_status ON content_records(section_key, status);
                CREATE INDEX IF NOT EXISTS idx_support_records_user_status ON support_records(user_id, status);
                CREATE INDEX IF NOT EXISTS idx_security_records_user ON security_records(user_id, section_key);
                CREATE VIEW IF NOT EXISTS user_master AS
                SELECT
                    ua.user_id AS user_id,
                    ua.username AS username,
                    ua.display_name AS display_name,
                    up.phone AS phone,
                    up.email AS email,
                    up.source AS source,
                    up.company AS company,
                    up.preferred_market AS preferred_market,
                    up.preferred_contact AS preferred_contact,
                    um.status AS vip_status,
                    um.plan_id AS vip_plan_id,
                    um.expires_at AS vip_expires_at,
                    COALESCE(ui.points, 0) AS points,
                    ua.created_at AS created_at,
                    ua.last_seen_at AS last_seen_at,
                    ua.updated_at AS updated_at,
                    ua.payload AS account_payload,
                    up.payload AS profile_payload,
                    um.payload AS membership_payload
                FROM user_accounts ua
                LEFT JOIN user_profiles_rel up ON up.user_id = ua.user_id
                LEFT JOIN user_memberships um ON um.user_id = ua.user_id
                LEFT JOIN users_index ui ON ui.user_id = ua.user_id;
                """
            )
            order_columns = {str(row["name"]) for row in connection.execute("PRAGMA table_info(orders_index)")}
            for column, sql_type in (
                ("payment_method", "TEXT"),
                ("transaction_hash", "TEXT"),
                ("verification_status", "TEXT"),
                ("updated_at", "TEXT"),
            ):
                if column not in order_columns:
                    connection.execute(f"ALTER TABLE orders_index ADD COLUMN {column} {sql_type}")
            connection.execute(
                "CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_txid_unique "
                "ON orders_index(transaction_hash) WHERE transaction_hash IS NOT NULL AND transaction_hash <> ''"
            )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES(1, ?)",
                (utc_now_iso(),),
            )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES(2, ?)",
                (utc_now_iso(),),
            )
            row = connection.execute("SELECT id FROM app_state WHERE id = 1").fetchone()
            if row is None:
                initial = self._initial_payload()
                payload = json.dumps(initial, ensure_ascii=False, separators=(",", ":"), allow_nan=False)
                connection.execute("BEGIN IMMEDIATE")
                try:
                    connection.execute(
                        "INSERT INTO app_state(id, version, payload, updated_at) VALUES(1, 1, ?, ?)",
                        (payload, utc_now_iso()),
                    )
                    self._sync_indexes(connection, initial)
                    connection.execute("COMMIT")
                except Exception:
                    connection.execute("ROLLBACK")
                    raise
            self._ensure_categorized_storage(connection)
        try:
            os.chmod(self.path, 0o600)
        except OSError:
            pass

    def _initial_payload(self) -> dict[str, Any]:
        candidates = [self.legacy_json, self.path.with_name("database.json")]
        for candidate in candidates:
            if candidate and candidate.is_file():
                try:
                    with candidate.open("r", encoding="utf-8") as handle:
                        return validate_database_payload(json.load(handle))
                except Exception as exc:
                    raise DatabaseLoadError(f"Legacy database validation failed for {candidate}; migration was stopped.") from exc
        return copy.deepcopy(DEFAULT_DB)

    @staticmethod
    def _categorized_table(section_key: str) -> str:
        if section_key == USER_ACCOUNT_SECTION:
            return "user_accounts"
        if section_key == USER_PROFILE_SECTION:
            return "user_profiles_rel"
        if section_key == USER_MEMBERSHIP_SECTION:
            return "user_memberships"
        if section_key in USER_PREFERENCE_SECTIONS:
            return "user_preferences"
        if section_key in USER_RECORD_SECTIONS:
            return "user_records"
        return DOMAIN_TABLES[section_domain(section_key)]

    @staticmethod
    def _json_load_sqlite(value: Any) -> Any:
        if isinstance(value, str):
            return json.loads(value)
        return value

    def _delete_categorized_section(self, connection: sqlite3.Connection, section_key: str) -> None:
        table = self._categorized_table(section_key)
        if table in {"user_accounts", "user_profiles_rel", "user_memberships"}:
            connection.execute(f"DELETE FROM {table}")  # nosec B608 -- fixed allowlisted table
        else:
            connection.execute(f"DELETE FROM {table} WHERE section_key = ?", (section_key,))  # nosec B608

    def _insert_categorized_section(self, connection: sqlite3.Connection, section_key: str, value: Any) -> int:
        now = utc_now_iso()
        if section_key == USER_ACCOUNT_SECTION:
            count = 0
            for user_id, payload in value.items() if isinstance(value, dict) else []:
                item = payload if isinstance(payload, dict) else {"value": payload}
                connection.execute(
                    """INSERT INTO user_accounts(
                        user_id, username, first_name, last_name, display_name, language_code,
                        created_at, last_seen_at, updated_at, payload
                    ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        str(user_id),
                        str(item.get("username") or "")[:64],
                        str(item.get("first_name") or "")[:200],
                        str(item.get("last_name") or "")[:200],
                        relational_display_name(item),
                        str(item.get("language_code") or "")[:32],
                        str(item.get("created_at") or ""),
                        str(item.get("last_seen_at") or ""),
                        str(item.get("updated_at") or item.get("last_seen_at") or now),
                        json_text(payload),
                    ),
                )
                count += 1
            return count
        if section_key == USER_PROFILE_SECTION:
            count = 0
            for user_id, payload in value.items() if isinstance(value, dict) else []:
                item = payload if isinstance(payload, dict) else {"value": payload}
                connection.execute(
                    """INSERT INTO user_profiles_rel(
                        user_id, phone, email, source, company, preferred_market, preferred_contact,
                        created_at, updated_at, payload
                    ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        str(user_id),
                        str(item.get("phone") or item.get("phone_number") or "")[:64],
                        str(item.get("email") or "")[:254],
                        str(item.get("source") or item.get("lead_source") or "")[:128],
                        str(item.get("company") or "")[:200],
                        str(item.get("preferred_market") or "")[:100],
                        str(item.get("preferred_contact") or "")[:64],
                        str(item.get("created_at") or ""),
                        str(item.get("updated_at") or now),
                        json_text(payload),
                    ),
                )
                count += 1
            return count
        if section_key == USER_MEMBERSHIP_SECTION:
            count = 0
            for user_id, payload in value.items() if isinstance(value, dict) else []:
                item = payload if isinstance(payload, dict) else {"value": payload}
                connection.execute(
                    """INSERT INTO user_memberships(
                        user_id, status, plan_id, starts_at, expires_at, updated_at, payload
                    ) VALUES(?,?,?,?,?,?,?)""",
                    (
                        str(user_id),
                        str(item.get("status") or "")[:64],
                        str(item.get("plan_id") or item.get("plan") or "")[:128],
                        str(item.get("starts_at") or item.get("start_at") or ""),
                        str(item.get("expires_at") or item.get("expiry") or ""),
                        str(item.get("updated_at") or item.get("approved_at") or now),
                        json_text(payload),
                    ),
                )
                count += 1
            return count
        if section_key in USER_PREFERENCE_SECTIONS:
            count = 0
            for user_id, payload in value.items() if isinstance(value, dict) else []:
                connection.execute(
                    "INSERT INTO user_preferences(section_key, user_id, payload, updated_at) VALUES(?,?,?,?)",
                    (section_key, str(user_id), json_text(payload), now),
                )
                count += 1
            return count

        table = self._categorized_table(section_key)
        count = 0
        for row in iter_section_records(value):
            user_id = row.user_id or user_id_from_key_or_payload(row.record_key, row.payload)
            if table != "user_records" and not row.user_id:
                user_id = ""
            connection.execute(
                f"""INSERT INTO {table}(
                    section_key, record_key, position, user_id, status, created_at, updated_at, payload
                ) VALUES(?,?,?,?,?,?,?,?)""",  # nosec B608 -- fixed allowlisted table
                (
                    section_key,
                    row.record_key,
                    row.position,
                    user_id,
                    row.status,
                    row.created_at,
                    row.updated_at or now,
                    json_text(row.payload),
                ),
            )
            count += 1
        return count

    def _sync_categorized(self, connection: sqlite3.Connection, data: dict[str, Any], *, force: bool = False) -> None:
        data = protect_sensitive_payload(data, SETTINGS.sensitive_data_key)
        existing = {
            str(row["section_key"]): str(row["checksum"])
            for row in connection.execute("SELECT section_key, checksum FROM section_registry")
        }
        now = utc_now_iso()
        for section_key, value in data.items():
            checksum = section_checksum(value)
            if not force and existing.get(section_key) == checksum:
                continue
            self._delete_categorized_section(connection, section_key)
            count = self._insert_categorized_section(connection, section_key, value)
            if section_key == USER_ACCOUNT_SECTION:
                domain = "user_accounts"
            elif section_key == USER_PROFILE_SECTION:
                domain = "user_profiles"
            elif section_key == USER_MEMBERSHIP_SECTION:
                domain = "user_memberships"
            elif section_key in USER_PREFERENCE_SECTIONS:
                domain = "user_preferences"
            elif section_key in USER_RECORD_SECTIONS:
                domain = "user_records"
            else:
                domain = section_domain(section_key)
            connection.execute(
                """INSERT INTO section_registry(section_key, domain, container_type, checksum, record_count, updated_at)
                VALUES(?,?,?,?,?,?)
                ON CONFLICT(section_key) DO UPDATE SET
                    domain=excluded.domain, container_type=excluded.container_type,
                    checksum=excluded.checksum, record_count=excluded.record_count, updated_at=excluded.updated_at""",
                (section_key, domain, container_type(value), checksum, count, now),
            )
        removed = set(existing) - set(data)
        for section_key in removed:
            self._delete_categorized_section(connection, section_key)
            connection.execute("DELETE FROM section_registry WHERE section_key = ?", (section_key,))

    def _read_categorized(self, connection: sqlite3.Connection) -> dict[str, Any]:
        result: dict[str, Any] = {}
        registry = connection.execute(
            "SELECT section_key, domain, container_type FROM section_registry ORDER BY section_key"
        ).fetchall()
        for meta in registry:
            section_key = str(meta["section_key"])
            kind = str(meta["container_type"])
            if section_key == USER_ACCOUNT_SECTION:
                rows = connection.execute("SELECT user_id, payload FROM user_accounts ORDER BY user_id").fetchall()
                result[section_key] = {str(row["user_id"]): self._json_load_sqlite(row["payload"]) for row in rows}
                continue
            if section_key == USER_PROFILE_SECTION:
                rows = connection.execute("SELECT user_id, payload FROM user_profiles_rel ORDER BY user_id").fetchall()
                result[section_key] = {str(row["user_id"]): self._json_load_sqlite(row["payload"]) for row in rows}
                continue
            if section_key == USER_MEMBERSHIP_SECTION:
                rows = connection.execute("SELECT user_id, payload FROM user_memberships ORDER BY user_id").fetchall()
                result[section_key] = {str(row["user_id"]): self._json_load_sqlite(row["payload"]) for row in rows}
                continue
            if section_key in USER_PREFERENCE_SECTIONS:
                rows = connection.execute(
                    "SELECT user_id, payload FROM user_preferences WHERE section_key = ? ORDER BY user_id",
                    (section_key,),
                ).fetchall()
                result[section_key] = {str(row["user_id"]): self._json_load_sqlite(row["payload"]) for row in rows}
                continue
            table = self._categorized_table(section_key)
            rows = connection.execute(
                f"SELECT record_key, position, payload FROM {table} WHERE section_key = ? ORDER BY position, record_key",  # nosec B608
                (section_key,),
            ).fetchall()
            result[section_key] = reconstruct_section(
                kind,
                ((str(row["record_key"]), int(row["position"]), self._json_load_sqlite(row["payload"])) for row in rows),
            )
        return validate_database_payload(unprotect_sensitive_payload(result, SETTINGS.sensitive_data_key))

    def _ensure_categorized_storage(self, connection: sqlite3.Connection) -> None:
        active = connection.execute("SELECT value FROM storage_meta WHERE key = 'relational_active'").fetchone()
        if active and str(active["value"]) == "1":
            if encryption_ready(SETTINGS.sensitive_data_key):
                protected = connection.execute(
                    "SELECT value FROM storage_meta WHERE key = 'sensitive_indexes_v1'"
                ).fetchone()
                if not protected or str(protected["value"]) != "1":
                    self._sync_indexes(connection, self._read_categorized(connection))
                    connection.execute(
                        """INSERT INTO storage_meta(key, value, updated_at) VALUES('sensitive_indexes_v1', '1', ?)
                        ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                        (utc_now_iso(),),
                    )
            return
        row = connection.execute("SELECT version, payload FROM app_state WHERE id = 1").fetchone()
        if row is None:
            raise DatabaseLoadError("SQLite legacy state row is missing during categorized migration")
        raw = validate_database_payload(json.loads(str(row["payload"])))
        connection.execute("BEGIN IMMEDIATE")
        try:
            archive_count = connection.execute("SELECT COUNT(*) AS count FROM legacy_state_archive").fetchone()
            if not archive_count or int(archive_count["count"]) == 0:
                connection.execute(
                    "INSERT INTO legacy_state_archive(source_version, payload, migrated_at) VALUES(?,?,?)",
                    (int(row["version"]), json_text(raw), utc_now_iso()),
                )
            self._sync_categorized(connection, raw, force=True)
            now = utc_now_iso()
            for key, value in (
                ("relational_active", "1"),
                ("relational_storage_version", str(RELATIONAL_STORAGE_VERSION)),
                ("state_version", str(int(row["version"]))),
            ):
                connection.execute(
                    """INSERT INTO storage_meta(key, value, updated_at) VALUES(?,?,?)
                    ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
                    (key, value, now),
                )
            manifest = {
                "storage": "categorized",
                "schema_version": SCHEMA_VERSION,
                "relational_storage_version": RELATIONAL_STORAGE_VERSION,
                "legacy_archive_available": True,
                "migrated_at": now,
            }
            connection.execute(
                "UPDATE app_state SET payload = ?, updated_at = ? WHERE id = 1",
                (json_text(manifest), now),
            )
            connection.execute(
                "INSERT OR IGNORE INTO schema_migrations(version, applied_at) VALUES(3, ?)",
                (now,),
            )
            connection.execute("COMMIT")
        except Exception:
            connection.execute("ROLLBACK")
            raise

    def _increment_state_version(self, connection: sqlite3.Connection) -> int:
        row = connection.execute("SELECT value FROM storage_meta WHERE key = 'state_version'").fetchone()
        version = int(row["value"]) + 1 if row else 1
        now = utc_now_iso()
        connection.execute(
            """INSERT INTO storage_meta(key, value, updated_at) VALUES('state_version', ?, ?)
            ON CONFLICT(key) DO UPDATE SET value=excluded.value, updated_at=excluded.updated_at""",
            (str(version), now),
        )
        connection.execute("UPDATE app_state SET version = ?, updated_at = ? WHERE id = 1", (version, now))
        return version

    def version(self) -> int:
        with closing(self._connect()) as connection:
            self._ensure_categorized_storage(connection)
            row = connection.execute("SELECT value FROM storage_meta WHERE key = 'state_version'").fetchone()
            return int(row["value"]) if row else 0

    def _read(self) -> dict[str, Any]:
        with closing(self._connect()) as connection:
            try:
                self._ensure_categorized_storage(connection)
                connection.execute("BEGIN")
                try:
                    result = self._read_categorized(connection)
                    connection.execute("COMMIT")
                    return result
                except BaseException:
                    connection.execute("ROLLBACK")
                    raise
            except Exception as exc:
                logger.exception("SQLite categorized database failed validation")
                raise DatabaseLoadError(f"SQLite database validation failed for {self.path}") from exc

    def _backup_if_needed(self, connection: sqlite3.Connection) -> None:
        global _LAST_BACKUP_DATE
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        if _LAST_BACKUP_DATE == today:
            return
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        target = self.backup_dir / f"sentinel-{today}.sqlite3"
        if not target.exists():
            destination = sqlite3.connect(target)
            try:
                connection.backup(destination)
            finally:
                destination.close()
            try:
                os.chmod(target, 0o600)
            except OSError:
                pass
        json_target = self.backup_dir / f"database-{today}.json"
        if not json_target.exists():
            snapshot_data = protect_sensitive_payload(
                self._read_categorized(connection),
                SETTINGS.sensitive_data_key,
            )
            json_target.write_text(
                json.dumps(snapshot_data, ensure_ascii=False, indent=2, allow_nan=False),
                encoding="utf-8",
            )
        _LAST_BACKUP_DATE = today
        for pattern in ("sentinel-*.sqlite3", "database-*.json"):
            backups = sorted(self.backup_dir.glob(pattern), reverse=True)
            for old in backups[14:]:
                old.unlink(missing_ok=True)

    @staticmethod
    def _display_name(user: dict[str, Any]) -> str:
        return str(
            user.get("full_name") or user.get("name") or " ".join(filter(None, [user.get("first_name"), user.get("last_name")])) or ""
        )[:200]

    @staticmethod
    def _delete_missing(connection: sqlite3.Connection, table: str, column: str, values: set[str | int]) -> None:
        if not values:
            connection.execute(f"DELETE FROM {table}")  # nosec B608
            return
        placeholders = ",".join("?" for _ in values)
        connection.execute(
            f"DELETE FROM {table} WHERE {column} NOT IN ({placeholders})",  # nosec B608
            tuple(values),
        )

    def _sync_indexes(self, connection: sqlite3.Connection, data: dict[str, Any]) -> None:
        desired_users: set[str | int] = set()
        desired_orders: set[str | int] = set()
        desired_signals: set[str | int] = set()
        desired_tickets: set[str | int] = set()
        vip_users = data.get("vip_users", {})
        points = data.get("user_points", {})
        users = data.get("users", {})
        now = utc_now_iso()
        for uid, user in users.items():
            if not isinstance(user, dict):
                continue
            vip = vip_users.get(str(uid), {}) if isinstance(vip_users, dict) else {}
            desired_users.add(str(uid))
            connection.execute(
                "INSERT OR REPLACE INTO users_index(user_id, username, display_name, vip_active, points, updated_at) VALUES(?,?,?,?,?,?)",
                (
                    str(uid),
                    str(user.get("username") or "")[:64],
                    self._display_name(user),
                    1 if isinstance(vip, dict) and vip.get("status") == "active" else 0,
                    int(points.get(str(uid), 0) or 0) if isinstance(points, dict) else 0,
                    str(user.get("updated_at") or user.get("last_seen_at") or now),
                ),
            )
        for kind, rows in (("vip", data.get("vip_orders", [])), ("education", data.get("education_orders", []))):
            for order in rows if isinstance(rows, list) else []:
                if not isinstance(order, dict):
                    continue
                order_id = str(order.get("order_id") or order.get("id") or "")
                if not order_id:
                    continue
                amount = order.get("price", order.get("amount", 0))
                try:
                    amount_value = int(float(str(amount).replace(",", "")))
                except (TypeError, ValueError):
                    amount_value = 0
                desired_orders.add(order_id)
                connection.execute(
                    """INSERT OR REPLACE INTO orders_index(
                        order_id, kind, user_id, status, amount, payment_method, transaction_hash,
                        verification_status, created_at, updated_at
                    ) VALUES(?,?,?,?,?,?,?,?,?,?)""",
                    (
                        order_id,
                        kind,
                        str(order.get("user_id") or ""),
                        str(order.get("status") or "unknown"),
                        max(0, amount_value),
                        str(order.get("payment_method") or ""),
                        _secure_transaction_index(order.get("transaction_hash")),
                        str(order.get("verification_status") or ""),
                        str(order.get("created_at") or ""),
                        str(order.get("updated_at") or order.get("approved_at") or ""),
                    ),
                )
        for signal in data.get("signals", []):
            if not isinstance(signal, dict):
                continue
            try:
                signal_id = int(signal.get("id"))
            except (TypeError, ValueError):
                continue
            desired_signals.add(signal_id)
            connection.execute(
                "INSERT OR REPLACE INTO signals_index(signal_id, symbol, side, status, cycle_id, created_at, updated_at) VALUES(?,?,?,?,?,?,?)",
                (
                    signal_id,
                    str(signal.get("symbol") or "").upper(),
                    str(signal.get("side") or ""),
                    str(signal.get("status") or "open"),
                    int(signal.get("cycle_id", 1) or 1),
                    str(signal.get("created_at") or ""),
                    str(signal.get("updated_at") or signal.get("result_updated_at") or ""),
                ),
            )
        for ticket in data.get("tickets", []):
            if not isinstance(ticket, dict):
                continue
            try:
                ticket_id = int(ticket.get("id"))
            except (TypeError, ValueError):
                continue
            desired_tickets.add(ticket_id)
            connection.execute(
                "INSERT OR REPLACE INTO tickets_index(ticket_id, user_id, status, priority, category, assigned_admin, updated_at) VALUES(?,?,?,?,?,?,?)",
                (
                    ticket_id,
                    str(ticket.get("user_id") or ""),
                    str(ticket.get("status") or "open"),
                    str(ticket.get("priority") or "normal"),
                    str(ticket.get("category") or "general"),
                    str(ticket.get("assigned_admin") or ""),
                    str(ticket.get("updated_at") or ""),
                ),
            )
        self._delete_missing(connection, "users_index", "user_id", desired_users)
        self._delete_missing(connection, "orders_index", "order_id", desired_orders)
        self._delete_missing(connection, "signals_index", "signal_id", desired_signals)
        self._delete_missing(connection, "tickets_index", "ticket_id", desired_tickets)

    def write(self, data: dict[str, Any]) -> None:
        canonical = validate_database_payload(data)
        with closing(self._connect()) as connection:
            self._ensure_categorized_storage(connection)
            self._backup_if_needed(connection)
            connection.execute("BEGIN IMMEDIATE")
            try:
                self._sync_categorized(connection, canonical)
                self._sync_indexes(connection, canonical)
                self._increment_state_version(connection)
                connection.execute("COMMIT")
            except Exception:
                connection.execute("ROLLBACK")
                raise

    def healthcheck(self) -> bool:
        with closing(self._connect()) as connection:
            row = connection.execute("SELECT 1").fetchone()
        return bool(row and int(row[0]) == 1)

    def transaction(self, fn: Callable[[dict[str, Any]], T]) -> tuple[T, dict[str, Any]]:
        with closing(self._connect()) as connection:
            self._ensure_categorized_storage(connection)
            self._backup_if_needed(connection)
            connection.execute("BEGIN IMMEDIATE")
            try:
                working = self._read_categorized(connection)
                index_before = _index_source_snapshot(working)
                result = fn(working)
                canonical = validate_database_payload(working)
                self._sync_categorized(connection, canonical)
                if _index_sources_changed(index_before, canonical):
                    self._sync_indexes(connection, canonical)
                self._increment_state_version(connection)
                connection.execute("COMMIT")
                return result, canonical
            except Exception:
                connection.execute("ROLLBACK")
                raise


class PostgresStore:
    """PostgreSQL canonical store used when DATABASE_URL is configured.

    It mirrors the SQLite schema and keeps the legacy dictionary contract, which
    allows zero-downtime migration without rewriting all Telegram handlers.
    """

    def __init__(self, url: str, backup_dir: Path, legacy_json: Path | None = None):
        from core.postgres_runtime import connection_kwargs, normalize_database_url, pool_policy
        self.url = normalize_database_url(url)
        self.backup_dir = backup_dir
        self.legacy_json = legacy_json
        try:
            from psycopg_pool import ConnectionPool
        except ImportError as exc:
            raise RuntimeError("psycopg-pool is required when DATABASE_URL is configured") from exc
        self._pool = ConnectionPool(
            conninfo=self.url,
            **pool_policy(legacy_max='POSTGRES_LEGACY_POOL_MAX'),
            kwargs=connection_kwargs(autocommit=True, application_name='sentinel-legacy'),
            check=ConnectionPool.check_connection,
            open=True,
        )
        try:
            self._initialize()
            from core.economy_integrity import create_schema
            with self._connect() as connection, connection.cursor() as cursor:
                create_schema(cursor)
        except BaseException:
            self._pool.close()
            raise

    def _connect(self):
        return self._pool.connection()

    def close(self) -> None:
        self._pool.close()

    def _initialize(self) -> None:
        with self._connect() as connection:
            with connection.cursor() as cursor:
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS app_state (
                        id SMALLINT PRIMARY KEY CHECK (id = 1),
                        version BIGINT NOT NULL,
                        payload JSONB NOT NULL,
                        updated_at TIMESTAMPTZ NOT NULL
                    )
                    """
                )
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS schema_migrations (
                        version INTEGER PRIMARY KEY,
                        applied_at TIMESTAMPTZ NOT NULL
                    )
                    """
                )
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS users_index (
                        user_id TEXT PRIMARY KEY,
                        username TEXT,
                        display_name TEXT,
                        vip_active BOOLEAN NOT NULL DEFAULT FALSE,
                        points BIGINT NOT NULL DEFAULT 0,
                        updated_at TEXT
                    )
                    """
                )
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS orders_index (
                        order_id TEXT PRIMARY KEY,
                        kind TEXT NOT NULL,
                        user_id TEXT NOT NULL,
                        status TEXT NOT NULL,
                        amount BIGINT NOT NULL DEFAULT 0,
                        payment_method TEXT,
                        transaction_hash TEXT,
                        verification_status TEXT,
                        created_at TEXT,
                        updated_at TEXT
                    )
                    """
                )
                for statement in (
                    "ALTER TABLE orders_index ADD COLUMN IF NOT EXISTS payment_method TEXT",
                    "ALTER TABLE orders_index ADD COLUMN IF NOT EXISTS transaction_hash TEXT",
                    "ALTER TABLE orders_index ADD COLUMN IF NOT EXISTS verification_status TEXT",
                    "ALTER TABLE orders_index ADD COLUMN IF NOT EXISTS updated_at TEXT",
                ):
                    cursor.execute(statement)
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_orders_user_status ON orders_index(user_id, status)")
                cursor.execute(
                    "CREATE UNIQUE INDEX IF NOT EXISTS idx_orders_txid_unique "
                    "ON orders_index(transaction_hash) WHERE transaction_hash IS NOT NULL AND transaction_hash <> ''"
                )
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS signals_index (
                        signal_id BIGINT PRIMARY KEY,
                        symbol TEXT NOT NULL,
                        side TEXT,
                        status TEXT NOT NULL,
                        cycle_id BIGINT,
                        created_at TEXT,
                        updated_at TEXT
                    )
                    """
                )
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_signals_symbol_status ON signals_index(symbol, status)")
                cursor.execute(
                    """
                    CREATE TABLE IF NOT EXISTS tickets_index (
                        ticket_id BIGINT PRIMARY KEY,
                        user_id TEXT NOT NULL,
                        status TEXT NOT NULL,
                        priority TEXT,
                        category TEXT,
                        assigned_admin TEXT,
                        updated_at TEXT
                    )
                    """
                )
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_tickets_status_priority ON tickets_index(status, priority, updated_at)")
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS storage_meta (
                        key TEXT PRIMARY KEY, value TEXT NOT NULL, updated_at TIMESTAMPTZ NOT NULL
                    )"""
                )
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS section_registry (
                        section_key TEXT PRIMARY KEY, domain TEXT NOT NULL, container_type TEXT NOT NULL,
                        checksum TEXT NOT NULL, record_count BIGINT NOT NULL DEFAULT 0,
                        updated_at TIMESTAMPTZ NOT NULL
                    )"""
                )
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS legacy_state_archive (
                        id BIGSERIAL PRIMARY KEY, source_version BIGINT NOT NULL,
                        payload JSONB NOT NULL, migrated_at TIMESTAMPTZ NOT NULL
                    )"""
                )
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS user_accounts (
                        user_id TEXT PRIMARY KEY, username TEXT, first_name TEXT, last_name TEXT,
                        display_name TEXT, language_code TEXT, created_at TEXT, last_seen_at TEXT,
                        updated_at TEXT, payload JSONB NOT NULL
                    )"""
                )
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_accounts_username ON user_accounts(username)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_accounts_last_seen ON user_accounts(last_seen_at)")
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS user_profiles_rel (
                        user_id TEXT PRIMARY KEY, phone TEXT, email TEXT, source TEXT, company TEXT,
                        preferred_market TEXT, preferred_contact TEXT, created_at TEXT, updated_at TEXT,
                        payload JSONB NOT NULL
                    )"""
                )
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS user_memberships (
                        user_id TEXT PRIMARY KEY, status TEXT, plan_id TEXT, starts_at TEXT,
                        expires_at TEXT, updated_at TEXT, payload JSONB NOT NULL
                    )"""
                )
                cursor.execute(
                    "CREATE INDEX IF NOT EXISTS idx_user_memberships_status_expiry ON user_memberships(status, expires_at)"
                )
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS user_preferences (
                        section_key TEXT NOT NULL, user_id TEXT NOT NULL, payload JSONB NOT NULL,
                        updated_at TIMESTAMPTZ NOT NULL, PRIMARY KEY(section_key, user_id)
                    )"""
                )
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_preferences_user ON user_preferences(user_id)")
                cursor.execute(
                    """CREATE TABLE IF NOT EXISTS user_records (
                        section_key TEXT NOT NULL, record_key TEXT NOT NULL, position BIGINT NOT NULL DEFAULT 0,
                        user_id TEXT, status TEXT, created_at TEXT, updated_at TEXT, payload JSONB NOT NULL,
                        PRIMARY KEY(section_key, record_key)
                    )"""
                )
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_records_user_section ON user_records(user_id, section_key)")
                cursor.execute("CREATE INDEX IF NOT EXISTS idx_user_records_status ON user_records(section_key, status)")
                for table in DOMAIN_TABLES.values():
                    cursor.execute(
                        f"""CREATE TABLE IF NOT EXISTS {table} (
                            section_key TEXT NOT NULL, record_key TEXT NOT NULL,
                            position BIGINT NOT NULL DEFAULT 0, user_id TEXT, status TEXT,
                            created_at TEXT, updated_at TEXT, payload JSONB NOT NULL,
                            PRIMARY KEY(section_key, record_key)
                        )"""  # nosec B608 -- fixed allowlisted table names
                    )
                    cursor.execute(
                        f"CREATE INDEX IF NOT EXISTS idx_{table}_user_status ON {table}(user_id, status)"  # nosec B608
                    )
                cursor.execute(
                    """CREATE OR REPLACE VIEW user_master AS
                    SELECT
                        ua.user_id AS user_id, ua.username AS username, ua.display_name AS display_name,
                        up.phone AS phone, up.email AS email, up.source AS source, up.company AS company,
                        up.preferred_market AS preferred_market, up.preferred_contact AS preferred_contact,
                        um.status AS vip_status, um.plan_id AS vip_plan_id, um.expires_at AS vip_expires_at,
                        COALESCE(ui.points, 0) AS points, ua.created_at AS created_at,
                        ua.last_seen_at AS last_seen_at, ua.updated_at AS updated_at,
                        ua.payload AS account_payload, up.payload AS profile_payload,
                        um.payload AS membership_payload
                    FROM user_accounts ua
                    LEFT JOIN user_profiles_rel up ON up.user_id = ua.user_id
                    LEFT JOIN user_memberships um ON um.user_id = ua.user_id
                    LEFT JOIN users_index ui ON ui.user_id = ua.user_id"""
                )
                cursor.execute("INSERT INTO schema_migrations(version, applied_at) VALUES(1, NOW()) ON CONFLICT(version) DO NOTHING")
                cursor.execute("SELECT id FROM app_state WHERE id = 1")
                if cursor.fetchone() is None:
                    initial = self._initial_payload()
                    cursor.execute(
                        "INSERT INTO app_state(id, version, payload, updated_at) VALUES(1, 1, %s::jsonb, NOW())",
                        (json.dumps(initial, ensure_ascii=False, allow_nan=False),),
                    )
                    self._sync_indexes(cursor, initial)
                with connection.transaction():
                    self._ensure_categorized_storage(cursor)

    def _initial_payload(self) -> dict[str, Any]:
        if self.legacy_json and self.legacy_json.is_file():
            try:
                return validate_database_payload(json.loads(self.legacy_json.read_text(encoding="utf-8")))
            except Exception as exc:
                raise DatabaseLoadError(f"Legacy database validation failed for {self.legacy_json}") from exc
        return copy.deepcopy(DEFAULT_DB)

    @staticmethod
    def _categorized_table(section_key: str) -> str:
        return SQLiteStore._categorized_table(section_key)

    @staticmethod
    def _json_load_postgres(value: Any) -> Any:
        # psycopg's JSONB loader has ALREADY decoded the JSON value. A Python
        # string here is a legitimate JSON string scalar, not serialized JSON.
        # Decoding it again crashes on ""/ordinary text and silently changes
        # types for strings such as "123", "null" or '{"x":1}'.
        return value

    def _delete_categorized_section(self, cursor: Any, section_key: str) -> None:
        table = self._categorized_table(section_key)
        if table in {"user_accounts", "user_profiles_rel", "user_memberships"}:
            cursor.execute(f"DELETE FROM {table}")  # nosec B608 -- fixed allowlisted table
        else:
            cursor.execute(f"DELETE FROM {table} WHERE section_key = %s", (section_key,))  # nosec B608

    def _insert_categorized_section(self, cursor: Any, section_key: str, value: Any) -> int:
        now = utc_now_iso()
        if section_key == USER_ACCOUNT_SECTION:
            rows = []
            for user_id, payload in value.items() if isinstance(value, dict) else []:
                item = payload if isinstance(payload, dict) else {"value": payload}
                rows.append(
                    (
                        str(user_id), str(item.get("username") or "")[:64],
                        str(item.get("first_name") or "")[:200], str(item.get("last_name") or "")[:200],
                        relational_display_name(item), str(item.get("language_code") or "")[:32],
                        str(item.get("created_at") or ""), str(item.get("last_seen_at") or ""),
                        str(item.get("updated_at") or item.get("last_seen_at") or now), json_text(payload),
                    )
                )
            if rows:
                cursor.executemany(
                    """INSERT INTO user_accounts(
                        user_id, username, first_name, last_name, display_name, language_code,
                        created_at, last_seen_at, updated_at, payload
                    ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)""",
                    rows,
                )
            return len(rows)
        if section_key == USER_PROFILE_SECTION:
            rows = []
            for user_id, payload in value.items() if isinstance(value, dict) else []:
                item = payload if isinstance(payload, dict) else {"value": payload}
                rows.append(
                    (
                        str(user_id), str(item.get("phone") or item.get("phone_number") or "")[:64],
                        str(item.get("email") or "")[:254],
                        str(item.get("source") or item.get("lead_source") or "")[:128],
                        str(item.get("company") or "")[:200], str(item.get("preferred_market") or "")[:100],
                        str(item.get("preferred_contact") or "")[:64], str(item.get("created_at") or ""),
                        str(item.get("updated_at") or now), json_text(payload),
                    )
                )
            if rows:
                cursor.executemany(
                    """INSERT INTO user_profiles_rel(
                        user_id, phone, email, source, company, preferred_market, preferred_contact,
                        created_at, updated_at, payload
                    ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s::jsonb)""",
                    rows,
                )
            return len(rows)
        if section_key == USER_MEMBERSHIP_SECTION:
            rows = []
            for user_id, payload in value.items() if isinstance(value, dict) else []:
                item = payload if isinstance(payload, dict) else {"value": payload}
                rows.append(
                    (
                        str(user_id), str(item.get("status") or "")[:64],
                        str(item.get("plan_id") or item.get("plan") or "")[:128],
                        str(item.get("starts_at") or item.get("start_at") or ""),
                        str(item.get("expires_at") or item.get("expiry") or ""),
                        str(item.get("updated_at") or item.get("approved_at") or now), json_text(payload),
                    )
                )
            if rows:
                cursor.executemany(
                    """INSERT INTO user_memberships(
                        user_id, status, plan_id, starts_at, expires_at, updated_at, payload
                    ) VALUES(%s,%s,%s,%s,%s,%s,%s::jsonb)""",
                    rows,
                )
            return len(rows)
        if section_key in USER_PREFERENCE_SECTIONS:
            rows = [
                (section_key, str(user_id), json_text(payload), now)
                for user_id, payload in (value.items() if isinstance(value, dict) else [])
            ]
            if rows:
                cursor.executemany(
                    "INSERT INTO user_preferences(section_key, user_id, payload, updated_at) VALUES(%s,%s,%s::jsonb,%s)",
                    rows,
                )
            return len(rows)

        table = self._categorized_table(section_key)
        rows = []
        for row in iter_section_records(value):
            user_id = row.user_id or user_id_from_key_or_payload(row.record_key, row.payload)
            if table != "user_records" and not row.user_id:
                user_id = ""
            rows.append(
                (
                    section_key, row.record_key, row.position, user_id, row.status,
                    row.created_at, row.updated_at or now, json_text(row.payload),
                )
            )
        if rows:
            cursor.executemany(
                f"""INSERT INTO {table}(
                    section_key, record_key, position, user_id, status, created_at, updated_at, payload
                ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s::jsonb)""",  # nosec B608
                rows,
            )
        return len(rows)

    def _sync_categorized(self, cursor: Any, data: dict[str, Any], *, force: bool = False) -> None:
        data = protect_sensitive_payload(data, SETTINGS.sensitive_data_key)
        cursor.execute("SELECT section_key, checksum FROM section_registry")
        existing = {str(row[0]): str(row[1]) for row in cursor.fetchall()}
        now = utc_now_iso()
        for section_key, value in data.items():
            checksum = section_checksum(value)
            if not force and existing.get(section_key) == checksum:
                continue
            self._delete_categorized_section(cursor, section_key)
            count = self._insert_categorized_section(cursor, section_key, value)
            if section_key == USER_ACCOUNT_SECTION:
                domain = "user_accounts"
            elif section_key == USER_PROFILE_SECTION:
                domain = "user_profiles"
            elif section_key == USER_MEMBERSHIP_SECTION:
                domain = "user_memberships"
            elif section_key in USER_PREFERENCE_SECTIONS:
                domain = "user_preferences"
            elif section_key in USER_RECORD_SECTIONS:
                domain = "user_records"
            else:
                domain = section_domain(section_key)
            cursor.execute(
                """INSERT INTO section_registry(section_key, domain, container_type, checksum, record_count, updated_at)
                VALUES(%s,%s,%s,%s,%s,%s)
                ON CONFLICT(section_key) DO UPDATE SET
                    domain=EXCLUDED.domain, container_type=EXCLUDED.container_type,
                    checksum=EXCLUDED.checksum, record_count=EXCLUDED.record_count, updated_at=EXCLUDED.updated_at""",
                (section_key, domain, container_type(value), checksum, count, now),
            )
        for section_key in set(existing) - set(data):
            self._delete_categorized_section(cursor, section_key)
            cursor.execute("DELETE FROM section_registry WHERE section_key = %s", (section_key,))

    def _read_categorized(self, cursor: Any) -> dict[str, Any]:
        result: dict[str, Any] = {}
        cursor.execute("SELECT section_key, domain, container_type FROM section_registry ORDER BY section_key")
        registry = cursor.fetchall()
        for section_key_raw, _domain, kind_raw in registry:
            section_key = str(section_key_raw)
            kind = str(kind_raw)
            if section_key == USER_ACCOUNT_SECTION:
                cursor.execute("SELECT user_id, payload FROM user_accounts ORDER BY user_id")
                result[section_key] = {str(row[0]): self._json_load_postgres(row[1]) for row in cursor.fetchall()}
                continue
            if section_key == USER_PROFILE_SECTION:
                cursor.execute("SELECT user_id, payload FROM user_profiles_rel ORDER BY user_id")
                result[section_key] = {str(row[0]): self._json_load_postgres(row[1]) for row in cursor.fetchall()}
                continue
            if section_key == USER_MEMBERSHIP_SECTION:
                cursor.execute("SELECT user_id, payload FROM user_memberships ORDER BY user_id")
                result[section_key] = {str(row[0]): self._json_load_postgres(row[1]) for row in cursor.fetchall()}
                continue
            if section_key in USER_PREFERENCE_SECTIONS:
                cursor.execute(
                    "SELECT user_id, payload FROM user_preferences WHERE section_key = %s ORDER BY user_id",
                    (section_key,),
                )
                result[section_key] = {str(row[0]): self._json_load_postgres(row[1]) for row in cursor.fetchall()}
                continue
            table = self._categorized_table(section_key)
            cursor.execute(
                f"SELECT record_key, position, payload FROM {table} WHERE section_key = %s ORDER BY position, record_key",  # nosec B608
                (section_key,),
            )
            result[section_key] = reconstruct_section(
                kind,
                ((str(row[0]), int(row[1]), self._json_load_postgres(row[2])) for row in cursor.fetchall()),
            )
        return validate_database_payload(unprotect_sensitive_payload(result, SETTINGS.sensitive_data_key))

    def _ensure_categorized_storage(self, cursor: Any) -> None:
        # The steady-state read path must never lock the legacy singleton row.
        # Only the one-time migration path locks app_state while converting it.
        cursor.execute("SELECT value FROM storage_meta WHERE key = 'relational_active'")
        active = cursor.fetchone()
        if active and str(active[0]) == "1":
            if encryption_ready(SETTINGS.sensitive_data_key):
                cursor.execute("SELECT value FROM storage_meta WHERE key = 'sensitive_indexes_v1'")
                protected = cursor.fetchone()
                if not protected or str(protected[0]) != "1":
                    self._sync_indexes(cursor, self._read_categorized(cursor))
                    cursor.execute(
                        """INSERT INTO storage_meta(key, value, updated_at) VALUES('sensitive_indexes_v1', '1', NOW())
                        ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, updated_at=EXCLUDED.updated_at"""
                    )
            return
        cursor.execute("SELECT version, payload FROM app_state WHERE id = 1 FOR UPDATE")
        row = cursor.fetchone()
        if row is None:
            raise DatabaseLoadError("PostgreSQL legacy state row is missing during categorized migration")
        raw_payload = self._json_load_postgres(row[1])
        raw = validate_database_payload(raw_payload)
        cursor.execute("SELECT COUNT(*) FROM legacy_state_archive")
        archive_count = cursor.fetchone()
        if not archive_count or int(archive_count[0]) == 0:
            cursor.execute(
                "INSERT INTO legacy_state_archive(source_version, payload, migrated_at) VALUES(%s,%s::jsonb,NOW())",
                (int(row[0]), json_text(raw)),
            )
        self._sync_categorized(cursor, raw, force=True)
        for key, value in (
            ("relational_active", "1"),
            ("relational_storage_version", str(RELATIONAL_STORAGE_VERSION)),
            ("state_version", str(int(row[0]))),
        ):
            cursor.execute(
                """INSERT INTO storage_meta(key, value, updated_at) VALUES(%s,%s,NOW())
                ON CONFLICT(key) DO UPDATE SET value=EXCLUDED.value, updated_at=EXCLUDED.updated_at""",
                (key, value),
            )
        manifest = {
            "storage": "categorized",
            "schema_version": SCHEMA_VERSION,
            "relational_storage_version": RELATIONAL_STORAGE_VERSION,
            "legacy_archive_available": True,
            "migrated_at": utc_now_iso(),
        }
        cursor.execute(
            "UPDATE app_state SET payload = %s::jsonb, updated_at = NOW() WHERE id = 1",
            (json_text(manifest),),
        )
        cursor.execute(
            "INSERT INTO schema_migrations(version, applied_at) VALUES(3, NOW()) ON CONFLICT(version) DO NOTHING"
        )

    def _increment_state_version(self, cursor: Any) -> int:
        # Compatibility counter only. Atomic UPDATE avoids an explicit global
        # SELECT FOR UPDATE and is no longer used to serialize business writes.
        cursor.execute(
            """INSERT INTO storage_meta(key, value, updated_at) VALUES('state_version', '1', NOW())
            ON CONFLICT(key) DO UPDATE SET
                value=((storage_meta.value)::bigint + 1)::text, updated_at=EXCLUDED.updated_at
            RETURNING value"""
        )
        row = cursor.fetchone()
        version = int(row[0]) if row else 1
        cursor.execute("UPDATE app_state SET version = %s, updated_at = NOW() WHERE id = 1", (version,))
        return version

    def version(self) -> int:
        # Cache invalidation is derived from section checksums, not a global hot
        # counter. Unrelated section writers therefore never contend here.
        with self._connect() as connection, connection.cursor() as cursor:
            self._ensure_categorized_storage(cursor)
            cursor.execute(
                "SELECT COALESCE(md5(string_agg(section_key || ':' || checksum, '|' ORDER BY section_key)), md5('')) FROM section_registry"
            )
            row = cursor.fetchone()
            digest = str(row[0]) if row and row[0] else "0"
            return int(digest[:15], 16)

    def _read(self) -> dict[str, Any]:
        with self._connect() as connection, connection.cursor() as cursor:
            self._ensure_categorized_storage(cursor)
            with connection.transaction():
                cursor.execute("SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY")
                return self._read_categorized(cursor)

    def _backup_if_needed(self, data: dict[str, Any]) -> None:
        global _LAST_BACKUP_DATE
        today = datetime.now(UTC).strftime("%Y-%m-%d")
        if _LAST_BACKUP_DATE == today:
            return
        self.backup_dir.mkdir(parents=True, exist_ok=True)
        target = self.backup_dir / f"database-{today}.json"
        if not target.exists():
            protected = protect_sensitive_payload(data, SETTINGS.sensitive_data_key)
            payload = json.dumps(protected, ensure_ascii=False, indent=2, allow_nan=False).encode("utf-8")
            fd, temp_name = tempfile.mkstemp(prefix=f".{target.name}.", suffix=".tmp", dir=str(self.backup_dir))
            temp = Path(temp_name)
            try:
                with os.fdopen(fd, "wb") as handle:
                    handle.write(payload)
                    handle.flush()
                    os.fsync(handle.fileno())
                try:
                    os.chmod(temp, 0o600)
                except OSError:
                    pass
                os.replace(temp, target)
                try:
                    directory_fd = os.open(self.backup_dir, os.O_RDONLY)
                    try:
                        os.fsync(directory_fd)
                    finally:
                        os.close(directory_fd)
                except OSError:
                    pass
            finally:
                temp.unlink(missing_ok=True)
        _LAST_BACKUP_DATE = today
        for old in sorted(self.backup_dir.glob("database-*.json"), reverse=True)[14:]:
            old.unlink(missing_ok=True)

    @staticmethod
    def _display_name(user: dict[str, Any]) -> str:
        return SQLiteStore._display_name(user)

    @staticmethod
    def _delete_missing_postgres(cursor: Any, table: str, column: str, values: list[Any]) -> None:
        allowed = {
            ("users_index", "user_id"),
            ("orders_index", "order_id"),
            ("signals_index", "signal_id"),
            ("tickets_index", "ticket_id"),
        }
        if (table, column) not in allowed:
            raise ValueError("unsupported index cleanup target")
        if not values:
            cursor.execute(f"DELETE FROM {table}")  # nosec B608
            return
        cursor.execute(
            f"DELETE FROM {table} WHERE NOT ({column} = ANY(%s))",  # nosec B608
            (values,),
        )

    def _sync_indexes(self, cursor: Any, data: dict[str, Any]) -> None:
        vip_users = data.get("vip_users", {})
        points = data.get("user_points", {})
        users = data.get("users", {})
        user_rows = []
        for uid, user in users.items():
            if not isinstance(user, dict):
                continue
            vip = vip_users.get(str(uid), {}) if isinstance(vip_users, dict) else {}
            user_rows.append(
                (
                    str(uid),
                    str(user.get("username") or "")[:64],
                    self._display_name(user),
                    bool(isinstance(vip, dict) and vip.get("status") == "active"),
                    int(points.get(str(uid), 0) or 0) if isinstance(points, dict) else 0,
                    str(user.get("updated_at") or user.get("last_seen_at") or utc_now_iso()),
                )
            )
        if user_rows:
            cursor.executemany(
                """INSERT INTO users_index(user_id, username, display_name, vip_active, points, updated_at)
                VALUES(%s,%s,%s,%s,%s,%s)
                ON CONFLICT(user_id) DO UPDATE SET
                    username=EXCLUDED.username, display_name=EXCLUDED.display_name,
                    vip_active=EXCLUDED.vip_active, points=EXCLUDED.points, updated_at=EXCLUDED.updated_at""",
                user_rows,
            )
        self._delete_missing_postgres(cursor, "users_index", "user_id", [row[0] for row in user_rows])

        order_rows = []
        for kind, rows in (("vip", data.get("vip_orders", [])), ("education", data.get("education_orders", []))):
            for order in rows if isinstance(rows, list) else []:
                if not isinstance(order, dict):
                    continue
                order_id = str(order.get("order_id") or order.get("id") or "")
                if not order_id:
                    continue
                try:
                    amount = int(float(str(order.get("price", order.get("amount", 0))).replace(",", "")))
                except (TypeError, ValueError):
                    amount = 0
                order_rows.append(
                    (
                        order_id,
                        kind,
                        str(order.get("user_id") or ""),
                        str(order.get("status") or "unknown"),
                        max(0, amount),
                        str(order.get("payment_method") or ""),
                        _secure_transaction_index(order.get("transaction_hash")),
                        str(order.get("verification_status") or ""),
                        str(order.get("created_at") or ""),
                        str(order.get("updated_at") or order.get("approved_at") or ""),
                    )
                )
        if order_rows:
            cursor.executemany(
                """INSERT INTO orders_index(
                    order_id, kind, user_id, status, amount, payment_method, transaction_hash,
                    verification_status, created_at, updated_at
                ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT(order_id) DO UPDATE SET
                    kind=EXCLUDED.kind, user_id=EXCLUDED.user_id, status=EXCLUDED.status,
                    amount=EXCLUDED.amount, payment_method=EXCLUDED.payment_method,
                    transaction_hash=EXCLUDED.transaction_hash, verification_status=EXCLUDED.verification_status,
                    created_at=EXCLUDED.created_at, updated_at=EXCLUDED.updated_at""",
                order_rows,
            )
        self._delete_missing_postgres(cursor, "orders_index", "order_id", [row[0] for row in order_rows])

        signal_rows = []
        for signal in data.get("signals", []):
            if not isinstance(signal, dict):
                continue
            try:
                signal_id = int(signal.get("id"))
            except (TypeError, ValueError):
                continue
            signal_rows.append(
                (
                    signal_id,
                    str(signal.get("symbol") or "").upper(),
                    str(signal.get("side") or ""),
                    str(signal.get("status") or "open"),
                    int(signal.get("cycle_id", 1) or 1),
                    str(signal.get("created_at") or ""),
                    str(signal.get("updated_at") or signal.get("result_updated_at") or ""),
                )
            )
        if signal_rows:
            cursor.executemany(
                """INSERT INTO signals_index(signal_id, symbol, side, status, cycle_id, created_at, updated_at)
                VALUES(%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT(signal_id) DO UPDATE SET
                    symbol=EXCLUDED.symbol, side=EXCLUDED.side, status=EXCLUDED.status,
                    cycle_id=EXCLUDED.cycle_id, created_at=EXCLUDED.created_at, updated_at=EXCLUDED.updated_at""",
                signal_rows,
            )
        self._delete_missing_postgres(cursor, "signals_index", "signal_id", [row[0] for row in signal_rows])

        ticket_rows = []
        for ticket in data.get("tickets", []):
            if not isinstance(ticket, dict):
                continue
            try:
                ticket_id = int(ticket.get("id"))
            except (TypeError, ValueError):
                continue
            ticket_rows.append(
                (
                    ticket_id,
                    str(ticket.get("user_id") or ""),
                    str(ticket.get("status") or "open"),
                    str(ticket.get("priority") or "normal"),
                    str(ticket.get("category") or "general"),
                    str(ticket.get("assigned_admin") or ""),
                    str(ticket.get("updated_at") or ""),
                )
            )
        if ticket_rows:
            cursor.executemany(
                """INSERT INTO tickets_index(ticket_id, user_id, status, priority, category, assigned_admin, updated_at)
                VALUES(%s,%s,%s,%s,%s,%s,%s)
                ON CONFLICT(ticket_id) DO UPDATE SET
                    user_id=EXCLUDED.user_id, status=EXCLUDED.status, priority=EXCLUDED.priority,
                    category=EXCLUDED.category, assigned_admin=EXCLUDED.assigned_admin, updated_at=EXCLUDED.updated_at""",
                ticket_rows,
            )
        self._delete_missing_postgres(cursor, "tickets_index", "ticket_id", [row[0] for row in ticket_rows])

    def write(self, data: dict[str, Any]) -> None:
        canonical = validate_database_payload(data)
        before = self._read()
        changed = _changed_sections(before, canonical)
        _commit_sections_optimistic(self, before=before, after=canonical, changed=changed)
        try:
            self._backup_if_needed(canonical)
        except Exception:
            logger.exception("PostgreSQL daily compatibility backup failed after committed write")

    def healthcheck(self) -> bool:
        with self._connect() as connection, connection.cursor() as cursor:
            cursor.execute("SELECT 1")
            row = cursor.fetchone()
        return bool(row and int(row[0]) == 1)

    def transaction(self, fn: Callable[[dict[str, Any]], T]) -> tuple[T, dict[str, Any]]:
        last_error: Exception | None = None
        for _attempt in range(4):
            before = self._read()
            working = copy.deepcopy(before)
            result = fn(working)
            canonical = validate_database_payload(working)
            changed = _changed_sections(before, canonical)
            try:
                _commit_sections_optimistic(self, before=before, after=canonical, changed=changed)
            except ConcurrentDatabaseUpdate as exc:
                last_error = exc
                continue
            try:
                self._backup_if_needed(canonical)
            except Exception:
                logger.exception("PostgreSQL daily compatibility backup failed after committed transaction")
            return result, canonical
        raise ConcurrentDatabaseUpdate("database sections changed repeatedly; retry the operation") from last_error


def _build_store() -> JsonStore | SQLiteStore | PostgresStore:
    if SETTINGS.database_url:
        return PostgresStore(SETTINGS.database_url, SETTINGS.backup_dir, legacy_json=SETTINGS.db_file.with_name("database.json"))
    suffix = SETTINGS.db_file.suffix.lower()
    if suffix in {".sqlite", ".sqlite3", ".db"}:
        return SQLiteStore(
            SETTINGS.db_file,
            SETTINGS.backup_dir,
            legacy_json=SETTINGS.db_file.with_name("database.json"),
        )
    return JsonStore(SETTINGS.db_file, SETTINGS.backup_dir)


# Build the persistence backend lazily. Importing ``core.db`` must not create
# files, connect to PostgreSQL, or mutate a mounted runtime volume. This also
# keeps release-cleanliness checks deterministic. Tests may still monkeypatch
# ``_STORE`` with an explicit backend.
_STORE: JsonStore | SQLiteStore | PostgresStore | None = None
_CACHE_VERSION: int | None = None
_GOOGLE_FAILOVER_ACTIVE = False
_GOOGLE_FAILOVER_BASE_CHECKSUM = ""
_GOOGLE_FAILOVER_LAST_ERROR = ""
_GOOGLE_FAILOVER_SYNC_VERSION = ""
_GOOGLE_FAILOVER_STARTED_AT = ""


def _get_store() -> JsonStore | SQLiteStore | PostgresStore:
    global _STORE
    with _LOCK:
        if _STORE is None:
            _STORE = _build_store()
        return _STORE


def close_database_store() -> None:
    """Close backend resources during graceful shutdown."""
    global _STORE
    store, _STORE = _STORE, None
    if store is not None and hasattr(store, "close"):
        store.close()


def _should_use_google_failover(exc: BaseException) -> bool:
    """Return True only for backend-availability failures, never business/SQL errors."""
    if isinstance(exc, (KeyError, ValueError, TypeError, ConcurrentDatabaseUpdate)):
        return False
    if isinstance(exc, (sqlite3.IntegrityError, sqlite3.ProgrammingError, sqlite3.DataError, sqlite3.NotSupportedError)):
        return False
    if isinstance(exc, (DatabaseLoadError, OSError, ConnectionError, TimeoutError)):
        return True
    if isinstance(exc, (sqlite3.OperationalError, sqlite3.DatabaseError)):
        return True
    module = str(exc.__class__.__module__ or "").lower()
    name = str(exc.__class__.__name__ or "").lower()
    sqlstate = str(getattr(exc, "sqlstate", "") or "")
    if module.startswith("psycopg"):
        if sqlstate.startswith("08"):
            return True
        return any(marker in name for marker in (
            "operationalerror", "interfaceerror", "adminshutdown", "cannotconnectnow",
            "connectionfailure", "connectiondoesnotexist",
        ))
    return any(marker in name for marker in ("operationalerror", "interfaceerror", "connectionerror"))


def _google_backup_module():
    from core import google_sheets_backup

    return google_sheets_backup


def _activate_google_failover(exc: BaseException) -> dict[str, Any]:
    global _CACHE, _CACHE_VERSION
    global _GOOGLE_FAILOVER_ACTIVE, _GOOGLE_FAILOVER_BASE_CHECKSUM
    global _GOOGLE_FAILOVER_LAST_ERROR, _GOOGLE_FAILOVER_SYNC_VERSION, _GOOGLE_FAILOVER_STARTED_AT
    backup = _google_backup_module()
    if not backup.is_configured():
        raise exc
    recovered = validate_database_payload(backup.recover_database_from_sheets())
    metadata = backup.raw_backup_metadata()
    base_checksum = str(metadata.get("database_checksum") or backup.protected_database_checksum(recovered))
    with _LOCK:
        _CACHE = recovered
        _CACHE_VERSION = None
        _GOOGLE_FAILOVER_ACTIVE = True
        _GOOGLE_FAILOVER_BASE_CHECKSUM = base_checksum
        _GOOGLE_FAILOVER_LAST_ERROR = f"{exc.__class__.__name__}:{str(exc)[:500]}"
        _GOOGLE_FAILOVER_SYNC_VERSION = str(metadata.get("sync_version") or "")
        _GOOGLE_FAILOVER_STARTED_AT = utc_now_iso()
    logger.critical(
        "Primary database is unavailable; Sentinel activated Google Sheets writable failover: %s",
        _GOOGLE_FAILOVER_LAST_ERROR,
    )
    return recovered


def google_sheets_failover_active() -> bool:
    return bool(_GOOGLE_FAILOVER_ACTIVE)


def google_sheets_backup_status() -> dict[str, Any]:
    try:
        backup = _google_backup_module()
        configured = backup.is_configured()
        pending = sorted(backup.pending_sections()) if configured else []
        email = backup.service_account_email()
        cfg = backup.config()
        return {
            "enabled": bool(cfg.enabled),
            "configured": configured,
            "spreadsheet_id": cfg.spreadsheet_id,
            "service_account_email": email,
            "projection_enabled": bool(cfg.projection_enabled),
            "write_failover": bool(cfg.write_failover),
            "auto_reconcile": bool(cfg.auto_reconcile),
            "failover_active": bool(_GOOGLE_FAILOVER_ACTIVE),
            "failover_started_at": _GOOGLE_FAILOVER_STARTED_AT,
            "base_primary_checksum": _GOOGLE_FAILOVER_BASE_CHECKSUM,
            "last_primary_error": _GOOGLE_FAILOVER_LAST_ERROR,
            "pending_sections": pending,
            "attestation": backup.backup_attestation_status(),
        }
    except Exception as exc:
        return {
            "enabled": False,
            "configured": False,
            "failover_active": bool(_GOOGLE_FAILOVER_ACTIVE),
            "error": f"{exc.__class__.__name__}:{str(exc)[:300]}",
        }


def _mirror_primary_to_google(db: dict[str, Any], changed: Iterable[str], *, source: str = "primary") -> None:
    """Queue Google mirroring without putting Google on the user request path.

    The primary database commit is authoritative. Previously this function made
    synchronous OAuth/Sheets calls after every mutation; a slow token refresh or
    Google outage could therefore exhaust worker threads while Railway still
    reported the process as online. The recurring secondary worker flushes this
    durable outbox every few seconds instead.
    """
    changed_keys = tuple(dict.fromkeys(str(key) for key in changed if str(key) and str(key) in db))
    if not changed_keys:
        return
    try:
        backup = _google_backup_module()
        if backup.config().enabled:
            backup.mark_pending_sections(changed_keys)
    except Exception:
        # Never let secondary-backup bookkeeping affect the primary commit.
        logger.exception("Could not queue Google Sheets secondary database sync")


def _with_google_failover_mutation(fn: Callable[[dict[str, Any]], T], primary_error: BaseException) -> T:
    global _CACHE, _CACHE_VERSION, _GOOGLE_FAILOVER_SYNC_VERSION
    backup = _google_backup_module()
    cfg = backup.config()
    if not cfg.write_failover:
        raise primary_error
    replicas = replica_count()
    if replicas > 1 and not str(os.getenv("ALLOW_MULTI_REPLICA_GOOGLE_WRITE_FAILOVER", "")).strip().lower() in {"1", "true", "yes", "on"}:
        raise DatabaseLoadError(
            "Google Sheets writable failover is fail-closed with multiple replicas; "
            "restore PostgreSQL or scale SENTINEL_REPLICA_COUNT to 1"
        ) from primary_error
    if not backup.is_configured():
        raise primary_error
    with _LOCK:
        if not _GOOGLE_FAILOVER_ACTIVE or _CACHE is None:
            _activate_google_failover(primary_error)
        before = copy.deepcopy(_CACHE or {})
        working = copy.deepcopy(before)
        result = fn(working)
        _dispatch_automation_events(before, working)
        canonical = validate_database_payload(working)
        changed = _changed_sections(before, canonical)
        if changed:
            failover_version = f"F-{int(time.time() * 1000)}"
            # A write is acknowledged only after Google accepted it. This keeps
            # failover durable across a process restart.
            backup.mirror_database_change(
                canonical,
                changed,
                sync_version=failover_version,
                source="google_failover",
            )
            _GOOGLE_FAILOVER_SYNC_VERSION = failover_version
        _CACHE = canonical
        _CACHE_VERSION = None
    _invalidate_runtime_indexes()
    return result


def google_sheets_sync_now(*, full: bool = False) -> dict[str, Any]:
    backup = _google_backup_module()
    if not backup.is_configured():
        return {"configured": False, "synced": 0, "pending": len(backup.pending_sections())}
    data = snapshot()
    if full:
        return backup.sync_full_snapshot(data, sync_version=utc_now_iso(), source="primary" if not _GOOGLE_FAILOVER_ACTIVE else "google_failover")
    return backup.flush_pending(data, sync_version=utc_now_iso())


def google_sheets_failover_reconcile() -> dict[str, Any]:
    global _CACHE, _CACHE_VERSION
    global _GOOGLE_FAILOVER_ACTIVE, _GOOGLE_FAILOVER_BASE_CHECKSUM
    global _GOOGLE_FAILOVER_LAST_ERROR, _GOOGLE_FAILOVER_SYNC_VERSION, _GOOGLE_FAILOVER_STARTED_AT
    if not _GOOGLE_FAILOVER_ACTIVE:
        return {"active": False, "status": "primary"}
    backup = _google_backup_module()
    cfg = backup.config()
    if not cfg.auto_reconcile:
        return {"active": True, "status": "manual_reconcile_required"}
    try:
        store = _get_store()
        primary = validate_database_payload(store._read())
    except Exception as exc:
        return {"active": True, "status": "primary_unavailable", "error": f"{exc.__class__.__name__}:{str(exc)[:300]}"}
    current_checksum = backup.protected_database_checksum(primary)
    if _GOOGLE_FAILOVER_BASE_CHECKSUM and current_checksum != _GOOGLE_FAILOVER_BASE_CHECKSUM:
        logger.error(
            "Google Sheets failover cannot auto-reconcile because the primary database changed independently"
        )
        return {
            "active": True,
            "status": "conflict",
            "primary_checksum": current_checksum,
            "expected_checksum": _GOOGLE_FAILOVER_BASE_CHECKSUM,
        }
    recovered = validate_database_payload(copy.deepcopy(_CACHE or backup.recover_database_from_sheets()))
    try:
        store.write(recovered)
        version = store.version() if isinstance(store, (SQLiteStore, PostgresStore)) else 1
    except Exception as exc:
        return {"active": True, "status": "reconcile_write_failed", "error": f"{exc.__class__.__name__}:{str(exc)[:300]}"}
    with _LOCK:
        _CACHE = recovered
        _CACHE_VERSION = int(version) if isinstance(version, int) else None
        _GOOGLE_FAILOVER_ACTIVE = False
        _GOOGLE_FAILOVER_BASE_CHECKSUM = ""
        _GOOGLE_FAILOVER_LAST_ERROR = ""
        _GOOGLE_FAILOVER_SYNC_VERSION = ""
        _GOOGLE_FAILOVER_STARTED_AT = ""
    try:
        backup.sync_full_snapshot(recovered, sync_version=utc_now_iso(), source="primary")
    except Exception:
        logger.exception("Primary recovery succeeded but post-reconcile Google Sheets sync failed")
    logger.warning("Sentinel reconciled Google Sheets failover data back to the recovered primary database")
    return {"active": False, "status": "reconciled"}


def load_db() -> dict[str, Any]:
    """Return the canonical database, falling back to Google Sheets when needed."""
    global _CACHE, _CACHE_VERSION
    with _LOCK:
        if _GOOGLE_FAILOVER_ACTIVE and _CACHE is not None:
            return _CACHE
        try:
            store = _get_store()
            if isinstance(store, (SQLiteStore, PostgresStore)):
                current_version = store.version()
                if _CACHE is None or _CACHE_VERSION != current_version:
                    _CACHE = store._read()
                    _CACHE_VERSION = current_version
            elif _CACHE is None:
                _CACHE = store._read()
                store.write(_CACHE)
            return _CACHE
        except Exception as exc:
            if not _should_use_google_failover(exc):
                raise
            return _activate_google_failover(exc)


def save_db(db: dict[str, Any] | None = None) -> None:
    global _CACHE, _CACHE_VERSION
    with _LOCK:
        if _GOOGLE_FAILOVER_ACTIVE:
            before = copy.deepcopy(_CACHE or {})
            working = copy.deepcopy(db if db is not None else _CACHE or {})
            canonical = validate_database_payload(working)
            changed = _changed_sections(before, canonical)
            backup = _google_backup_module()
            if changed:
                backup.mirror_database_change(canonical, changed, sync_version=f"F-{int(time.time() * 1000)}", source="google_failover")
            _CACHE = canonical
            _CACHE_VERSION = None
            return
        try:
            store = _get_store()
            before = copy.deepcopy(store._read())
            if db is not None and db is not _CACHE:
                _CACHE = db
            if _CACHE is None:
                _CACHE = before
            canonical = validate_database_payload(_CACHE)
            store.write(canonical)
            _CACHE = canonical
            if isinstance(store, (SQLiteStore, PostgresStore)):
                _CACHE_VERSION = None  # Reload a coherent committed snapshot on the next read.
            _mirror_primary_to_google(canonical, _changed_sections(before, canonical))
        except Exception as exc:
            if not _should_use_google_failover(exc):
                raise
            if db is None and _CACHE is None:
                _activate_google_failover(exc)
                return
            canonical = validate_database_payload(copy.deepcopy(db if db is not None else _CACHE or {}))
            before = _activate_google_failover(exc)
            changed = _changed_sections(before, canonical)
            if changed:
                _google_backup_module().mirror_database_change(canonical, changed, sync_version=f"F-{int(time.time() * 1000)}", source="google_failover")
            _CACHE = canonical
            _CACHE_VERSION = None

def with_db_read(fn: Callable[[dict[str, Any]], T]) -> T:
    """Run a read-only callback without opening a write transaction.

    The returned database is a defensive deep copy of the current canonical
    snapshot. Read paths therefore never acquire ``FOR UPDATE``/``BEGIN
    IMMEDIATE`` locks, never increment ``state_version``, and cannot mutate the
    process cache accidentally.
    """
    with _LOCK:
        working = copy.deepcopy(load_db())
    return fn(working)


def _changed_sections(before: dict[str, Any], after: dict[str, Any]) -> tuple[str, ...]:
    keys = set(before) | set(after)
    return tuple(sorted(key for key in keys if section_checksum(before.get(key)) != section_checksum(after.get(key))))


def _protected_section_checksum(section_key: str, value: Any) -> str:
    protected = protect_sensitive_payload({section_key: value}, SETTINGS.sensitive_data_key).get(section_key)
    return section_checksum(protected)


def _commit_sections_optimistic(
    store: SQLiteStore | PostgresStore,
    *,
    before: dict[str, Any],
    after: dict[str, Any],
    changed: tuple[str, ...],
    expected_version: int | None = None,
) -> int | None:
    """Commit only changed logical sections with per-section concurrency.

    PostgreSQL uses deterministic advisory locks derived from section names;
    unrelated domains can therefore commit concurrently.  The legacy global
    ``state_version FOR UPDATE`` lock and full-state rewrite are intentionally
    absent.  SQLite keeps its unavoidable single-writer lock but still writes
    only changed sections.
    """
    if not changed:
        return
    index_sources = {"users", "user_profiles", "user_points", "vip_users", "vip_orders", "signals", "tickets"}
    if isinstance(store, SQLiteStore):
        with closing(store._connect()) as connection:
            store._ensure_categorized_storage(connection)
            connection.execute("BEGIN IMMEDIATE")
            version_row = connection.execute("SELECT value FROM storage_meta WHERE key = 'state_version'").fetchone()
            cache_safe = expected_version is not None and int(version_row["value"] or 0) == expected_version
            try:
                for key in changed:
                    row = connection.execute(
                        "SELECT checksum FROM section_registry WHERE section_key = ?",
                        (key,),
                    ).fetchone()
                    current_checksum = str(row["checksum"]) if row else None
                    expected_checksum = _protected_section_checksum(key, before.get(key)) if row and key in before else None
                    if current_checksum != expected_checksum:
                        raise ConcurrentDatabaseUpdate(f"section {key!r} changed concurrently")
                if "vip_users" in changed:
                    from core.membership_bridge import validate_membership_reads
                    validate_membership_reads(connection.cursor())
                from core.economy_integrity import project_constraints
                project_constraints(connection.cursor(), before, after)
                now = utc_now_iso()
                for key in changed:
                    store._delete_categorized_section(connection, key)
                    if key not in after:
                        connection.execute("DELETE FROM section_registry WHERE section_key = ?", (key,))
                        continue
                    protected = protect_sensitive_payload({key: after[key]}, SETTINGS.sensitive_data_key)[key]
                    count = store._insert_categorized_section(connection, key, protected)
                    if key == USER_ACCOUNT_SECTION:
                        domain = "user_accounts"
                    elif key == USER_PROFILE_SECTION:
                        domain = "user_profiles"
                    elif key == USER_MEMBERSHIP_SECTION:
                        domain = "user_memberships"
                    elif key in USER_PREFERENCE_SECTIONS:
                        domain = "user_preferences"
                    elif key in USER_RECORD_SECTIONS:
                        domain = "user_records"
                    else:
                        domain = section_domain(key)
                    connection.execute(
                        """INSERT INTO section_registry(section_key,domain,container_type,checksum,record_count,updated_at)
                        VALUES(?,?,?,?,?,?) ON CONFLICT(section_key) DO UPDATE SET
                        domain=excluded.domain,container_type=excluded.container_type,checksum=excluded.checksum,
                        record_count=excluded.record_count,updated_at=excluded.updated_at""",
                        (key, domain, container_type(protected), section_checksum(protected), count, now),
                    )
                if index_sources.intersection(changed):
                    store._sync_indexes(connection, store._read_categorized(connection))
                # Every successful section-level commit must advance the same
                # compatibility version observed by load_db(). Without this, a
                # process could keep a stale full-database cache after another
                # writer changed a section, causing every optimistic retry to
                # compare against the same stale checksum.
                committed_version = store._increment_state_version(connection)
                connection.execute("COMMIT")
            except Exception:
                connection.execute("ROLLBACK")
                raise
        return committed_version if cache_safe else None

    with store._connect() as connection:
        with connection.transaction(), connection.cursor() as cursor:
            store._ensure_categorized_storage(cursor)
            # Per-section advisory locks avoid one global hot row. Sorted order
            # prevents deadlocks when an operation changes multiple sections.
            for key in changed:
                cursor.execute("SELECT pg_advisory_xact_lock(hashtextextended(%s, 0))", (key,))
            cursor.execute("SELECT section_key,checksum FROM section_registry")
            registry = {str(row[0]): str(row[1]) for row in cursor.fetchall()}
            digest = hashlib.md5("|".join(key + ":" + registry[key] for key in sorted(registry)).encode()).hexdigest()  # nosec B324 -- version fingerprint
            cache_safe = expected_version is not None and int(digest[:15], 16) == expected_version
            if "vip_users" in changed:
                from core.membership_bridge import validate_membership_reads
                validate_membership_reads(cursor, postgres=True)
            for key in changed:
                cursor.execute("SELECT checksum FROM section_registry WHERE section_key = %s", (key,))
                row = cursor.fetchone()
                current_checksum = str(row[0]) if row else None
                expected_checksum = _protected_section_checksum(key, before.get(key)) if row and key in before else None
                if current_checksum != expected_checksum:
                    raise ConcurrentDatabaseUpdate(f"section {key!r} changed concurrently")
            from core.economy_integrity import project_constraints
            project_constraints(cursor, before, after, postgres=True)
            now = utc_now_iso()
            for key in changed:
                store._delete_categorized_section(cursor, key)
                if key not in after:
                    cursor.execute("DELETE FROM section_registry WHERE section_key = %s", (key,))
                    continue
                protected = protect_sensitive_payload({key: after[key]}, SETTINGS.sensitive_data_key)[key]
                count = store._insert_categorized_section(cursor, key, protected)
                if key == USER_ACCOUNT_SECTION:
                    domain = "user_accounts"
                elif key == USER_PROFILE_SECTION:
                    domain = "user_profiles"
                elif key == USER_MEMBERSHIP_SECTION:
                    domain = "user_memberships"
                elif key in USER_PREFERENCE_SECTIONS:
                    domain = "user_preferences"
                elif key in USER_RECORD_SECTIONS:
                    domain = "user_records"
                else:
                    domain = section_domain(key)
                cursor.execute(
                    """INSERT INTO section_registry(section_key,domain,container_type,checksum,record_count,updated_at)
                    VALUES(%s,%s,%s,%s,%s,%s) ON CONFLICT(section_key) DO UPDATE SET
                    domain=EXCLUDED.domain,container_type=EXCLUDED.container_type,checksum=EXCLUDED.checksum,
                    record_count=EXCLUDED.record_count,updated_at=EXCLUDED.updated_at""",
                    (key, domain, container_type(protected), section_checksum(protected), count, now),
                )
            if index_sources.intersection(changed):
                store._sync_indexes(cursor, store._read_categorized(cursor))
            # Keep the compatibility/cache version monotonic for section-level
            # writers as well as legacy full transactions. This is not a global
            # business lock: PostgreSQL section advisory locks above still scope
            # concurrency, while the counter only invalidates process caches.
            store._increment_state_version(cursor)
    if not cache_safe:
        return None
    for key in changed:
        if key in after:
            registry[key] = _protected_section_checksum(key, after[key])
        else:
            registry.pop(key, None)
    digest = hashlib.md5("|".join(key + ":" + registry[key] for key in sorted(registry)).encode()).hexdigest()  # nosec B324
    return int(digest[:15], 16)


def _invalidate_runtime_indexes() -> None:
    """Invalidate optional process-local read indexes after a successful commit."""
    try:
        from modules.admin_command_os import invalidate_search_index
        invalidate_search_index()
    except Exception:
        logger.exception("Runtime search-index invalidation failed")


def _dispatch_automation_events(before: dict[str, Any], working: dict[str, Any]) -> None:
    """Derive business events inside the same database transaction.

    Automation failures are isolated from the originating business mutation;
    the event bus records per-rule errors and must never make a payment, ticket
    or signal update fail. The local import avoids a core.db import cycle.
    """
    try:
        from modules.automation_event_bus import dispatch_automation_events_inplace
        dispatch_automation_events_inplace(before, working)
    except Exception as exc:
        logger.exception("Automation event dispatch failed")
        working.setdefault("automation_v2_event_log", []).append({
            "id": f"dispatch-error-{utc_now_iso()}",
            "event_count": 0,
            "run_count": 0,
            "errors": [{"error": f"{exc.__class__.__name__}:{str(exc)[:300]}"}],
            "created_at": utc_now_iso(),
        })
        working["automation_v2_event_log"] = working["automation_v2_event_log"][-5000:]


def with_db(fn: Callable[[dict[str, Any]], T]) -> T:
    from core.membership_bridge import membership_mutation_scope
    with membership_mutation_scope():
        return _with_db_impl(fn)


def _with_db_impl(fn: Callable[[dict[str, Any]], T]) -> T:
    """Run a mutation against primary storage with durable Google failover."""
    global _CACHE, _CACHE_VERSION
    if _GOOGLE_FAILOVER_ACTIVE:
        primary_error = DatabaseLoadError(_GOOGLE_FAILOVER_LAST_ERROR or "primary database is in failover mode")
        return _with_google_failover_mutation(fn, primary_error)
    try:
        store = _get_store()
    except Exception as exc:
        if _should_use_google_failover(exc):
            return _with_google_failover_mutation(fn, exc)
        raise

    if not isinstance(store, (SQLiteStore, PostgresStore)):
        try:
            with _LOCK:
                before = copy.deepcopy(load_db())
                working = copy.deepcopy(before)
                result = fn(working)
                _dispatch_automation_events(before, working)
                canonical = validate_database_payload(working)
                changed = _changed_sections(before, canonical)
                store.write(canonical)
                _CACHE = canonical
                _invalidate_runtime_indexes()
            _mirror_primary_to_google(canonical, changed)
            return result
        except Exception as exc:
            if _should_use_google_failover(exc):
                return _with_google_failover_mutation(fn, exc)
            raise

    last_error: Exception | None = None
    for _attempt in range(4):
        from core.membership_bridge import reset_membership_reads
        reset_membership_reads()
        try:
            # Fast path: reuse the version-checked canonical cache instead of
            # reconstructing the entire categorized store for every legacy
            # callback. If optimistic validation detects that an extension/test
            # mutated a legacy cache reference or another writer won the race,
            # retries refresh directly from storage before re-running the callback.
            # This keeps the common path fast without weakening compatibility.
            if _attempt == 0:
                with _LOCK:
                    before = load_db()
                    before_version = _CACHE_VERSION
            else:
                before = store._read()
                before_version = None
            working = copy.deepcopy(before)
        except Exception as exc:
            if _should_use_google_failover(exc):
                return _with_google_failover_mutation(fn, exc)
            raise
        result = fn(working)
        _dispatch_automation_events(before, working)
        canonical = validate_database_payload(working)
        changed = _changed_sections(before, canonical)
        try:
            _commit_version = _commit_sections_optimistic(store, before=before, after=canonical, changed=changed, expected_version=before_version)
        except ConcurrentDatabaseUpdate as exc:
            last_error = exc
            continue
        except Exception as exc:
            if _should_use_google_failover(exc):
                return _with_google_failover_mutation(fn, exc)
            raise
        committed_version = _commit_version if _commit_version is not None and store.version() == _commit_version else None
        with _LOCK:
            _CACHE = canonical
            _CACHE_VERSION = committed_version
        _invalidate_runtime_indexes()
        _mirror_primary_to_google(canonical, changed)
        return result
    raise ConcurrentDatabaseUpdate("database sections changed repeatedly; retry the operation") from last_error

def snapshot() -> dict[str, Any]:
    with _LOCK:
        return copy.deepcopy(load_db())


def reset_cache_for_tests() -> None:
    global _CACHE, _CACHE_VERSION, _LAST_BACKUP_DATE
    global _GOOGLE_FAILOVER_ACTIVE, _GOOGLE_FAILOVER_BASE_CHECKSUM
    global _GOOGLE_FAILOVER_LAST_ERROR, _GOOGLE_FAILOVER_SYNC_VERSION, _GOOGLE_FAILOVER_STARTED_AT
    with _LOCK:
        _CACHE = None
        _CACHE_VERSION = None
        _LAST_BACKUP_DATE = None
        _GOOGLE_FAILOVER_ACTIVE = False
        _GOOGLE_FAILOVER_BASE_CHECKSUM = ""
        _GOOGLE_FAILOVER_LAST_ERROR = ""
        _GOOGLE_FAILOVER_SYNC_VERSION = ""
        _GOOGLE_FAILOVER_STARTED_AT = ""




def _read_db_section_primary(section_key: str) -> Any:
    """Return one section directly from relational storage when available."""
    key = str(section_key or "").strip()
    if not key:
        raise ValueError("section_key is required")
    store = _get_store()
    if isinstance(store, SQLiteStore):
        with _LOCK, closing(store._connect()) as connection:
            store._ensure_categorized_storage(connection)
            meta = connection.execute(
                "SELECT container_type FROM section_registry WHERE section_key = ?",
                (key,),
            ).fetchone()
            if meta is None:
                raise KeyError(key)
            if key == USER_ACCOUNT_SECTION:
                rows = connection.execute("SELECT user_id, payload FROM user_accounts ORDER BY user_id").fetchall()
                value = {str(row["user_id"]): store._json_load_sqlite(row["payload"]) for row in rows}
            elif key == USER_PROFILE_SECTION:
                rows = connection.execute("SELECT user_id, payload FROM user_profiles_rel ORDER BY user_id").fetchall()
                value = {str(row["user_id"]): store._json_load_sqlite(row["payload"]) for row in rows}
            elif key == USER_MEMBERSHIP_SECTION:
                rows = connection.execute("SELECT user_id, payload FROM user_memberships ORDER BY user_id").fetchall()
                value = {str(row["user_id"]): store._json_load_sqlite(row["payload"]) for row in rows}
            elif key in USER_PREFERENCE_SECTIONS:
                rows = connection.execute(
                    "SELECT user_id, payload FROM user_preferences WHERE section_key = ? ORDER BY user_id",
                    (key,),
                ).fetchall()
                value = {str(row["user_id"]): store._json_load_sqlite(row["payload"]) for row in rows}
            else:
                table = store._categorized_table(key)
                rows = connection.execute(
                    f"SELECT record_key, position, payload FROM {table} WHERE section_key = ? ORDER BY position, record_key",  # nosec B608
                    (key,),
                ).fetchall()
                value = reconstruct_section(
                    str(meta["container_type"]),
                    (
                        (
                            str(row["record_key"]),
                            int(row["position"]),
                            store._json_load_sqlite(row["payload"]),
                        )
                        for row in rows
                    ),
                )
            return copy.deepcopy(
                unprotect_sensitive_payload({key: value}, SETTINGS.sensitive_data_key)[key]
            )
    if isinstance(store, PostgresStore):
        with _LOCK, store._connect() as connection:
            with connection.cursor() as cursor:
                store._ensure_categorized_storage(cursor)
                cursor.execute(
                    "SELECT container_type FROM section_registry WHERE section_key = %s",
                    (key,),
                )
                meta = cursor.fetchone()
                if meta is None:
                    raise KeyError(key)
                if key == USER_ACCOUNT_SECTION:
                    cursor.execute("SELECT user_id, payload FROM user_accounts ORDER BY user_id")
                    value = {str(row[0]): store._json_load_postgres(row[1]) for row in cursor.fetchall()}
                elif key == USER_PROFILE_SECTION:
                    cursor.execute("SELECT user_id, payload FROM user_profiles_rel ORDER BY user_id")
                    value = {str(row[0]): store._json_load_postgres(row[1]) for row in cursor.fetchall()}
                elif key == USER_MEMBERSHIP_SECTION:
                    cursor.execute("SELECT user_id, payload FROM user_memberships ORDER BY user_id")
                    value = {str(row[0]): store._json_load_postgres(row[1]) for row in cursor.fetchall()}
                elif key in USER_PREFERENCE_SECTIONS:
                    cursor.execute(
                        "SELECT user_id, payload FROM user_preferences WHERE section_key = %s ORDER BY user_id",
                        (key,),
                    )
                    value = {str(row[0]): store._json_load_postgres(row[1]) for row in cursor.fetchall()}
                else:
                    table = store._categorized_table(key)
                    cursor.execute(
                        f"SELECT record_key, position, payload FROM {table} WHERE section_key = %s ORDER BY position, record_key",  # nosec B608
                        (key,),
                    )
                    value = reconstruct_section(
                        str(meta[0]),
                        (
                            (str(row[0]), int(row[1]), store._json_load_postgres(row[2]))
                            for row in cursor.fetchall()
                        ),
                    )
                return copy.deepcopy(
                    unprotect_sensitive_payload({key: value}, SETTINGS.sensitive_data_key)[key]
                )
    data = snapshot()
    if key not in data:
        raise KeyError(key)
    return copy.deepcopy(data[key])



def read_db_section(section_key: str) -> Any:
    key = str(section_key or "").strip()
    if not key:
        raise ValueError("section_key is required")
    if _GOOGLE_FAILOVER_ACTIVE:
        data = load_db()
        if key not in data:
            raise KeyError(key)
        return copy.deepcopy(data[key])
    try:
        return _read_db_section_primary(key)
    except Exception as exc:
        if not _should_use_google_failover(exc):
            raise
        data = _activate_google_failover(exc)
        if key not in data:
            raise KeyError(key)
        return copy.deepcopy(data[key])


def _query_db_records_primary(
    section_key: str,
    *,
    user_id: int | str | None = None,
    status: str | None = None,
    limit: int = 100,
    newest_first: bool = True,
) -> list[Any]:
    """Read a bounded set of rows without materializing the complete database."""
    key = str(section_key or "").strip()
    if not key:
        raise ValueError("section_key is required")
    bounded_limit = max(1, min(10_000, int(limit or 100)))
    store = _get_store()
    if (
        not isinstance(store, (SQLiteStore, PostgresStore))
        or key in {USER_ACCOUNT_SECTION, USER_PROFILE_SECTION, USER_MEMBERSHIP_SECTION}
        or key in USER_PREFERENCE_SECTIONS
    ):
        value = read_db_section(key)
        rows = list(value.values()) if isinstance(value, dict) else list(value) if isinstance(value, list) else [value]
        if user_id is not None:
            rows = [row for row in rows if isinstance(row, dict) and str(row.get("user_id")) == str(user_id)]
        if status is not None:
            rows = [row for row in rows if isinstance(row, dict) and str(row.get("status")) == str(status)]
        return copy.deepcopy((list(reversed(rows)) if newest_first else rows)[:bounded_limit])

    order = "DESC" if newest_first else "ASC"
    if isinstance(store, SQLiteStore):
        with _LOCK, closing(store._connect()) as connection:
            store._ensure_categorized_storage(connection)
            table = store._categorized_table(key)
            clauses = ["section_key = ?"]
            params: list[Any] = [key]
            if user_id is not None:
                clauses.append("user_id = ?")
                params.append(str(user_id))
            if status is not None:
                clauses.append("status = ?")
                params.append(str(status))
            params.append(bounded_limit)
            sql = (
                f"SELECT payload FROM {table} WHERE {' AND '.join(clauses)} "  # nosec B608
                f"ORDER BY position {order}, record_key {order} LIMIT ?"  # nosec B608
            )
            payloads = [store._json_load_sqlite(row["payload"]) for row in connection.execute(sql, params)]
    else:
        with _LOCK, store._connect() as connection:
            with connection.cursor() as cursor:
                store._ensure_categorized_storage(cursor)
                table = store._categorized_table(key)
                clauses = ["section_key = %s"]
                params = [key]
                if user_id is not None:
                    clauses.append("user_id = %s")
                    params.append(str(user_id))
                if status is not None:
                    clauses.append("status = %s")
                    params.append(str(status))
                params.append(bounded_limit)
                sql = (
                    f"SELECT payload FROM {table} WHERE {' AND '.join(clauses)} "  # nosec B608
                    f"ORDER BY position {order}, record_key {order} LIMIT %s"  # nosec B608
                )
                cursor.execute(sql, params)
                payloads = [store._json_load_postgres(row[0]) for row in cursor.fetchall()]
    return copy.deepcopy(
        unprotect_sensitive_payload({"records": payloads}, SETTINGS.sensitive_data_key)["records"]
    )



def query_db_records(
    section_key: str,
    *,
    user_id: int | str | None = None,
    status: str | None = None,
    limit: int = 100,
    newest_first: bool = True,
) -> list[Any]:
    if not _GOOGLE_FAILOVER_ACTIVE:
        try:
            return _query_db_records_primary(
                section_key,
                user_id=user_id,
                status=status,
                limit=limit,
                newest_first=newest_first,
            )
        except Exception as exc:
            if not _should_use_google_failover(exc):
                raise
            _activate_google_failover(exc)
    value = read_db_section(section_key)
    rows = list(value.values()) if isinstance(value, dict) else list(value) if isinstance(value, list) else [value]
    if user_id is not None:
        rows = [row for row in rows if isinstance(row, dict) and str(row.get("user_id")) == str(user_id)]
    if status is not None:
        rows = [row for row in rows if isinstance(row, dict) and str(row.get("status")) == str(status)]
    bounded = max(1, min(10_000, int(limit or 100)))
    ordered = list(reversed(rows)) if newest_first else rows
    return copy.deepcopy(ordered[:bounded])


def _read_db_record_primary(section_key: str, record_key: int | str) -> Any | None:
    """Read one dictionary record without materializing its complete section."""
    key = str(section_key or "").strip()
    target = str(record_key)
    if not key or not target:
        raise ValueError("section_key and record_key are required")
    store = _get_store()
    if not isinstance(store, (SQLiteStore, PostgresStore)):
        value = read_db_section(key)
        return copy.deepcopy(value.get(target)) if isinstance(value, dict) else None
    if key in {
        USER_ACCOUNT_SECTION,
        USER_PROFILE_SECTION,
        USER_MEMBERSHIP_SECTION,
        *USER_PREFERENCE_SECTIONS,
    }:
        value = read_db_section(key)
        return copy.deepcopy(value.get(target)) if isinstance(value, dict) else None

    table = store._categorized_table(key)
    if isinstance(store, SQLiteStore):
        with _LOCK, closing(store._connect()) as connection:
            store._ensure_categorized_storage(connection)
            meta = connection.execute(
                "SELECT container_type FROM section_registry WHERE section_key = ?",
                (key,),
            ).fetchone()
            if meta is None:
                raise KeyError(key)
            if str(meta["container_type"]) != "dict":
                raise TypeError(f"section {key} is not a dictionary")
            row = connection.execute(
                f"SELECT payload FROM {table} WHERE section_key = ? AND record_key = ?",  # nosec B608
                (key, target),
            ).fetchone()
            payload = None if row is None else store._json_load_sqlite(row["payload"])
    else:
        with _LOCK, store._connect() as connection, connection.cursor() as cursor:
            store._ensure_categorized_storage(cursor)
            cursor.execute(
                "SELECT container_type FROM section_registry WHERE section_key = %s",
                (key,),
            )
            meta = cursor.fetchone()
            if meta is None:
                raise KeyError(key)
            if str(meta[0]) != "dict":
                raise TypeError(f"section {key} is not a dictionary")
            cursor.execute(
                f"SELECT payload FROM {table} WHERE section_key = %s AND record_key = %s",  # nosec B608
                (key, target),
            )
            row = cursor.fetchone()
            payload = None if row is None else store._json_load_postgres(row[0])
    if payload is None:
        return None
    return copy.deepcopy(
        unprotect_sensitive_payload({key: {target: payload}}, SETTINGS.sensitive_data_key)[key][target]
    )



def read_db_record(section_key: str, record_key: int | str) -> Any | None:
    key = str(section_key or "").strip()
    target = str(record_key)
    if not key or not target:
        raise ValueError("section_key and record_key are required")
    if not _GOOGLE_FAILOVER_ACTIVE:
        try:
            return _read_db_record_primary(key, target)
        except Exception as exc:
            if not _should_use_google_failover(exc):
                raise
            _activate_google_failover(exc)
    value = read_db_section(key)
    return copy.deepcopy(value.get(target)) if isinstance(value, dict) else None


def _upsert_db_record_primary(section_key: str, record_key: int | str, payload: Any) -> Any:
    """Atomically upsert one categorized dictionary row.

    Index-source sections keep the legacy full transaction so their specialized
    search indexes remain authoritative. Other high-volume dictionaries avoid
    loading or rewriting unrelated sections.
    """
    global _CACHE, _CACHE_VERSION
    key = str(section_key or "").strip()
    target = str(record_key)
    if not key or not target:
        raise ValueError("section_key and record_key are required")
    store = _get_store()
    if (
        not isinstance(store, (SQLiteStore, PostgresStore))
        or key in _INDEX_SOURCE_KEYS
        or key in {
            USER_ACCOUNT_SECTION,
            USER_PROFILE_SECTION,
            USER_MEMBERSHIP_SECTION,
            *USER_PREFERENCE_SECTIONS,
        }
    ):
        def mutate(section: Any) -> Any:
            if not isinstance(section, dict):
                raise TypeError(f"section {key} is not a dictionary")
            section[target] = copy.deepcopy(payload)
            return copy.deepcopy(payload)

        return with_db_section(key, mutate)

    protected = protect_sensitive_payload(
        {key: {target: copy.deepcopy(payload)}},
        SETTINGS.sensitive_data_key,
    )[key][target]
    record = next(iter(iter_section_records({target: protected})))
    now = utc_now_iso()
    table = store._categorized_table(key)
    with _LOCK:
        if isinstance(store, SQLiteStore):
            with closing(store._connect()) as connection:
                connection.execute("BEGIN IMMEDIATE")
                try:
                    store._ensure_categorized_storage(connection)
                    meta = connection.execute(
                        "SELECT container_type FROM section_registry WHERE section_key = ?",
                        (key,),
                    ).fetchone()
                    if meta is None:
                        raise KeyError(key)
                    if str(meta["container_type"]) != "dict":
                        raise TypeError(f"section {key} is not a dictionary")
                    existing = connection.execute(
                        f"SELECT position FROM {table} WHERE section_key = ? AND record_key = ?",  # nosec B608
                        (key, target),
                    ).fetchone()
                    if existing is None:
                        position = int(
                            connection.execute(
                                f"SELECT COALESCE(MAX(position), -1) + 1 FROM {table} WHERE section_key = ?",  # nosec B608
                                (key,),
                            ).fetchone()[0]
                        )
                    else:
                        position = int(existing["position"])
                    user_id = record.user_id or (
                        user_id_from_key_or_payload(target, protected)
                        if table == "user_records"
                        else ""
                    )
                    connection.execute(
                        f"""INSERT INTO {table}(
                            section_key, record_key, position, user_id, status,
                            created_at, updated_at, payload
                        ) VALUES(?,?,?,?,?,?,?,?)
                        ON CONFLICT(section_key, record_key) DO UPDATE SET
                            user_id=excluded.user_id, status=excluded.status,
                            created_at=excluded.created_at, updated_at=excluded.updated_at,
                            payload=excluded.payload""",  # nosec B608
                        (
                            key,
                            target,
                            position,
                            user_id,
                            record.status,
                            record.created_at,
                            record.updated_at or now,
                            json_text(protected),
                        ),
                    )
                    count = int(
                        connection.execute(
                            f"SELECT COUNT(*) FROM {table} WHERE section_key = ?",  # nosec B608
                            (key,),
                        ).fetchone()[0]
                    )
                    connection.execute(
                        """UPDATE section_registry
                        SET checksum = ?, record_count = ?, updated_at = ?
                        WHERE section_key = ?""",
                        (f"row-level:{now}", count, now, key),
                    )
                    version = store._increment_state_version(connection)
                    connection.execute("COMMIT")
                except Exception:
                    connection.execute("ROLLBACK")
                    raise
        else:
            with store._connect() as connection, connection.transaction(), connection.cursor() as cursor:
                store._ensure_categorized_storage(cursor)
                cursor.execute(
                    "SELECT container_type FROM section_registry WHERE section_key = %s FOR UPDATE",
                    (key,),
                )
                meta = cursor.fetchone()
                if meta is None:
                    raise KeyError(key)
                if str(meta[0]) != "dict":
                    raise TypeError(f"section {key} is not a dictionary")
                cursor.execute(
                    f"SELECT position FROM {table} WHERE section_key = %s AND record_key = %s",  # nosec B608
                    (key, target),
                )
                existing = cursor.fetchone()
                if existing is None:
                    cursor.execute(
                        f"SELECT COALESCE(MAX(position), -1) + 1 FROM {table} WHERE section_key = %s",  # nosec B608
                        (key,),
                    )
                    position = int(cursor.fetchone()[0])
                else:
                    position = int(existing[0])
                user_id = record.user_id or (
                    user_id_from_key_or_payload(target, protected)
                    if table == "user_records"
                    else ""
                )
                cursor.execute(
                    f"""INSERT INTO {table}(
                        section_key, record_key, position, user_id, status,
                        created_at, updated_at, payload
                    ) VALUES(%s,%s,%s,%s,%s,%s,%s,%s::jsonb)
                    ON CONFLICT(section_key, record_key) DO UPDATE SET
                        user_id=EXCLUDED.user_id, status=EXCLUDED.status,
                        created_at=EXCLUDED.created_at, updated_at=EXCLUDED.updated_at,
                        payload=EXCLUDED.payload""",  # nosec B608
                    (
                        key,
                        target,
                        position,
                        user_id,
                        record.status,
                        record.created_at,
                        record.updated_at or now,
                        json_text(protected),
                    ),
                )
                cursor.execute(
                    f"SELECT COUNT(*) FROM {table} WHERE section_key = %s",  # nosec B608
                    (key,),
                )
                count = int(cursor.fetchone()[0])
                cursor.execute(
                    """UPDATE section_registry
                    SET checksum = %s, record_count = %s, updated_at = NOW()
                    WHERE section_key = %s""",
                    (f"row-level:{now}", count, key),
                )
                version = store._increment_state_version(cursor)
        if _CACHE is not None:
            cached_section = _CACHE.setdefault(key, {})
            if isinstance(cached_section, dict):
                cached_section[target] = copy.deepcopy(payload)
        _CACHE_VERSION = None  # A row patch cannot prove freshness of every cached section.
    return copy.deepcopy(payload)



def upsert_db_record(section_key: str, record_key: int | str, payload: Any) -> Any:
    key = str(section_key or "").strip()
    target = str(record_key)
    if not key or not target:
        raise ValueError("section_key and record_key are required")
    primary_error: BaseException = DatabaseLoadError(_GOOGLE_FAILOVER_LAST_ERROR or "primary database unavailable")
    if not _GOOGLE_FAILOVER_ACTIVE:
        try:
            result = _upsert_db_record_primary(key, target, payload)
            # Fast-path row upserts bypass with_db(), so mirror the completed
            # logical section here. Index-source sections already sync through
            # with_db and duplicate writes are avoided by their primary path.
            if key not in _INDEX_SOURCE_KEYS and key not in {
                USER_ACCOUNT_SECTION,
                USER_PROFILE_SECTION,
                USER_MEMBERSHIP_SECTION,
                *USER_PREFERENCE_SECTIONS,
            }:
                try:
                    full_snapshot = snapshot()
                    _mirror_primary_to_google(full_snapshot, (key,))
                except Exception:
                    logger.exception("Google Sheets mirror after row-level upsert failed")
            return result
        except Exception as exc:
            if not _should_use_google_failover(exc):
                raise
            primary_error = exc
    def mutate(section: Any) -> Any:
        if not isinstance(section, dict):
            raise TypeError(f"section {key} is not a dictionary")
        section[target] = copy.deepcopy(payload)
        return copy.deepcopy(payload)
    def mutate_db(db: dict[str, Any]) -> Any:
        if key not in db:
            raise KeyError(key)
        return mutate(db[key])

    return _with_google_failover_mutation(mutate_db, primary_error)


def with_db_section(section_key: str, fn: Callable[[Any], T]) -> T:
    """Mutate one logical section without materializing the entire database.

    When Automation V2 has active rules, the full compatibility transaction is
    retained because event derivation intentionally compares multiple domains.
    Otherwise relational backends use optimistic per-section commits, which
    keeps a small user preference/points mutation from deep-copying the whole
    database as the installation grows.
    """
    global _CACHE, _CACHE_VERSION
    key = str(section_key or "").strip()
    if not key:
        raise ValueError("section_key is required")

    def _mutate(db: dict[str, Any]) -> T:
        if key not in db:
            raise KeyError(key)
        return fn(db[key])

    if _GOOGLE_FAILOVER_ACTIVE or key == "automation_rules_v2":
        return with_db(_mutate)

    try:
        rules = _read_db_section_primary("automation_rules_v2")
        automation_active = isinstance(rules, dict) and any(
            isinstance(row, dict) and bool(row.get("enabled")) for row in rules.values()
        )
    except KeyError:
        automation_active = False
    except Exception:
        # Any uncertainty keeps the conservative legacy path.
        return with_db(_mutate)
    if automation_active:
        return with_db(_mutate)

    try:
        store = _get_store()
    except Exception as exc:
        if _should_use_google_failover(exc):
            return _with_google_failover_mutation(_mutate, exc)
        raise
    if not isinstance(store, (SQLiteStore, PostgresStore)):
        return with_db(_mutate)

    last_error: Exception | None = None
    for _attempt in range(4):
        try:
            before_value = _read_db_section_primary(key)
        except Exception as exc:
            if _should_use_google_failover(exc):
                return _with_google_failover_mutation(_mutate, exc)
            raise
        working_value = copy.deepcopy(before_value)
        result = fn(working_value)
        # Preserve the established JSON-safety invariant without forcing a full
        # cross-domain migration/validation pass for an unrelated section.
        json.dumps(working_value, ensure_ascii=False, allow_nan=False)
        if isinstance(before_value, dict) and not isinstance(working_value, dict):
            raise TypeError(f"section {key!r} must remain a dictionary")
        if isinstance(before_value, list) and not isinstance(working_value, list):
            raise TypeError(f"section {key!r} must remain a list")
        before = {key: before_value}
        after = {key: working_value}
        try:
            _commit_sections_optimistic(store, before=before, after=after, changed=(key,))
        except ConcurrentDatabaseUpdate as exc:
            last_error = exc
            continue
        except Exception as exc:
            if _should_use_google_failover(exc):
                return _with_google_failover_mutation(_mutate, exc)
            raise
        committed_version = None  # Invalidate: another writer may commit before cache publication.
        with _LOCK:
            if _CACHE is not None:
                _CACHE[key] = copy.deepcopy(working_value)
            _CACHE_VERSION = committed_version
        _invalidate_runtime_indexes()
        _mirror_primary_to_google(after, (key,))
        return result
    raise ConcurrentDatabaseUpdate(f"section {key!r} changed repeatedly; retry the operation") from last_error


def with_db_sections(section_keys: Iterable[str], fn: Callable[[dict[str, Any]], T]) -> T:
    """Mutate a bounded set of top-level sections with one optimistic commit.

    This is the safe migration bridge between the legacy whole-database callback
    API and row/section repositories.  It never materializes unrelated sections
    when Automation V2 is inactive.  If automation rules are enabled (or the
    primary store cannot prove section-level semantics), it conservatively falls
    back to ``with_db`` so cross-domain event derivation remains unchanged.
    """
    global _CACHE, _CACHE_VERSION
    keys = tuple(dict.fromkeys(str(key or "").strip() for key in section_keys if str(key or "").strip()))
    if not keys:
        raise ValueError("at least one section key is required")

    def _mutate_full(db: dict[str, Any]) -> T:
        subset = {key: db[key] for key in keys if key in db}
        missing = [key for key in keys if key not in subset]
        if missing:
            raise KeyError(missing[0])
        result = fn(subset)
        for key in keys:
            if key in subset:
                db[key] = subset[key]
            else:
                db.pop(key, None)
        return result

    if _GOOGLE_FAILOVER_ACTIVE or "automation_rules_v2" in keys:
        return with_db(_mutate_full)

    try:
        rules = _read_db_section_primary("automation_rules_v2")
        automation_active = isinstance(rules, dict) and any(
            isinstance(row, dict) and bool(row.get("enabled")) for row in rules.values()
        )
    except KeyError:
        automation_active = False
    except Exception:
        return with_db(_mutate_full)
    if automation_active:
        return with_db(_mutate_full)

    try:
        store = _get_store()
    except Exception as exc:
        if _should_use_google_failover(exc):
            return _with_google_failover_mutation(_mutate_full, exc)
        raise
    if not isinstance(store, (SQLiteStore, PostgresStore)):
        return with_db(_mutate_full)

    last_error: Exception | None = None
    for _attempt in range(4):
        before: dict[str, Any] = {}
        try:
            for key in keys:
                before[key] = _read_db_section_primary(key)
        except Exception as exc:
            if _should_use_google_failover(exc):
                return _with_google_failover_mutation(_mutate_full, exc)
            raise
        working = copy.deepcopy(before)
        result = fn(working)
        for key in keys:
            if key not in working:
                continue
            json.dumps(working[key], ensure_ascii=False, allow_nan=False)
            previous = before.get(key)
            current = working[key]
            if isinstance(previous, dict) and not isinstance(current, dict):
                raise TypeError(f"section {key!r} must remain a dictionary")
            if isinstance(previous, list) and not isinstance(current, list):
                raise TypeError(f"section {key!r} must remain a list")
        changed = tuple(
            key for key in keys
            if (key in before) != (key in working) or before.get(key) != working.get(key)
        )
        if not changed:
            return result
        try:
            _commit_sections_optimistic(store, before=before, after=working, changed=changed)
        except ConcurrentDatabaseUpdate as exc:
            last_error = exc
            continue
        except Exception as exc:
            if _should_use_google_failover(exc):
                return _with_google_failover_mutation(_mutate_full, exc)
            raise
        committed_version = None  # Invalidate: another writer may commit before cache publication.
        with _LOCK:
            if _CACHE is not None:
                for key in changed:
                    if key in working:
                        _CACHE[key] = copy.deepcopy(working[key])
                    else:
                        _CACHE.pop(key, None)
            _CACHE_VERSION = committed_version
        _invalidate_runtime_indexes()
        _mirror_primary_to_google(working, changed)
        return result
    raise ConcurrentDatabaseUpdate(
        f"database sections {keys!r} changed repeatedly; retry the operation"
    ) from last_error


def database_catalog() -> dict[str, Any]:
    """Return a safe operational overview of the categorized database."""
    if _GOOGLE_FAILOVER_ACTIVE:
        data = snapshot()
        sections = []
        for key, value in sorted(data.items()):
            count = len(value) if isinstance(value, (dict, list)) else 1
            sections.append({
                "section": key,
                "domain": section_domain(key),
                "container": container_type(value),
                "records": count,
                "updated_at": "google-failover",
            })
        domain_totals: dict[str, int] = {}
        for item in sections:
            domain = str(item["domain"])
            domain_totals[domain] = domain_totals.get(domain, 0) + int(item["records"])
        return {
            "backend": "GoogleSheetsFailover",
            "schema_version": SCHEMA_VERSION,
            "relational_storage_version": RELATIONAL_STORAGE_VERSION,
            "state_version": 0,
            "users": len(data.get("users", {})) if isinstance(data.get("users"), dict) else 0,
            "user_profiles": len(data.get("user_profiles", {})) if isinstance(data.get("user_profiles"), dict) else 0,
            "active_or_historical_memberships": len(data.get("vip_users", {})) if isinstance(data.get("vip_users"), dict) else 0,
            "section_count": len(sections),
            "domain_totals": domain_totals,
            "sections": sections,
        }
    store = _get_store()
    if isinstance(store, SQLiteStore):
        with closing(store._connect()) as connection:
            store._ensure_categorized_storage(connection)
            rows = connection.execute(
                "SELECT section_key, domain, container_type, record_count, updated_at "
                "FROM section_registry ORDER BY domain, section_key"
            ).fetchall()
            sections = [
                {
                    "section": str(row["section_key"]),
                    "domain": str(row["domain"]),
                    "container": str(row["container_type"]),
                    "records": int(row["record_count"]),
                    "updated_at": str(row["updated_at"]),
                }
                for row in rows
            ]
            user_count = int(connection.execute("SELECT COUNT(*) FROM user_accounts").fetchone()[0])
            profile_count = int(connection.execute("SELECT COUNT(*) FROM user_profiles_rel").fetchone()[0])
            membership_count = int(connection.execute("SELECT COUNT(*) FROM user_memberships").fetchone()[0])
            version = store.version()
    elif isinstance(store, PostgresStore):
        with store._connect() as connection, connection.cursor() as cursor:
            store._ensure_categorized_storage(cursor)
            cursor.execute(
                "SELECT section_key, domain, container_type, record_count, updated_at "
                "FROM section_registry ORDER BY domain, section_key"
            )
            sections = [
                {
                    "section": str(row[0]),
                    "domain": str(row[1]),
                    "container": str(row[2]),
                    "records": int(row[3]),
                    "updated_at": str(row[4]),
                }
                for row in cursor.fetchall()
            ]
            cursor.execute("SELECT COUNT(*) FROM user_accounts")
            user_count = int(cursor.fetchone()[0])
            cursor.execute("SELECT COUNT(*) FROM user_profiles_rel")
            profile_count = int(cursor.fetchone()[0])
            cursor.execute("SELECT COUNT(*) FROM user_memberships")
            membership_count = int(cursor.fetchone()[0])
            version = store.version()
    else:
        data = store._read()
        sections = []
        for key, value in sorted(data.items()):
            if isinstance(value, (dict, list)):
                count = len(value)
            else:
                count = 1
            sections.append(
                {
                    "section": key,
                    "domain": section_domain(key),
                    "container": container_type(value),
                    "records": count,
                    "updated_at": "",
                }
            )
        user_count = len(data.get("users", {})) if isinstance(data.get("users"), dict) else 0
        profile_count = len(data.get("user_profiles", {})) if isinstance(data.get("user_profiles"), dict) else 0
        membership_count = len(data.get("vip_users", {})) if isinstance(data.get("vip_users"), dict) else 0
        version = 1

    domain_totals: dict[str, int] = {}
    for item in sections:
        domain = str(item["domain"])
        domain_totals[domain] = domain_totals.get(domain, 0) + int(item["records"])
    return {
        "backend": type(store).__name__,
        "schema_version": SCHEMA_VERSION,
        "relational_storage_version": RELATIONAL_STORAGE_VERSION,
        "state_version": int(version),
        "users": user_count,
        "user_profiles": profile_count,
        "active_or_historical_memberships": membership_count,
        "section_count": len(sections),
        "domain_totals": domain_totals,
        "sections": sections,
    }

def database_healthcheck() -> bool:
    """Perform a bounded connectivity check for the active writable backend.

    This function intentionally avoids loading the canonical database snapshot.
    It is designed for a background readiness worker, not direct request-path I/O.
    """
    if _GOOGLE_FAILOVER_ACTIVE:
        try:
            backup = _google_backup_module()
            cfg = backup.config()
            return bool(
                cfg.write_failover
                and backup.healthcheck()
                and _CACHE
                and int(_CACHE.get("schema_version", 0) or 0) == SCHEMA_VERSION
            )
        except Exception:
            logger.exception("Google Sheets failover readiness probe failed")
            return False
    try:
        store = _get_store()
        if hasattr(store, "healthcheck"):
            return bool(store.healthcheck())
        return True
    except Exception:
        logger.exception("Database readiness probe failed")
        return False


def read_db_sections(section_keys: Iterable[str]) -> dict[str, Any]:
    """Read only the requested logical sections into a compatibility snapshot.

    Mini App GET endpoints use this path so PostgreSQL/SQLite do not materialize
    or lock unrelated business domains. Missing optional sections receive their
    canonical default and may be safely initialized by read helpers without
    affecting persistent state.
    """
    requested = tuple(dict.fromkeys(str(key).strip() for key in section_keys if str(key).strip()))
    data: dict[str, Any] = {"schema_version": SCHEMA_VERSION}
    for key in requested:
        try:
            data[key] = read_db_section(key)
        except KeyError:
            data[key] = copy.deepcopy(DEFAULT_DB.get(key, {}))
    # Core helpers often use these counters/settings as read-time defaults.
    for key in ("settings", "next_ids", "operations"):
        if key not in data and key in requested:
            data[key] = copy.deepcopy(DEFAULT_DB.get(key, {}))
    return data


def with_db_read_sections(section_keys: Iterable[str], fn: Callable[[dict[str, Any]], T]) -> T:
    """Run a callback against a bounded, defensive, read-only snapshot."""
    return fn(read_db_sections(section_keys))
