from __future__ import annotations

import base64
import gzip
import hashlib
import json
import logging
import os
import socket
import threading
import tempfile
import time
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from pathlib import Path
from typing import Any, Callable, Iterable, Sequence
from urllib.parse import quote

import httpx
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding

from config import SETTINGS
from core.relational_storage import container_type
from core.sensitive_data import protect_sensitive_payload, unprotect_sensitive_payload
from core.storage.schema import SCHEMA_REVISION

logger = logging.getLogger(__name__)

DEFAULT_SPREADSHEET_ID = "1vZrEIJvLXADn46dXMmsPGxl1Z4nsvPPB2r-SSxaDW8M"
RAW_SHEET = "RAW_BACKUP"
SYNC_LOG_SHEET = "SYNC_LOG"
RAW_HEADER_COLUMNS = 8
RAW_FIRST_CHUNK_COLUMN = 9  # I
RAW_MAX_ROWS = 2000
RAW_MAX_COLUMNS = 320
RAW_CHUNK_CHARS = 40_000
META_SECTION = "__SENTINEL_META__"
V8_META_SECTION = "__V8_META__"
FULL_SNAPSHOT_MARKER = "__SENTINEL_FORCE_FULL_SNAPSHOT__"
BACKUP_ATTESTATION_SECTION = "__SENTINEL_BACKUP_ATTESTATION__"
V8_TABLE_PREFIX = "__V8_TABLE__:"
V8_GENERATION_TABLE_PREFIX = "__V8_GEN_TABLE__:"
V8_GENERATION_MANIFEST_PREFIX = "__V8_GEN_MANIFEST__:"
V8_GENERATIONS_TO_KEEP = 5
LEGACY_GENERATION_SECTION_PREFIX = "__LEGACY_GEN_SECTION__:"
LEGACY_GENERATION_MANIFEST_PREFIX = "__LEGACY_GEN_MANIFEST__:"
LEGACY_GENERATIONS_TO_KEEP = 5
NORMALIZED_TABLES: tuple[str, ...] = (
    "v8_schema_migrations", "v8_meta", "v8_signals", "v8_signal_revisions",
    "v8_signal_outcomes", "v8_trading_accounts", "v8_positions", "v8_position_pnl_events",
    "v8_equity_events", "v8_broker_snapshots", "v8_daily_account_snapshots",
    "v8_prop_rule_templates", "v8_prop_rule_evaluations", "v8_receipts",
    "v8_checkout_quotes", "v8_vip_orders", "v8_vip_entitlements", "v8_tickets",
    "v8_ticket_messages", "v8_user_preferences", "v8_journal_entries", "v8_admin_commands",
    "v8_idempotency", "v8_events", "v8_data_provenance", "v8_market_returns",
    "v8_audit_log", "v8_telegram_updates", "v8_mt5_pairing_codes", "v8_mt5_connectors",
    "v8_mt5_nonces", "v8_mt5_events", "v8_risk_daily_plans", "v8_risk_checkins",
    "v8_prop_alerts", "v8_recovery_runs",
    "signal_deletion_audit", "economy_referral_codes", "economy_referral_attribution", "economy_ledger",
)
_SCOPE = "https://www.googleapis.com/auth/spreadsheets"
_SECRET_MARKERS = (
    "token",
    "secret",
    "password",
    "private_key",
    "api_key",
    "apikey",
    "credential",
    "authorization",
    "cookie",
    "session_secret",
    "webhook_secret",
    "encryption_key",
)


class GoogleSheetsBackupError(RuntimeError):
    pass


class GoogleSheetsBackupNotConfigured(GoogleSheetsBackupError):
    pass


@dataclass(frozen=True, slots=True)
class GoogleSheetsBackupConfig:
    enabled: bool
    spreadsheet_id: str
    service_account: dict[str, Any] | None
    timeout_seconds: float
    max_retries: int
    write_failover: bool
    auto_reconcile: bool
    projection_enabled: bool


def _truthy(name: str, default: bool = False) -> bool:
    raw = str(os.getenv(name, "true" if default else "false") or "").strip().lower()
    return raw in {"1", "true", "yes", "on"}


def _load_service_account() -> dict[str, Any] | None:
    raw = str(os.getenv("GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON", "") or "").strip()
    raw_b64 = str(os.getenv("GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON_B64", "") or "").strip()
    if not raw and raw_b64:
        try:
            raw = base64.b64decode(raw_b64).decode("utf-8")
        except Exception as exc:  # pragma: no cover - defensive configuration path
            raise GoogleSheetsBackupError("GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON_B64 is invalid") from exc
    if not raw:
        return None
    try:
        parsed = json.loads(raw)
    except json.JSONDecodeError as exc:
        raise GoogleSheetsBackupError("GOOGLE_SHEETS_SERVICE_ACCOUNT_JSON is not valid JSON") from exc
    if not isinstance(parsed, dict):
        raise GoogleSheetsBackupError("Google service-account credentials must be a JSON object")
    if not parsed.get("client_email") or not parsed.get("private_key"):
        raise GoogleSheetsBackupError("Google service-account JSON is missing client_email/private_key")
    return parsed


def config() -> GoogleSheetsBackupConfig:
    enabled = _truthy("GOOGLE_SHEETS_BACKUP_ENABLED", True)
    service_account = _load_service_account() if enabled else None
    try:
        timeout_seconds = max(2.0, min(float(os.getenv("GOOGLE_SHEETS_TIMEOUT_SECONDS", "8") or 8), 30.0))
    except ValueError:
        timeout_seconds = 8.0
    try:
        max_retries = max(0, min(int(os.getenv("GOOGLE_SHEETS_MAX_RETRIES", "3") or 3), 6))
    except ValueError:
        max_retries = 3
    return GoogleSheetsBackupConfig(
        enabled=enabled,
        spreadsheet_id=str(os.getenv("GOOGLE_SHEETS_SPREADSHEET_ID", DEFAULT_SPREADSHEET_ID) or DEFAULT_SPREADSHEET_ID).strip(),
        service_account=service_account,
        timeout_seconds=timeout_seconds,
        max_retries=max_retries,
        write_failover=_truthy("GOOGLE_SHEETS_WRITE_FAILOVER", True),
        auto_reconcile=_truthy("GOOGLE_SHEETS_AUTO_RECONCILE", True),
        projection_enabled=_truthy("GOOGLE_SHEETS_PROJECTION_ENABLED", True),
    )


def is_configured() -> bool:
    try:
        cfg = config()
    except GoogleSheetsBackupError:
        return False
    return bool(cfg.enabled and cfg.spreadsheet_id and cfg.service_account)


def service_account_email() -> str:
    try:
        cfg = config()
    except GoogleSheetsBackupError:
        return ""
    if not cfg.service_account:
        return ""
    return str(cfg.service_account.get("client_email") or "")


def _b64url(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).rstrip(b"=").decode("ascii")


class _GoogleSheetsClient:
    def __init__(self, cfg: GoogleSheetsBackupConfig):
        if not cfg.enabled or not cfg.spreadsheet_id or not cfg.service_account:
            raise GoogleSheetsBackupNotConfigured("Google Sheets backup credentials are not configured")
        self.cfg = cfg
        self._token = ""  # nosec B105
        self._token_expires_at = 0.0
        self._token_lock = threading.Lock()

    def _jwt_assertion(self) -> tuple[str, str]:
        credentials = self.cfg.service_account or {}
        token_uri = str(credentials.get("token_uri") or "https://oauth2.googleapis.com/token")
        now = int(time.time())
        header = {"alg": "RS256", "typ": "JWT"}
        payload = {
            "iss": str(credentials["client_email"]),
            "scope": _SCOPE,
            "aud": token_uri,
            "iat": now,
            "exp": now + 3600,
        }
        encoded_header = _b64url(json.dumps(header, separators=(",", ":"), sort_keys=True).encode("utf-8"))
        encoded_payload = _b64url(json.dumps(payload, separators=(",", ":"), sort_keys=True).encode("utf-8"))
        signing_input = f"{encoded_header}.{encoded_payload}".encode("ascii")
        private_key = serialization.load_pem_private_key(
            str(credentials["private_key"]).encode("utf-8"),
            password=None,
        )
        signature = private_key.sign(signing_input, padding.PKCS1v15(), hashes.SHA256())
        return token_uri, f"{encoded_header}.{encoded_payload}.{_b64url(signature)}"

    def _access_token(self, *, force: bool = False) -> str:
        with self._token_lock:
            if not force and self._token and time.monotonic() < self._token_expires_at - 300:
                return self._token
            token_uri, assertion = self._jwt_assertion()
            with httpx.Client(timeout=self.cfg.timeout_seconds) as client:
                response = client.post(
                    token_uri,
                    data={
                        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
                        "assertion": assertion,
                    },
                    headers={"Content-Type": "application/x-www-form-urlencoded"},
                )
            if response.status_code >= 400:
                raise GoogleSheetsBackupError(f"Google OAuth failed with HTTP {response.status_code}")
            payload = response.json()
            token = str(payload.get("access_token") or "")
            if not token:
                raise GoogleSheetsBackupError("Google OAuth did not return an access token")
            expires_in = int(payload.get("expires_in") or 3600)
            self._token = token
            # Refresh well before Google's normal one-hour expiry. Keep the
            # effective cache lifetime bounded even if an unexpected expires_in
            # value is returned by the token endpoint.
            self._token_expires_at = time.monotonic() + max(60, min(expires_in, 3600))
            return token

    def _invalidate_token(self) -> None:
        with self._token_lock:
            self._token = ""  # nosec B105
            self._token_expires_at = 0.0

    def request(
        self,
        method: str,
        path: str,
        *,
        json_body: Any | None = None,
        params: Any | None = None,
    ) -> Any:
        url = f"https://sheets.googleapis.com/v4/spreadsheets/{self.cfg.spreadsheet_id}{path}"
        last_error: Exception | None = None
        force_token = False
        for attempt in range(self.cfg.max_retries + 1):
            try:
                token = self._access_token(force=force_token)
                force_token = False
                with httpx.Client(timeout=self.cfg.timeout_seconds) as client:
                    response = client.request(
                        method,
                        url,
                        headers={"Authorization": f"Bearer {token}", "Content-Type": "application/json"},
                        json=json_body,
                        params=params,
                    )
                if response.status_code == 401 and attempt < self.cfg.max_retries:
                    self._invalidate_token()
                    force_token = True
                    continue
                if response.status_code in {408, 429, 500, 502, 503, 504} and attempt < self.cfg.max_retries:
                    time.sleep(min(4.0, 0.4 * (2**attempt)))
                    continue
                if response.status_code >= 400:
                    detail = ""
                    try:
                        body = response.json()
                        detail = str(body.get("error", {}).get("message") or "")[:300]
                    except Exception:
                        detail = response.text[:300]
                    raise GoogleSheetsBackupError(
                        f"Google Sheets API HTTP {response.status_code}: {detail or 'request failed'}"
                    )
                if response.status_code == 204 or not response.content:
                    return {}
                return response.json()
            except (httpx.HTTPError, GoogleSheetsBackupError, ValueError, TypeError) as exc:
                last_error = exc
                if attempt >= self.cfg.max_retries:
                    break
                time.sleep(min(4.0, 0.4 * (2**attempt)))
        if isinstance(last_error, GoogleSheetsBackupError):
            raise last_error
        raise GoogleSheetsBackupError(f"Google Sheets request failed: {last_error}") from last_error

    def get_values(self, range_a1: str) -> list[list[Any]]:
        encoded = quote(range_a1, safe="")
        payload = self.request("GET", f"/values/{encoded}", params={"majorDimension": "ROWS"})
        values = payload.get("values", []) if isinstance(payload, dict) else []
        return values if isinstance(values, list) else []

    def batch_get(self, ranges: Iterable[str]) -> dict[str, list[list[Any]]]:
        requested = [str(item) for item in ranges if str(item)]
        if not requested:
            return {}
        payload = self.request(
            "GET",
            "/values:batchGet",
            params=[("ranges", item) for item in requested] + [("majorDimension", "ROWS")],  # type: ignore[arg-type]
        )
        result: dict[str, list[list[Any]]] = {}
        for row in payload.get("valueRanges", []) if isinstance(payload, dict) else []:
            if not isinstance(row, dict):
                continue
            result[str(row.get("range") or "")] = row.get("values", []) if isinstance(row.get("values"), list) else []
        return result

    def batch_update_values(self, data: list[dict[str, Any]]) -> None:
        if not data:
            return
        self.request(
            "POST",
            "/values:batchUpdate",
            json_body={"valueInputOption": "RAW", "data": data, "includeValuesInResponse": False},
        )

    def batch_clear(self, ranges: list[str]) -> None:
        ranges = [str(item) for item in ranges if str(item)]
        if not ranges:
            return
        self.request("POST", "/values:batchClear", json_body={"ranges": ranges})

    def append_values(self, range_a1: str, values: list[list[Any]]) -> None:
        if not values:
            return
        encoded = quote(range_a1, safe="")
        self.request(
            "POST",
            f"/values/{encoded}:append",
            params={"valueInputOption": "RAW", "insertDataOption": "INSERT_ROWS"},
            json_body={"values": values, "majorDimension": "ROWS"},
        )


_CLIENT: _GoogleSheetsClient | None = None
_CLIENT_CONFIG_FINGERPRINT = ""
_CLIENT_LOCK = threading.Lock()
_RAW_INDEX: dict[str, tuple[int, int]] | None = None  # section -> (row, chunk_count)
_RAW_INDEX_LOCK = threading.RLock()
_NORMALIZED_PENDING_LOCK = threading.RLock()
_ATTESTATION_LOCK = threading.RLock()
_LAST_ATTESTATION: dict[str, Any] = {"status": "unknown", "verified_at": "", "error": ""}
_PENDING_LOCK = threading.RLock()
_ATTESTATION_LOCK = threading.RLock()
_LAST_ATTESTATION: dict[str, Any] = {"status": "unknown", "verified_at": "", "error": ""}


def _client() -> _GoogleSheetsClient:
    global _CLIENT, _CLIENT_CONFIG_FINGERPRINT
    cfg = config()
    if not cfg.enabled or not cfg.service_account:
        raise GoogleSheetsBackupNotConfigured("Google Sheets backup is enabled but service-account JSON is missing")
    fingerprint = hashlib.sha256(
        f"{cfg.spreadsheet_id}|{cfg.service_account.get('client_email')}|{cfg.service_account.get('private_key_id')}".encode("utf-8")
    ).hexdigest()
    with _CLIENT_LOCK:
        if _CLIENT is None or _CLIENT_CONFIG_FINGERPRINT != fingerprint:
            _CLIENT = _GoogleSheetsClient(cfg)
            _CLIENT_CONFIG_FINGERPRINT = fingerprint
        return _CLIENT


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _instance_id() -> str:
    return str(
        os.getenv("RAILWAY_DEPLOYMENT_ID")
        or os.getenv("RAILWAY_REPLICA_ID")
        or os.getenv("HOSTNAME")
        or socket.gethostname()
        or "sentinel"
    )[:120]


def _json_text(value: Any) -> str:
    return json.dumps(value, ensure_ascii=False, separators=(",", ":"), sort_keys=True, allow_nan=False, default=str)


def _sha256_text(value: str) -> str:
    return hashlib.sha256(value.encode("utf-8")).hexdigest()


def protected_database_checksum(db: dict[str, Any]) -> str:
    protected = protect_sensitive_payload(db, SETTINGS.sensitive_data_key)
    return _sha256_text(_json_text(protected))


def _encode_section(section_key: str, value: Any) -> tuple[str, str, int, list[str]]:
    protected_value = protect_sensitive_payload({section_key: value}, SETTINGS.sensitive_data_key)[section_key]
    raw = _json_text(protected_value)
    checksum = _sha256_text(raw)
    compressed = gzip.compress(raw.encode("utf-8"), compresslevel=6)
    encoded = base64.b64encode(compressed).decode("ascii")
    chunks = [encoded[i : i + RAW_CHUNK_CHARS] for i in range(0, len(encoded), RAW_CHUNK_CHARS)] or [""]
    if RAW_FIRST_CHUNK_COLUMN - 1 + len(chunks) > RAW_MAX_COLUMNS:
        raise GoogleSheetsBackupError(
            f"Section {section_key!r} exceeds RAW_BACKUP row capacity ({len(chunks)} chunks)"
        )
    record_count = len(value) if isinstance(value, (dict, list, tuple, set)) else 1
    return container_type(value), checksum, int(record_count), chunks


def _decode_section(chunks: Iterable[Any], checksum: str) -> Any:
    encoded = "".join(str(item or "") for item in chunks)
    try:
        raw = gzip.decompress(base64.b64decode(encoded)).decode("utf-8")
    except Exception as exc:
        raise GoogleSheetsBackupError("RAW_BACKUP payload could not be decoded") from exc
    actual = _sha256_text(raw)
    if checksum and actual != checksum:
        raise GoogleSheetsBackupError("RAW_BACKUP checksum mismatch")
    return json.loads(raw)


def _col_name(index_1_based: int) -> str:
    if index_1_based < 1:
        raise ValueError("column index must be >= 1")
    value = index_1_based
    chars: list[str] = []
    while value:
        value, remainder = divmod(value - 1, 26)
        chars.append(chr(65 + remainder))
    return "".join(reversed(chars))


def _load_raw_index(*, force: bool = False) -> dict[str, tuple[int, int]]:
    global _RAW_INDEX
    with _RAW_INDEX_LOCK:
        if _RAW_INDEX is not None and not force:
            return dict(_RAW_INDEX)
        rows = _client().get_values(f"{RAW_SHEET}!A2:H{RAW_MAX_ROWS}")
        index: dict[str, tuple[int, int]] = {}
        for offset, row in enumerate(rows, start=2):
            if not row:
                continue
            section = str(row[0] or "").strip()
            if not section:
                continue
            try:
                chunk_count = int(row[7]) if len(row) > 7 and str(row[7]).strip() else 0
            except (TypeError, ValueError):
                chunk_count = 0
            index[section] = (offset, max(0, chunk_count))
        _RAW_INDEX = index
        return dict(index)


def _allocate_raw_rows(section_keys: Iterable[str]) -> dict[str, tuple[int, int]]:
    global _RAW_INDEX
    keys = [str(key) for key in section_keys]
    with _RAW_INDEX_LOCK:
        index = _load_raw_index() if _RAW_INDEX is None else dict(_RAW_INDEX)
        used = {row for row, _chunks in index.values()}
        next_row = 2
        for key in keys:
            if key in index:
                continue
            while next_row in used:
                next_row += 1
            if next_row > RAW_MAX_ROWS:
                raise GoogleSheetsBackupError("RAW_BACKUP has no free section rows")
            index[key] = (next_row, 0)
            used.add(next_row)
            next_row += 1
        _RAW_INDEX = index
        return {key: index[key] for key in keys}


def _safe_cell(value: Any, limit: int = 45_000) -> Any:
    if value is None:
        return ""
    if isinstance(value, bool):
        return value
    if isinstance(value, (int, float)):
        return value
    if isinstance(value, (dict, list, tuple, set)):
        value = _json_text(value)
    text = str(value)
    if len(text) > limit:
        text = text[: limit - 1] + "…"
    # Avoid formula injection in human-readable projection sheets.
    if text.startswith(("=", "+", "-", "@")):
        text = "'" + text
    return text


def _record_checksum(row: Any) -> str:
    return _sha256_text(_json_text(row))


def _iter_records(value: Any) -> list[tuple[str, Any]]:
    if isinstance(value, dict):
        return [(str(key), item) for key, item in value.items()]
    if isinstance(value, list):
        rows: list[tuple[str, Any]] = []
        for idx, item in enumerate(value):
            if isinstance(item, dict):
                key = item.get("id") or item.get("order_id") or item.get("ticket_id") or item.get("signal_id") or idx
            else:
                key = idx
            rows.append((str(key), item))
        return rows
    if value is None:
        return []
    return [("root", value)]


def _get(row: Any, *keys: str, default: Any = "") -> Any:
    if not isinstance(row, dict):
        return default
    for key in keys:
        value = row.get(key)
        if value not in (None, ""):
            return value
    return default


def _targets(value: Any) -> tuple[Any, Any, Any]:
    if isinstance(value, list):
        values = list(value) + ["", "", ""]
        return values[0], values[1], values[2]
    return "", "", ""


def _sync_meta(version: Any, row: Any, *, source: str) -> list[Any]:
    now = _now_iso()
    return [version, source, "Synced", now, "", _record_checksum(row)]


def _projection_users(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    users = db.get("users") if isinstance(db.get("users"), dict) else {}
    profiles = db.get("user_profiles") if isinstance(db.get("user_profiles"), dict) else {}
    vip = db.get("vip_users") if isinstance(db.get("vip_users"), dict) else {}
    bans = db.get("user_bans") if isinstance(db.get("user_bans"), dict) else {}
    result: list[list[Any]] = []
    for uid, user in users.items():
        user = user if isinstance(user, dict) else {}
        profile = profiles.get(str(uid), profiles.get(uid, {})) if isinstance(profiles, dict) else {}
        profile = profile if isinstance(profile, dict) else {}
        is_vip = str(uid) in vip or uid in vip
        status = "Banned" if str(uid) in bans or uid in bans else "Active"
        row = [
            uid,
            _get(user, "username"),
            _get(profile, "email"),
            _get(profile, "phone"),
            _get(user, "created_at", "registration_date", "first_seen_at"),
            status,
            "VIP" if is_vip else "User",
            _get(user, "last_seen_at", "last_login", "updated_at"),
        ]
        result.append([_safe_cell(v) for v in row] + _sync_meta(version, row, source=source))
    return result


def _projection_user_activity(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("user_activity")):
        item = item if isinstance(item, dict) else {"value": item}
        row = [
            _get(item, "id", "log_id", default=key),
            _get(item, "user_id", "telegram_id"),
            _get(item, "action", "event", "type", "feature"),
            _get(item, "timestamp", "created_at", "updated_at"),
            _get(item, "ip", "ip_address"),
            _get(item, "device", "user_agent", "platform"),
        ]
        result.append([_safe_cell(v) for v in row] + _sync_meta(version, row, source=source))
    return result


def _projection_admins(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    admins = db.get("delegated_admins") if isinstance(db.get("delegated_admins"), dict) else {}
    result = []
    for uid, item in admins.items():
        item = item if isinstance(item, dict) else {}
        approval = str(item.get("approval_status") or "approved").lower()
        enabled = item.get("enabled", item.get("active", True))
        status = "Active" if enabled and approval == "approved" else "Inactive"
        row = [uid, _get(item, "username", "name", "display_name"), _get(item, "role", default="Analyst"), status, _get(item, "last_login", "last_seen_at", "updated_at")]
        result.append([_safe_cell(v) for v in row] + _sync_meta(version, row, source=source))
    return result


def _projection_admin_permissions(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    admins = db.get("delegated_admins") if isinstance(db.get("delegated_admins"), dict) else {}
    result = []
    for uid, item in admins.items():
        item = item if isinstance(item, dict) else {}
        permissions = item.get("permissions") or []
        if isinstance(permissions, str):
            permissions = [permissions]
        for idx, permission in enumerate(permissions if isinstance(permissions, (list, tuple, set)) else []):
            row = [f"{uid}:{idx + 1}", uid, permission, "Full"]
            result.append([_safe_cell(v) for v in row] + _sync_meta(version, row, source=source))
    return result


def _projection_admin_activity(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = db.get("admin_logs") if isinstance(db.get("admin_logs"), list) else []
    result = []
    for idx, item in enumerate(rows):
        item = item if isinstance(item, dict) else {"value": item}
        row = [
            _get(item, "id", "log_id", default=idx + 1),
            _get(item, "admin_id", "user_id", "actor_id"),
            _get(item, "action", "event"),
            _get(item, "target_id", "target", "entity_id"),
            _get(item, "timestamp", "created_at"),
            _get(item, "ip", "ip_address"),
        ]
        result.append([_safe_cell(v) for v in row] + _sync_meta(version, row, source=source))
    return result


def _projection_signals(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("signals")):
        item = item if isinstance(item, dict) else {}
        t1, t2, t3 = _targets(item.get("targets"))
        row = [
            _get(item, "id", "signal_id", default=key),
            _get(item, "market", "category", "market_type"),
            _get(item, "symbol", "pair"),
            str(_get(item, "side", "direction", "type")).title(),
            _get(item, "entry", "entry_price", "entryPrice"),
            _get(item, "sl", "stop_loss", "stopLoss"),
            _get(item, "tp1", "take_profit_1", default=t1),
            _get(item, "tp2", "take_profit_2", default=t2),
            _get(item, "tp3", "take_profit_3", default=t3),
            _get(item, "status", "state"),
            _get(item, "created_at", "timestamp", "published_at"),
        ]
        result.append([_safe_cell(v) for v in row] + _sync_meta(version, row, source=source))
    return result


def _projection_signal_events(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("signal_outcome_events")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "event_id", default=key),
            _get(item, "signal_id"),
            _get(item, "event_type", "type", "event", "status"),
            _get(item, "timestamp", "created_at"),
            _get(item, "details", "note", "reason"),
        ]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_signal_performance(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("signals")):
        item = item if isinstance(item, dict) else {}
        outcome = _get(item, "result", "outcome", "final_result")
        if not outcome and str(item.get("status") or "").lower() not in {"closed", "completed", "stopped", "tp", "sl"}:
            continue
        row = [
            _get(item, "id", "signal_id", default=key),
            outcome or _get(item, "status"),
            _get(item, "pnl", "profit", "profit_loss"),
            _get(item, "roi", "return_percent", "r_multiple"),
            _get(item, "closed_at", "completed_at", "result_updated_at", "updated_at"),
        ]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_trading_accounts(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    data = db.get("trading_accounts")
    for key, item in _iter_records(data):
        if isinstance(item, list):
            children = [(f"{key}:{idx}", child) for idx, child in enumerate(item)]
        else:
            children = [(key, item)]
        for account_key, account in children:
            account = account if isinstance(account, dict) else {}
            row = [
                _get(account, "id", "account_id", default=account_key),
                _get(account, "user_id", "telegram_id", default=key if str(key).isdigit() else ""),
                _get(account, "broker", "provider", "platform"),
                _get(account, "account_type", "type"),
                _get(account, "balance", "equity"),
                _get(account, "status", default="Active"),
            ]
            result.append([_safe_cell(v) for v in row])
    return result


def _projection_journal(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("trade_journal")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "trade_id", default=key),
            _get(item, "account_id"),
            _get(item, "signal_id"),
            _get(item, "entry_time", "opened_at", "created_at"),
            _get(item, "exit_time", "closed_at"),
            _get(item, "result", "outcome"),
            _get(item, "pnl", "profit_loss", "profit"),
            _get(item, "notes", "note", "reason"),
        ]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_risk(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("personal_risk_profiles")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "metric_id", default=key),
            _get(item, "account_id", default=key),
            _get(item, "drawdown", "current_drawdown"),
            _get(item, "daily_loss", "daily_loss_percent"),
            _get(item, "risk_score", "score"),
            _get(item, "status", "risk_status", default="Safe"),
        ]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_market_alerts(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("price_alerts")):
        item = item if isinstance(item, dict) else {}
        condition = _get(item, "condition") or f"{_get(item, 'direction', 'operator')} {_get(item, 'target_price', 'price')}".strip()
        row = [_get(item, "id", "alert_id", default=key), _get(item, "symbol", "market", "asset"), condition, _get(item, "created_at", "timestamp"), _get(item, "status", default="Active")]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_news(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("economic_calendar")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "event_id", default=key),
            _get(item, "title", "name", "event"),
            str(_get(item, "importance", "impact", default="Medium")).title(),
            _get(item, "market_impact", "currency", "symbol"),
            _get(item, "timestamp", "datetime", "time", "date"),
        ]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_vip(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for uid, item in _iter_records(db.get("vip_users")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "subscription_id", "sub_id", default=f"vip:{uid}"),
            _get(item, "user_id", default=uid),
            _get(item, "plan", "plan_id", "duration", default="VIP"),
            _get(item, "start_date", "starts_at", "created_at"),
            _get(item, "end_date", "expires_at", "expiry"),
            _get(item, "status", default="Active"),
        ]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_vip_history(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for key, item in _iter_records(db.get("vip_orders")):
        item = item if isinstance(item, dict) else {}
        details = {k: v for k, v in item.items() if not _is_secret_key(str(k)) and k not in {"receipt", "receipt_path", "image"}}
        row = [_get(item, "order_id", "id", default=key), _get(item, "user_id"), _get(item, "status", "action"), _get(item, "updated_at", "created_at"), details]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_payments(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for section in ("vip_orders", "education_orders"):
        for key, item in _iter_records(db.get(section)):
            item = item if isinstance(item, dict) else {}
            row = [
                _get(item, "payment_id", "order_id", "id", default=f"{section}:{key}"),
                _get(item, "user_id"),
                _get(item, "amount", "final_price", "price"),
                _get(item, "currency", default="IRR"),
                _get(item, "payment_method", "method"),
                _get(item, "status", "payment_status"),
                _get(item, "paid_at", "created_at", "updated_at"),
            ]
            result.append([_safe_cell(v) for v in row])
    return result


def _projection_coupons(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    result = []
    for code, item in _iter_records(db.get("discount_codes")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "coupon_id", default=code),
            _get(item, "code", default=code),
            _get(item, "discount_type", "type", default="Percentage"),
            _get(item, "value", "percent", "discount"),
            _get(item, "expiry_date", "expires_at"),
            _get(item, "status", default="Active"),
        ]
        result.append([_safe_cell(v) for v in row])
    return result


def _projection_coupon_usage(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    history: list[Any] = []
    for section in ("discount_history", "discount_events"):
        value = db.get(section)
        if isinstance(value, list):
            history.extend(value)
    for idx, item in enumerate(history):
        item = item if isinstance(item, dict) else {}
        row = [_get(item, "id", "usage_id", default=idx + 1), _get(item, "coupon_id", "code", "discount_code"), _get(item, "user_id"), _get(item, "timestamp", "created_at")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_referrals(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("user_referrals")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "referral_id", default=key),
            _get(item, "referrer_id", "referrer", default=key if str(key).isdigit() else ""),
            _get(item, "referee_id", "referred_user_id", "user_id"),
            _get(item, "status", default="Completed"),
            _get(item, "reward", "points"),
            _get(item, "timestamp", "created_at"),
        ]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_campaigns(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("marketing_campaigns")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "campaign_id", default=key),
            _get(item, "name", "title"),
            _get(item, "platform", "channel", "source", default="Telegram"),
            _get(item, "status", default="Active"),
            _get(item, "spend", "cost", "budget"),
            _get(item, "clicks"),
            _get(item, "signups", "conversions", "members"),
            _get(item, "revenue"),
        ]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_links(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("public_channel_links")):
        item = item if isinstance(item, dict) else {}
        row = [_get(item, "id", "link_id", default=key), _get(item, "campaign_id"), _get(item, "url", "link", "invite_link"), _get(item, "clicks", "joins"), _get(item, "signups", "members")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_tickets(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("tickets")):
        item = item if isinstance(item, dict) else {}
        row = [
            _get(item, "id", "ticket_id", default=key),
            _get(item, "user_id"),
            _get(item, "subject", "title"),
            _get(item, "category", default="Support"),
            _get(item, "priority", default="Medium"),
            _get(item, "status", default="Open"),
            _get(item, "created_at", "timestamp"),
            _get(item, "updated_at", "closed_at"),
        ]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_messages(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for ticket_key, ticket in _iter_records(db.get("tickets")):
        if not isinstance(ticket, dict):
            continue
        messages = ticket.get("messages") or ticket.get("history") or []
        if not isinstance(messages, list):
            continue
        for idx, item in enumerate(messages):
            item = item if isinstance(item, dict) else {"message": item}
            row = [
                _get(item, "id", "message_id", default=f"{ticket_key}:{idx + 1}"),
                _get(ticket, "id", "ticket_id", default=ticket_key),
                _get(item, "sender", "sender_type", "role", default="User"),
                _get(item, "message", "text", "content"),
                _get(item, "timestamp", "created_at"),
            ]
            rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_contests(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("contests")):
        item = item if isinstance(item, dict) else {}
        row = [_get(item, "id", "contest_id", default=key), _get(item, "name", "title"), _get(item, "start_date", "starts_at", "created_at"), _get(item, "end_date", "ends_at", "deadline"), _get(item, "status", default="Active"), _get(item, "prize_pool", "prize", "reward")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_contest_participants(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for contest_key, contest in _iter_records(db.get("contests")):
        if not isinstance(contest, dict):
            continue
        participants = contest.get("participants") or contest.get("entries") or []
        if isinstance(participants, dict):
            iterable = list(participants.items())
        elif isinstance(participants, list):
            iterable = [(str(idx), item) for idx, item in enumerate(participants)]
        else:
            iterable = []
        for idx, item in iterable:
            if isinstance(item, dict):
                uid = _get(item, "user_id", default=idx)
                score = _get(item, "score", "points")
                rank = _get(item, "rank")
            else:
                uid, score, rank = item, "", ""
            row = [f"{contest_key}:{idx}", _get(contest, "id", "contest_id", default=contest_key), uid, score, rank]
            rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_notifications(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    combined: list[Any] = []
    for section in ("economic_calendar_notifications", "price_alert_deliveries", "broadcasts"):
        value = db.get(section)
        if isinstance(value, list):
            combined.extend(value)
        elif isinstance(value, dict):
            combined.extend(value.values())
    for idx, item in enumerate(combined):
        item = item if isinstance(item, dict) else {"message": item}
        row = [_get(item, "id", "notification_id", default=idx + 1), _get(item, "user_id", "chat_id"), _get(item, "type", "channel", default="InApp"), _get(item, "message", "text", "title"), _get(item, "status", default="Sent"), _get(item, "timestamp", "created_at", "sent_at")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_miniapp_sessions(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("miniapp_event_stream")):
        item = item if isinstance(item, dict) else {}
        row = [_get(item, "session_id", "id", default=key), _get(item, "user_id"), _get(item, "started_at", "timestamp", "created_at"), _get(item, "ended_at"), _get(item, "duration", "duration_seconds")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_feature_usage(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    counters: dict[tuple[str, str], tuple[int, str]] = {}
    for _key, item in _iter_records(db.get("user_activity")):
        if not isinstance(item, dict):
            continue
        uid = str(_get(item, "user_id", "telegram_id"))
        feature = str(_get(item, "feature", "action", "event", "type"))
        if not uid and not feature:
            continue
        timestamp = str(_get(item, "timestamp", "created_at"))
        count, last = counters.get((uid, feature), (0, ""))
        counters[(uid, feature)] = (count + 1, max(last, timestamp))
    rows = []
    for idx, ((uid, feature), (count, last)) in enumerate(sorted(counters.items()), start=1):
        rows.append([idx, _safe_cell(uid), _safe_cell(feature), count, _safe_cell(last)])
    return rows


def _projection_ai(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    combined: list[tuple[str, Any]] = []
    for section in ("ai_audit_log", "ai_report_notes"):
        for key, item in _iter_records(db.get(section)):
            combined.append((f"{section}:{key}", item))
    behavioral = db.get("behavioral_insights")
    for key, item in _iter_records(behavioral):
        combined.append((f"behavioral:{key}", item))
    for key, item in combined:
        item = item if isinstance(item, dict) else {"result": item}
        row = [_get(item, "id", "analysis_id", default=key), _get(item, "target", "user_id", "entity_id"), _get(item, "type", "analysis_type", "action"), _get(item, "result", "summary", "answer", "details"), _get(item, "confidence", "score"), _get(item, "timestamp", "created_at", "updated_at")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_errors(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("incidents")):
        item = item if isinstance(item, dict) else {}
        severity = str(_get(item, "severity", default="Medium")).title()
        status = "Resolved" if _get(item, "resolved_at") or str(_get(item, "status")).lower() in {"resolved", "closed"} else "Open"
        row = [_get(item, "id", "incident_id", default=key), _get(item, "source", "module"), _get(item, "detail", "message", "error"), severity, status, _get(item, "created_at", "timestamp")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_api_usage(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for key, item in _iter_records(db.get("provider_health")):
        item = item if isinstance(item, dict) else {}
        status_code = 200 if bool(item.get("healthy", item.get("ok", False))) else _get(item, "status_code", default=503)
        row = [_get(item, "id", "log_id", default=key), _get(item, "endpoint", "provider", default=key), _get(item, "method", default="GET"), status_code, _get(item, "response_time", "latency_ms"), _get(item, "checked_at", "timestamp", "updated_at")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_system_changes(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    source_rows = db.get("security_audit_log") if isinstance(db.get("security_audit_log"), list) else []
    for idx, item in enumerate(source_rows):
        item = item if isinstance(item, dict) else {}
        row = [_get(item, "id", default=idx + 1), _get(item, "admin_id", "actor_id", "user_id"), _get(item, "module", "source"), _get(item, "description", "action", "detail"), _get(item, "timestamp", "created_at")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _is_secret_key(key: str) -> bool:
    normalized = key.strip().lower()
    return any(marker in normalized for marker in _SECRET_MARKERS)


def _projection_system_config(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    settings = db.get("settings") if isinstance(db.get("settings"), dict) else {}
    runtime = db.get("runtime_safety") if isinstance(db.get("runtime_safety"), dict) else {}
    merged = {**settings, **{f"runtime_safety.{k}": v for k, v in runtime.items()}}
    for key, value in sorted(merged.items()):
        if _is_secret_key(str(key)):
            continue
        rows.append([_safe_cell(key), _safe_cell(value), "Synced from Sentinel primary database", _now_iso()])
    return rows


def _projection_audit(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    combined: list[Any] = []
    for section in ("security_audit_log", "admin_logs", "privacy_log"):
        value = db.get(section)
        if isinstance(value, list):
            combined.extend(value)
    for idx, item in enumerate(combined):
        item = item if isinstance(item, dict) else {}
        row = [_get(item, "id", "audit_id", default=idx + 1), _get(item, "table", "module", "source"), _get(item, "record_id", "target_id", "entity_id"), _get(item, "action", "event"), _get(item, "changed_by", "admin_id", "user_id", "actor_id"), _get(item, "timestamp", "created_at")]
        rows.append([_safe_cell(v) for v in row])
    return rows


def _projection_data_quality(db: dict[str, Any], version: Any, source: str) -> list[list[Any]]:
    rows = []
    for idx, item in enumerate(db.get("incidents") if isinstance(db.get("incidents"), list) else []):
        if not isinstance(item, dict):
            continue
        row = [_get(item, "id", default=idx + 1), _get(item, "source", "module"), _get(item, "kind", "issue_type"), _get(item, "detail", "description"), "Fixed" if item.get("resolved_at") else "Pending", _get(item, "created_at", "timestamp")]
        rows.append([_safe_cell(v) for v in row])
    return rows


@dataclass(frozen=True, slots=True)
class ProjectionSpec:
    sheet: str
    triggers: frozenset[str]
    columns: int
    renderer: Callable[[dict[str, Any], Any, str], list[list[Any]]]
    max_rows: int = 999


_PROJECTIONS: tuple[ProjectionSpec, ...] = (
    ProjectionSpec("USERS", frozenset({"users", "user_profiles", "vip_users", "user_bans"}), 14, _projection_users),
    ProjectionSpec("USER_ACTIVITY", frozenset({"user_activity"}), 12, _projection_user_activity),
    ProjectionSpec("ADMINS", frozenset({"delegated_admins"}), 11, _projection_admins),
    ProjectionSpec("ADMIN_PERMISSIONS", frozenset({"delegated_admins"}), 10, _projection_admin_permissions),
    ProjectionSpec("ADMIN_ACTIVITY_LOG", frozenset({"admin_logs"}), 12, _projection_admin_activity),
    ProjectionSpec("SIGNALS", frozenset({"signals"}), 17, _projection_signals),
    ProjectionSpec("SIGNAL_EVENTS", frozenset({"signal_outcome_events"}), 5, _projection_signal_events),
    ProjectionSpec("SIGNAL_PERFORMANCE", frozenset({"signals"}), 5, _projection_signal_performance),
    ProjectionSpec("TRADING_ACCOUNTS", frozenset({"trading_accounts"}), 6, _projection_trading_accounts),
    ProjectionSpec("JOURNAL", frozenset({"trade_journal"}), 8, _projection_journal),
    ProjectionSpec("RISK_METRICS", frozenset({"personal_risk_profiles"}), 6, _projection_risk),
    ProjectionSpec("MARKET_ALERTS", frozenset({"price_alerts"}), 5, _projection_market_alerts),
    ProjectionSpec("NEWS", frozenset({"economic_calendar"}), 5, _projection_news),
    ProjectionSpec("VIP_SUBSCRIPTIONS", frozenset({"vip_users"}), 6, _projection_vip),
    ProjectionSpec("VIP_HISTORY", frozenset({"vip_orders"}), 5, _projection_vip_history),
    ProjectionSpec("PAYMENTS", frozenset({"vip_orders", "education_orders"}), 7, _projection_payments),
    ProjectionSpec("COUPONS", frozenset({"discount_codes"}), 6, _projection_coupons),
    ProjectionSpec("COUPON_USAGE", frozenset({"discount_history", "discount_events"}), 4, _projection_coupon_usage),
    ProjectionSpec("REFERRALS", frozenset({"user_referrals"}), 6, _projection_referrals),
    ProjectionSpec("AD_CAMPAIGNS", frozenset({"marketing_campaigns"}), 8, _projection_campaigns),
    ProjectionSpec("TRACKING_LINKS", frozenset({"public_channel_links"}), 5, _projection_links),
    ProjectionSpec("CRM_TICKETS", frozenset({"tickets"}), 8, _projection_tickets),
    ProjectionSpec("CRM_MESSAGES", frozenset({"tickets"}), 5, _projection_messages),
    ProjectionSpec("CONTESTS", frozenset({"contests"}), 6, _projection_contests),
    ProjectionSpec("CONTEST_PARTICIPANTS", frozenset({"contests"}), 5, _projection_contest_participants),
    ProjectionSpec("NOTIFICATIONS", frozenset({"economic_calendar_notifications", "price_alert_deliveries", "broadcasts"}), 6, _projection_notifications),
    ProjectionSpec("MINIAPP_SESSIONS", frozenset({"miniapp_event_stream"}), 5, _projection_miniapp_sessions),
    ProjectionSpec("FEATURE_USAGE", frozenset({"user_activity"}), 5, _projection_feature_usage),
    ProjectionSpec("AI_ANALYSIS", frozenset({"ai_audit_log", "ai_report_notes", "behavioral_insights"}), 6, _projection_ai),
    ProjectionSpec("ERROR_LOG", frozenset({"incidents"}), 6, _projection_errors),
    ProjectionSpec("API_USAGE", frozenset({"provider_health"}), 6, _projection_api_usage),
    ProjectionSpec("SYSTEM_CHANGES", frozenset({"security_audit_log"}), 5, _projection_system_changes),
    ProjectionSpec("SYSTEM_CONFIG", frozenset({"settings", "runtime_safety"}), 4, _projection_system_config),
    ProjectionSpec("AUDIT_LOG", frozenset({"security_audit_log", "admin_logs", "privacy_log"}), 6, _projection_audit),
    ProjectionSpec("DATA_QUALITY", frozenset({"incidents"}), 6, _projection_data_quality),
)


def _projection_updates(db: dict[str, Any], changed: set[str], version: Any, source: str) -> tuple[list[str], list[dict[str, Any]]]:
    clear_ranges: list[str] = []
    updates: list[dict[str, Any]] = []
    for spec in _PROJECTIONS:
        if changed and not spec.triggers.intersection(changed):
            continue
        rows = spec.renderer(db, version, source)
        clear_ranges.append(f"{spec.sheet}!A2:{_col_name(spec.columns)}{spec.max_rows + 1}")
        if rows:
            rows = rows[: spec.max_rows]
            updates.append({"range": f"{spec.sheet}!A2:{_col_name(spec.columns)}{len(rows) + 1}", "majorDimension": "ROWS", "values": rows})
    return clear_ranges, updates


def _write_value_updates(client: _GoogleSheetsClient, updates: list[dict[str, Any]], *, max_chars: int = 4_000_000) -> None:
    current: list[dict[str, Any]] = []
    size = 0
    for item in updates:
        item_size = len(_json_text(item))
        if current and (len(current) >= 50 or size + item_size > max_chars):
            client.batch_update_values(current)
            current = []
            size = 0
        current.append(item)
        size += item_size
    if current:
        client.batch_update_values(current)


def _log_sync(*, mode: str, source: str, sections: Iterable[str], status: str, duration_ms: int, checksum: str, error: str = "") -> None:
    try:
        _client().append_values(
            f"{SYNC_LOG_SHEET}!A:J",
            [[
                uuid.uuid4().hex,
                _now_iso(),
                mode,
                source,
                ",".join(sorted(str(item) for item in sections))[:20_000],
                status,
                duration_ms,
                checksum,
                str(error)[:10_000],
                _instance_id(),
            ]],
        )
    except Exception:
        logger.exception("Could not append Google Sheets sync log")


def _pending_path() -> Path:
    return SETTINGS.backup_dir / "google-sheets-sync-outbox.json"


def _read_pending_state_unlocked() -> dict[str, int]:
    path = _pending_path()
    if not path.exists():
        return {}
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        if not isinstance(payload, dict):
            return {}
        generations = payload.get("generations")
        if isinstance(generations, dict):
            result: dict[str, int] = {}
            for key, value in generations.items():
                name = str(key).strip()
                if not name:
                    continue
                try:
                    result[name] = max(1, int(value))
                except (TypeError, ValueError):
                    result[name] = 1
            return result
        # Backward compatibility with the original {"sections": [...]} outbox.
        rows = payload.get("sections", [])
        return {str(item): 1 for item in rows if str(item)} if isinstance(rows, list) else {}
    except Exception:
        logger.exception("Could not read Google Sheets sync outbox; forcing a full snapshot")
        # A corrupt outbox must fail safe. Treating corruption as an empty queue
        # could silently lose unsynced mutations. Preserve the bad file for
        # diagnosis and force the next worker pass to rebuild the full mirror.
        try:
            corrupt = path.with_name(f"{path.name}.corrupt-{int(time.time())}-{uuid.uuid4().hex[:8]}")
            os.replace(path, corrupt)
        except OSError:
            pass
        return {FULL_SNAPSHOT_MARKER: 1}


def _write_pending_state_unlocked(state: dict[str, int]) -> None:
    path = _pending_path()
    normalized = {str(key): max(1, int(value)) for key, value in state.items() if str(key)}
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        if not normalized:
            path.unlink(missing_ok=True)
            return
        fd, temp_name = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=str(path.parent))
        temp = Path(temp_name)
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                handle.write(_json_text({
                    "sections": sorted(normalized),
                    "generations": dict(sorted(normalized.items())),
                    "updated_at": _now_iso(),
                }))
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(temp, path)
        finally:
            temp.unlink(missing_ok=True)
        try:
            os.chmod(path, 0o600)
        except OSError:
            pass
    except Exception:
        logger.exception("Could not persist Google Sheets sync outbox")


def _read_pending_state() -> dict[str, int]:
    with _PENDING_LOCK:
        return _read_pending_state_unlocked()


def _read_pending() -> set[str]:
    return set(_read_pending_state())


def _write_pending(sections: Iterable[str]) -> None:
    # Compatibility helper used by tests and recovery paths. Replacing the set
    # is safe because callers that merge concurrent writes use mark_pending_sections.
    with _PENDING_LOCK:
        current = _read_pending_state_unlocked()
        desired = {str(item) for item in sections if str(item)}
        _write_pending_state_unlocked({name: current.get(name, 1) for name in desired})


def mark_pending_sections(sections: Iterable[str]) -> set[str]:
    """Atomically queue dirty legacy sections without calling Google inline.

    Generation counters prevent a successful slow sync from acknowledging a newer
    write that arrived while the Google request was in flight.
    """
    values = {str(item) for item in sections if str(item)}
    if not values:
        return _read_pending()
    with _PENDING_LOCK:
        state = _read_pending_state_unlocked()
        for name in values:
            state[name] = int(state.get(name, 0)) + 1
        _write_pending_state_unlocked(state)
        return set(state)


def _ensure_pending_sections(sections: Iterable[str]) -> set[str]:
    """Ensure sections remain queued without fabricating a new mutation generation.

    Retry/recovery paths use this helper. Real primary writes use
    :func:`mark_pending_sections`, which increments the generation counter.
    """
    values = {str(item) for item in sections if str(item)}
    if not values:
        return _read_pending()
    with _PENDING_LOCK:
        state = _read_pending_state_unlocked()
        for name in values:
            state.setdefault(name, 1)
        _write_pending_state_unlocked(state)
        return set(state)


def _capture_pending_generations(sections: Iterable[str]) -> dict[str, int]:
    wanted = {str(item) for item in sections if str(item)}
    with _PENDING_LOCK:
        state = _read_pending_state_unlocked()
        return {name: state[name] for name in wanted if name in state}


def _ack_pending_generations(captured: dict[str, int]) -> None:
    if not captured:
        return
    with _PENDING_LOCK:
        state = _read_pending_state_unlocked()
        for name, generation in captured.items():
            if state.get(name) == generation:
                state.pop(name, None)
        _write_pending_state_unlocked(state)


def pending_sections() -> set[str]:
    return _read_pending()




def _legacy_generation_token() -> str:
    return f"{time.time_ns():020d}-{uuid.uuid4().hex[:12]}"


def _legacy_generation_manifest_key(generation: str) -> str:
    return f"{LEGACY_GENERATION_MANIFEST_PREFIX}{generation}"


def _legacy_generation_section_key(generation: str, section: str) -> str:
    digest = hashlib.sha256(section.encode("utf-8")).hexdigest()[:16]
    return f"{LEGACY_GENERATION_SECTION_PREFIX}{generation}:{digest}"


def _legacy_generation_manifests() -> list[tuple[str, dict[str, Any]]]:
    raw = _read_raw_named_sections(LEGACY_GENERATION_MANIFEST_PREFIX)
    manifests: list[tuple[str, dict[str, Any]]] = []
    for key, value in raw.items():
        if not isinstance(value, dict):
            continue
        generation = str(value.get("generation") or key[len(LEGACY_GENERATION_MANIFEST_PREFIX):])
        sections = value.get("sections")
        if generation and isinstance(sections, dict):
            manifests.append((generation, value))
    manifests.sort(key=lambda item: item[0], reverse=True)
    return manifests


def _latest_legacy_generation_manifest() -> dict[str, Any] | None:
    manifests = _legacy_generation_manifests()
    return manifests[0][1] if manifests else None


def _gc_legacy_generations() -> None:
    manifests = _legacy_generation_manifests()
    if len(manifests) <= LEGACY_GENERATIONS_TO_KEEP:
        return
    keep = manifests[:LEGACY_GENERATIONS_TO_KEEP]
    discard = manifests[LEGACY_GENERATIONS_TO_KEEP:]
    referenced: set[str] = set()
    for _generation, manifest in keep:
        sections = manifest.get("sections") if isinstance(manifest, dict) else {}
        if isinstance(sections, dict):
            referenced.update(str(value) for value in sections.values() if str(value))
    delete_keys = {_legacy_generation_manifest_key(generation) for generation, _manifest in discard}
    for _generation, manifest in discard:
        sections = manifest.get("sections") if isinstance(manifest, dict) else {}
        if isinstance(sections, dict):
            for value in sections.values():
                key = str(value or "")
                if key and key not in referenced:
                    delete_keys.add(key)
    _delete_raw_named_keys(delete_keys)


def _write_legacy_generation(
    db: dict[str, Any],
    changed: set[str],
    *,
    sync_version: Any,
    source: str,
) -> dict[str, Any]:
    current_sections = {str(key) for key in db if str(key) != META_SECTION}
    previous = _latest_legacy_generation_manifest()
    previous_refs = dict(previous.get("sections") or {}) if previous else {}
    # Drop references for sections deleted from the current database.
    section_refs = {key: str(value) for key, value in previous_refs.items() if key in current_sections and str(value)}
    bootstrap = not previous or not current_sections.issubset(section_refs)
    exported = set(current_sections) if bootstrap else (set(changed) & current_sections)
    generation = _legacy_generation_token()
    payloads: dict[str, Any] = {}
    for section in sorted(exported):
        key = _legacy_generation_section_key(generation, section)
        payloads[key] = db[section]
        section_refs[section] = key
    if payloads:
        _write_raw_named_payloads(
            payloads,
            sync_version=sync_version,
            source=source,
            mode="legacy_generation_payload",
        )
    checksum = protected_database_checksum(db)
    manifest = {
        "schema_version": db.get("schema_version"),
        "generation": generation,
        "sync_version": _safe_cell(sync_version),
        "source": source,
        "updated_at": _now_iso(),
        "instance_id": _instance_id(),
        "database_checksum": checksum,
        "sections": {section: section_refs[section] for section in sorted(current_sections)},
    }
    manifest_key = _legacy_generation_manifest_key(generation)
    _write_raw_named_payloads(
        {manifest_key: manifest},
        sync_version=sync_version,
        source=source,
        mode="legacy_generation_commit",
        overall_checksum=checksum,
    )
    try:
        _gc_legacy_generations()
    except Exception:
        logger.warning("Could not garbage-collect old legacy Google generations", exc_info=True)
    return {"generation": generation, "checksum": checksum, "bootstrap": bootstrap, "synced": len(exported)}


def _recover_legacy_generation() -> dict[str, Any]:
    manifests = _legacy_generation_manifests()
    if not manifests:
        raise GoogleSheetsBackupError("RAW_BACKUP does not contain a committed legacy generation")
    payload_cache = _read_raw_named_sections(LEGACY_GENERATION_SECTION_PREFIX)
    last_error: Exception | None = None
    for generation, manifest in manifests:
        try:
            refs = manifest.get("sections")
            if not isinstance(refs, dict) or not refs:
                raise GoogleSheetsBackupError("legacy generation manifest has no section map")
            protected_db: dict[str, Any] = {}
            for section, key_value in refs.items():
                key = str(key_value or "")
                if not key.startswith(LEGACY_GENERATION_SECTION_PREFIX) or key not in payload_cache:
                    raise GoogleSheetsBackupError(f"legacy generation {generation} missing section {section}")
                protected_db[str(section)] = payload_cache[key]
            recovered = unprotect_sensitive_payload(protected_db, SETTINGS.sensitive_data_key)
            if not isinstance(recovered, dict):
                raise GoogleSheetsBackupError("legacy generation did not decode to a database object")
            expected = str(manifest.get("database_checksum") or "")
            if expected and protected_database_checksum(recovered) != expected:
                raise GoogleSheetsBackupError(f"legacy generation {generation} database checksum mismatch")
            return recovered
        except Exception as exc:
            last_error = exc
            logger.warning("Skipping incomplete legacy Google generation %s: %s", generation, exc)
    raise GoogleSheetsBackupError("No complete committed legacy Google generation is recoverable") from last_error

def mirror_database_change(
    db: dict[str, Any],
    changed_sections: Iterable[str],
    *,
    sync_version: Any = "",
    source: str = "primary",
    force_projections: bool = False,
) -> dict[str, Any]:
    cfg = config()
    changed = {str(key) for key in changed_sections if str(key) and str(key) in db}
    if not cfg.enabled:
        return {"enabled": False, "synced": 0, "pending": 0}
    if not cfg.service_account:
        # Never replace the durable outbox when credentials are temporarily
        # unavailable. A previous pending section may still need to be synced,
        # and replacing the set here could silently drop it. The generation-
        # aware merge also preserves writes that arrive concurrently.
        _ensure_pending_sections(changed)
        return {"enabled": True, "configured": False, "synced": 0, "pending": len(_read_pending())}
    if not changed:
        return {"enabled": True, "configured": True, "synced": 0, "pending": len(_read_pending())}

    started = time.monotonic()
    pending_generations = _capture_pending_generations(changed)
    client = _client()
    checksum = protected_database_checksum(db)
    source_label = "GOOGLE_FAILOVER" if source == "google_failover" else "PRIMARY"
    sections_with_meta = sorted(changed | {META_SECTION})
    row_info = _allocate_raw_rows(sections_with_meta)
    raw_updates: list[dict[str, Any]] = []
    clear_ranges: list[str] = []
    index = _load_raw_index()
    now = _now_iso()
    meta_payload = {
        "schema_version": db.get("schema_version"),
        "database_checksum": checksum,
        "sync_version": sync_version,
        "source": source,
        "updated_at": now,
        "instance_id": _instance_id(),
    }
    values_by_key = {key: db[key] for key in changed}
    values_by_key[META_SECTION] = meta_payload
    for key in sections_with_meta:
        value = values_by_key[key]
        kind, section_checksum, record_count, chunks = _encode_section(key, value)
        row_number, old_chunk_count = row_info[key]
        row_values = [key, kind, record_count, _safe_cell(sync_version), now, section_checksum, "gzip+base64", len(chunks), *chunks]
        end_col = _col_name(len(row_values))
        raw_updates.append({"range": f"{RAW_SHEET}!A{row_number}:{end_col}{row_number}", "majorDimension": "ROWS", "values": [row_values]})
        if old_chunk_count > len(chunks):
            clear_start = RAW_FIRST_CHUNK_COLUMN + len(chunks)
            clear_end = RAW_FIRST_CHUNK_COLUMN - 1 + old_chunk_count
            clear_ranges.append(f"{RAW_SHEET}!{_col_name(clear_start)}{row_number}:{_col_name(clear_end)}{row_number}")
        index[key] = (row_number, len(chunks))
    try:
        generation_result = _write_legacy_generation(
            db,
            changed,
            sync_version=sync_version,
            source=source,
        )
        if clear_ranges:
            client.batch_clear(clear_ranges)
        _write_value_updates(client, raw_updates)
        if cfg.projection_enabled:
            projection_clear, projection_updates = _projection_updates(
                db,
                set() if force_projections else changed,
                sync_version,
                source_label,
            )
            if projection_clear:
                client.batch_clear(projection_clear)
            _write_value_updates(client, projection_updates)
        _ack_pending_generations(pending_generations)
        pending = _read_pending()
        with _RAW_INDEX_LOCK:
            global _RAW_INDEX
            _RAW_INDEX = index
        duration = int((time.monotonic() - started) * 1000)
        _log_sync(mode="dual_write", source=source, sections=changed, status="OK", duration_ms=duration, checksum=checksum)
        return {
            "enabled": True,
            "configured": True,
            "synced": len(changed),
            "pending": len(pending),
            "checksum": checksum,
            "duration_ms": duration,
            "generation": generation_result.get("generation"),
            "generation_atomic": True,
        }
    except Exception as exc:
        # A failed retry must keep the captured generation pending, but it must
        # not pretend that a new primary mutation occurred.
        _ensure_pending_sections(changed)
        pending = _read_pending()
        duration = int((time.monotonic() - started) * 1000)
        _log_sync(mode="dual_write", source=source, sections=changed, status="ERROR", duration_ms=duration, checksum=checksum, error=f"{exc.__class__.__name__}:{exc}")
        raise


def sync_full_snapshot(db: dict[str, Any], *, sync_version: Any = "", source: str = "primary") -> dict[str, Any]:
    return mirror_database_change(
        db,
        [key for key in db.keys() if str(key) != META_SECTION],
        sync_version=sync_version,
        source=source,
        force_projections=True,
    )


def flush_pending(db: dict[str, Any], *, sync_version: Any = "") -> dict[str, Any]:
    state = _read_pending_state()
    pending = set(state)
    if not pending:
        return {"synced": 0, "pending": 0}
    if FULL_SNAPSHOT_MARKER in pending:
        marker_generation = int(state.get(FULL_SNAPSHOT_MARKER, 1))
        result = sync_full_snapshot(db, sync_version=sync_version, source="outbox_recovery")
        with _PENDING_LOCK:
            current = _read_pending_state_unlocked()
            if int(current.get(FULL_SNAPSHOT_MARKER, 0)) == marker_generation:
                current.pop(FULL_SNAPSHOT_MARKER, None)
                _write_pending_state_unlocked(current)
        result["forced_full_snapshot"] = True
        return result
    available = [key for key in pending if key in db]
    if not available:
        # Unknown keys may belong to a newer application version. Keep them
        # queued instead of silently acknowledging data we did not mirror.
        return {"synced": 0, "pending": len(pending)}
    return mirror_database_change(db, available, sync_version=sync_version, source="retry")


def raw_backup_metadata() -> dict[str, Any]:
    if not is_configured():
        raise GoogleSheetsBackupNotConfigured("Google Sheets backup is not configured")
    index = _load_raw_index(force=True)
    if META_SECTION not in index:
        return {}
    row, chunk_count = index[META_SECTION]
    if chunk_count <= 0:
        return {}
    end_col = _col_name(RAW_FIRST_CHUNK_COLUMN - 1 + chunk_count)
    values = _client().get_values(f"{RAW_SHEET}!A{row}:{end_col}{row}")
    if not values:
        return {}
    first = values[0]
    checksum = str(first[5]) if len(first) > 5 else ""
    chunks = first[8 : 8 + chunk_count]
    payload = _decode_section(chunks, checksum)
    return payload if isinstance(payload, dict) else {}


def recover_database_from_sheets() -> dict[str, Any]:
    if not is_configured():
        raise GoogleSheetsBackupNotConfigured("Google Sheets backup is not configured")
    started = time.monotonic()
    try:
        recovered_generation = _recover_legacy_generation()
    except GoogleSheetsBackupError:
        recovered_generation = None
    if recovered_generation is not None:
        duration = int((time.monotonic() - started) * 1000)
        checksum = protected_database_checksum(recovered_generation)
        _log_sync(
            mode="failover_read_generation",
            source="google",
            sections=recovered_generation.keys(),
            status="OK",
            duration_ms=duration,
            checksum=checksum,
        )
        return recovered_generation
    client = _client()
    index_rows = client.get_values(f"{RAW_SHEET}!A2:H{RAW_MAX_ROWS}")
    descriptors: list[tuple[str, int, int, str]] = []
    for offset, row in enumerate(index_rows, start=2):
        if not row:
            continue
        key = str(row[0] or "").strip()
        if not key or key == META_SECTION:
            continue
        try:
            chunk_count = int(row[7]) if len(row) > 7 else 0
        except (TypeError, ValueError):
            chunk_count = 0
        if chunk_count <= 0:
            continue
        checksum = str(row[5] or "") if len(row) > 5 else ""
        descriptors.append((key, offset, chunk_count, checksum))
    protected_db: dict[str, Any] = {}
    # Fetch payload rows in bounded groups to avoid oversized query strings.
    for start in range(0, len(descriptors), 40):
        group = descriptors[start : start + 40]
        ranges = []
        by_range: dict[str, tuple[str, int, str]] = {}
        for key, row_number, chunk_count, checksum in group:
            end_col = _col_name(RAW_FIRST_CHUNK_COLUMN - 1 + chunk_count)
            range_a1 = f"{RAW_SHEET}!I{row_number}:{end_col}{row_number}"
            ranges.append(range_a1)
            by_range[range_a1] = (key, chunk_count, checksum)
        payload = client.request(
            "GET",
            "/values:batchGet",
            params=[("ranges", item) for item in ranges] + [("majorDimension", "ROWS")],  # type: ignore[arg-type]
        )
        value_ranges = payload.get("valueRanges", []) if isinstance(payload, dict) else []
        for requested, returned in zip(group, value_ranges, strict=False):
            key, _row_number, chunk_count, checksum = requested
            values = returned.get("values", []) if isinstance(returned, dict) else []
            chunks = values[0][:chunk_count] if values and isinstance(values[0], list) else []
            if len(chunks) < chunk_count:
                chunks = list(chunks) + [""] * (chunk_count - len(chunks))
            protected_db[key] = _decode_section(chunks, checksum)
    if not protected_db:
        raise GoogleSheetsBackupError("RAW_BACKUP does not contain a recoverable Sentinel database")
    recovered = unprotect_sensitive_payload(protected_db, SETTINGS.sensitive_data_key)
    if not isinstance(recovered, dict):
        raise GoogleSheetsBackupError("Recovered Google Sheets backup is not a database object")
    duration = int((time.monotonic() - started) * 1000)
    checksum = protected_database_checksum(recovered)
    _log_sync(mode="failover_read", source="google", sections=recovered.keys(), status="OK", duration_ms=duration, checksum=checksum)
    return recovered


def backup_attestation_status() -> dict[str, Any]:
    with _ATTESTATION_LOCK:
        return dict(_LAST_ATTESTATION)


def attest_backup_read_write() -> dict[str, Any]:
    """Prove the configured Sheet is writable and readable by this service account.

    A fixed RAW_BACKUP key is overwritten, so the attestation does not grow the
    sheet.  Read-back of a random nonce proves that credentials, spreadsheet ID,
    write permission and read permission all work at the time of the check.
    """
    if not is_configured():
        raise GoogleSheetsBackupNotConfigured("Google Sheets backup is not configured")
    nonce = uuid.uuid4().hex
    now = _now_iso()
    payload = {"nonce": nonce, "created_at": now, "host": socket.gethostname()}
    try:
        _write_raw_named_payloads(
            {BACKUP_ATTESTATION_SECTION: payload},
            sync_version=now,
            source="backup_attestation",
            mode="backup_attestation",
            overall_checksum=_sha256_text(_json_text(payload)),
        )
        recovered = _read_raw_named_sections(BACKUP_ATTESTATION_SECTION)
        observed = recovered.get(BACKUP_ATTESTATION_SECTION)
        if not isinstance(observed, dict) or str(observed.get("nonce") or "") != nonce:
            raise GoogleSheetsBackupError("Google Sheets backup attestation read-back mismatch")
        result = {"status": "ok", "verified_at": now, "error": ""}
    except Exception as exc:
        result = {
            "status": "failed",
            "verified_at": now,
            "error": f"{exc.__class__.__name__}:{str(exc)[:300]}",
        }
        with _ATTESTATION_LOCK:
            _LAST_ATTESTATION.clear()
            _LAST_ATTESTATION.update(result)
        raise
    with _ATTESTATION_LOCK:
        _LAST_ATTESTATION.clear()
        _LAST_ATTESTATION.update(result)
    return dict(result)


def healthcheck() -> bool:
    if not is_configured():
        return False
    try:
        values = _client().get_values(f"{RAW_SHEET}!A1:H3")
        return bool(values and values[0] and str(values[0][0]) == "SectionKey")
    except Exception:
        logger.exception("Google Sheets backup healthcheck failed")
        return False


def bootstrap_needed() -> bool:
    if not is_configured():
        return False
    try:
        if _legacy_generation_manifests():
            return False
        return not bool(raw_backup_metadata())
    except Exception:
        return True


# ---------------------------------------------------------------------------
# Normalized v8 storage mirror
# ---------------------------------------------------------------------------

def _normalized_pending_path() -> Path:
    return Path(SETTINGS.backup_dir) / "google-sheets-normalized-sync-outbox.json"


def _read_normalized_pending_state() -> dict[str, int]:
    path = _normalized_pending_path()
    with _NORMALIZED_PENDING_LOCK:
        try:
            payload = json.loads(path.read_text(encoding="utf-8"))
        except FileNotFoundError:
            return {}
        except Exception:
            logger.exception("Could not read normalized Google Sheets sync outbox")
            return {table: 1 for table in NORMALIZED_TABLES}
        if not isinstance(payload, dict):
            return {table: 1 for table in NORMALIZED_TABLES}
        generations = payload.get("generations")
        state: dict[str, int] = {}
        if isinstance(generations, dict):
            for table, generation in generations.items():
                name = str(table)
                if name not in NORMALIZED_TABLES:
                    continue
                try:
                    state[name] = max(1, int(generation))
                except (TypeError, ValueError):
                    state[name] = 1
            return state
        # Backwards compatibility with the original set-only outbox format.
        rows = payload.get("tables", [])
        if isinstance(rows, list):
            return {str(item): 1 for item in rows if str(item) in NORMALIZED_TABLES}
        return {}


def _write_normalized_pending_state(state: dict[str, int]) -> None:
    selected = {
        str(table): max(1, int(generation))
        for table, generation in state.items()
        if str(table) in NORMALIZED_TABLES
    }
    path = _normalized_pending_path()
    with _NORMALIZED_PENDING_LOCK:
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            if not selected:
                path.unlink(missing_ok=True)
                return
            payload = {
                "tables": sorted(selected),
                "generations": {name: selected[name] for name in sorted(selected)},
                "updated_at": _now_iso(),
            }
            temporary = path.with_name(
                f"{path.name}.{os.getpid()}.{threading.get_ident()}.{uuid.uuid4().hex}.tmp"
            )
            try:
                encoded = json.dumps(payload, ensure_ascii=False, indent=2).encode("utf-8")
                with temporary.open("wb") as handle:
                    handle.write(encoded)
                    handle.flush()
                    os.fsync(handle.fileno())
                os.replace(temporary, path)
                # Persist the directory entry as well. On abrupt VM/container
                # loss this prevents an acknowledged database commit from
                # surviving while its outbox rename disappears.
                try:
                    directory_fd = os.open(path.parent, os.O_RDONLY)
                except OSError:
                    directory_fd = -1
                if directory_fd >= 0:
                    try:
                        os.fsync(directory_fd)
                    finally:
                        os.close(directory_fd)
            finally:
                temporary.unlink(missing_ok=True)
        except Exception as exc:
            logger.exception("Could not persist normalized Google Sheets sync outbox")
            raise GoogleSheetsBackupError("Could not persist normalized Google Sheets sync outbox") from exc


def _read_normalized_pending() -> set[str]:
    return set(_read_normalized_pending_state())


def _write_normalized_pending(tables: Iterable[str]) -> None:
    selected = {str(item) for item in tables if str(item) in NORMALIZED_TABLES}
    current = _read_normalized_pending_state()
    _write_normalized_pending_state({table: current.get(table, 1) for table in selected})


def _capture_normalized_generations(tables: Iterable[str]) -> dict[str, int]:
    selected = {str(item) for item in tables if str(item) in NORMALIZED_TABLES}
    with _NORMALIZED_PENDING_LOCK:
        current = _read_normalized_pending_state()
        return {table: current.get(table, 0) for table in selected}


def _ensure_normalized_pending(tables: Iterable[str]) -> None:
    selected = {str(item) for item in tables if str(item) in NORMALIZED_TABLES}
    if not selected:
        return
    with _NORMALIZED_PENDING_LOCK:
        current = _read_normalized_pending_state()
        for table in selected:
            current.setdefault(table, 1)
        _write_normalized_pending_state(current)


def _ack_normalized_pending(tables: Iterable[str], captured: dict[str, int]) -> None:
    selected = {str(item) for item in tables if str(item) in NORMALIZED_TABLES}
    with _NORMALIZED_PENDING_LOCK:
        current = _read_normalized_pending_state()
        for table in selected:
            # Clear only the exact generation that was captured before export.
            # A write that committed during the network sync increments the
            # generation, so it remains pending for the next pass.
            if current.get(table, 0) == captured.get(table, 0):
                current.pop(table, None)
        _write_normalized_pending_state(current)


def mark_normalized_dirty(tables: Iterable[str]) -> None:
    """Durably mark normalized tables for the secondary-database worker.

    Each commit increments a persistent generation. This prevents a concurrent
    Google sync from acknowledging a newer write that happened after its
    snapshot was exported.
    """
    selected = {str(item) for item in tables if str(item) in NORMALIZED_TABLES}
    if not selected:
        return
    with _NORMALIZED_PENDING_LOCK:
        current = _read_normalized_pending_state()
        for table in selected:
            current[table] = current.get(table, 0) + 1
        _write_normalized_pending_state(current)


def normalized_pending_tables() -> set[str]:
    return _read_normalized_pending()


def _normalized_row_value(value: Any) -> Any:
    if isinstance(value, (datetime,)):
        return value.isoformat()
    if isinstance(value, (bytes, bytearray, memoryview)):
        return {"__sentinel_bytes_b64__": base64.b64encode(bytes(value)).decode("ascii")}
    return value


def export_normalized_tables(engine: Any, table_names: Iterable[str] | None = None) -> dict[str, list[dict[str, Any]]]:
    names = [str(name) for name in (table_names or NORMALIZED_TABLES) if str(name) in NORMALIZED_TABLES]
    exported: dict[str, list[dict[str, Any]]] = {}
    if not names:
        return exported
    engine.ensure_schema()
    with engine.transaction(read_only=True) as cursor:
        for table in names:
            # Table identifiers come exclusively from NORMALIZED_TABLES.
            rows = cursor.execute(f"SELECT * FROM {table}").fetchall()  # nosec B608
            exported[table] = [
                {str(key): _normalized_row_value(value) for key, value in row.items()}
                for row in rows
            ]
    return exported


def normalized_snapshot_checksum(snapshot: dict[str, Any]) -> str:
    protected = protect_sensitive_payload(snapshot, SETTINGS.sensitive_data_key)
    return _sha256_text(_json_text(protected))


def _write_raw_named_payloads(
    payloads: dict[str, Any],
    *,
    sync_version: Any,
    source: str,
    mode: str,
    overall_checksum: str = "",
) -> dict[str, Any]:
    if not payloads:
        return {"synced": 0, "checksum": overall_checksum}
    started = time.monotonic()
    client = _client()
    row_info = _allocate_raw_rows(payloads.keys())
    raw_updates: list[dict[str, Any]] = []
    clear_ranges: list[str] = []
    index = _load_raw_index()
    now = _now_iso()
    for key in sorted(payloads):
        kind, section_checksum, record_count, chunks = _encode_section(key, payloads[key])
        row_number, old_chunk_count = row_info[key]
        row_values = [key, kind, record_count, _safe_cell(sync_version), now, section_checksum, "gzip+base64", len(chunks), *chunks]
        end_col = _col_name(len(row_values))
        raw_updates.append({"range": f"{RAW_SHEET}!A{row_number}:{end_col}{row_number}", "majorDimension": "ROWS", "values": [row_values]})
        if old_chunk_count > len(chunks):
            clear_start = RAW_FIRST_CHUNK_COLUMN + len(chunks)
            clear_end = RAW_FIRST_CHUNK_COLUMN - 1 + old_chunk_count
            clear_ranges.append(f"{RAW_SHEET}!{_col_name(clear_start)}{row_number}:{_col_name(clear_end)}{row_number}")
        index[key] = (row_number, len(chunks))
    if clear_ranges:
        client.batch_clear(clear_ranges)
    _write_value_updates(client, raw_updates)
    with _RAW_INDEX_LOCK:
        global _RAW_INDEX
        _RAW_INDEX = index
    duration = int((time.monotonic() - started) * 1000)
    _log_sync(
        mode=mode,
        source=source,
        sections=payloads.keys(),
        status="OK",
        duration_ms=duration,
        checksum=overall_checksum,
    )
    return {"synced": len(payloads), "checksum": overall_checksum, "duration_ms": duration}


def mirror_normalized_tables(
    engine: Any,
    table_names: Iterable[str],
    *,
    sync_version: Any = "",
    source: str = "primary_v8",
    include_meta: bool = False,
) -> dict[str, Any]:
    cfg = config()
    selected = {str(name) for name in table_names if str(name) in NORMALIZED_TABLES}
    if not selected:
        return {"enabled": cfg.enabled, "configured": is_configured(), "synced": 0, "pending": len(_read_normalized_pending())}
    sync_generations = _capture_normalized_generations(selected)
    if not cfg.enabled or not cfg.service_account:
        _ensure_normalized_pending(selected)
        return {"enabled": cfg.enabled, "configured": False, "synced": 0, "pending": len(_read_normalized_pending())}
    try:
        result = _write_normalized_generation(
            engine,
            selected,
            sync_version=sync_version,
            source=source,
        )
        _ack_normalized_pending(selected, sync_generations)
        result.update({
            "enabled": True,
            "configured": True,
            "pending": len(_read_normalized_pending()),
            "generation_atomic": True,
        })
        return result
    except Exception as exc:
        _ensure_normalized_pending(selected)
        try:
            _log_sync(
                mode="normalized_generation",
                source=source,
                sections=selected,
                status="ERROR",
                duration_ms=0,
                checksum="",
                error=f"{exc.__class__.__name__}:{exc}",
            )
        except Exception:
            logger.debug("Could not write normalized Google sync error log", exc_info=True)
        raise


def sync_full_normalized_snapshot(engine: Any, *, sync_version: Any = "", source: str = "primary_v8") -> dict[str, Any]:
    return mirror_normalized_tables(
        engine,
        NORMALIZED_TABLES,
        sync_version=sync_version,
        source=source,
        include_meta=True,
    )


def flush_normalized_pending(engine: Any, *, sync_version: Any = "") -> dict[str, Any]:
    pending = _read_normalized_pending()
    if not pending:
        return {"synced": 0, "pending": 0}
    return mirror_normalized_tables(engine, pending, sync_version=sync_version, source="retry_v8")


def _read_raw_named_sections(prefix: str) -> dict[str, Any]:
    if not is_configured():
        raise GoogleSheetsBackupNotConfigured("Google Sheets backup is not configured")
    client = _client()
    index_rows = client.get_values(f"{RAW_SHEET}!A2:H{RAW_MAX_ROWS}")
    descriptors: list[tuple[str, int, int, str]] = []
    for row_number, row in enumerate(index_rows, start=2):
        if not row:
            continue
        key = str(row[0] or "").strip()
        if not key.startswith(prefix):
            continue
        try:
            chunk_count = int(row[7]) if len(row) > 7 else 0
        except (TypeError, ValueError):
            chunk_count = 0
        if chunk_count <= 0:
            continue
        descriptors.append((key, row_number, chunk_count, str(row[5] or "") if len(row) > 5 else ""))
    recovered: dict[str, Any] = {}
    for start in range(0, len(descriptors), 40):
        group = descriptors[start : start + 40]
        ranges = [
            f"{RAW_SHEET}!I{row_number}:{_col_name(RAW_FIRST_CHUNK_COLUMN - 1 + chunk_count)}{row_number}"
            for _key, row_number, chunk_count, _checksum in group
        ]
        results = client.batch_get(ranges)
        # Google may canonicalize returned A1 ranges, so first use request order
        # and only fall back to keyed lookup when the canonical range matches.
        returned_rows = list(results.values())
        for index_in_group, descriptor in enumerate(group):
            key, _row_number, chunk_count, checksum = descriptor
            values = returned_rows[index_in_group] if index_in_group < len(returned_rows) else []
            chunks = values[0][:chunk_count] if values and isinstance(values[0], list) else []
            if len(chunks) < chunk_count:
                chunks = list(chunks) + [""] * (chunk_count - len(chunks))
            recovered[key] = _decode_section(chunks, checksum)
    return recovered




def _normalized_generation_token() -> str:
    return f"{time.time_ns():020d}-{uuid.uuid4().hex[:12]}"


def _normalized_generation_manifest_key(generation: str) -> str:
    return f"{V8_GENERATION_MANIFEST_PREFIX}{generation}"


def _normalized_generation_table_key(generation: str, table: str) -> str:
    return f"{V8_GENERATION_TABLE_PREFIX}{generation}:{table}"


def _normalized_generation_manifests() -> list[tuple[str, dict[str, Any]]]:
    raw = _read_raw_named_sections(V8_GENERATION_MANIFEST_PREFIX)
    manifests: list[tuple[str, dict[str, Any]]] = []
    for key, value in raw.items():
        if not isinstance(value, dict):
            continue
        generation = str(value.get("generation") or key[len(V8_GENERATION_MANIFEST_PREFIX):])
        tables = value.get("tables")
        if not generation or not isinstance(tables, dict):
            continue
        manifests.append((generation, value))
    manifests.sort(key=lambda item: item[0], reverse=True)
    return manifests


def _latest_normalized_generation_manifest() -> dict[str, Any] | None:
    for _generation, manifest in _normalized_generation_manifests():
        tables = manifest.get("tables")
        if isinstance(tables, dict) and all(str(table) in tables for table in NORMALIZED_TABLES):
            return manifest
    return None


def _delete_raw_named_keys(keys: Iterable[str]) -> None:
    selected = {str(key) for key in keys if str(key)}
    if not selected:
        return
    index = _load_raw_index(force=True)
    ranges: list[str] = []
    for key in selected:
        entry = index.get(key)
        if not entry:
            continue
        row, chunk_count = entry
        end_col = _col_name(max(RAW_HEADER_COLUMNS, RAW_FIRST_CHUNK_COLUMN - 1 + int(chunk_count)))
        ranges.append(f"{RAW_SHEET}!A{row}:{end_col}{row}")
    if ranges:
        _client().batch_clear(ranges)
    with _RAW_INDEX_LOCK:
        global _RAW_INDEX
        if _RAW_INDEX is not None:
            for key in selected:
                _RAW_INDEX.pop(key, None)


def _gc_normalized_generations() -> None:
    manifests = _normalized_generation_manifests()
    if len(manifests) <= V8_GENERATIONS_TO_KEEP:
        return
    keep = manifests[:V8_GENERATIONS_TO_KEEP]
    discard = manifests[V8_GENERATIONS_TO_KEEP:]
    referenced: set[str] = set()
    for _generation, manifest in keep:
        tables = manifest.get("tables") if isinstance(manifest, dict) else {}
        if isinstance(tables, dict):
            referenced.update(str(value) for value in tables.values() if str(value))
    delete_keys = {_normalized_generation_manifest_key(generation) for generation, _manifest in discard}
    for _generation, manifest in discard:
        tables = manifest.get("tables") if isinstance(manifest, dict) else {}
        if isinstance(tables, dict):
            for value in tables.values():
                key = str(value or "")
                if key and key not in referenced:
                    delete_keys.add(key)
    _delete_raw_named_keys(delete_keys)


def _write_normalized_generation(
    engine: Any,
    selected: set[str],
    *,
    sync_version: Any,
    source: str,
) -> dict[str, Any]:
    previous = _latest_normalized_generation_manifest()
    previous_tables = dict(previous.get("tables") or {}) if previous else {}
    # A manifest is only recoverable when it references every normalized table.
    # Bootstrap therefore writes one complete generation; subsequent commits may
    # write only changed tables and carry forward immutable references for the rest.
    bootstrap = not all(table in previous_tables for table in NORMALIZED_TABLES)
    exported_tables = set(NORMALIZED_TABLES) if bootstrap else set(selected)
    snapshot = export_normalized_tables(engine, exported_tables)
    generation = _normalized_generation_token()
    payloads: dict[str, Any] = {}
    table_refs = dict(previous_tables)
    for table in sorted(exported_tables):
        key = _normalized_generation_table_key(generation, table)
        payloads[key] = snapshot.get(table, [])
        table_refs[table] = key
    # Immutable payload rows are written first. They are unreachable until the
    # generation manifest itself is written successfully, which acts as commit.
    _write_raw_named_payloads(
        payloads,
        sync_version=sync_version,
        source=source,
        mode="normalized_generation_payload",
    )
    manifest = {
        "schema_revision": SCHEMA_REVISION,
        "generation": generation,
        "sync_version": _safe_cell(sync_version),
        "source": source,
        "updated_at": _now_iso(),
        "instance_id": _instance_id(),
        "tables": {table: table_refs[table] for table in NORMALIZED_TABLES},
    }
    manifest_key = _normalized_generation_manifest_key(generation)
    _write_raw_named_payloads(
        {manifest_key: manifest},
        sync_version=sync_version,
        source=source,
        mode="normalized_generation_commit",
    )
    try:
        _gc_normalized_generations()
    except Exception:
        logger.warning("Could not garbage-collect old normalized Google generations", exc_info=True)
    return {
        "generation": generation,
        "manifest_key": manifest_key,
        "synced": len(exported_tables),
        "bootstrap": bootstrap,
    }


def _recover_normalized_generation() -> dict[str, list[dict[str, Any]]]:
    manifests = _normalized_generation_manifests()
    if not manifests:
        raise GoogleSheetsBackupError("RAW_BACKUP does not contain a committed normalized generation")
    payload_cache = _read_raw_named_sections(V8_GENERATION_TABLE_PREFIX)
    last_error: Exception | None = None
    for generation, manifest in manifests:
        try:
            table_refs = manifest.get("tables")
            if not isinstance(table_refs, dict):
                raise GoogleSheetsBackupError("normalized generation manifest has no table map")
            protected_snapshot: dict[str, Any] = {}
            for table in NORMALIZED_TABLES:
                key = str(table_refs.get(table) or "")
                if not key.startswith(V8_GENERATION_TABLE_PREFIX):
                    raise GoogleSheetsBackupError(f"normalized generation {generation} is missing {table}")
                value = payload_cache.get(key)
                if not isinstance(value, list):
                    raise GoogleSheetsBackupError(f"normalized generation {generation} payload missing for {table}")
                protected_snapshot[table] = value
            unprotected = unprotect_sensitive_payload(protected_snapshot, SETTINGS.sensitive_data_key)
            if not isinstance(unprotected, dict):
                raise GoogleSheetsBackupError("normalized generation did not decode to a database object")
            return {
                table: (unprotected.get(table) if isinstance(unprotected.get(table), list) else [])
                for table in NORMALIZED_TABLES
            }
        except Exception as exc:
            last_error = exc
            logger.warning("Skipping incomplete normalized Google generation %s: %s", generation, exc)
    raise GoogleSheetsBackupError("No complete committed normalized Google generation is recoverable") from last_error

def recover_normalized_snapshot_from_sheets() -> dict[str, list[dict[str, Any]]]:
    # Immutable generation payloads and manifests provide a
    # manifest is visible only after every referenced table payload has been
    # written, so recovery can never combine tables from two partial syncs.
    try:
        return _recover_normalized_generation()
    except GoogleSheetsBackupError:
        # Backwards compatibility for installations that have not yet produced
        # their first generation-atomic snapshot. The next successful sync will
        # bootstrap the new format.
        raw = _read_raw_named_sections(V8_TABLE_PREFIX)
        result: dict[str, list[dict[str, Any]]] = {}
        for key, value in raw.items():
            table = key[len(V8_TABLE_PREFIX) :]
            if table in NORMALIZED_TABLES and isinstance(value, list):
                unprotected = unprotect_sensitive_payload({table: value}, SETTINGS.sensitive_data_key).get(table, [])
                result[table] = unprotected if isinstance(unprotected, list) else []
        if set(result) != set(NORMALIZED_TABLES):
            raise GoogleSheetsBackupError("RAW_BACKUP does not contain a complete recoverable normalized v8 database")
        return result


def _sqlite_restore_value(value: Any) -> Any:
    if isinstance(value, dict) and set(value) == {"__sentinel_bytes_b64__"}:
        return base64.b64decode(str(value["__sentinel_bytes_b64__"]))
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)
    if isinstance(value, bool):
        return 1 if value else 0
    return value


def restore_normalized_snapshot_to_sqlite(snapshot: dict[str, list[dict[str, Any]]], sqlite_path: Path) -> Path:
    """Restore a Google normalized snapshot into an emergency local SQLite DB."""
    import sqlite3
    from core.storage.engine import DatabaseEngine

    target = Path(sqlite_path).resolve()
    target.parent.mkdir(parents=True, exist_ok=True)
    # Rebuild from scratch to avoid stale rows and to make the restore atomic-ish
    # at file level for a newly activated failover database.
    target.unlink(missing_ok=True)
    engine = DatabaseEngine(database_url="", sqlite_path=target)
    engine.ensure_schema()
    connection = sqlite3.connect(target, timeout=30)
    try:
        connection.execute("PRAGMA foreign_keys=OFF")
        connection.execute("BEGIN IMMEDIATE")
        for table in reversed(NORMALIZED_TABLES):
            connection.execute(f"DELETE FROM {table}")  # nosec B608
        for table in NORMALIZED_TABLES:
            rows = snapshot.get(table, [])
            for row in rows:
                if not isinstance(row, dict) or not row:
                    continue
                columns = [str(column) for column in row.keys()]
                if not all(column.replace("_", "").isalnum() for column in columns):
                    raise GoogleSheetsBackupError(f"Unsafe column name while restoring {table}")
                placeholders = ",".join("?" for _ in columns)
                names = ",".join(columns)
                values = [_sqlite_restore_value(row[column]) for column in columns]
                connection.execute(f"INSERT INTO {table}({names}) VALUES({placeholders})", values)  # nosec B608
        connection.commit()
    except Exception:
        connection.rollback()
        raise
    finally:
        connection.close()
    return target


def _normalized_failover_metadata_path(sqlite_path: Path) -> Path:
    return Path(sqlite_path).with_suffix(Path(sqlite_path).suffix + ".google-meta.json")


def normalized_failover_base_checksum(sqlite_path: Path) -> str:
    try:
        payload = json.loads(_normalized_failover_metadata_path(sqlite_path).read_text(encoding="utf-8"))
    except (OSError, ValueError, TypeError):
        return ""
    return str(payload.get("base_checksum") or "") if isinstance(payload, dict) else ""


def _restore_engine_value(value: Any) -> Any:
    if isinstance(value, dict) and set(value) == {"__sentinel_bytes_b64__"}:
        return base64.b64decode(str(value["__sentinel_bytes_b64__"]))
    if isinstance(value, (dict, list, tuple)):
        return json.dumps(value, ensure_ascii=False, separators=(",", ":"), default=str)
    return value


def restore_normalized_snapshot_to_engine(snapshot: dict[str, list[dict[str, Any]]], engine: Any) -> None:
    """Transactionally replace a normalized database from a verified snapshot.

    This is used only by the guarded Google failover reconciliation path after
    the recovered primary database checksum is proven equal to the snapshot on
    which failover began.
    """
    engine.ensure_schema()
    with engine.transaction() as cursor:
        if getattr(engine.dialect, "name", "") == "postgres":
            tables = ",".join(NORMALIZED_TABLES)
            cursor.execute(f"TRUNCATE TABLE {tables} RESTART IDENTITY CASCADE")  # nosec B608 -- fixed allow-list
        else:
            for table in reversed(NORMALIZED_TABLES):
                cursor.execute(f"DELETE FROM {table}")  # nosec B608 -- fixed allow-list
        for table in NORMALIZED_TABLES:
            for row in snapshot.get(table, []):
                if not isinstance(row, dict) or not row:
                    continue
                columns = [str(column) for column in row.keys()]
                if not all(column.replace("_", "").isalnum() for column in columns):
                    raise GoogleSheetsBackupError(f"Unsafe column name while restoring {table}")
                placeholders = ",".join("?" for _ in columns)
                names = ",".join(columns)
                values = [_restore_engine_value(row[column]) for column in columns]
                cursor.execute(f"INSERT INTO {table}({names}) VALUES({placeholders})", values)  # nosec B608
        if getattr(engine.dialect, "name", "") == "postgres":
            for table in ("v8_events", "v8_audit_log"):
                cursor.execute(
                    f"SELECT setval(pg_get_serial_sequence('{table}', 'sequence'), "
                    f"COALESCE((SELECT MAX(sequence) FROM {table}), 1), "
                    f"EXISTS(SELECT 1 FROM {table}))"  # nosec B608 -- fixed allow-list
                )


def build_normalized_failover_sqlite() -> Path:
    snapshot = recover_normalized_snapshot_from_sheets()
    target = Path(SETTINGS.backup_dir) / "google-sheets-v8-failover.sqlite3"
    restored = restore_normalized_snapshot_to_sqlite(snapshot, target)
    checksum = normalized_snapshot_checksum(snapshot)
    metadata_path = _normalized_failover_metadata_path(restored)
    metadata_path.write_text(
        json.dumps({"base_checksum": checksum, "restored_at": _now_iso()}, ensure_ascii=False),
        encoding="utf-8",
    )
    _log_sync(
        mode="normalized_failover_restore",
        source="google",
        sections=snapshot.keys(),
        status="OK",
        duration_ms=0,
        checksum=checksum,
    )
    return restored


def normalized_bootstrap_needed() -> bool:
    if not is_configured():
        return False
    try:
        return not bool(_normalized_generation_manifests()) and V8_META_SECTION not in _load_raw_index(force=True)
    except Exception:
        return True
