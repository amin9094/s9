from __future__ import annotations

import asyncio
import base64
import hashlib
import hmac
import io
import json
import logging
import mimetypes
import os
import re
import secrets
import threading
import time
from contextlib import asynccontextmanager
from html import escape as html_escape
from pathlib import Path
from typing import Any, AsyncIterator, Callable
from urllib.parse import unquote, urlsplit

import uvicorn
from fastapi import FastAPI, File, Header, HTTPException, Query, Request, Response, UploadFile
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse, PlainTextResponse, StreamingResponse

from config import SETTINGS
from core.webapp_auth import TelegramWebAppIdentity, validate_init_data
from core.async_runtime import run_blocking
from core.connection_limits import acquire_connection_limits
from core.rate_limit import allow as rate_limit_allow
from core.logging_context import reset_correlation_id, set_correlation_id
from core.metrics_v2 import action_result, api_request, sse_connected
from core.observability import increment, gauge
from modules.miniapp_product import store_receipt_bytes
from modules.receipt_storage import delete_receipt_blob
from repositories.v2.commerce import CommerceRepository
from services.event_stream_service import EventStreamService
from services.miniapp_action_service_v2 import handle_miniapp_action_for_identity
from services import miniapp_read_service_v2 as v2

logger = logging.getLogger(__name__)
_WEBAPP_ROOT = (Path(__file__).resolve().parents[1] / "webapp").resolve()
_SESSION_COOKIE = "sentinel_session"
_SESSION_TTL = max(900, min(int(os.getenv("WEBAPP_SESSION_TTL_SECONDS", "86400") or 86400), 86400))
# Telegram may keep a Mini App WebView alive for hours. The payload remains
# signature-verified and replay-protected, so a one-day launch window avoids
# rejecting a legitimate still-open WebView while retaining a finite lifetime.
_INIT_MAX_AGE = max(300, min(int(os.getenv("WEBAPP_AUTH_MAX_AGE_SECONDS", "86400") or 86400), 172800))
_SERVER: uvicorn.Server | None = None
_THREAD: threading.Thread | None = None
_SESSION_SECRET_CACHE: bytes | None = None
_TELEGRAM_APPLICATION: Any | None = None
_TELEGRAM_EVENT_LOOP: asyncio.AbstractEventLoop | None = None
_TELEGRAM_APPLICATION_LOCK = threading.RLock()
_MAX_TELEGRAM_UPDATE_BYTES = 1_000_000
_BACKGROUND_TASKS: set[asyncio.Task[Any]] = set()

_ERROR_MESSAGES = {
    "fa": {
        "UNAUTHORIZED": "نشست شما معتبر نیست؛ مینی‌اپ را دوباره از تلگرام باز کنید.",
        "CSRF_INVALID": "اعتبار امنیتی درخواست منقضی شده است.",
        "RATE_LIMITED": "درخواست‌ها خیلی سریع ارسال می‌شوند؛ کمی صبر کنید.",
        "SIGNAL_NOT_FOUND": "سیگنال پیدا نشد.",
        "EXECUTION_CONFIRMATION_REQUIRED": "پیش از ثبت معامله، جزئیات اجرای واقعی را تأیید کنید.",
        "PRETRADE_GATE_BLOCKED": "این معامله با قوانین ریسک حساب سازگار نیست.",
        "PRETRADE_HARD_BLOCK": "این ورود به‌دلیل قانون قطعی ریسک قابل انجام یا دورزدن نیست.",
        "REQUEST_IN_PROGRESS": "این درخواست در حال پردازش است؛ چند لحظه بعد نتیجه را بررسی کنید.",
        "IDEMPOTENCY_CONFLICT": "شناسه درخواست قبلاً با اطلاعات متفاوت استفاده شده است.",
        "TEMPORARILY_UNAVAILABLE": "سرویس موقتاً در دسترس نیست.",
        "SYSTEM_READ_ONLY": "سامانه در حالت نگهداری یا فقط‌خواندنی است؛ کمی بعد دوباره تلاش کنید.",
        "MINIAPP_DISABLED": "مینی‌اپ موقتاً توسط مدیر غیرفعال شده است.",
        "INIT_DATA_MISSING": "اطلاعات ورود تلگرام دریافت نشد؛ مینی‌اپ را از دکمه داخل ربات باز کنید.",
        "INIT_DATA_SIGNATURE_INVALID": "امضای ورود تلگرام معتبر نیست؛ توکن ربات و تنظیم BotFather را بررسی کنید.",
        "INIT_DATA_EXPIRED": "اطلاعات ورود تلگرام منقضی شده است؛ مینی‌اپ را ببندید و دوباره باز کنید.",
        "INIT_DATA_USER_INVALID": "اطلاعات حساب تلگرام معتبر نیست.",
        "INIT_DATA_REPLAYED": "این نشست تلگرام قبلاً استفاده شده است؛ مینی‌اپ را دوباره باز کنید.",
        "PROP_RULE_TEMPLATE_NOT_FOUND": "قالب قوانین انتخاب‌شده فعال نیست؛ یک قالب دیگر انتخاب کنید.",
        "PAIRING_CODE_INVALID": "کد اتصال متاتریدر معتبر نیست یا قبلاً استفاده شده است.",
        "PAIRING_CODE_EXPIRED": "کد اتصال متاتریدر منقضی شده است؛ کد جدید بسازید.",
        "CONNECTOR_AUTH_INVALID": "اعتبار اتصال متاتریدر معتبر نیست.",
        "CONNECTOR_SIGNATURE_INVALID": "امضای امنیتی اتصال متاتریدر معتبر نیست.",
        "CONNECTOR_REPLAY_DETECTED": "این درخواست متاتریدر قبلاً پردازش شده است.",
        "CONNECTOR_TIMESTAMP_EXPIRED": "زمان درخواست متاتریدر معتبر نیست؛ ساعت سیستم را تنظیم کنید.",
        "CONNECTOR_PAYLOAD_TOO_LARGE": "حجم اطلاعات متاتریدر بیش از حد مجاز است.",
    },
    "en": {
        "UNAUTHORIZED": "Your session is invalid. Reopen the Mini App from Telegram.",
        "CSRF_INVALID": "The security token has expired.",
        "RATE_LIMITED": "Too many requests. Please wait a moment.",
        "SIGNAL_NOT_FOUND": "Signal not found.",
        "EXECUTION_CONFIRMATION_REQUIRED": "Confirm the real execution details before opening the position.",
        "PRETRADE_GATE_BLOCKED": "This trade violates the account risk rules.",
        "PRETRADE_HARD_BLOCK": "This entry is blocked by a non-overridable risk rule.",
        "REQUEST_IN_PROGRESS": "This request is still being processed. Check again shortly.",
        "IDEMPOTENCY_CONFLICT": "The request id was already used with a different payload.",
        "TEMPORARILY_UNAVAILABLE": "The service is temporarily unavailable.",
        "SYSTEM_READ_ONLY": "The system is in maintenance or read-only mode. Try again later.",
        "MINIAPP_DISABLED": "The Mini App is temporarily disabled by an administrator.",
        "INIT_DATA_MISSING": "Telegram launch data was not received. Open the Mini App from the bot button.",
        "INIT_DATA_SIGNATURE_INVALID": "Telegram login signature is invalid. Check the bot token and BotFather configuration.",
        "INIT_DATA_EXPIRED": "Telegram launch data has expired. Close and reopen the Mini App.",
        "INIT_DATA_USER_INVALID": "Telegram user data is invalid.",
        "INIT_DATA_REPLAYED": "This Telegram launch session was already used. Reopen the Mini App.",
        "PROP_RULE_TEMPLATE_NOT_FOUND": "The selected rule template is not active. Choose another template.",
        "PAIRING_CODE_INVALID": "The MetaTrader pairing code is invalid or already used.",
        "PAIRING_CODE_EXPIRED": "The MetaTrader pairing code expired. Generate a new code.",
        "CONNECTOR_AUTH_INVALID": "The MetaTrader connector credentials are invalid.",
        "CONNECTOR_SIGNATURE_INVALID": "The MetaTrader connector signature is invalid.",
        "CONNECTOR_REPLAY_DETECTED": "This MetaTrader request was already processed.",
        "CONNECTOR_TIMESTAMP_EXPIRED": "The MetaTrader request time is invalid. Check the terminal clock.",
        "CONNECTOR_PAYLOAD_TOO_LARGE": "The MetaTrader payload is too large.",
    },
}


def _b64(data: bytes) -> str:
    return base64.urlsafe_b64encode(data).decode().rstrip("=")


def _unb64(value: str) -> bytes:
    return base64.urlsafe_b64decode(value + "=" * (-len(value) % 4))


def _is_production() -> bool:
    environment = str(
        os.getenv("SENTINEL_ENV") or os.getenv("ENVIRONMENT") or os.getenv("RAILWAY_ENVIRONMENT") or "development"
    ).strip().lower()
    return environment in {"production", "prod"} or bool(os.getenv("RAILWAY_PROJECT_ID"))


def _session_keyring() -> tuple[str, dict[str, bytes]]:
    configured = str(getattr(SETTINGS, "webapp_session_secret", "") or os.getenv("WEBAPP_SESSION_SECRET", "")).strip()
    if not configured:
        if _is_production():
            raise RuntimeError("WEBAPP_SESSION_SECRET is required in production and must be independent from BOT_TOKEN")
        seed = os.getenv("SENTINEL_TEST_SESSION_SECRET", "sentinel-development-only-secret")
        configured = hashlib.sha256(f"sentinel-development:{seed}".encode("utf-8")).hexdigest()
    normalized = re.sub(r"[^a-z0-9]+", "_", configured.lower()).strip("_")
    blocked = ("change_me", "changeme", "your_secret", "default_secret", "test_secret", "replace_me", "example")
    if len(configured) < 32 or any(marker in normalized for marker in blocked):
        raise RuntimeError("WEBAPP_SESSION_SECRET must be a random value of at least 32 characters")
    if configured == SETTINGS.bot_token or (SETTINGS.bot_token and SETTINGS.bot_token in configured):
        raise RuntimeError("WEBAPP_SESSION_SECRET must not reuse BOT_TOKEN")
    current_version = str(getattr(SETTINGS, "session_key_version", "") or os.getenv("WEBAPP_SESSION_KEY_VERSION", "v1")).strip() or "v1"
    keys = {current_version: hashlib.sha256(configured.encode()).digest()}
    for row in getattr(SETTINGS, "session_previous_keys", ()) or ():
        version, separator, secret = str(row).partition(":")
        if separator and version and len(secret) >= 32 and version not in keys:
            keys[version] = hashlib.sha256(secret.encode()).digest()
    return current_version, keys


def _session_secret() -> bytes:
    global _SESSION_SECRET_CACHE
    if _SESSION_SECRET_CACHE is None:
        current_version, keys = _session_keyring()
        _SESSION_SECRET_CACHE = keys[current_version]
    return _SESSION_SECRET_CACHE


def _session_token(identity: TelegramWebAppIdentity) -> tuple[str, str]:
    csrf = secrets.token_urlsafe(24)
    payload = {
        "uid": identity.user_id,
        "username": identity.username,
        "first_name": identity.first_name,
        "last_name": identity.last_name,
        "iat": int(time.time()),
        "exp": int(time.time()) + _SESSION_TTL,
        "csrf": csrf,
        "nonce": secrets.token_hex(8),
        "kid": _session_keyring()[0],
    }
    encoded = _b64(json.dumps(payload, separators=(",", ":"), ensure_ascii=False).encode())
    signature = _b64(hmac.new(_session_secret(), encoded.encode(), hashlib.sha256).digest())
    return f"{encoded}.{signature}", csrf


def _identity_from_session(token: str) -> tuple[TelegramWebAppIdentity, dict[str, Any]]:
    try:
        encoded, supplied = str(token or "").split(".", 1)
        payload = json.loads(_unb64(encoded))
        current_version, keyring = _session_keyring()
        key_id = str(payload.get("kid") or current_version)
        key = keyring.get(key_id)
        if key is None:
            raise ValueError
        expected = _b64(hmac.new(key, encoded.encode(), hashlib.sha256).digest())
        if not hmac.compare_digest(expected, supplied):
            raise ValueError
        if int(payload.get("exp", 0)) <= int(time.time()) or int(payload.get("uid", 0)) <= 0:
            raise ValueError
        identity = TelegramWebAppIdentity(
            user_id=int(payload["uid"]),
            username=str(payload.get("username") or ""),
            first_name=str(payload.get("first_name") or ""),
            last_name=str(payload.get("last_name") or ""),
            auth_date=int(payload.get("iat") or 0),
            query_id="session",
        )
        return identity, payload
    except (ValueError, TypeError, KeyError, json.JSONDecodeError, UnicodeDecodeError) as exc:
        raise HTTPException(status_code=401, detail="UNAUTHORIZED") from exc




def _track_background_task(coro: Any, *, name: str) -> asyncio.Task[Any]:
    task = asyncio.create_task(coro, name=name)
    _BACKGROUND_TASKS.add(task)

    def done(completed: asyncio.Task[Any]) -> None:
        _BACKGROUND_TASKS.discard(completed)
        if completed.cancelled():
            return
        try:
            completed.result()
        except Exception:
            logger.exception("Mini App background task failed: %s", completed.get_name())

    task.add_done_callback(done)
    return task


async def _drain_owned_tasks(tasks, *, timeout: float) -> None:
    """Run cancellation on the event loop that owns these tasks."""
    if not tasks:
        return
    for task in tasks:
        task.cancel()
    done, pending = await asyncio.wait(tasks, timeout=max(0.1, float(timeout)))
    for task in pending:
        logger.warning("Mini App background task did not stop before shutdown: %s", task.get_name())
    for task in done:
        if not task.cancelled():
            try:
                task.result()
            except Exception:
                logger.exception("Mini App background task failed while draining: %s", task.get_name())


async def drain_background_tasks(*, timeout: float = 5.0) -> None:
    """Drain both the FastAPI and Telegram loops without cross-thread cancel."""
    current = asyncio.get_running_loop()
    groups = {}
    for task in tuple(_BACKGROUND_TASKS):
        if not task.done():
            groups.setdefault(task.get_loop(), []).append(task)
    waits = []
    for owner, tasks in groups.items():
        if owner is current:
            waits.append(_drain_owned_tasks(tasks, timeout=timeout))
        elif owner.is_running():
            future = asyncio.run_coroutine_threadsafe(_drain_owned_tasks(tasks, timeout=timeout), owner)
            waits.append(asyncio.wrap_future(future))
        else:
            logger.warning("Background task owner loop is unavailable during shutdown")
    if waits:
        try:
            async with asyncio.timeout(max(0.1, timeout) + 0.5):
                await asyncio.gather(*waits)
        except TimeoutError:
            logger.warning("Background tasks exceeded shutdown drain budget")

def register_telegram_application(
    application: Any, loop: asyncio.AbstractEventLoop | None = None
) -> None:
    """Expose PTB to FastAPI and preserve cross-thread event-loop safety."""
    global _TELEGRAM_APPLICATION, _TELEGRAM_EVENT_LOOP
    if loop is None:
        loop = asyncio.get_running_loop()
    with _TELEGRAM_APPLICATION_LOCK:
        _TELEGRAM_APPLICATION = application
        _TELEGRAM_EVENT_LOOP = loop


def unregister_telegram_application(application: Any | None = None) -> None:
    global _TELEGRAM_APPLICATION, _TELEGRAM_EVENT_LOOP
    with _TELEGRAM_APPLICATION_LOCK:
        if application is None or _TELEGRAM_APPLICATION is application:
            _TELEGRAM_APPLICATION = None
            _TELEGRAM_EVENT_LOOP = None


def _telegram_application() -> tuple[Any | None, asyncio.AbstractEventLoop | None]:
    with _TELEGRAM_APPLICATION_LOCK:
        return _TELEGRAM_APPLICATION, _TELEGRAM_EVENT_LOOP


def _miniapp_access_allowed(user_id: int | str) -> bool:
    from core.db import read_db_sections
    from modules.admin_access import is_any_admin
    from modules.miniapp_runtime import miniapp_enabled

    db = read_db_sections(("settings", "delegated_admins", "admin_shifts"))
    return miniapp_enabled(db) or is_any_admin(db, user_id)


async def _run_on_telegram_loop(coro: Any) -> Any:
    application, loop = _telegram_application()
    if application is None or loop is None or not loop.is_running():
        if hasattr(coro, "close"):
            coro.close()
        return None
    try:
        current = asyncio.get_running_loop()
    except RuntimeError:
        current = None
    if current is loop:
        return await coro
    future = asyncio.run_coroutine_threadsafe(coro, loop)
    return await asyncio.wrap_future(future)


def _admin_ids_for(permission: str) -> list[int]:
    from core.db import read_db_sections
    from modules.admin_access import delegated_admins, has_permission

    db = read_db_sections(("delegated_admins", "admin_shifts"))
    ids = {int(value) for value in SETTINGS.admin_ids}
    for uid, row in delegated_admins(db).items():
        if row.get("active", True) and has_permission(db, uid, permission):
            try:
                ids.add(int(uid))
            except (TypeError, ValueError):
                continue
    return sorted(ids)


async def _after_action_telegram_sync(action: str, result: dict[str, Any], identity: TelegramWebAppIdentity) -> None:
    application, _ = _telegram_application()
    if application is None:
        if action == "payment_approve":
            # Approval cannot succeed without Telegram channel invite creation.
            from repositories.v2.commerce import CommerceRepository
            order_data = result.get("data") if isinstance(result.get("data"), dict) else {}
            action_data = order_data.get("result") if isinstance(order_data.get("result"), dict) else order_data
            order_id = action_data.get("id") or action_data.get("order_id")
            if order_id:
                CommerceRepository().release_order_approval(order_id, actor_id=str(identity.user_id), error="telegram runtime unavailable")
            raise RuntimeError("TELEGRAM_RUNTIME_UNAVAILABLE")
        return
    data = result.get("data") if isinstance(result.get("data"), dict) else {}
    action_data = data.get("result") if isinstance(data.get("result"), dict) else data
    try:
        from telegram import InlineKeyboardMarkup, MenuButtonCommands
        from ui.button_factory import InlineKeyboardButton
        from modules.admin_access import PERMISSION_PAYMENTS

        if action in {"ticket_create", "ticket_reply", "ticket_admin_reply", "ticket_admin_status_update", "ticket_admin_assign"}:
            async def trigger_support_outbox() -> None:
                await asyncio.sleep(0.15)
                try:
                    from services.automation_delivery_service import deliver_automation_outbox
                    await _run_on_telegram_loop(deliver_automation_outbox(application.bot, limit=25))
                except Exception:
                    logger.exception("Immediate support outbox delivery failed; recurring worker will retry")
            _track_background_task(trigger_support_outbox(), name=f"support-outbox:{action}:{action_data.get('id','unknown')}")
        elif action in {"vip_order_submit", "vip_order_resubmit"}:
            from modules.receipt_storage import read_receipt_bytes
            from repositories.v2.commerce import CommerceRepository
            from services.vip_order_projection import project_normalized_order_to_legacy

            order_id = action_data.get("id") or action_data.get("order_id")
            projected = await run_blocking(project_normalized_order_to_legacy, order_id) if order_id else None
            order = projected or action_data
            receipt_id = str(order.get("receipt_id") or order.get("receipt_key") or "")
            receipt = await run_blocking(CommerceRepository().get_receipt_admin, receipt_id) if receipt_id else None
            receipt_payload = await run_blocking(read_receipt_bytes, receipt) if receipt else None
            method = "تتر" if str(order.get("payment_method")) == "usdt" else "ریالی"
            caption = (
                "💳 <b>رسید پرداخت VIP جدید</b>\n"
                f"سفارش: <code>{order_id}</code>\n"
                f"کاربر: <code>{identity.user_id}</code>\n"
                f"روش: <b>{method} — بررسی دستی</b>\n"
                f"مبلغ: <b>{int(order.get('amount_toman') or order.get('price') or 0):,} تومان</b>\n"
                f"TXID اختیاری: <code>{order.get('transaction_hash') or '—'}</code>\n"
                "رسید را بررسی و سپس تأیید یا رد کنید."
            )
            keyboard = InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ تأیید دستی و ارسال لینک", callback_data=f"approve:{order_id}"),
                InlineKeyboardButton("❌ رد رسید", callback_data=f"reject:{order_id}"),
            ]])
            delivered = False
            for admin_id in _admin_ids_for(PERMISSION_PAYMENTS):
                try:
                    if receipt_payload:
                        stream = io.BytesIO(receipt_payload)
                        stream.name = "sentinel-payment-receipt.webp"
                        await _run_on_telegram_loop(application.bot.send_photo(admin_id, stream, caption=caption, parse_mode="HTML", reply_markup=keyboard))
                    else:
                        await _run_on_telegram_loop(application.bot.send_message(admin_id, caption, parse_mode="HTML", reply_markup=keyboard))
                    delivered = True
                except Exception:
                    logger.exception("Could not notify payment admin=%s order=%s", admin_id, order_id)
            from services.vip_order_projection import mark_projected_order_notification
            await run_blocking(
                mark_projected_order_notification, order_id, audience="admin", success=delivered,
                error="all payment admin deliveries failed" if not delivered else "",
            )
        elif action == "payment_approve":
            from services.vip_payment_orchestrator import approve_manual_vip_order
            order_id = action_data.get("id") or action_data.get("order_id")
            approved = await _run_on_telegram_loop(
                approve_manual_vip_order(application.bot, order_id, identity.user_id)
            )
            action_data.clear()
            action_data.update(approved)
        elif action == "payment_reject":
            from services.vip_payment_orchestrator import notify_manual_order_user
            from services.vip_order_projection import mark_projected_order_notification
            notified = bool(await _run_on_telegram_loop(notify_manual_order_user(application.bot, action_data)))
            await run_blocking(
                mark_projected_order_notification,
                action_data.get("id") or action_data.get("order_id"),
                audience="user",
                success=notified,
                error="Telegram rejection notification failed" if not notified else "",
            )
        elif action == "miniapp_signal_publish":
            async def trigger_signal_worker() -> None:
                await asyncio.sleep(1.15)
                try:
                    from types import SimpleNamespace
                    from bot_runtime.growth_campaigns import scheduled_signal_job
                    await asyncio.wait_for(
                        _run_on_telegram_loop(scheduled_signal_job(SimpleNamespace(bot=application.bot))),
                        timeout=35,
                    )
                except Exception:
                    logger.exception("Immediate Mini App signal worker failed; recurring worker will retry")
            _track_background_task(trigger_signal_worker(), name=f"miniapp-signal-publish:{action_data.get('queue_id','unknown')}")
        elif action in {"signal_edit", "signal_result_set", "signal_result_reset"}:
            from bot_runtime.growth_campaigns import (
                _publish_signal_update, _refresh_signal_channel_messages,
                _signal_result_message, _sync_signal_live_status, _sync_smart_pin,
            )
            row = action_data if isinstance(action_data, dict) else {}
            if not row.get("id"):
                return
            if action == "signal_edit":
                history = row.get("edit_history") if isinstance(row.get("edit_history"), list) else []
                field = str((history[-1] if history else {}).get("field") or "update")
                rebuild = field in {"stop", "entry", "add_target"} or field.startswith("target_")
                await _run_on_telegram_loop(_refresh_signal_channel_messages(application.bot, row, rebuild_media=rebuild))
                signal_number = html_escape(str(row.get("display_number") or row.get("id") or "—"))
                update_detail = html_escape(str(row.get("update_note") or field))
                update_message = f"✏️ <b>سیگنال #{signal_number} بروزرسانی شد</b>\n{update_detail}"
                await _run_on_telegram_loop(_publish_signal_update(application.bot, row, update_message))
            elif action == "signal_result_set":
                await _run_on_telegram_loop(_refresh_signal_channel_messages(application.bot, row))
                await _run_on_telegram_loop(_publish_signal_update(application.bot, row, _signal_result_message(row)))
                await _run_on_telegram_loop(_sync_smart_pin(application.bot))
            else:
                await _run_on_telegram_loop(_refresh_signal_channel_messages(application.bot, row))
                await _run_on_telegram_loop(_sync_signal_live_status(application.bot, row))
                await _run_on_telegram_loop(_sync_smart_pin(application.bot))
        elif action == "signal_delete":
            from bot_runtime.growth_campaigns import _sync_smart_pin
            removed = action_data.get("signal") if isinstance(action_data, dict) and isinstance(action_data.get("signal"), dict) else {}
            deleted: set[tuple[int, int]] = set()
            for delivery in removed.get("deliveries", []) if isinstance(removed.get("deliveries"), list) else []:
                if not isinstance(delivery, dict):
                    continue
                try:
                    chat_id = int(delivery.get("chat_id", 0) or 0)
                except (TypeError, ValueError):
                    continue
                for key in ("status_message_id", "message_id"):
                    try:
                        message_id = int(delivery.get(key, 0) or 0)
                    except (TypeError, ValueError):
                        message_id = 0
                    pair = (chat_id, message_id)
                    if not chat_id or not message_id or pair in deleted:
                        continue
                    deleted.add(pair)
                    try:
                        await _run_on_telegram_loop(application.bot.delete_message(chat_id=chat_id, message_id=message_id))
                    except Exception:
                        logger.warning("Could not delete signal channel message chat=%s message=%s", chat_id, message_id)
            await _run_on_telegram_loop(_sync_smart_pin(application.bot))
            try:
                from repositories.v2.signals import SignalRepository
                await run_blocking(SignalRepository().delete, removed.get("id"))
            except Exception:
                logger.exception("Could not delete normalized signal projection signal_id=%s", removed.get("id"))
        elif action == "miniapp_runtime_toggle":
            # Mini App enable/disable changes inline access only. Keep the
            # left-side Telegram button dedicated to native commands.
            await _run_on_telegram_loop(
                application.bot.set_chat_menu_button(menu_button=MenuButtonCommands())
            )
    except Exception:
        logger.exception("Post-action Telegram synchronization failed action=%s user_id=%s", action, identity.user_id)
        if action == "payment_approve":
            # The orchestrator releases the claim and revokes an unused link.
            # Propagate the failure so the Mini App never displays a false approval.
            raise



def finalize_action_telegram_sync(
    action: str,
    result: dict[str, Any],
    identity: TelegramWebAppIdentity,
    *,
    timeout_seconds: float = 90.0,
) -> None:
    """Run the shared Telegram post-action finalizer from a worker thread.

    Gemini admin execution runs in ``asyncio.to_thread``. Database mutations
    such as payment approval must therefore be finalized on the live PTB event
    loop before the action is reported as successful.
    """
    application, loop = _telegram_application()
    if application is None or loop is None or not loop.is_running():
        # Preserve the existing payment safety behavior: release an approval
        # claim and raise instead of reporting a false VIP activation.
        asyncio.run(_after_action_telegram_sync(action, result, identity))
        return
    try:
        current = asyncio.get_running_loop()
    except RuntimeError:
        current = None
    if current is loop:
        raise RuntimeError("TELEGRAM_FINALIZER_REQUIRES_ASYNC_CALL")
    future = asyncio.run_coroutine_threadsafe(
        _after_action_telegram_sync(action, result, identity),
        loop,
    )
    future.result(timeout=max(5.0, float(timeout_seconds)))

def _transport_audit_context(request: Request) -> dict[str, str]:
    client_host = str(getattr(request.client, "host", "") or "")
    user_agent = str(request.headers.get("user-agent") or "")[:300]
    session = str(request.cookies.get(_SESSION_COOKIE) or "")
    return {
        "request_id": str(getattr(request.state, "request_id", "") or ""),
        "client_hash": hashlib.sha256(f"{client_host}|{user_agent}".encode()).hexdigest()[:24],
        "session_hash": hashlib.sha256(session.encode()).hexdigest()[:24] if session else "",
    }


def _request_identity(request: Request) -> tuple[TelegramWebAppIdentity, dict[str, Any]]:
    return _identity_from_session(request.cookies.get(_SESSION_COOKIE, ""))


def _language(request: Request) -> str:
    value = str(request.headers.get("Accept-Language") or "fa").lower()
    return "en" if value.startswith("en") else "fa"


def _error_payload(code: str, *, request_id: str, detail: str = "", language: str = "fa") -> dict[str, Any]:
    clean = str(code or "TEMPORARILY_UNAVAILABLE").split(":", 1)[0]
    message = _ERROR_MESSAGES.get(language, {}).get(clean) or detail or clean.replace("_", " ").title()
    return {"ok": False, "error": {"code": clean, "message": message, "detail": detail[:500], "request_id": request_id}}


def _request_id(request: Request) -> str:
    supplied = str(request.headers.get("X-Request-ID") or "").strip()
    if supplied and len(supplied) <= 100 and all(ch.isalnum() or ch in "-_:." for ch in supplied):
        return supplied
    return secrets.token_hex(10)


def _json(data: Any, *, request_id: str = "", status: int = 200) -> JSONResponse:
    payload = data if isinstance(data, dict) else {"data": data}
    if "ok" not in payload:
        payload = {"ok": True, "data": payload}
    response = JSONResponse(payload, status_code=status)
    if request_id:
        response.headers["X-Request-ID"] = request_id
    response.headers["Cache-Control"] = "no-store"
    return response


def _static_path(url_path: str) -> Path | None:
    # Decode before applying the SPA fallback. Without this, an encoded
    # traversal-like path could be mistaken for a normal extensionless client
    # route and receive index.html. It did not expose files, but returning the
    # application shell for a hostile path is misleading and weakens audits.
    clean = str(url_path or "")
    for _ in range(3):
        decoded = unquote(clean)
        if decoded == clean:
            break
        clean = decoded
    clean = clean.replace("\\", "/").lstrip("/")
    if "\x00" in clean or any(part == ".." for part in clean.split("/")):
        return None
    if clean in {"", "app", "app/"}:
        clean = "index.html"
    elif clean.startswith("app/"):
        clean = clean[4:] or "index.html"
    candidate = (_WEBAPP_ROOT / clean).resolve()
    try:
        candidate.relative_to(_WEBAPP_ROOT)
    except ValueError:
        return None
    if candidate.is_file():
        return candidate
    if "." not in Path(clean).name:
        index = _WEBAPP_ROOT / "index.html"
        return index if index.is_file() else None
    return None


def _canonical_origins() -> set[str]:
    configured = [str(SETTINGS.webapp_url or "").strip(), *str(os.getenv("WEBAPP_ALLOWED_ORIGINS") or "").split(",")]
    output: set[str] = set()
    for item in configured:
        item = item.strip().rstrip("/")
        if not item:
            continue
        parsed = urlsplit(item)
        if parsed.scheme in {"https", "http"} and parsed.netloc:
            output.add(f"{parsed.scheme}://{parsed.netloc}".lower())
    return output


def _validate_same_origin(request: Request) -> None:
    """Validate mutations against the configured canonical origin.

    Forwarded host/protocol headers are intentionally ignored because they are
    attacker-controlled unless the entire proxy chain is explicitly trusted.
    Native Telegram WebViews may omit Origin; those requests are still protected
    by a signed session, CSRF token and validated Telegram initData bootstrap.
    """
    origin = str(request.headers.get("Origin") or "").strip().rstrip("/").lower()
    if not origin:
        return
    allowed = _canonical_origins()
    if not allowed or not any(hmac.compare_digest(origin, candidate) for candidate in allowed):
        raise HTTPException(status_code=403, detail="CSRF_INVALID")


def create_app() -> FastAPI:
    @asynccontextmanager
    async def lifespan(_: FastAPI) -> AsyncIterator[None]:
        from core.storage.engine import normalized_engine
        from core.storage.migration import migrate_legacy_state
        engine = await run_blocking(normalized_engine, timeout=60)
        await run_blocking(engine.ensure_schema, timeout=60)
        await run_blocking(migrate_legacy_state, engine, timeout=60)
        # Fail closed before serving authenticated financial actions.
        _session_secret()
        try:
            yield
        finally:
            await drain_background_tasks(timeout=3)
            from core.connection_limits import close_connection_limit_client
            from core.shared_cache import close_shared_cache
            for cleanup in (close_connection_limit_client, close_shared_cache):
                try:
                    async with asyncio.timeout(3):
                        await cleanup()
                except Exception:
                    logger.exception("Mini App Redis client cleanup failed")

    app = FastAPI(
        title="SENTINEL Mini App API", version=str(getattr(SETTINGS, "release_version", "8.3.6-rc1")), docs_url=None,
        redoc_url=None, openapi_url=None, lifespan=lifespan,
    )
    app.add_middleware(GZipMiddleware, minimum_size=1024, compresslevel=6)

    webhook_path = "/" + str(getattr(SETTINGS, "webhook_path", "telegram") or "telegram").strip("/")
    always_available_paths = {"/health", "/healthz", "/livez", "/ready", "/readyz", "/metrics", webhook_path}

    @app.middleware("http")
    async def security_headers(request: Request, call_next: Callable[..., Any]) -> Response:
        request.state.request_id = _request_id(request)
        correlation_token = set_correlation_id(request.state.request_id)
        started = time.monotonic()
        try:
            # WEBAPP_API_ENABLED is a real kill switch, not only a validation
            # hint. Health/metrics and Telegram webhook remain available so the
            # service can stay observable and the bot can keep receiving updates.
            webapp_enabled = bool(getattr(SETTINGS, "webapp_api_enabled", True))
            if not webapp_enabled and request.url.path not in always_available_paths:
                if request.url.path.startswith("/api/"):
                    response = JSONResponse(
                        _error_payload(
                            "NOT_FOUND",
                            request_id=request.state.request_id,
                            language=_language(request),
                        ),
                        status_code=404,
                        headers={"Cache-Control": "no-store"},
                    )
                else:
                    response = PlainTextResponse("Not found", status_code=404)
            else:
                response = await call_next(request)
        finally:
            reset_correlation_id(correlation_token)
        route = request.scope.get("route")
        route_path = str(getattr(route, "path", request.url.path))
        api_request(route_path, request.method, int(response.status_code), time.monotonic() - started)
        response.headers.setdefault("X-Content-Type-Options", "nosniff")
        response.headers.setdefault("Referrer-Policy", "no-referrer")
        response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        response.headers.setdefault("Cross-Origin-Opener-Policy", "same-origin-allow-popups")
        response.headers.setdefault("Cross-Origin-Resource-Policy", "same-origin")
        if _is_production():
            response.headers.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        response.headers["X-Request-ID"] = request.state.request_id
        if not request.url.path.startswith("/api/"):
            response.headers.setdefault(
                "Content-Security-Policy",
                "default-src 'self'; script-src 'self' https://telegram.org; style-src 'self' 'unsafe-inline'; "
                "img-src 'self' data: blob: https:; media-src 'self' blob:; connect-src 'self'; worker-src 'self'; manifest-src 'self'; "
                "frame-ancestors https://web.telegram.org https://*.telegram.org https://t.me; base-uri 'none'; form-action 'self'",
            )
        return response

    @app.exception_handler(HTTPException)
    async def http_error(request: Request, exc: HTTPException) -> JSONResponse:
        code = str(exc.detail or "TEMPORARILY_UNAVAILABLE")
        return JSONResponse(
            _error_payload(code, request_id=request.state.request_id, language=_language(request)),
            status_code=exc.status_code,
            headers={"Cache-Control": "no-store", "X-Request-ID": request.state.request_id},
        )

    @app.exception_handler(ValueError)
    async def value_error(request: Request, exc: ValueError) -> JSONResponse:
        code = str(exc).split(":", 1)[0] or "INVALID_REQUEST"
        logger.info("Domain validation failed code=%s request_id=%s", code, request.state.request_id)
        return JSONResponse(
            _error_payload(code, request_id=request.state.request_id, language=_language(request)),
            status_code=400,
            headers={"Cache-Control": "no-store", "X-Request-ID": request.state.request_id},
        )

    @app.exception_handler(PermissionError)
    async def permission_error(request: Request, exc: PermissionError) -> JSONResponse:
        supplied = str(exc).split(":", 1)[0].strip()
        known = set(_ERROR_MESSAGES.get("fa", {})) | set(_ERROR_MESSAGES.get("en", {}))
        code = supplied if supplied in known else "FORBIDDEN"
        logger.info("Permission denied code=%s request_id=%s", code, request.state.request_id)
        return JSONResponse(
            _error_payload(code, request_id=request.state.request_id, language=_language(request)),
            status_code=403,
            headers={"Cache-Control": "no-store", "X-Request-ID": request.state.request_id},
        )

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception) -> JSONResponse:
        logger.exception("Mini App API failed request_id=%s", request.state.request_id)
        return JSONResponse(
            _error_payload("TEMPORARILY_UNAVAILABLE", request_id=request.state.request_id, language=_language(request)),
            status_code=503,
            headers={"Cache-Control": "no-store", "X-Request-ID": request.state.request_id},
        )

    @app.get("/health")
    @app.get("/healthz")
    @app.get("/livez")
    async def health() -> dict[str, Any]:
        from core.observability import liveness_snapshot
        return liveness_snapshot()

    @app.get("/ready")
    @app.get("/readyz")
    async def ready() -> Response:
        from core.observability import readiness_snapshot
        try:
            payload = await run_blocking(readiness_snapshot, timeout=3, acquire_timeout=1)
        except TimeoutError:
            payload = {"status": "degraded", "ready": False, "checks": {"readiness_probe": False}}
        return JSONResponse(payload, status_code=200 if payload.get("ready") else 503)

    @app.get("/metrics")
    async def metrics(authorization: str = Header(default="")) -> Response:
        from core.observability import prometheus_text
        token = os.getenv("METRICS_TOKEN", "").strip()
        if not token or not authorization.startswith("Bearer ") or not secrets.compare_digest(authorization[7:].strip(), token):
            raise HTTPException(status_code=403, detail="FORBIDDEN")
        return PlainTextResponse(await run_blocking(prometheus_text, timeout=3, acquire_timeout=1), media_type="text/plain; version=0.0.4")

    @app.post(webhook_path, include_in_schema=False)
    async def telegram_webhook(request: Request) -> Response:
        if str(getattr(SETTINGS, "run_mode", "polling")) != "webhook":
            raise HTTPException(status_code=404, detail="NOT_FOUND")
        supplied = str(request.headers.get("X-Telegram-Bot-Api-Secret-Token") or "")
        expected = str(getattr(SETTINGS, "webhook_secret_token", "") or "")
        if not supplied or not expected or not secrets.compare_digest(supplied, expected):
            raise HTTPException(status_code=403, detail="FORBIDDEN")
        content_type = str(request.headers.get("content-type") or "").lower()
        if "application/json" not in content_type:
            raise HTTPException(status_code=415, detail="INVALID_REQUEST")
        raw = await request.body()
        if not raw or len(raw) > _MAX_TELEGRAM_UPDATE_BYTES:
            raise HTTPException(status_code=413, detail="INVALID_REQUEST")
        application, telegram_loop = _telegram_application()
        if (
            application is None
            or telegram_loop is None
            or not telegram_loop.is_running()
            or not bool(getattr(application, "running", False))
        ):
            raise HTTPException(status_code=503, detail="TEMPORARILY_UNAVAILABLE")
        try:
            payload = json.loads(raw)
            if not isinstance(payload, dict):
                raise ValueError("payload must be an object")
            update_id = int(payload.get("update_id"))
            if update_id < 0:
                raise ValueError("invalid update id")
        except (ValueError, TypeError, json.JSONDecodeError) as exc:
            raise HTTPException(status_code=400, detail="INVALID_REQUEST") from exc
        from core.telegram_update_store import UpdateReplayConflict, backlog, persist
        try:
            persistence_state = await run_blocking(persist, update_id, payload, timeout=5)
            queue_state = await run_blocking(backlog, timeout=5)
        except UpdateReplayConflict as exc:
            increment("telegram_webhook_replay_conflict_total")
            logger.warning("Telegram update replay conflict update_id=%s", update_id)
            raise HTTPException(status_code=409, detail="UPDATE_REPLAY_CONFLICT") from exc
        except Exception as exc:
            logger.exception("Telegram update could not be durably persisted update_id=%s", update_id)
            raise HTTPException(status_code=503, detail="TEMPORARILY_UNAVAILABLE") from exc
        increment(f"telegram_webhook_{persistence_state}_total")
        gauge("telegram_update_backlog", int(queue_state.get("pending") or 0))
        return _json({"ok": True, "duplicate": persistence_state == "duplicate"}, request_id=request.state.request_id)


    def _require_mt5_connector_enabled() -> None:
        if str(os.getenv("MT5_CONNECTOR_ENABLED", "true")).strip().lower() not in {"1", "true", "yes", "on"}:
            raise HTTPException(status_code=404, detail="MT5_CONNECTOR_DISABLED")

    @app.post("/api/v1/mt5/pair")
    async def mt5_pair(request: Request) -> Response:
        """Exchange a one-time pairing code for read-only connector credentials."""
        _require_mt5_connector_enabled()
        raw = await request.body()
        if not raw or len(raw) > 128_000:
            raise HTTPException(status_code=413, detail="CONNECTOR_PAYLOAD_TOO_LARGE")
        try:
            body = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError("INVALID_REQUEST") from exc
        if not isinstance(body, dict):
            raise ValueError("INVALID_REQUEST")
        code = str(body.pop("pairing_code", "") or body.pop("code", "")).strip()
        if not code:
            raise ValueError("PAIRING_CODE_INVALID")
        transport = _transport_audit_context(request)
        limiter_key = int(hashlib.sha256(str(transport.get("client_hash") or "anonymous").encode()).hexdigest()[:12], 16)
        if not await run_blocking(rate_limit_allow, limiter_key, "mt5_pair", 2.0, timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        from services.mt5_connector_service import pair_connector
        result = await run_blocking(pair_connector, code, body)
        return _json({"ok": True, "data": result}, request_id=request.state.request_id)

    async def _mt5_verified_request(
        request: Request,
        connector_id: str,
        device_token: str,
        timestamp: str,
        nonce: str,
        signature: str,
    ) -> tuple[dict[str, Any], bytes, dict[str, Any]]:
        _require_mt5_connector_enabled()
        raw = await request.body()
        try:
            payload = json.loads(raw)
        except json.JSONDecodeError as exc:
            raise ValueError("INVALID_REQUEST") from exc
        if not isinstance(payload, dict):
            raise ValueError("INVALID_REQUEST")
        from repositories.v2.mt5_connectors import MT5ConnectorRepository
        from services.mt5_connector_service import verify_connector_request
        connector = await run_blocking(
            verify_connector_request,
            MT5ConnectorRepository(),
            connector_id=connector_id,
            device_token=device_token,
            timestamp=timestamp,
            nonce=nonce,
            signature=signature,
            body=raw,
        )
        return connector, raw, payload

    @app.post("/api/v1/mt5/snapshot")
    async def mt5_snapshot(
        request: Request,
        connector_id: str = Header(default="", alias="X-Sentinel-Connector"),
        device_token: str = Header(default="", alias="X-Sentinel-Token"),
        timestamp: str = Header(default="", alias="X-Sentinel-Timestamp"),
        nonce: str = Header(default="", alias="X-Sentinel-Nonce"),
        signature: str = Header(default="", alias="X-Sentinel-Signature"),
    ) -> Response:
        connector, _raw, payload = await _mt5_verified_request(
            request, connector_id, device_token, timestamp, nonce, signature,
        )
        from services.mt5_connector_service import ingest_snapshot
        result = await run_blocking(ingest_snapshot, connector, payload)
        return _json({"ok": True, "data": result}, request_id=request.state.request_id)

    @app.post("/api/v1/mt5/event")
    async def mt5_event(
        request: Request,
        connector_id: str = Header(default="", alias="X-Sentinel-Connector"),
        device_token: str = Header(default="", alias="X-Sentinel-Token"),
        timestamp: str = Header(default="", alias="X-Sentinel-Timestamp"),
        nonce: str = Header(default="", alias="X-Sentinel-Nonce"),
        signature: str = Header(default="", alias="X-Sentinel-Signature"),
    ) -> Response:
        connector, _raw, payload = await _mt5_verified_request(
            request, connector_id, device_token, timestamp, nonce, signature,
        )
        from services.mt5_connector_service import record_connector_event
        result = await run_blocking(record_connector_event, connector, payload)
        return _json({"ok": True, "data": result}, request_id=request.state.request_id)

    @app.post("/api/v1/auth/bootstrap")
    async def bootstrap(request: Request, x_telegram_init_data: str = Header(default="")) -> Response:
        transport = _transport_audit_context(request)
        transport_material = f"{transport.get('client_hash') or 'anonymous'}|{hashlib.sha256(x_telegram_init_data.encode()).hexdigest()[:16]}"
        transport_key = int(hashlib.sha256(transport_material.encode()).hexdigest()[:12], 16)
        identity = validate_init_data(x_telegram_init_data, str(getattr(SETTINGS, "bot_token", "")), max_age_seconds=_INIT_MAX_AGE)
        if not await run_blocking(_miniapp_access_allowed, identity.user_id, timeout=5):
            raise HTTPException(status_code=503, detail="MINIAPP_DISABLED")
        # A reload may reuse the same Telegram query_id while the signed,
        # HttpOnly SENTINEL session is still valid. Reuse only a session that
        # belongs to the identity Telegram just authenticated; this keeps
        # bootstrap idempotent without allowing a cross-account cookie reuse.
        try:
            session_identity, session_payload = _request_identity(request)
        except HTTPException:
            session_identity, session_payload = None, {}
        if session_identity is not None and session_identity.user_id == identity.user_id:
            return _json(
                {
                    "user_id": identity.user_id,
                    "csrf_token": str(session_payload.get("csrf") or ""),
                    "expires_in": max(0, int(session_payload.get("exp") or 0) - int(time.time())),
                    "resumed": True,
                },
                request_id=request.state.request_id,
            )
        if not await run_blocking(rate_limit_allow, transport_key, "miniapp_bootstrap_transport", float(os.getenv("SESSION_BOOTSTRAP_TRANSPORT_COOLDOWN_SECONDS", "0.2") or 0.2), timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        if not await run_blocking(rate_limit_allow, identity.user_id, "miniapp_session_bootstrap", float(os.getenv("SESSION_BOOTSTRAP_COOLDOWN_SECONDS", "1.5") or 1.5), timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        from core.initdata_replay import consume as consume_initdata
        replay_fingerprint = identity.query_id or hashlib.sha256(x_telegram_init_data.encode()).hexdigest()
        replay_ok = await run_blocking(
            consume_initdata, replay_fingerprint, client_hash=str(transport.get("client_hash") or ""),
            ttl_seconds=_INIT_MAX_AGE, timeout=5,
        )
        if not replay_ok:
            raise HTTPException(status_code=409, detail="INIT_DATA_REPLAYED")
        token, csrf = _session_token(identity)
        response = _json(
            {"ok": True, "data": {"user_id": identity.user_id, "csrf_token": csrf, "expires_in": _SESSION_TTL}},
            request_id=request.state.request_id,
        )
        response.set_cookie(
            _SESSION_COOKIE,
            token,
            max_age=_SESSION_TTL,
            httponly=True,
            secure=True,
            samesite="none",
            path="/",
        )
        return response

    @app.get("/api/v1/auth/session")
    async def auth_session(request: Request) -> Response:
        """Resume an unexpired signed session when Telegram keeps the WebView."""
        identity, payload = _request_identity(request)
        if not await run_blocking(_miniapp_access_allowed, identity.user_id, timeout=5):
            raise HTTPException(status_code=503, detail="MINIAPP_DISABLED")
        return _json(
            {
                "user_id": identity.user_id,
                "csrf_token": str(payload.get("csrf") or ""),
                "expires_in": max(0, int(payload.get("exp") or 0) - int(time.time())),
                "resumed": True,
            },
            request_id=request.state.request_id,
        )

    @app.post("/api/v1/auth/logout")
    async def logout(request: Request) -> Response:
        try:
            identity = await auth(request)
            if not await run_blocking(rate_limit_allow, identity.user_id, "miniapp_logout", 0.5, timeout=5):
                raise HTTPException(status_code=429, detail="RATE_LIMITED")
        except HTTPException as exc:
            if exc.status_code != 401:
                raise
        response = _json({"ok": True, "data": {"logged_out": True}}, request_id=request.state.request_id)
        response.delete_cookie(_SESSION_COOKIE, path="/", secure=True, httponly=True, samesite="none")
        return response

    async def auth(request: Request) -> TelegramWebAppIdentity:
        identity = _request_identity(request)[0]
        if not await run_blocking(_miniapp_access_allowed, identity.user_id, timeout=5):
            raise HTTPException(status_code=503, detail="MINIAPP_DISABLED")
        return identity

    async def csrf(request: Request) -> TelegramWebAppIdentity:
        _validate_same_origin(request)
        identity, payload = _request_identity(request)
        if not await run_blocking(_miniapp_access_allowed, identity.user_id, timeout=5):
            raise HTTPException(status_code=503, detail="MINIAPP_DISABLED")
        supplied = str(request.headers.get("X-CSRF-Token") or "")
        if not supplied or not secrets.compare_digest(supplied, str(payload.get("csrf") or "")):
            raise HTTPException(status_code=403, detail="CSRF_INVALID")
        return identity

    @app.get("/api/v1/overview")
    async def api_overview(request: Request) -> Response:
        return _json(await run_blocking(v2.overview, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/signals")
    async def api_signals(request: Request, cursor: str = "", limit: int = 20, status: str = "", market: str = "", scope: str = "", q: str = "", live: bool = False) -> Response:
        return _json(await run_blocking(v2.signals, await auth(request), cursor=cursor, limit=limit, status=status, market=market, scope=scope, query=q, live=live), request_id=request.state.request_id)

    @app.get("/api/v1/signals/{signal_id}")
    async def api_signal(request: Request, signal_id: str, account_id: str | None = None, live: bool = False) -> Response:
        return _json(await run_blocking(v2.signal_detail, await auth(request), signal_id, account_id=account_id, live=live), request_id=request.state.request_id)

    @app.get("/api/v1/signals/{signal_id}/chart")
    async def api_signal_chart(request: Request, signal_id: str) -> Response:
        identity = await auth(request)
        from repositories.v2.signals import SignalRepository
        signal = await run_blocking(SignalRepository().get, signal_id)
        if not signal or not v2._visible_signal(signal, v2._safe_shell(identity)["vip_active"]):
            raise HTTPException(status_code=404, detail="SIGNAL_NOT_FOUND")
        chart_photo_file_id = str(signal.get("chart_photo_file_id") or "").strip()
        if not chart_photo_file_id:
            raise HTTPException(status_code=404, detail="SIGNAL_CHART_NOT_FOUND")
        application, _ = _telegram_application()
        if application is None:
            raise HTTPException(status_code=503, detail="TELEGRAM_RUNTIME_UNAVAILABLE")
        telegram_file = await _run_on_telegram_loop(application.bot.get_file(chart_photo_file_id))
        if telegram_file is None:
            raise HTTPException(status_code=503, detail="TELEGRAM_FILE_UNAVAILABLE")
        payload = bytes(await _run_on_telegram_loop(telegram_file.download_as_bytearray()))
        media_type = str(getattr(telegram_file, "mime_type", "") or "")
        if not media_type:
            suffix = str(getattr(telegram_file, "file_path", "") or "").lower()
            if suffix.endswith('.png'):
                media_type = 'image/png'
            elif suffix.endswith('.webp'):
                media_type = 'image/webp'
            else:
                media_type = 'image/jpeg'
        return Response(content=payload, media_type=media_type, headers={
            "Cache-Control": "private, max-age=120",
            "Content-Disposition": f'inline; filename="signal-chart-{signal_id}"',
            "X-Content-Type-Options": "nosniff",
        })

    @app.get("/api/v1/signals/{signal_id}/result-chart")
    async def api_signal_result_chart(request: Request, signal_id: str) -> Response:
        identity = await auth(request)
        from repositories.v2.signals import SignalRepository
        signal = await run_blocking(SignalRepository().get, signal_id)
        if not signal or not v2._visible_signal(signal, v2._safe_shell(identity)["vip_active"]):
            raise HTTPException(status_code=404, detail="SIGNAL_NOT_FOUND")
        photo_file_id = str(signal.get("result_chart_photo_file_id") or "").strip()
        if not photo_file_id:
            raise HTTPException(status_code=404, detail="SIGNAL_RESULT_CHART_NOT_FOUND")
        application, _ = _telegram_application()
        if application is None:
            raise HTTPException(status_code=503, detail="TELEGRAM_RUNTIME_UNAVAILABLE")
        telegram_file = await _run_on_telegram_loop(application.bot.get_file(photo_file_id))
        if telegram_file is None:
            raise HTTPException(status_code=503, detail="TELEGRAM_FILE_UNAVAILABLE")
        payload = bytes(await _run_on_telegram_loop(telegram_file.download_as_bytearray()))
        media_type = str(getattr(telegram_file, "mime_type", "") or "")
        if not media_type:
            suffix = str(getattr(telegram_file, "file_path", "") or "").lower()
            media_type = "image/png" if suffix.endswith(".png") else "image/webp" if suffix.endswith(".webp") else "image/jpeg"
        return Response(content=payload, media_type=media_type, headers={
            "Cache-Control": "private, max-age=120",
            "Content-Disposition": f'inline; filename="signal-result-chart-{signal_id}"',
            "X-Content-Type-Options": "nosniff",
        })

    @app.get("/api/v1/signals/{signal_id}/replay")
    async def api_signal_replay(request: Request, signal_id: str) -> Response:
        return _json(await run_blocking(v2.signal_replay_detail, await auth(request), signal_id), request_id=request.state.request_id)

    @app.get("/api/v1/signals/{signal_id}/share-card")
    async def api_signal_share_card(request: Request, signal_id: str) -> Response:
        return _json(await run_blocking(v2.signal_share_card_detail, await auth(request), signal_id), request_id=request.state.request_id)

    @app.get("/api/v1/risk")
    async def api_risk(request: Request, account_id: str | None = None) -> Response:
        return _json(await run_blocking(v2.risk, await auth(request), account_id=account_id), request_id=request.state.request_id)

    @app.get("/api/v1/journal")
    async def api_journal(request: Request, cursor: str = "", limit: int = 30, status: str = "", symbol: str = "", q: str = "") -> Response:
        return _json(await run_blocking(v2.journal, await auth(request), cursor=cursor, limit=limit, status=status, symbol=symbol, query=q), request_id=request.state.request_id)

    @app.get("/api/v1/journal/export.pdf")
    async def api_journal_pdf(
        request: Request, lang: str = "fa", account_id: str = "", status: str = "",
        date_from: str = "", date_to: str = "",
    ) -> Response:
        identity = await auth(request)
        if not await run_blocking(rate_limit_allow, identity.user_id, "miniapp_journal_pdf", 30.0, timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        from services.journal_pdf_service import build_journal_pdf
        payload = await run_blocking(
            build_journal_pdf, identity.user_id, language=lang, account_id=account_id,
            status=status, date_from=date_from, date_to=date_to,
        )
        filename = f"sentinel-journal-{identity.user_id}.pdf"
        return Response(content=payload, media_type="application/pdf", headers={
            "Content-Disposition": f'attachment; filename="{filename}"',
            "Cache-Control": "no-store",
        })

    @app.get("/api/v1/contests")
    async def api_contests(request: Request) -> Response:
        return _json(await run_blocking(v2.contests, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/contests/{kind}/image")
    async def api_contest_image(request: Request, kind: str) -> Response:
        identity = await auth(request)
        photo_file_id = await run_blocking(v2.contest_image_file_id, identity, kind)
        if not photo_file_id:
            raise HTTPException(status_code=404, detail="CONTEST_IMAGE_NOT_FOUND")
        application, _ = _telegram_application()
        if application is None:
            raise HTTPException(status_code=503, detail="TELEGRAM_RUNTIME_UNAVAILABLE")
        telegram_file = await _run_on_telegram_loop(application.bot.get_file(photo_file_id))
        if telegram_file is None:
            raise HTTPException(status_code=503, detail="TELEGRAM_FILE_UNAVAILABLE")
        payload = bytes(await _run_on_telegram_loop(telegram_file.download_as_bytearray()))
        media_type = str(getattr(telegram_file, "mime_type", "") or "")
        if not media_type:
            suffix = str(getattr(telegram_file, "file_path", "") or "").lower()
            media_type = "image/png" if suffix.endswith(".png") else "image/webp" if suffix.endswith(".webp") else "image/jpeg"
        return Response(content=payload, media_type=media_type, headers={
            "Cache-Control": "private, max-age=60",
            "Content-Disposition": f'inline; filename="contest-{kind}"',
            "X-Content-Type-Options": "nosniff",
        })

    @app.get("/api/v1/market")
    async def api_market(request: Request, live: bool = False) -> Response:
        return _json(await run_blocking(v2.market, await auth(request), live=live), request_id=request.state.request_id)

    @app.get("/api/v1/market/quote")
    async def api_market_quote(request: Request, symbol: str = Query(..., min_length=2, max_length=32), live: bool = True) -> Response:
        identity = await auth(request)
        if not await run_blocking(rate_limit_allow, identity.user_id, "miniapp_live_quote", 1.0, timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        from services.live_market_service import live_quote_snapshot
        return _json(await run_blocking(live_quote_snapshot, symbol, force=live), request_id=request.state.request_id)

    async def iran_equity_admin(request: Request, bucket: str):
        identity = await auth(request)
        from services.setup_review_service import can_review_setups
        if not await run_blocking(can_review_setups,identity.user_id,timeout=5):
            raise HTTPException(status_code=403,detail='FORBIDDEN')
        if not await run_blocking(rate_limit_allow,identity.user_id,bucket,2.0,timeout=5):
            raise HTTPException(status_code=429,detail='RATE_LIMITED')
        return identity

    @app.get('/api/v1/admin/iran-equities/search')
    async def api_iran_equities_search(request: Request,q: str=Query(...,min_length=2,max_length=40)) -> Response:
        await iran_equity_admin(request,'iran_equity_search')
        from services.iran_equity_service import IranEquityUnavailable,search_instruments
        try:
            result=await search_instruments(q)
        except ValueError:
            raise HTTPException(status_code=400,detail='IR_EQUITY_QUERY_INVALID') from None
        except IranEquityUnavailable:
            raise HTTPException(status_code=503,detail='TSETMC_SOURCE_UNAVAILABLE') from None
        return _json(result,request_id=request.state.request_id)

    @app.get('/api/v1/admin/iran-equities/chart')
    async def api_iran_equities_chart(request: Request,ins_code: str=Query(...,min_length=1,max_length=20),
                                     limit: int=Query(300,ge=1,le=500),before_ms: int | None=None,timeframe: str='1d') -> Response:
        await iran_equity_admin(request,'iran_equity_chart')
        from services.iran_equity_service import IranEquityUnavailable,equity_chart
        try:
            result=await equity_chart(ins_code,limit=limit,before_ms=before_ms,timeframe=timeframe)
        except ValueError:
            raise HTTPException(status_code=400,detail='IR_EQUITY_REQUEST_INVALID') from None
        except IranEquityUnavailable as exc:
            code=str(exc)
            if code=='IR_CASH_EQUITY_REQUIRED':
                raise HTTPException(status_code=422,detail=code) from None
            if code in {'IR_EQUITY_CLASSIFICATION_UNVERIFIED','IR_EQUITY_IDENTITY_MISMATCH','IR_EQUITY_INTRADAY_INCOMPLETE'}:
                raise HTTPException(status_code=503,detail=code) from None
            raise HTTPException(status_code=503,detail='TSETMC_SOURCE_UNAVAILABLE') from None
        return _json(result,request_id=request.state.request_id)

    @app.get('/api/v1/market/universe')
    async def api_market_universe(request: Request) -> Response:
        await auth(request)
        from services.canonical_market_service import universe
        return _json(await universe(), request_id=request.state.request_id)

    @app.get('/api/v1/market/chart')
    async def api_market_chart(request: Request, symbol: str = Query(...,min_length=2,max_length=24),
                               timeframe: str = '5m', limit: int = Query(300,ge=1,le=500),
                               before_ms: int | None = None, provider: str | None = None) -> Response:
        identity = await auth(request)
        if not await run_blocking(rate_limit_allow,identity.user_id,'canonical_chart',0.5,timeout=5):
            raise HTTPException(status_code=429,detail='RATE_LIMITED')
        from services.canonical_market_service import MarketUnavailable, chart_history
        try:
            data = await chart_history(symbol,timeframe,limit=limit,before_ms=before_ms,provider=provider)
        except MarketUnavailable as exc:
            return JSONResponse({'state':'UNAVAILABLE','bars':[],'reason':str(exc)},status_code=503)
        return _json(data,request_id=request.state.request_id)

    @app.get('/api/v1/market/reference')
    async def api_market_reference(request: Request,symbol: str=Query('XAUUSD',min_length=6,max_length=6),provider: str | None=None) -> Response:
        identity=await auth(request)
        if not await run_blocking(rate_limit_allow,identity.user_id,'market_reference',1.0,timeout=5):
            raise HTTPException(status_code=429,detail='RATE_LIMITED')
        from services.market_reference_service import gold_reference
        if symbol.upper() not in {'XAUUSD','XAGUSD'} or provider not in {None,'gold_api','goldpricetoday_ir'}:
            raise HTTPException(status_code=400,detail='REFERENCE_SOURCE_OR_SYMBOL_INVALID')
        try:
            data=await gold_reference(symbol.upper(),provider=provider)
        except Exception:
            return JSONResponse({'state':'UNAVAILABLE','reason':'REFERENCE_SOURCES_UNAVAILABLE'},status_code=503)
        return _json(data,request_id=request.state.request_id)

    @app.get('/api/v1/market/setups')
    async def api_market_setups(request: Request,symbol: str = Query(...,min_length=2,max_length=24),timeframe: str='5m',admin: bool=False) -> Response:
        identity=await auth(request)
        from repositories.v2.setup_proposals import SetupRepository
        from services.setup_review_service import can_review_setups
        privileged=await run_blocking(can_review_setups,identity.user_id,timeout=5)
        if admin and not privileged:
            raise HTTPException(status_code=403,detail='FORBIDDEN')
        def read_overlays():
            repository=SetupRepository()
            rows=repository.list(symbol=symbol.upper(),timeframe=timeframe)
            if admin:return {'admin':True,'items':[{**row,'admin_events':repository.admin_events(row['id'])} for row in rows]}
            return {'admin':False,'items':[overlay for row in rows if (overlay:=repository.public_overlay(row['id']))]}
        return _json(await run_blocking(read_overlays,timeout=10),request_id=request.state.request_id)

    @app.get('/api/v1/market/analysis')
    async def api_market_analysis(request: Request,symbol: str = Query(...,min_length=2,max_length=24),timeframe: str='5m') -> Response:
        identity=await auth(request)
        from services.setup_review_service import can_review_setups
        if not await run_blocking(can_review_setups,identity.user_id,timeout=5):
            raise HTTPException(status_code=403,detail='FORBIDDEN')
        from services.strategy_analysis_service import research_analysis
        result=await research_analysis(symbol,timeframe)
        return _json(result,request_id=request.state.request_id)

    @app.get('/api/v1/market/readiness')
    async def api_market_readiness(request: Request,symbol: str='XAUUSD',timeframe: str='5m',stream_sample: bool=False) -> Response:
        identity=await auth(request)
        from services.setup_review_service import can_review_setups
        if not await run_blocking(can_review_setups,identity.user_id,timeout=5):
            raise HTTPException(status_code=403,detail='FORBIDDEN')
        if not await run_blocking(rate_limit_allow,identity.user_id,'market_readiness',5.0,timeout=5):
            raise HTTPException(status_code=429,detail='RATE_LIMITED')
        from services.strategy_readiness_service import inspect_market_readiness
        try:
            result=await inspect_market_readiness(symbol,timeframe)
            if stream_sample:
                from services.biquote_stream_check import sample_stream
                result={**result,'stream_probe':await sample_stream(result['symbol'])}
        except ValueError:
            raise HTTPException(status_code=400,detail='READINESS_MARKET_UNSUPPORTED') from None
        except Exception:
            raise HTTPException(status_code=503,detail='READINESS_INPUTS_UNAVAILABLE') from None
        return _json(result,request_id=request.state.request_id)

    @app.get('/api/v1/market/public-quotes')
    async def api_public_market_quotes(request: Request) -> Response:
        await auth(request)
        from services.public_fxcm_service import public_quotes
        try:
            result = await public_quotes()
        except (RuntimeError,ValueError):
            raise HTTPException(status_code=503,detail='PUBLIC_QUOTES_UNAVAILABLE') from None
        return _json(result,request_id=request.state.request_id)

    @app.get('/api/v1/market/feedback')
    async def api_strategy_feedback(request: Request,
                                    symbol: str | None = Query(None,min_length=2,max_length=24),
                                    timeframe: str | None = None,engine: str | None = None,
                                    limit: int = Query(500,ge=1,le=2000)) -> Response:
        identity = await auth(request)
        from services.strategy_feedback_service import strategy_feedback
        result = await run_blocking(strategy_feedback,identity.user_id,symbol=symbol,
                                    timeframe=timeframe,engine=engine,limit=limit,timeout=10)
        return _json(result,request_id=request.state.request_id)

    @app.get('/api/v1/market/reviews')
    async def api_strategy_reviews(request: Request,
                                   symbol: str | None = Query(None,min_length=2,max_length=24),
                                   timeframe: str | None = None,engine: str | None = None) -> Response:
        identity = await auth(request)
        from modules.canonical_market import ANALYSIS_TIMEFRAMES
        from modules.setup_lifecycle import ENGINES
        from services.strategy_review_queue_service import review_cases
        if timeframe and timeframe not in ANALYSIS_TIMEFRAMES or engine and engine not in ENGINES | {'market_data'}:
            raise ValueError('REVIEW_FILTER_INVALID')
        result = await run_blocking(review_cases,identity.user_id,symbol=symbol.upper() if symbol else None,
                                   timeframe=timeframe,engine=engine,timeout=10)
        return _json(result,request_id=request.state.request_id)

    @app.post('/api/v1/market/analyze')
    async def api_strategy_analyze_store(request: Request) -> Response:
        identity = await csrf(request)
        raw = await request.body()
        if len(raw) > 2000:
            raise HTTPException(status_code=413,detail='INVALID_REQUEST')
        try:
            body = json.loads(raw)
        except (ValueError,UnicodeDecodeError):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST') from None
        if not isinstance(body,dict) or set(body)-{'symbol','timeframe','profile_id','provider','venue','product'} or not isinstance(body.get('symbol'),str) or not 2 <= len(body['symbol']) <= 24 or not isinstance(body.get('timeframe','5m'),str) or body.get('timeframe','5m') not in {'5m','1h'} or body.get('profile_id') is not None and not isinstance(body['profile_id'],str):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST')
        for field in ('provider','venue','product'):
            if field in body and (not isinstance(body[field],str) or not 1 <= len(body[field]) <= 100):
                raise HTTPException(status_code=400,detail='INVALID_REQUEST')
        if 'provider' in body and body['provider'] not in {'biquote','yahoo','yahoo_fx','twelve_data','streamdata','okx','kraken','bybit','binance'}:
            raise HTTPException(status_code=400,detail='INVALID_REQUEST')
        from services.strategy_review_queue_service import analyze_and_store
        market_identity = {target:body[source] for source,target in
                           (('provider','provider'),('venue','expected_venue'),('product','expected_product')) if source in body}
        result = await analyze_and_store(identity.user_id,body['symbol'],body.get('timeframe','5m'),
                                         profile_id=body.get('profile_id'),**market_identity)
        return _json(result,request_id=request.state.request_id)

    @app.get('/api/v1/market/research-profiles')
    async def api_strategy_profiles(request: Request) -> Response:
        identity = await auth(request)
        from services.setup_review_service import can_review_setups
        if not await run_blocking(can_review_setups,identity.user_id,timeout=5):
            raise PermissionError('FORBIDDEN')
        from modules.strategy_experiments import research_profiles
        from modules.strategy_engines import Parameters
        from services.strategy_profile_service import profile_selection
        selection = await run_blocking(profile_selection,identity.user_id,timeout=5)
        return _json({'items':[{'profile_id':p.profile_id,'production_qualified':False} for p in research_profiles(Parameters())],
                      **selection},request_id=request.state.request_id)

    @app.post('/api/v1/market/research-profiles/select')
    async def api_select_research_profile(request: Request) -> Response:
        identity = await csrf(request)
        raw = await request.body()
        if len(raw) > 1000:
            raise HTTPException(status_code=413,detail='INVALID_REQUEST')
        try:
            body = json.loads(raw)
        except (ValueError,UnicodeDecodeError):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST') from None
        if not isinstance(body,dict) or set(body) != {'engine','profile_id'} or not all(isinstance(value,str) for value in body.values()):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST')
        from services.strategy_profile_service import select_profile
        return _json(await run_blocking(select_profile,identity.user_id,body['engine'],body['profile_id'],timeout=10),request_id=request.state.request_id)

    @app.post('/api/v1/market/setups/{setup_id}/approve')
    async def api_setup_approve(request: Request,setup_id: str) -> Response:
        identity=await csrf(request)
        from services.setup_review_service import approve_setup_event_live
        raw=await request.body()
        if len(raw)>32000:
            raise HTTPException(status_code=413,detail='INVALID_REQUEST')
        try:
            body=json.loads(raw)
        except (ValueError,UnicodeDecodeError):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST') from None
        if not isinstance(body,dict) or set(body)-{'version','event_id','audience'} or not isinstance(body.get('version'),int) or isinstance(body.get('version'),bool) or body.get('version',0)<1 or not isinstance(body.get('event_id','SIGNAL'),str) or not 1<=len(body.get('event_id','SIGNAL'))<=128 or not isinstance(body.get('audience','miniapp'),str) or body.get('audience','miniapp') not in {'miniapp','telegram_public','telegram_private'}:
            raise HTTPException(status_code=400,detail='INVALID_REQUEST')
        result=await approve_setup_event_live(identity.user_id,setup_id,body)
        return _json(result,request_id=request.state.request_id)

    @app.post('/api/v1/market/setups/{setup_id}/exit')
    async def api_setup_exit(request: Request,setup_id: str) -> Response:
        identity = await csrf(request)
        raw = await request.body()
        if len(raw) > 4000:
            raise HTTPException(status_code=413,detail='INVALID_REQUEST')
        try:
            body = json.loads(raw)
        except (ValueError,UnicodeDecodeError):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST') from None
        required = {'version','percentage_original','reference_price','reason','request_id'}
        if not isinstance(body,dict) or not required <= set(body) or set(body)-required-{'cost_in_initial_r'} or type(body.get('version')) is not int or not isinstance(body.get('reason'),str) or not isinstance(body.get('request_id'),str):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST')
        from services.setup_review_service import record_setup_exit
        return _json(await run_blocking(record_setup_exit,identity.user_id,setup_id,body,timeout=10),request_id=request.state.request_id)

    @app.post('/api/v1/market/setups/{setup_id}/cancel')
    async def api_cancel_pending_setup(request: Request,setup_id: str) -> Response:
        identity=await csrf(request)
        raw=await request.body()
        if len(raw)>4000:
            raise HTTPException(status_code=413,detail='INVALID_REQUEST')
        try:
            body=json.loads(raw)
        except (ValueError,UnicodeDecodeError):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST') from None
        if not isinstance(body,dict) or set(body)!={'version','reason','request_id'} or type(body.get('version')) is not int or not isinstance(body.get('reason'),str) or not isinstance(body.get('request_id'),str):
            raise HTTPException(status_code=400,detail='INVALID_REQUEST')
        from services.setup_review_service import cancel_pending_setup
        return _json(await run_blocking(cancel_pending_setup,identity.user_id,setup_id,body,timeout=10),request_id=request.state.request_id)

    @app.get("/api/v1/feed")
    async def api_feed(request: Request, limit: int = 50) -> Response:
        return _json(await run_blocking(v2.feed, await auth(request), limit=limit), request_id=request.state.request_id)

    @app.get("/api/v1/user-hub")
    async def api_user_hub(request: Request, cursor: int = Query(0, ge=0), limit: int = Query(20, ge=1, le=50)) -> Response:
        return _json(await run_blocking(v2.user_hub,await auth(request),cursor=cursor,limit=limit),request_id=request.state.request_id)

    @app.get("/api/v1/expansion")
    async def api_expansion(request: Request) -> Response:
        return _json(await run_blocking(v2.expansion, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/ai")
    async def api_ai_assistant(request: Request, limit: int = 30) -> Response:
        return _json(await run_blocking(v2.ai_assistant, await auth(request), limit=limit), request_id=request.state.request_id)

    @app.get("/api/v1/calendar")
    async def api_calendar(request: Request, cursor: str = "", limit: int = 40, currency: str = "", impact: str = "", q: str = "") -> Response:
        return _json(await run_blocking(v2.calendar, await auth(request), cursor=cursor, limit=limit, currency=currency, impact=impact, query=q), request_id=request.state.request_id)

    @app.get("/api/v1/orders")
    async def api_orders(request: Request, cursor: str = "", limit: int = 20, status: str = "", q: str = "") -> Response:
        return _json(await run_blocking(v2.orders, await auth(request), cursor=cursor, limit=limit, status=status, query=q), request_id=request.state.request_id)

    @app.get("/api/v1/orders/{order_id}")
    async def api_order(request: Request, order_id: str) -> Response:
        return _json(await run_blocking(v2.order, await auth(request), order_id), request_id=request.state.request_id)

    @app.get("/api/v1/orders/{order_id}/receipt")
    async def api_order_receipt(request: Request, order_id: str) -> Response:
        identity = await auth(request)
        detail = await run_blocking(v2.order, identity, order_id)
        receipt_id = str(detail.get("receipt_id") or detail.get("receipt_key") or "")
        if not receipt_id:
            receipt_meta = detail.get("receipt") if isinstance(detail.get("receipt"), dict) else {}
            receipt_id = str(receipt_meta.get("id") or "")
        if not receipt_id:
            raise HTTPException(status_code=404, detail="RECEIPT_NOT_FOUND")
        repository = CommerceRepository()
        record = await run_blocking(repository.get_receipt, identity.user_id, receipt_id)
        if not record:
            raise HTTPException(status_code=404, detail="RECEIPT_NOT_FOUND")
        from modules.receipt_storage import ReceiptStorageUnavailable, read_receipt_bytes
        try:
            payload = await run_blocking(read_receipt_bytes, record)
        except ReceiptStorageUnavailable as exc:
            raise HTTPException(status_code=503, detail="TEMPORARILY_UNAVAILABLE") from exc
        if payload is None:
            raise HTTPException(status_code=404, detail="RECEIPT_NOT_FOUND")
        mime = str(record.get("mime_type") or record.get("mime") or "image/webp").lower()
        if mime not in {"image/webp", "image/jpeg", "image/png"}:
            mime = "application/octet-stream"
        return Response(
            content=payload, media_type=mime,
            headers={"Cache-Control": "private, no-store", "Content-Disposition": f'inline; filename="receipt-{order_id}"', "X-Content-Type-Options": "nosniff"},
        )

    @app.get("/api/v1/tickets")
    async def api_tickets(request: Request, cursor: str = "", limit: int = 20, status: str = "", q: str = "") -> Response:
        return _json(await run_blocking(v2.tickets, await auth(request), cursor=cursor, limit=limit, status=status, query=q), request_id=request.state.request_id)

    @app.get("/api/v1/tickets/{ticket_id}")
    async def api_ticket(request: Request, ticket_id: str) -> Response:
        return _json(await run_blocking(v2.ticket, await auth(request), ticket_id), request_id=request.state.request_id)


    @app.post("/api/v1/support/attachments")
    async def api_support_attachment_upload(request: Request, file: UploadFile = File(...)) -> Response:
        identity = await csrf(request)
        if not await run_blocking(rate_limit_allow, identity.user_id, "support_attachment_upload", 2.0, timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        from core.db import with_db
        from modules.support_attachment_storage import MAX_SUPPORT_ATTACHMENT_BYTES, store_support_attachment
        payload = await file.read(MAX_SUPPORT_ATTACHMENT_BYTES + 1)
        if len(payload) > MAX_SUPPORT_ATTACHMENT_BYTES:
            raise HTTPException(status_code=413, detail="SUPPORT_ATTACHMENT_SIZE_INVALID")
        try:
            row = await run_blocking(
                with_db,
                lambda db: store_support_attachment(
                    db, identity.user_id, payload, file_name=str(file.filename or "attachment"),
                    mime_type=str(file.content_type or "application/octet-stream"),
                ),
            )
        except ValueError as exc:
            code = str(exc) or "SUPPORT_ATTACHMENT_INVALID"
            status = 413 if code == "SUPPORT_ATTACHMENT_SIZE_INVALID" else 415 if code == "SUPPORT_ATTACHMENT_TYPE_INVALID" else 400
            raise HTTPException(status_code=status, detail=code) from exc
        return _json(row, request_id=request.state.request_id)

    @app.get("/api/v1/support/attachments/{storage_id}")
    async def api_support_attachment_download(request: Request, storage_id: str) -> Response:
        identity = await auth(request)
        from core.db import with_db_read
        from modules.admin_access import PERMISSION_TICKET_ATTACHMENTS_VIEW, has_permission
        from modules.support_attachment_storage import attachment_record, read_support_attachment

        def resolve(db: dict[str, Any]) -> tuple[dict[str, Any] | None, bool]:
            row = attachment_record(db, storage_id)
            if not row:
                return None, False
            owner = str(row.get("owner_id") or "") == str(identity.user_id)
            ticket_owner = False
            ticket_id = row.get("ticket_id")
            if ticket_id not in {None, ""}:
                for ticket in db.get("support_tickets", []):
                    if isinstance(ticket, dict) and str(ticket.get("id")) == str(ticket_id):
                        ticket_owner = str(ticket.get("user_id")) == str(identity.user_id)
                        break
            return row, bool(owner or ticket_owner or has_permission(db, identity.user_id, PERMISSION_TICKET_ATTACHMENTS_VIEW))

        row, allowed = await run_blocking(with_db_read, resolve)
        if not row or not allowed:
            raise HTTPException(status_code=404, detail="SUPPORT_ATTACHMENT_NOT_FOUND")
        payload = await run_blocking(read_support_attachment, row)
        if payload is None:
            raise HTTPException(status_code=410, detail="SUPPORT_ATTACHMENT_UNAVAILABLE")
        safe_name = re.sub(r"[^A-Za-z0-9._-]+", "_", str(row.get("file_name") or "attachment"))[:180]
        return Response(content=payload, media_type=str(row.get("mime_type") or "application/octet-stream"), headers={
            "Content-Disposition": f'inline; filename="{safe_name}"', "Cache-Control": "private, max-age=300",
            "X-Content-Type-Options": "nosniff",
        })

    @app.get("/api/v1/track-record")
    async def api_track_record(request: Request, symbol: str = "", market: str = "", cursor: str = "", limit: int = 20) -> Response:
        return _json(await run_blocking(v2.track_record, await auth(request), symbol=symbol, market_filter=market, cursor=cursor, limit=limit), request_id=request.state.request_id)

    @app.get("/api/v1/revisions")
    async def api_revisions(request: Request, cursor: str = "", limit: int = 50, signal_id: str = "") -> Response:
        return _json(await run_blocking(v2.revisions, await auth(request), cursor=cursor, limit=limit, signal_id=signal_id or None), request_id=request.state.request_id)

    @app.get("/api/v1/search")
    async def api_search(request: Request, q: str = "", limit: int = 30) -> Response:
        return _json(await run_blocking(v2.global_search, await auth(request), q, limit=limit), request_id=request.state.request_id)

    @app.get("/api/v1/admin/operations")
    async def api_admin_operations(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_operations, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/platform")
    async def api_admin_platform(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_platform, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/capabilities")
    async def api_admin_capabilities(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_capabilities, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/signal-cycles")
    async def api_admin_signal_cycles(
        request: Request, cursor: int = 0, limit: int = 50,
    ) -> Response:
        return _json(
            await run_blocking(v2.admin_signal_cycles, await auth(request), cursor=cursor, limit=limit),
            request_id=request.state.request_id,
        )

    @app.get("/api/v1/admin/signal-cycles/{cycle_id}")
    async def api_admin_signal_cycle_detail(
        request: Request, cycle_id: int, cursor: int = 0, limit: int = 100,
    ) -> Response:
        return _json(
            await run_blocking(
                v2.admin_signal_cycle_detail, await auth(request), cycle_id, cursor=cursor, limit=limit,
            ),
            request_id=request.state.request_id,
        )

    @app.get("/api/v1/admin/signal-cycles/{cycle_id}/export.pdf")
    async def api_admin_signal_cycle_pdf(
        request: Request, cycle_id: int, lang: str = "fa",
    ) -> Response:
        identity = await auth(request)
        if not await run_blocking(rate_limit_allow, identity.user_id, "miniapp_signal_cycle_pdf", 15.0, timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        # Authorize against the same admin read contract before touching the PDF builder.
        await run_blocking(v2.admin_signal_cycle_detail, identity, cycle_id, cursor=0, limit=1)
        from core.db import with_db_read
        from services.signal_cycle_pdf_service import build_signal_cycle_pdf
        payload = await run_blocking(
            with_db_read, lambda db: build_signal_cycle_pdf(db, cycle_id, language=lang),
        )
        filename = f"sentinel-signal-period-{cycle_id}.pdf"
        return Response(
            content=payload,
            media_type="application/pdf",
            headers={
                "Content-Disposition": f'attachment; filename="{filename}"',
                "Cache-Control": "private, no-store",
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.get("/api/v1/admin/integration")
    async def api_admin_integration(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_integration, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/audit")
    async def api_admin_audit(request: Request, cursor: str = "", limit: int = 50, q: str = "", action: str = "") -> Response:
        return _json(await run_blocking(v2.admin_audit_logs, await auth(request), cursor=cursor, limit=limit, query=q, action=action), request_id=request.state.request_id)

    @app.get("/api/v1/admin/experiments")
    async def api_admin_experiments(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_experiments, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/experiments/{experiment_id}")
    async def api_admin_experiment(request: Request, experiment_id: str) -> Response:
        return _json(await run_blocking(v2.admin_experiment_detail, await auth(request), experiment_id), request_id=request.state.request_id)

    @app.get("/api/v1/admin/campaigns")
    async def api_admin_campaigns(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_campaigns, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/campaigns/{campaign_id}")
    async def api_admin_campaign(request: Request, campaign_id: str) -> Response:
        return _json(await run_blocking(v2.admin_campaign_detail, await auth(request), campaign_id), request_id=request.state.request_id)

    @app.get("/api/v1/admin/ai")
    async def api_admin_ai(request: Request, limit: int = 50) -> Response:
        return _json(await run_blocking(v2.admin_ai_center, await auth(request), limit=limit), request_id=request.state.request_id)

    @app.get("/api/v1/admin/vip-plans")
    async def api_admin_vip_plans(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_vip_plans, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/orders")
    async def api_admin_orders(request: Request, cursor: str = "", limit: int = 50, status: str = "", q: str = "") -> Response:
        return _json(
            await run_blocking(v2.admin_orders, await auth(request), cursor=cursor, limit=limit, status=status, query=q),
            request_id=request.state.request_id,
        )

    @app.get("/api/v1/admin/orders/{order_id}")
    async def api_admin_order(request: Request, order_id: str) -> Response:
        return _json(await run_blocking(v2.admin_order, await auth(request), order_id), request_id=request.state.request_id)

    @app.get("/api/v1/admin/orders/{order_id}/receipt")
    async def api_admin_order_receipt(request: Request, order_id: str) -> Response:
        identity = await auth(request)
        detail = await run_blocking(v2.admin_order, identity, order_id)
        receipt_meta = detail.get("receipt") if isinstance(detail.get("receipt"), dict) else None
        receipt_id = str((receipt_meta or {}).get("id") or "")
        if not receipt_id:
            raise HTTPException(status_code=404, detail="RECEIPT_NOT_FOUND")
        repository = CommerceRepository()
        record = await run_blocking(repository.get_receipt_admin, receipt_id)
        if not record:
            raise HTTPException(status_code=404, detail="RECEIPT_NOT_FOUND")
        from modules.receipt_storage import ReceiptStorageUnavailable, read_receipt_bytes
        try:
            payload = await run_blocking(read_receipt_bytes, record)
        except ReceiptStorageUnavailable as exc:
            raise HTTPException(status_code=503, detail="TEMPORARILY_UNAVAILABLE") from exc
        if payload is None:
            raise HTTPException(status_code=404, detail="RECEIPT_NOT_FOUND")
        mime = str(record.get("mime_type") or record.get("mime") or "image/webp").lower()
        if mime not in {"image/webp", "image/jpeg", "image/png"}:
            mime = "application/octet-stream"
        return Response(
            content=payload,
            media_type=mime,
            headers={
                "Cache-Control": "private, no-store",
                "Content-Disposition": f'inline; filename="receipt-{order_id}"',
                "X-Content-Type-Options": "nosniff",
            },
        )

    @app.get("/api/v1/admin/tickets")
    async def api_admin_tickets(
        request: Request, cursor: str = "", limit: int = 50, status: str = "", q: str = "",
        priority: str = "", assigned_admin: str = "", overdue_only: bool = False,
    ) -> Response:
        return _json(
            await run_blocking(
                v2.admin_tickets, await auth(request), cursor=cursor, limit=limit, status=status, query=q,
                priority=priority, assigned_admin=assigned_admin, overdue_only=overdue_only,
            ), request_id=request.state.request_id,
        )

    @app.get("/api/v1/admin/tickets/{ticket_id}")
    async def api_admin_ticket(request: Request, ticket_id: str) -> Response:
        return _json(await run_blocking(v2.admin_ticket, await auth(request), ticket_id), request_id=request.state.request_id)


    @app.get("/api/v1/admin/users")
    async def api_admin_users(request: Request, cursor: str = "", limit: int = 50, q: str = "", status: str = "") -> Response:
        return _json(await run_blocking(v2.admin_users, await auth(request), cursor=cursor, limit=limit, query=q, status=status), request_id=request.state.request_id)

    @app.get("/api/v1/admin/users/{user_id}")
    async def api_admin_user(request: Request, user_id: str) -> Response:
        return _json(await run_blocking(v2.admin_user, await auth(request), user_id), request_id=request.state.request_id)

    @app.get("/api/v1/admin/admins")
    async def api_admin_admins(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_delegated_admins, await auth(request)), request_id=request.state.request_id)

    @app.get("/api/v1/admin/signals")
    async def api_admin_signals(request: Request, cursor: str = "", limit: int = 50, status: str = "", q: str = "") -> Response:
        return _json(await run_blocking(v2.admin_signals, await auth(request), cursor=cursor, limit=limit, status=status, query=q), request_id=request.state.request_id)

    @app.get("/api/v1/admin/signals/{signal_id}")
    async def api_admin_signal(request: Request, signal_id: str) -> Response:
        return _json(await run_blocking(v2.admin_signal, await auth(request), signal_id), request_id=request.state.request_id)

    @app.get("/api/v1/admin/signal-jobs")
    async def api_admin_signal_jobs(request: Request, cursor: str = "", limit: int = 50, status: str = "", q: str = "") -> Response:
        return _json(await run_blocking(v2.admin_signal_jobs, await auth(request), cursor=cursor, limit=limit, status=status, query=q), request_id=request.state.request_id)

    @app.get("/api/v1/admin/signal-jobs/{job_id}")
    async def api_admin_signal_job(request: Request, job_id: str) -> Response:
        return _json(await run_blocking(v2.admin_signal_job, await auth(request), job_id), request_id=request.state.request_id)

    @app.get("/api/v1/admin/signal-templates")
    async def api_admin_signal_templates(request: Request) -> Response:
        return _json(await run_blocking(v2.admin_signal_templates, await auth(request)), request_id=request.state.request_id)

    @app.post("/api/v1/admin/signal-templates/background")
    async def api_admin_signal_template_upload(
        request: Request,
        side: str = Query(...),
        file: UploadFile = File(...),
    ) -> Response:
        identity = await csrf(request)
        payload = await file.read(_MAX_TEMPLATE_UPLOAD_READ)
        if await file.read(1):
            raise HTTPException(status_code=413, detail="TEMPLATE_SIZE_INVALID")
        result = await run_blocking(
            v2.admin_store_signal_template,
            identity,
            side,
            payload,
            original_name=str(file.filename or "template"),
        )
        return _json(result, request_id=request.state.request_id)

    @app.delete("/api/v1/admin/signal-templates/background")
    async def api_admin_signal_template_reset(request: Request, side: str = Query(...)) -> Response:
        result = await run_blocking(v2.admin_reset_signal_template, await csrf(request), side)
        return _json(result, request_id=request.state.request_id)

    @app.post("/api/v1/actions/{action}")
    async def api_action(request: Request, action: str) -> Response:
        identity = await csrf(request)
        body = await request.json()
        payload = body if isinstance(body, dict) else {}
        payload["action"] = action
        supplied_key = str(payload.get("request_id") or request.headers.get("Idempotency-Key") or "").strip()
        if supplied_key:
            payload["request_id"] = supplied_key
        started = time.monotonic()
        try:
            payload["_transport_request_id"] = request.state.request_id
            transport = _transport_audit_context(request)
            transport["source"] = "miniapp_human_action"
            if action in {
                "delegated_admin_approve", "delegated_admin_reject",
                "admin_ai_command_approve", "admin_ai_command_reject",
                "admin_ai_proposal_approve", "admin_ai_proposal_reject",
                "governance_request_approve", "governance_request_reject", "governance_request_apply",
                "ai_signal_draft_approve", "ai_signal_draft_reject",
            }:
                transport["human_confirmation"] = True
            payload["_transport_context"] = transport
            result = await run_blocking(handle_miniapp_action_for_identity, identity, payload)
        except Exception:
            action_result(action, ok=False, duration=time.monotonic() - started)
            raise
        action_result(action, ok=True, duration=time.monotonic() - started)
        try:
            await _after_action_telegram_sync(action, result, identity)
        except Exception:
            if supplied_key:
                from repositories.v2.idempotency import IdempotencyRepository
                await run_blocking(IdempotencyRepository().reset_completed, identity.user_id, supplied_key)
            raise
        if supplied_key and action == "payment_approve":
            from repositories.v2.idempotency import IdempotencyRepository
            await run_blocking(
                IdempotencyRepository().replace_completed_response,
                identity.user_id, supplied_key, response=result,
            )
        return _json(result, request_id=request.state.request_id)

    @app.post("/api/v1/checkout/quote")
    async def checkout_quote(request: Request) -> Response:
        identity = await csrf(request)
        body = await request.json()
        if not isinstance(body, dict):
            raise ValueError("INVALID_REQUEST")
        request_key = str(body.get("request_id") or request.headers.get("Idempotency-Key") or "").strip()
        if not request_key:
            raise ValueError("IDEMPOTENCY_KEY_REQUIRED")
        result = await run_blocking(
            handle_miniapp_action_for_identity,
            identity,
            {
                "action": "checkout_quote_create",
                "payload": body,
                "request_id": request_key,
                "_transport_request_id": request.state.request_id,
                "_transport_context": _transport_audit_context(request),
            },
        )
        return _json(result, request_id=request.state.request_id)

    @app.post("/api/v1/checkout/receipt")
    async def upload_receipt(
        request: Request,
        file: UploadFile = File(...),
    ) -> Response:
        identity = await csrf(request)
        if not await run_blocking(rate_limit_allow, identity.user_id, "receipt_upload", float(os.getenv("RECEIPT_UPLOAD_COOLDOWN_SECONDS", "5") or 5), timeout=5):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        repository = CommerceRepository()
        cutoff = time.time() - 3600
        from datetime import UTC, datetime
        usage = await run_blocking(repository.receipt_usage, identity.user_id, since_iso=datetime.fromtimestamp(cutoff, UTC).isoformat())
        if usage["count"] >= max(1, int(os.getenv("RECEIPT_MAX_UPLOADS_PER_HOUR", "10") or 10)):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        if usage["bytes"] >= max(1_000_000, int(os.getenv("RECEIPT_MAX_BYTES_PER_USER_PER_HOUR", str(25 * 1024 * 1024)) or 0)):
            raise HTTPException(status_code=429, detail="RATE_LIMITED")
        total_usage = await run_blocking(repository.receipt_usage, identity.user_id)
        if total_usage["available_bytes"] >= max(1_000_000, int(os.getenv("RECEIPT_MAX_AVAILABLE_BYTES_PER_USER", str(15 * 1024 * 1024)) or 0)):
            raise HTTPException(status_code=429, detail="RECEIPT_STORAGE_QUOTA_EXCEEDED")
        payload = await file.read(_MAX_UPLOAD_READ)
        if await file.read(1):
            raise HTTPException(status_code=413, detail="RECEIPT_SIZE_INVALID")
        temporary: dict[str, Any] = {"receipt_uploads": {}}
        normalized = await run_blocking(
            store_receipt_bytes,
            temporary,
            payload=payload,
            content_type=str(file.content_type or ""),
            user_id=identity.user_id,
            original_name=str(file.filename or "receipt"),
        )
        started = time.monotonic()
        try:
            result = await run_blocking(repository.create_receipt, identity.user_id, {
                **normalized,
                "id": normalized.get("receipt_id"),
                "mime_type": normalized.get("mime") or "image/webp",
            })
        except Exception:
            deleted = await run_blocking(delete_receipt_blob, normalized)
            if not deleted:
                logger.critical(
                    "Receipt upload failed after blob storage and orphan cleanup failed receipt_id=%s request_id=%s",
                    normalized.get("receipt_id"),
                    request.state.request_id,
                )
            action_result("receipt_upload", ok=False, duration=time.monotonic() - started)
            raise
        max_available = max(1, int(os.getenv("RECEIPT_MAX_AVAILABLE_PER_USER", "3") or 3))
        removed = await run_blocking(repository.prune_available_receipts, identity.user_id, keep=max_available, exclude_id=str(result.get("id") or ""))
        for stale in removed:
            deleted = await run_blocking(delete_receipt_blob, stale)
            logger.info(
                "receipt retention cleanup user_id=%s receipt_id=%s deleted=%s request_id=%s",
                identity.user_id, stale.get("id") or stale.get("receipt_id"), deleted, request.state.request_id,
            )
        action_result("receipt_upload", ok=True, duration=time.monotonic() - started)
        # User responses never expose absolute paths, buckets or internal storage metadata.
        public = {key: result.get(key) for key in ("id", "receipt_id", "status", "checksum", "mime_type", "size_bytes", "created_at")}
        return _json(public, request_id=request.state.request_id)

    @app.get("/api/v1/events")
    async def event_stream(
        request: Request,
        last_id: int = Query(default=0, ge=0),
        last_event_id: str = Header(default="", alias="Last-Event-ID"),
    ) -> Response:
        identity = await auth(request)
        try:
            header_cursor = max(0, int(str(last_event_id or "0").split("-", 1)[0]))
        except (TypeError, ValueError):
            header_cursor = 0
        source = EventStreamService()
        session_value = str(request.cookies.get(_SESSION_COOKIE) or "")
        rotate_seconds = max(15, min(300, int(os.getenv("SSE_ROTATE_SECONDS", "55") or 55)))
        lease = await acquire_connection_limits(
            (
                ("sse-user", str(identity.user_id), max(1, int(os.getenv("SSE_MAX_CONNECTIONS_PER_USER", "3") or 3))),
                ("sse-session", session_value, max(1, int(os.getenv("SSE_MAX_CONNECTIONS_PER_SESSION", "2") or 2))),
            ),
            # Include a blocking read and teardown margin. A live stream must
            # never lose its admission lease before its rotation deadline.
            ttl_seconds=max(rotate_seconds + 30, int(os.getenv("SSE_CONNECTION_TTL_SECONDS", "90") or 90)),
        )
        if lease is None:
            raise HTTPException(status_code=429, detail="RATE_LIMITED")

        async def generate() -> AsyncIterator[bytes]:
            cursor_value = max(int(last_id), header_cursor)
            stream_identity = identity
            started = time.monotonic()
            sse_connected(1)
            try:
                while not await request.is_disconnected() and time.monotonic() - started < rotate_seconds:
                    batch = await source.read(stream_identity.user_id, cursor_value, block_ms=12_000, limit=200)
                    try:
                        # Sessions, VIP grants and delegated roles may expire
                        # or be revoked while a read is waiting for events.
                        stream_identity = await auth(request)
                    except HTTPException as exc:
                        yield f"event: stream.auth_required\ndata: {json.dumps({'reason': str(exc.detail)})}\n\n".encode()
                        return
                    if batch.events:
                        access = await run_blocking(v2.access_context, stream_identity, timeout=5)
                        for row in batch.events:
                            sequence = int(row.get("sequence") or cursor_value)
                            cursor_value = max(cursor_value, sequence)
                            payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
                            access_tier = str(payload.get("access_tier") or "public").lower()
                            if access_tier == "vip" and not bool(access.get("vip_active") or access.get("is_admin")):
                                continue
                            event_name = str(row.get("event_type") or "message")
                            yield f"id: {sequence}\nevent: {event_name}\ndata: {json.dumps(row, ensure_ascii=False, default=str)}\n\n".encode()
                    else:
                        yield b": keepalive\n\n"
                yield f"event: stream.rotate\ndata: {json.dumps({'cursor': cursor_value})}\n\n".encode()
            finally:
                sse_connected(-1)
                await lease.release()
        return StreamingResponse(generate(), media_type="text/event-stream", headers={
            "Cache-Control": "no-cache, no-store", "X-Accel-Buffering": "no", "Connection": "keep-alive"
        })

    # The pre-v1 dashboard/action endpoints were removed in v8.0.
    # All clients must use the authenticated, versioned /api/v1 contract.

    @app.api_route("/api/dashboard", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    @app.api_route("/api/action", methods=["GET", "POST", "PUT", "PATCH", "DELETE"])
    async def removed_legacy_api(request: Request) -> Response:
        return _json({"ok": False, "error": {"code": "API_GONE", "message": "Use /api/v1 endpoints", "request_id": request.state.request_id}}, request_id=request.state.request_id, status=410)

    @app.api_route("/api/{unknown_path:path}", methods=["GET", "POST", "PUT", "PATCH", "DELETE", "OPTIONS"])
    async def unknown_api(request: Request, unknown_path: str) -> Response:
        return _json({"ok": False, "error": {"code": "API_NOT_FOUND", "message": "Unknown API endpoint", "request_id": request.state.request_id}}, request_id=request.state.request_id, status=404)

    @app.get("/{path:path}")
    async def static(request: Request, path: str = "") -> Response:
        file_path = _static_path(path)
        if not file_path:
            raise HTTPException(status_code=404, detail="NOT_FOUND")
        media, _ = mimetypes.guess_type(file_path.name)
        response = FileResponse(file_path, media_type=media)
        if file_path.name in {"index.html", "sw.js", "manifest.webmanifest"}:
            response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        elif re.search(r"\.[0-9a-f]{8,}\.", file_path.name):
            response.headers["Cache-Control"] = "public, max-age=31536000, immutable"
        else:
            response.headers["Cache-Control"] = "public, max-age=3600, must-revalidate"
        return response

    return app


_MAX_UPLOAD_READ = 5_000_000
_MAX_TEMPLATE_UPLOAD_READ = 12 * 1024 * 1024


def start(host: str, port: int) -> None:
    global _SERVER, _THREAD
    if not port or _SERVER is not None:
        return
    app = create_app()
    trusted_proxies = str(os.getenv("TRUSTED_PROXY_IPS") or "127.0.0.1").strip()
    config = uvicorn.Config(
        app,
        host=host,
        port=int(port),
        log_level="info",
        access_log=False,
        proxy_headers=True,
        forwarded_allow_ips=trusted_proxies,
    )
    server = uvicorn.Server(config)
    thread = threading.Thread(target=server.run, name="sentinel-miniapp-fastapi", daemon=True)
    _SERVER = server
    _THREAD = thread
    thread.start()
    deadline = time.monotonic() + max(1.0, float(os.getenv("HTTP_STARTUP_TIMEOUT_SECONDS", "15") or 15))
    while time.monotonic() < deadline:
        if bool(getattr(server, "started", False)):
            logger.info("SENTINEL FastAPI Mini App listening on %s:%s", host, port)
            return
        if not thread.is_alive():
            _SERVER = None
            _THREAD = None
            raise RuntimeError("FastAPI health/Mini App server failed during startup")
        time.sleep(0.05)
    server.should_exit = True
    thread.join(timeout=3)
    _SERVER = None
    _THREAD = None
    raise RuntimeError("FastAPI health/Mini App server did not become ready before startup timeout")


def is_running() -> bool:
    """Return whether the unified FastAPI/health server thread is alive."""
    thread = _THREAD
    server = _SERVER
    return bool(
        thread is not None
        and thread.is_alive()
        and server is not None
        and bool(getattr(server, "started", False))
        and not bool(getattr(server, "should_exit", False))
    )


def stop() -> None:
    global _SERVER, _THREAD
    if _SERVER is not None:
        _SERVER.should_exit = True
    if _THREAD is not None:
        _THREAD.join(timeout=5)
    _SERVER = None
    _THREAD = None
