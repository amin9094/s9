from __future__ import annotations

import asyncio
import logging
import secrets
import threading
import time
import math
from dataclasses import dataclass
from typing import Any
from urllib.parse import urlparse
from weakref import WeakKeyDictionary

import httpx

from config import SETTINGS

logger = logging.getLogger(__name__)


@dataclass(slots=True)
class CircuitState:
    failures: int = 0
    opened_until: float = 0.0
    last_error: str = ""


_LOCK = threading.RLock()
_CLIENTS: WeakKeyDictionary[asyncio.AbstractEventLoop, httpx.AsyncClient] = WeakKeyDictionary()
_CIRCUITS: dict[str, CircuitState] = {}


def _provider(url: str) -> str:
    return (urlparse(url).hostname or "unknown").lower()


async def get_client() -> httpx.AsyncClient:
    loop = asyncio.get_running_loop()
    with _LOCK:
        client = _CLIENTS.get(loop)
        if client is None or client.is_closed:
            limits = httpx.Limits(max_connections=50, max_keepalive_connections=20, keepalive_expiry=30)
            timeout = httpx.Timeout(SETTINGS.request_timeout_seconds, connect=min(5, SETTINGS.request_timeout_seconds))
            client = httpx.AsyncClient(
                timeout=timeout,
                limits=limits,
                follow_redirects=True,
                headers={"User-Agent": "SENTINELBot/5.2", "Accept": "application/json,text/plain,*/*"},
            )
            _CLIENTS[loop] = client
        return client


async def close_http_client() -> None:
    """Close the client owned by the current event loop.

    A process may create multiple loops during tests, embedded recovery, or a
    controlled application restart.  AsyncClient transports are loop-bound, so
    sharing or closing a client from a different loop can deadlock.
    """

    loop = asyncio.get_running_loop()
    with _LOCK:
        client = _CLIENTS.pop(loop, None)
    if client is not None and not client.is_closed:
        await client.aclose()


def circuit_snapshot() -> dict[str, dict[str, Any]]:
    now = time.monotonic()
    return {
        provider: {
            "failures": state.failures,
            "open": state.opened_until > now,
            "seconds_remaining": max(0, round(state.opened_until - now, 1)),
            "last_error": state.last_error,
        }
        for provider, state in _CIRCUITS.items()
    }


async def request(
    method: str,
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    content: Any = None,
    json_body: Any = None,
    timeout_seconds: float | None = None,
    follow_redirects: bool | None = None,
    retries: int = 2,
    allow_circuit_open: bool = False,
) -> httpx.Response:
    provider = _provider(url)
    state = _CIRCUITS.setdefault(provider, CircuitState())
    now = time.monotonic()
    if not allow_circuit_open and state.opened_until > now:
        raise RuntimeError(f"provider circuit is open: {provider}")

    client = await get_client()
    last_error: Exception | None = None
    circuit_failure = False
    attempts = max(1, int(retries) + 1)
    for attempt in range(attempts):
        if provider == 'api.twelvedata.com':
            from repositories.v2.provider_budget import reserve_twelve
            from core.async_runtime import run_blocking
            # Outside the retry handler: an exhausted/unavailable ledger must
            # never turn into an unmetered network request.
            await run_blocking(reserve_twelve, params, timeout=5)
        try:
            request_kwargs: dict[str, Any] = {
                "params": params,
                "headers": headers,
                "content": content,
                "json": json_body,
            }
            if timeout_seconds is not None:
                request_kwargs["timeout"] = httpx.Timeout(timeout_seconds)
            if follow_redirects is not None:
                request_kwargs["follow_redirects"] = follow_redirects
            response = await client.request(method.upper(), url, **request_kwargs)
            response.raise_for_status()
            state.failures = 0
            state.opened_until = 0.0
            state.last_error = ""
            return response
        except (httpx.TimeoutException, httpx.NetworkError, httpx.RemoteProtocolError, httpx.HTTPStatusError) as exc:
            last_error = exc
            status = exc.response.status_code if isinstance(exc, httpx.HTTPStatusError) else 0
            retryable = status in {0, 408, 425, 429, 500, 502, 503, 504}
            circuit_failure = circuit_failure or retryable
            if not retryable or attempt >= attempts - 1:
                break
            retry_after = 0.0
            if isinstance(exc, httpx.HTTPStatusError):
                try:
                    retry_after = float(exc.response.headers.get("Retry-After", "0") or 0)
                except ValueError:
                    retry_after = 0.0
            retry_after = min(30.0, max(0.0, retry_after)) if math.isfinite(retry_after) else 0.0
            delay = retry_after or min(4.0, 0.25 * (2**attempt))
            await asyncio.sleep(delay + secrets.randbelow(151) / 1000)

    if circuit_failure:
        state.failures += 1
        state.last_error = f"{type(last_error).__name__}: HTTP_{status}"
        if state.failures >= 3:
            state.opened_until = time.monotonic() + min(300, 30 * state.failures)
            logger.warning("Opened HTTP circuit for %s after %s failures", provider, state.failures)
    if last_error is None:
        raise RuntimeError(f"HTTP request failed without a captured error: {provider}")
    raise last_error


async def get_json(
    url: str,
    *,
    params: dict[str, Any] | None = None,
    headers: dict[str, str] | None = None,
    timeout_seconds: float | None = None,
    retries: int = 2,
) -> Any:
    response = await request(
        "GET",
        url,
        params=params,
        headers=headers,
        timeout_seconds=timeout_seconds,
        retries=retries,
    )
    try:
        return response.json()
    except ValueError as exc:
        raise RuntimeError(f"provider returned invalid JSON: {_provider(url)}") from exc
