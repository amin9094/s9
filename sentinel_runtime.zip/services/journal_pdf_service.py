from __future__ import annotations

from datetime import timedelta
from io import BytesIO
from pathlib import Path
from typing import Any

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import mm
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont
from reportlab.platypus import (
    KeepTogether, PageBreak, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle,
)

from core.rtl_text import visual_rtl
from core.utils import parse_dt
from repositories.v2.journal import JournalRepository

FONT_REGULAR = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf")
FONT_BOLD = Path("/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf")
_FONT_READY = False


def _register_fonts() -> None:
    global _FONT_READY
    if _FONT_READY:
        return
    if not FONT_REGULAR.exists() or not FONT_BOLD.exists():
        raise RuntimeError("JOURNAL_PDF_FONT_MISSING")
    pdfmetrics.registerFont(TTFont("SentinelSans", str(FONT_REGULAR)))
    pdfmetrics.registerFont(TTFont("SentinelSansBold", str(FONT_BOLD)))
    _FONT_READY = True


def _all_rows(user_id: int | str, *, limit: int = 5000) -> list[dict[str, Any]]:
    repo = JournalRepository()
    cursor: str | None = None
    rows: list[dict[str, Any]] = []
    while len(rows) < limit:
        page = repo.list_for_user(user_id, cursor=cursor, limit=min(100, limit - len(rows)))
        items = page.get("items") if isinstance(page, dict) else []
        if not isinstance(items, list) or not items:
            break
        rows.extend(dict(item) for item in items if isinstance(item, dict))
        cursor = page.get("next_cursor")
        if not cursor:
            break
    return rows


def _result_r(row: dict[str, Any]) -> float:
    try:
        return float(row.get("result_r") or 0)
    except (TypeError, ValueError):
        return 0.0


def _fmt(value: Any, digits: int = 5) -> str:
    if value in (None, ""):
        return "-"
    try:
        number = float(value)
        return f"{number:.{digits}f}".rstrip("0").rstrip(".")
    except (TypeError, ValueError):
        return str(value)


def _clean_text(value: Any, limit: int = 600) -> str:
    return " ".join(str(value or "-").replace("\r", " ").replace("\n", " ").split())[:limit]


def _filtered_rows(
    rows: list[dict[str, Any]], *, account_id: str = "", status: str = "",
    date_from: str = "", date_to: str = "",
) -> list[dict[str, Any]]:
    start = parse_dt(date_from) if date_from else None
    end = parse_dt(date_to) if date_to else None
    if end is not None and len(str(date_to).strip()) <= 10:
        end = end + timedelta(days=1)
    clean_account = str(account_id or "").strip()
    clean_status = str(status or "").strip().lower()
    output: list[dict[str, Any]] = []
    for row in rows:
        if clean_account and str(row.get("account_id") or "") != clean_account:
            continue
        if clean_status and clean_status != "all" and str(row.get("status") or "").lower() != clean_status:
            continue
        opened = parse_dt(row.get("opened_at") or row.get("created_at"))
        if start and (opened is None or opened < start):
            continue
        if end and (opened is None or opened >= end):
            continue
        output.append(row)
    return output


def _paragraph(text: Any, style: ParagraphStyle) -> Paragraph:
    value = _clean_text(text)
    if style.wordWrap == "RTL":
        value = visual_rtl(value)
    safe = value.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return Paragraph(safe, style)


def _page_decorator(canvas, doc, *, fa: bool) -> None:
    canvas.saveState()
    width, height = landscape(A4)
    canvas.setFont("SentinelSans", 8)
    canvas.setFillColor(colors.HexColor("#64748B"))
    page = canvas.getPageNumber()
    label = visual_rtl(f"صفحه {page}") if fa else f"Page {page}"
    canvas.drawRightString(width - 14 * mm, 8 * mm, label)
    canvas.drawString(14 * mm, 8 * mm, "SENTINEL")
    canvas.setStrokeColor(colors.HexColor("#CBD5E1"))
    canvas.line(14 * mm, 12 * mm, width - 14 * mm, 12 * mm)
    canvas.restoreState()


def build_journal_pdf(
    user_id: int | str, *, language: str = "fa", account_id: str = "", status: str = "",
    date_from: str = "", date_to: str = "",
) -> bytes:
    """Build a searchable, low-memory journal PDF.

    ReportLab streams text and table rows directly to PDF pages.  Unlike the old
    PIL implementation, it does not rasterize pages or keep full-page images in
    memory, so exports with thousands of journal rows remain practical on
    Railway and text can be searched or copied by the user.
    """
    _register_fonts()
    fa = str(language or "fa").lower().startswith("fa")
    rows = _filtered_rows(
        _all_rows(user_id), account_id=account_id, status=status,
        date_from=date_from, date_to=date_to,
    )
    closed = [row for row in rows if str(row.get("status") or "").lower() == "closed"]
    stats = {
        "total": len(rows),
        "open": sum(1 for row in rows if str(row.get("status") or "").lower() not in {"closed", "archived", "skipped"}),
        "wins": sum(1 for row in closed if _result_r(row) > 0),
        "losses": sum(1 for row in closed if _result_r(row) < 0),
        "net_r": sum(_result_r(row) for row in closed),
    }

    buffer = BytesIO()
    doc = SimpleDocTemplate(
        buffer, pagesize=landscape(A4), rightMargin=12 * mm, leftMargin=12 * mm,
        topMargin=12 * mm, bottomMargin=17 * mm, title="SENTINEL Trading Journal",
        author="SENTINEL", subject="Trading journal export",
    )
    styles = getSampleStyleSheet()
    base = ParagraphStyle(
        "SentinelBase", parent=styles["BodyText"], fontName="SentinelSans",
        fontSize=8.2, leading=11, alignment=TA_RIGHT if fa else TA_LEFT,
        wordWrap="RTL" if fa else None, textColor=colors.HexColor("#0F172A"),
    )
    small = ParagraphStyle("SentinelSmall", parent=base, fontSize=7.2, leading=9)
    center = ParagraphStyle("SentinelCenter", parent=base, alignment=TA_CENTER)
    header = ParagraphStyle(
        "SentinelHeader", parent=center, fontName="SentinelSansBold", fontSize=8.3,
        leading=10, textColor=colors.white,
    )
    title = ParagraphStyle(
        "SentinelTitle", parent=base, fontName="SentinelSansBold", fontSize=17,
        leading=23, alignment=TA_RIGHT if fa else TA_LEFT,
    )
    stat_label = ParagraphStyle("StatLabel", parent=center, fontSize=7.5, textColor=colors.HexColor("#475569"))
    stat_value = ParagraphStyle("StatValue", parent=center, fontName="SentinelSansBold", fontSize=13, leading=16)

    story: list[Any] = []
    story.append(_paragraph("گزارش ژورنال معاملاتی SENTINEL" if fa else "SENTINEL Trading Journal Report", title))
    filter_parts = []
    if account_id:
        filter_parts.append(("حساب" if fa else "Account") + f": {account_id}")
    if status and status != "all":
        filter_parts.append(("وضعیت" if fa else "Status") + f": {status}")
    if date_from:
        filter_parts.append(("از" if fa else "From") + f": {date_from[:10]}")
    if date_to:
        filter_parts.append(("تا" if fa else "To") + f": {date_to[:10]}")
    if filter_parts:
        story.append(_paragraph(" | ".join(filter_parts), small))
    story.append(Spacer(1, 4 * mm))

    labels = ["تعداد کل", "معاملات باز", "برد", "باخت", "R خالص"] if fa else ["Total", "Open", "Wins", "Losses", "Net R"]
    values = [stats["total"], stats["open"], stats["wins"], stats["losses"], f"{stats['net_r']:+.2f}R"]
    stat_data = [[_paragraph(label, stat_label) for label in labels], [_paragraph(value, stat_value) for value in values]]
    stat_table = Table(stat_data, colWidths=[49 * mm] * 5, rowHeights=[8 * mm, 12 * mm])
    stat_table.setStyle(TableStyle([
        ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#F1F5F9")),
        ("BOX", (0, 0), (-1, -1), 0.6, colors.HexColor("#CBD5E1")),
        ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#CBD5E1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 4), ("RIGHTPADDING", (0, 0), (-1, -1), 4),
    ]))
    story.extend([stat_table, Spacer(1, 5 * mm)])

    headers = (["تاریخ", "نماد", "جهت", "ورود / حد ضرر", "خروج / نتیجه R", "وضعیت", "دلیل ورود", "یادداشت"] if fa else
               ["Date", "Symbol", "Side", "Entry / Stop", "Exit / Result R", "Status", "Entry reason", "Note"])
    table_data: list[list[Any]] = [[_paragraph(value, header) for value in headers]]
    for row in rows:
        opened = str(row.get("opened_at") or row.get("created_at") or "-")[:16].replace("T", " ")
        result = f"{_result_r(row):+.2f}R" if row.get("result_r") not in (None, "") else "-"
        reason = row.get("entry_reason") or row.get("entry_reason_type") or row.get("source") or "-"
        cells = [
            opened, row.get("symbol") or "-", row.get("side") or "-",
            f"{_fmt(row.get('entry_price'))} / SL {_fmt(row.get('actual_stop') or row.get('stop_loss'))}",
            f"{_fmt(row.get('exit_price'))} / {result}", row.get("status") or "open", reason,
            row.get("note") or "-",
        ]
        table_data.append([
            _paragraph(cells[0], center), _paragraph(cells[1], center), _paragraph(cells[2], center),
            _paragraph(cells[3], center), _paragraph(cells[4], center), _paragraph(cells[5], center),
            _paragraph(cells[6], base), _paragraph(cells[7], small),
        ])
    if not rows:
        empty_label = "ژورنال خالی است." if fa else "No journal trades have been recorded yet."
        table_data.append([_paragraph(empty_label, center)] + [""] * 7)

    widths = [25 * mm, 20 * mm, 14 * mm, 31 * mm, 31 * mm, 21 * mm, 51 * mm, 67 * mm]
    journal_table = Table(table_data, colWidths=widths, repeatRows=1, splitByRow=True, hAlign="RIGHT" if fa else "LEFT")
    style_commands = [
        ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#0F172A")),
        ("GRID", (0, 0), (-1, -1), 0.35, colors.HexColor("#CBD5E1")),
        ("VALIGN", (0, 0), (-1, -1), "MIDDLE"),
        ("LEFTPADDING", (0, 0), (-1, -1), 3), ("RIGHTPADDING", (0, 0), (-1, -1), 3),
        ("TOPPADDING", (0, 0), (-1, -1), 4), ("BOTTOMPADDING", (0, 0), (-1, -1), 4),
    ]
    for index in range(1, len(table_data)):
        if index % 2 == 0:
            style_commands.append(("BACKGROUND", (0, index), (-1, index), colors.HexColor("#F8FAFC")))
    journal_table.setStyle(TableStyle(style_commands))
    story.append(KeepTogether([journal_table]) if len(rows) <= 4 else journal_table)
    doc.build(
        story,
        onFirstPage=lambda canvas, document: _page_decorator(canvas, document, fa=fa),
        onLaterPages=lambda canvas, document: _page_decorator(canvas, document, fa=fa),
    )
    return buffer.getvalue()
