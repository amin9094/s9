"""Bounded recurring research discovery and private admin notifications."""

from __future__ import annotations

import asyncio
import time
from weakref import WeakKeyDictionary

from core.async_runtime import run_blocking
from repositories.v2.strategy_outbox import StrategyOutboxRepository
from services.canonical_market_service import universe
from services.strategy_analysis_service import research_analysis
from services.strategy_review_queue_service import _save_analysis

_SCAN_DUE = WeakKeyDictionary()


def due_markets(symbols, profiles, cursor, now):
    """Closed-bar cadence; gold/FX first, indices every 30 min M5 / 4 h H1."""
    due = _SCAN_DUE.setdefault(asyncio.get_running_loop(),{})
    profile_key = tuple((name,p.profile_id) for name,p in profiles)
    # Same Nasdaq cash chart alias must not consume two automatic requests.
    symbols = [symbol for symbol in symbols if symbol!='NAS100' or 'US100' not in symbols]
    indices = {'US30','US100','NAS100'}
    def priority(symbol):
        return 0 if symbol=='XAUUSD' else 3 if symbol in indices else 2 if symbol.endswith('USDT') else 1
    rotated = symbols[cursor%len(symbols):]+symbols[:cursor%len(symbols)]
    ordered = sorted(rotated,key=priority)
    selected = []
    for tf,capacity in [('5m',3),('1h',1)]:
        for symbol in ordered:
            key = (symbol,tf,profile_key)
            if due.get(key,0)>now:
                continue
            period = (1800 if tf=='5m' else 14400) if symbol in indices else (300 if tf=='5m' else 3600)
            due[key] = (int(now)//period+1)*period+15
            selected.append((symbol,tf))
            capacity -= 1
            if capacity==0:
                break
    return selected


def review_message(review):
    title = review.get("title_fa") or "نیازمند بررسی ادمین"
    lines = [title, f"{review.get('symbol', '')} · {review.get('timeframe', '')} · {review.get('engine', '')}"]
    if review.get("original_zone"):
        lines.append("محدودهٔ اصلی: " + " — ".join(review["original_zone"]))
    if review.get("poc"):
        poc = review["poc"]
        lines.append(f"POC: {poc.get('price', '—')} · {poc.get('proxy_label_fa', poc.get('volume_kind', ''))}")
    if review.get("fib_061"):
        lines.append(f"فیبوناچی ۰٫۶۱: {review['fib_061']}")
    if review.get("explanation_fa"):
        lines.append(review["explanation_fa"])
    if review.get('required_action_fa'):
        lines.append('اقدام لازم: ' + review['required_action_fa'])
    if review.get('observation'):
        subject=review['observation']
        lines.append(f"منبع: {subject['provider']} · {subject['venue']} · {subject['product']}")
        lines.append('جهت مشاهده: ' + subject['direction'])
        lines.append('این محدوده سیگنال ورود نیست؛ Bid/Ask، تازگی کامل و مدیریت ریسک هنوز تأیید نشده‌اند.')
        factors=review.get('fibonacci_confirmation',{}).get('confirmations',[])
        lines.append('تأییدهای هندسی فیبوناچی: ' + str(len(factors)))
    if review.get("draft_plan"):
        p = review["draft_plan"]
        lines.append(f"پیشنهاد پژوهشی: Entry {p['entry']} · SL {p['stop']} · TP1 {p['tp1']} · TP2 {p['tp2']}")
    lines.append("این مورد برای بررسی است؛ انتشار عمومی یا اجرای معامله انجام نشده است.")
    return "\n".join(lines)[:3500]


async def deliver_reviews(bot, admin_ids):
    repository = StrategyOutboxRepository()
    allowed = {str(int(value)) for value in admin_ids}
    rows = await run_blocking(repository.claim, timeout=5)
    for row in rows:
        if row["admin_id"] not in allowed:
            await run_blocking(repository.finish, row["id"], "REVOKED", timeout=5)
            continue
        try:
            async with asyncio.timeout(12):
                message = await bot.send_message(chat_id=int(row["admin_id"]), text=review_message(row["payload"]["review"]))
        except asyncio.CancelledError:
            # SENDING remains an uncertain delivery after restart; no resending.
            raise
        except Exception as exc:
            from telegram.error import BadRequest, Forbidden, RetryAfter

            status = "PENDING" if isinstance(exc, RetryAfter) else "FAILED" if isinstance(exc, BadRequest | Forbidden) else "UNCERTAIN"
            retry = getattr(exc, "retry_after", 0)
            retry = retry.total_seconds() if hasattr(retry, "total_seconds") else retry
            await run_blocking(repository.finish, row["id"], status, retry_seconds=retry, timeout=5)
        else:
            await run_blocking(repository.finish, row["id"], "SENT", message_id=message.message_id, timeout=5)
    return len(rows)


async def scan_cycle(bot, admin_ids, *, cursor=0, settings=None):
    settings = settings or {}
    if not settings.get("enabled", True) or not admin_ids:
        return {"cursor": cursor, "state": "PAUSED", "analyzed": 0}
    directory = await universe()
    symbols = list(dict.fromkeys([*directory["core_symbols"], *[row["symbol"] for row in directory["crypto_top20"]]]))
    if not symbols:
        return {"cursor": cursor, "state": "MARKET_UNIVERSE_UNAVAILABLE", "analyzed": 0}
    from services.strategy_profile_service import selected_parameters
    profiles = selected_parameters(settings)
    selected = due_markets(symbols,profiles,cursor,time.time())
    semaphore = asyncio.Semaphore(2)

    async def analyze(symbol, timeframe):
        async with semaphore:
            try:
                from services.market_data_issues import automatic_source_block
                result = automatic_source_block(symbol,timeframe)
                if result is None:
                    async with asyncio.timeout(20):
                        result = await research_analysis(symbol, timeframe, engine_parameters=profiles)
            except Exception as exc:
                from services.market_data_issues import data_block, safe_market_error
                result = data_block(safe_market_error(exc))
            blocked = not result.get('results') and result.get('state') in {'NEEDS_REVIEW','UNAVAILABLE'}
            if blocked:
                result["results"] = [{"engine": "market_data", "symbol": symbol, "timeframe": timeframe,
                                       "state": "NEEDS_REVIEW", "reason": result.get("reason", "MARKET_DATA_UNAVAILABLE"),
                                       "title_fa": "نیازمند بررسی: اتصال دادهٔ این بازار کامل نیست",
                                       "available_ms": int(time.time() * 1000),
                                       **{key:result[key] for key in ('explanation_fa','required_action_fa','provider','product','data_gap') if key in result}}]
            from services.strategy_quote_owner import current_owner
            owner=current_owner()
            saved = await owner.prepare_result(result) if owner else await run_blocking(_save_analysis,result,timeout=10)
            await run_blocking(StrategyOutboxRepository().enqueue, saved["new_review_ids"], admin_ids, timeout=5)
            return {'symbol':symbol,'timeframe':timeframe,'blocked':blocked,
                    'automatic_request_skipped':result.get('automatic_request_skipped',False),
                    'reason':result.get('reason','') if blocked else ''}

    outcomes = await asyncio.gather(*(analyze(*case) for case in selected))
    await deliver_reviews(bot, admin_ids)
    gaps=[row for row in outcomes if row['blocked']]
    skipped=sum(row['automatic_request_skipped'] for row in outcomes)
    return {"cursor": cursor + max(1,len(selected)), "state": "RESEARCH_SCANNING_WITH_DATA_GAPS" if gaps else "RESEARCH_SCANNING", "analyzed": len(selected)-skipped,
            'attempted':len(selected),'completed_analyses':len(selected)-len(gaps),'blocked_markets':gaps,
            'skipped_missing_live_source':skipped,
            "production_qualified": False, "public_auto_publish": False}
