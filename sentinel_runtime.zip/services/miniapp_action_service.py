"""Deprecated v7 compatibility surface.

Production HTTP routes must use ``services.miniapp_action_service_v2``.  This
module keeps historical policy constants for migrations/tests, but its legacy
write dispatcher is fail-closed to prevent a second Mini App source of truth.
"""
from __future__ import annotations

LEGACY_RUNTIME_DISABLED = True

import hashlib
import json
from datetime import UTC, datetime, timedelta
from typing import Any

from config import SETTINGS
from core.db import with_db
from core.idempotency import abort as abort_idempotency
from core.idempotency import complete as complete_idempotency
from core.idempotency import reserve as reserve_idempotency
from core.rate_limit import allow as rate_limit_allow
from core.utils import parse_dt, utc_iso
from core.webapp_auth import TelegramWebAppIdentity, validate_init_data
from modules.action_inbox import action_inbox_snapshot
from modules.admin_control_center import (
    NOTIFICATION_KEYS,
    notification_preferences,
    pause_notifications,
    set_notification_quiet_hours,
    set_notification_timezone,
)
from modules.admin_access import (
    PERMISSION_AUTOMATIONS,
    PERMISSION_CAMPAIGNS,
    PERMISSION_ADMIN_SHIFTS,
    PERMISSION_INCIDENTS,
    PERMISSION_MISSION_CONTROL,
    PERMISSION_RUNTIME_SAFETY,
    PERMISSION_TICKETS,
)
from modules.automation_outbox import retry_automation_message
from modules.broker_import import import_broker_statement
from modules.campaign_studio import set_campaign_status
from modules.economic_calendar import update_user_calendar_preferences
from modules.experiment_lab import create_experiment, set_experiment_status
from modules.i18n import set_user_language, user_language
from modules.incident_center import update_incident_status
from modules.miniapp_product import (
    cancel_vip_order,
    create_checkout_quote,
    create_vip_order_from_miniapp,
    resubmit_vip_order,
)
from modules.mission_control import mission_control_snapshot
from modules.notification_router import set_notification_filters
from modules.operations_handoff import create_shift_handoff, update_shift_handoff
from modules.personal_risk import risk_profile, update_risk_profile
from modules.product_intelligence import update_onboarding
from modules.portfolio import (
    add_journal_entry,
    add_partial_close,
    delete_journal_entry,
    ensure_signal_journal_entry,
    find_journal_entry,
    link_position_journal,
    import_journal_csv,
    remove_watchlist_symbol,
    set_watchlist_alerts,
    toggle_watchlist_symbol,
    sync_journal_from_position,
    sync_position_from_journal,
    update_journal_result,
    void_signal_journal_entry,
)
from modules.rules import accept_current_rules
from modules.runtime_safety import set_runtime_mode
from modules.signal_portal import set_user_signal_choice
from modules.support import (
    append_ticket_message,
    create_ticket,
    find_ticket,
    set_ticket_satisfaction,
    set_ticket_status,
)
from modules.trading_os import (
    acknowledge_revision,
    accounts_for_user,
    archive_account,
    close_position,
    create_or_update_account,
    emit_event,
    open_position,
    update_position_from_signal_choice,
)
from services.access_policy import ActionPolicy, enforce_action_policy

USER_ACTIONS = {
    "risk_profile_update", "account_upsert", "account_archive", "watchlist_toggle", "watchlist_remove",
    "watchlist_alerts", "journal_add", "journal_delete", "journal_result_update", "journal_partial_close",
    "journal_import_csv", "broker_import", "ticket_create", "ticket_reply", "ticket_status_update", "ticket_satisfaction",
    "notification_preferences_update", "calendar_preferences_update", "signal_choice_update", "position_close",
    "revision_ack", "checkout_quote_create", "vip_order_submit", "vip_order_cancel", "vip_order_resubmit",
    "language_update", "rules_accept", "onboarding_update",
}
ADMIN_ACTIONS = {
    "runtime_mode_update", "mission_control_refresh", "action_inbox_refresh", "incident_status_update",
    "campaign_status_update", "automation_retry", "ticket_admin_reply", "ticket_admin_status_update",
    "shift_handoff_create", "shift_handoff_status_update", "experiment_create", "experiment_status_update",
}

_ACTION_MODULE = {
    "risk_profile_update": "risk", "account_upsert": "risk", "account_archive": "risk", "position_close": "risk",
    "revision_ack": "signals", "signal_choice_update": "signals", "watchlist_toggle": "watchlists",
    "watchlist_remove": "watchlists", "watchlist_alerts": "watchlists", "journal_add": "journal",
    "journal_delete": "journal", "journal_result_update": "journal", "journal_partial_close": "journal",
    "journal_import_csv": "journal", "broker_import": "journal", "ticket_create": "support", "ticket_reply": "support",
    "ticket_status_update": "support", "ticket_satisfaction": "support", "notification_preferences_update": "account",
    "calendar_preferences_update": "calendar", "checkout_quote_create": "subscriptions", "vip_order_submit": "subscriptions",
    "vip_order_cancel": "subscriptions", "vip_order_resubmit": "subscriptions", "language_update": "account",
    "rules_accept": "account", "onboarding_update": "account",
}
ACTION_POLICIES = {name: ActionPolicy(module, rules_required=name not in {"language_update", "rules_accept"}) for name, module in _ACTION_MODULE.items()}
ACTION_POLICIES.update({
    "runtime_mode_update": ActionPolicy("runtime", permission=PERMISSION_RUNTIME_SAFETY, admin_only=True),
    "mission_control_refresh": ActionPolicy("dashboard", permission=PERMISSION_MISSION_CONTROL, admin_only=True),
    "action_inbox_refresh": ActionPolicy("dashboard", permission=PERMISSION_MISSION_CONTROL, admin_only=True),
    "incident_status_update": ActionPolicy("incidents", permission=PERMISSION_INCIDENTS, admin_only=True),
    "campaign_status_update": ActionPolicy("campaigns", permission=PERMISSION_CAMPAIGNS, admin_only=True),
    "automation_retry": ActionPolicy("automations", permission=PERMISSION_AUTOMATIONS, admin_only=True),
    "ticket_admin_reply": ActionPolicy("support", permission=PERMISSION_TICKETS, admin_only=True),
    "ticket_admin_status_update": ActionPolicy("support", permission=PERMISSION_TICKETS, admin_only=True),
    "shift_handoff_create": ActionPolicy("admin_shifts", permission=PERMISSION_ADMIN_SHIFTS, admin_only=True),
    "shift_handoff_status_update": ActionPolicy("admin_shifts", permission=PERMISSION_ADMIN_SHIFTS, admin_only=True),
    "experiment_create": ActionPolicy("campaigns", permission=PERMISSION_CAMPAIGNS, admin_only=True),
    "experiment_status_update": ActionPolicy("campaigns", permission=PERMISSION_CAMPAIGNS, admin_only=True),
})
ACTION_COOLDOWNS = {name: 0.7 for name in USER_ACTIONS | ADMIN_ACTIONS}
ACTION_COOLDOWNS.update({
    "ticket_create": 3.0, "vip_order_submit": 4.0, "checkout_quote_create": 1.5,
    "journal_import_csv": 5.0, "broker_import": 8.0, "shift_handoff_create": 2.0,
    "experiment_create": 3.0,
})


def _signal(db: dict[str, Any], signal_id: int | str) -> dict[str, Any]:
    target = int(signal_id)
    row = next((item for item in db.get("signals", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == target), None)
    if not row:
        raise ValueError("SIGNAL_NOT_FOUND")
    return row


def _set_extended_choice(db: dict[str, Any], uid: str, signal: dict[str, Any], choice: str) -> dict[str, Any]:
    rows = db.setdefault("user_signal_choices", {}).setdefault(uid, {})
    previous = rows.get(str(signal["id"]), {}) if isinstance(rows.get(str(signal["id"])), dict) else {}
    data = {
        "signal_id": int(signal["id"]),
        "cycle_id": int(signal.get("cycle_id", 1) or 1),
        "display_number": int(signal.get("display_number", signal["id"]) or signal["id"]),
        "market_category": str(signal.get("market_category") or "forex"),
        "choice": choice,
        "selected_at": previous.get("selected_at") or utc_iso(),
        "updated_at": utc_iso(),
    }
    rows[str(signal["id"])] = data
    return data


def handle_miniapp_action_for_identity(identity: TelegramWebAppIdentity, body: dict[str, Any]) -> dict[str, Any]:
    raise RuntimeError("LEGACY_MINIAPP_WRITE_DISABLED_USE_V2")
    action = str(body.get("action") or "").strip()
    payload = body.get("payload") if isinstance(body.get("payload"), dict) else {}
    request_id = str(body.get("request_id") or "").strip()
    if request_id and (len(request_id) > 100 or not all(ch.isalnum() or ch in "-_:." for ch in request_id)):
        raise ValueError("INVALID_REQUEST_ID")
    request_fingerprint = hashlib.sha256(
        json.dumps({"action": action, "payload": payload}, sort_keys=True, ensure_ascii=False, default=str).encode("utf-8")
    ).hexdigest()
    if action not in USER_ACTIONS | ADMIN_ACTIONS:
        raise ValueError("UNKNOWN_ACTION")

    uid = str(identity.user_id)
    reservation = reserve_idempotency(
        uid, request_id, action=action, fingerprint=request_fingerprint, ttl_seconds=86_400
    )
    if reservation.state == "conflict":
        raise ValueError("IDEMPOTENCY_CONFLICT")
    if reservation.state == "in_progress":
        raise ValueError("REQUEST_IN_PROGRESS")
    if reservation.state == "replay" and reservation.response is not None:
        return dict(reservation.response)

    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        enforce_action_policy(db, uid, ACTION_POLICIES[action], owner_id=SETTINGS.admin_ids[0] if SETTINGS.admin_ids else None)
        operations = db.setdefault("operations", {})
        idempotency = db.setdefault("miniapp_idempotency_records", {})
        cutoff = datetime.now(UTC) - timedelta(hours=24)
        for stale_key, stale in list(idempotency.items()):
            created = parse_dt(str(stale.get("created_at") or "")) if isinstance(stale, dict) else None
            if created is None or created < cutoff:
                idempotency.pop(stale_key, None)
        cache_key = f"{uid}:{request_id}"
        if request_id:
            existing = idempotency.get(cache_key)
            if isinstance(existing, dict):
                if existing.get("action") != action or existing.get("request_fingerprint") != request_fingerprint:
                    raise ValueError("IDEMPOTENCY_CONFLICT")
                return dict(existing["response"])
        if not rate_limit_allow(uid, f"miniapp:{action}", ACTION_COOLDOWNS.get(action, 0.7)):
            raise ValueError("RATE_LIMITED")

        if action == "risk_profile_update":
            data = update_risk_profile(db, uid, payload)
        elif action == "account_upsert":
            data = create_or_update_account(db, uid, payload, account_id=payload.get("account_id"))
        elif action == "account_archive":
            data = archive_account(db, uid, payload.get("account_id"))
        elif action == "watchlist_toggle":
            added, row = toggle_watchlist_symbol(db, uid, str(payload.get("symbol") or ""))
            data = {"added": added, "item": row}
        elif action == "watchlist_remove":
            data = {"removed": remove_watchlist_symbol(db, uid, str(payload.get("symbol") or ""))}
        elif action == "watchlist_alerts":
            data = set_watchlist_alerts(db, uid, str(payload.get("symbol") or ""), bool(payload.get("enabled", True)))
        elif action == "journal_add":
            data = add_journal_entry(
                db, uid, symbol=str(payload.get("symbol") or ""), side=str(payload.get("side") or ""),
                entry_price=payload.get("entry_price"), volume=payload.get("volume"), note=str(payload.get("note") or ""),
                account_id=payload.get("account_id"), actual_stop=payload.get("actual_stop"), setup=str(payload.get("setup") or ""),
                emotion=str(payload.get("emotion") or ""), tags=payload.get("tags") if isinstance(payload.get("tags"), list) else [],
            )
        elif action == "journal_delete":
            data = {"archived": delete_journal_entry(db, uid, payload.get("id"))}
        elif action == "journal_result_update":
            data = update_journal_result(
                db, uid, payload.get("id"), pnl_percent=float(payload.get("pnl_percent")), exit_price=payload.get("exit_price"),
                pnl_amount=payload.get("pnl_amount"), note=str(payload.get("note") or "") or None,
                fees=float(payload.get("fees") or 0), commission=float(payload.get("commission") or 0),
                swap=float(payload.get("swap") or 0), mae=payload.get("mae"), mfe=payload.get("mfe"),
            )
            linked_position = sync_position_from_journal(db, uid, data)
            if linked_position:
                data = {**dict(data), "position": dict(linked_position)}
        elif action == "journal_partial_close":
            journal = find_journal_entry(db, uid, payload.get("id"))
            if not journal:
                raise ValueError("JOURNAL_ENTRY_NOT_FOUND")
            remaining_volume = float(journal.get("remaining_volume") if journal.get("remaining_volume") is not None else journal.get("volume") or 0)
            close_volume = float(payload.get("volume"))
            if journal.get("position_id") and remaining_volume > 0:
                position = close_position(db, uid, journal.get("position_id"), {
                    "exit_price": payload.get("exit_price"),
                    "close_fraction": close_volume / remaining_volume,
                    "pnl_amount": payload.get("pnl_amount"),
                    "fees": payload.get("fees", 0),
                    "commission": payload.get("commission", 0),
                    "swap": payload.get("swap", 0),
                    "note": payload.get("note", ""),
                })
                data = sync_journal_from_position(db, uid, position) or journal
                data = {**dict(data), "position": position}
            else:
                data = add_partial_close(db, uid, payload.get("id"), volume=close_volume, exit_price=float(payload.get("exit_price")), pnl_amount=float(payload.get("pnl_amount")))
        elif action == "journal_import_csv":
            data = import_journal_csv(db, uid, str(payload.get("content") or ""))
        elif action == "broker_import":
            data = import_broker_statement(
                db, uid, str(payload.get("content") or ""), filename=str(payload.get("filename") or "statement.csv"),
                broker=str(payload.get("broker") or "MT5"), account_id=payload.get("account_id"),
            )
        elif action == "signal_choice_update":
            signal = _signal(db, payload.get("signal_id"))
            choice = str(payload.get("choice") or "").lower()
            if choice == "taken":
                execution = payload.get("execution") if isinstance(payload.get("execution"), dict) else {}
                required = {"account_id", "actual_entry", "actual_stop"}
                if not required.issubset(execution) or not execution.get("confirmation"):
                    raise ValueError("EXECUTION_CONFIRMATION_REQUIRED")
                execution_payload = {
                    "account_id": execution.get("account_id"),
                    "actual_entry": execution.get("actual_entry"),
                    "actual_stop": execution.get("actual_stop"),
                    "risk_percent": execution.get("risk_percent"),
                    "actual_volume": execution.get("volume"),
                    "current_price": execution.get("current_price"),
                    "override": bool(execution.get("override")),
                    "override_reason": str(execution.get("override_reason") or ""),
                    "late_entry": bool(execution.get("late_entry")),
                }
                position = open_position(db, uid, signal, execution_payload)
                data = set_user_signal_choice(db, uid, int(signal["id"]), "taken")
                journal = ensure_signal_journal_entry(db, uid, signal, position=position)
                linked = link_position_journal(db, uid, position["id"], journal["id"])
                if linked:
                    position = dict(linked)
                data = {**dict(data), "position": position, "journal": journal}
            elif choice in {"skipped", "watching", "late_entry"}:
                data = set_user_signal_choice(db, uid, int(signal["id"]), "skipped") if choice == "skipped" else _set_extended_choice(db, uid, signal, choice)
                position = update_position_from_signal_choice(db, uid, int(signal["id"]), choice)
                voided = void_signal_journal_entry(db, uid, int(signal["id"]), reason=f"choice_changed_to_{choice}")
                data = {**dict(data), "position": position, "voided_journal_entries": voided}
            else:
                raise ValueError("INVALID_SIGNAL_CHOICE")
        elif action == "position_close":
            close_payload = {
                "exit_price": payload.get("exit_price"),
                "close_fraction": payload.get("close_fraction", 1.0),
                "pnl_amount": payload.get("pnl_amount"),
                "pnl_percent": payload.get("pnl_percent"),
                "fees": payload.get("fees", 0),
                "commission": payload.get("commission", 0),
                "swap": payload.get("swap", 0),
                "note": payload.get("note", ""),
            }
            position = close_position(db, uid, payload.get("position_id"), close_payload)
            journal = sync_journal_from_position(db, uid, position)
            data = {**dict(position), "journal": journal}
        elif action == "revision_ack":
            data = acknowledge_revision(db, uid, payload.get("signal_id"), payload.get("revision"))
        elif action == "checkout_quote_create":
            data = create_checkout_quote(db, uid, plan_id=payload.get("plan_id"), payment_method=str(payload.get("payment_method") or ""), coupon=str(payload.get("coupon") or ""))
        elif action == "vip_order_submit":
            data = create_vip_order_from_miniapp(db, user_id=identity.user_id, username=identity.username, first_name=identity.first_name, payload=payload)
        elif action == "vip_order_cancel":
            data = cancel_vip_order(db, uid, str(payload.get("order_id") or ""), str(payload.get("reason") or ""))
        elif action == "vip_order_resubmit":
            data = resubmit_vip_order(db, uid, str(payload.get("order_id") or ""), receipt_id=str(payload.get("receipt_id") or ""), quote_id=str(payload.get("quote_id") or ""), transaction_hash=str(payload.get("transaction_hash") or ""))
        elif action == "ticket_create":
            data = create_ticket(db, uid, str(payload.get("text") or ""), subject=str(payload.get("subject") or "پشتیبانی"), category=str(payload.get("category") or "general"), priority=str(payload.get("priority") or "normal"))
        elif action == "ticket_reply":
            ticket = find_ticket(db, payload.get("ticket_id"))
            if not ticket or str(ticket.get("user_id")) != uid:
                raise PermissionError("TICKET_NOT_OWNED")
            data = append_ticket_message(db, payload.get("ticket_id"), "user", uid, str(payload.get("text") or ""))
        elif action == "ticket_status_update":
            ticket = find_ticket(db, payload.get("ticket_id"))
            if not ticket or str(ticket.get("user_id")) != uid:
                raise PermissionError("TICKET_NOT_OWNED")
            data = set_ticket_status(db, payload.get("ticket_id"), str(payload.get("status") or ""))
        elif action == "ticket_satisfaction":
            data = set_ticket_satisfaction(db, payload.get("ticket_id"), uid, int(payload.get("score")))
        elif action == "calendar_preferences_update":
            data = update_user_calendar_preferences(db, uid, payload)
        elif action == "notification_preferences_update":
            markets = payload.get("markets") if isinstance(payload.get("markets"), list) else str(payload.get("markets") or "").split(",")
            symbols = payload.get("symbols") if isinstance(payload.get("symbols"), list) else str(payload.get("symbols") or "").split(",")
            data = set_notification_filters(db, uid, markets=markets, symbols=symbols)
            allowed_keys = {key for key, _ in NOTIFICATION_KEYS} | {"quiet_enabled"}
            for key in allowed_keys:
                if key in payload:
                    data[key] = bool(payload.get(key))
            if "quiet_start" in payload or "quiet_end" in payload:
                set_notification_quiet_hours(
                    db, uid, str(payload.get("quiet_start") or data.get("quiet_start") or "23:00"),
                    str(payload.get("quiet_end") or data.get("quiet_end") or "07:00"),
                )
            if payload.get("timezone"):
                set_notification_timezone(db, uid, str(payload.get("timezone")))
            if "pause_hours" in payload:
                pause_notifications(db, uid, int(payload.get("pause_hours") or 0))
            data = notification_preferences(db, uid)
        elif action == "onboarding_update":
            data = update_onboarding(db, uid, payload)
            accounts = accounts_for_user(db, uid)
            default_account = next((row for row in accounts if row.get("is_default")), accounts[0])
            risk_tolerance = str(data.get("risk_tolerance") or "balanced")
            risk_plan = {
                "conservative": (0.5, 2.0, 3.0),
                "balanced": (1.0, 3.0, 5.0),
                "aggressive": (1.5, 4.0, 6.0),
            }[risk_tolerance]
            account_size = float(data.get("account_size", 0) or 0)
            account_values = {
                "default_risk_percent": risk_plan[0],
                "max_daily_risk_percent": risk_plan[1],
                "max_open_risk_percent": risk_plan[2],
                "risk_enabled": True,
            }
            if account_size > 0:
                account_values.update({"balance": account_size, "equity": account_size, "starting_balance": account_size})
            data["account"] = create_or_update_account(db, uid, account_values, account_id=default_account["id"])
        elif action == "language_update":
            data = {"language": set_user_language(db, uid, str(payload.get("language") or "fa"))}
        elif action == "rules_accept":
            data = accept_current_rules(db, uid, str(payload.get("language") or user_language(db, uid) or "fa"))
        elif action == "runtime_mode_update":
            data = set_runtime_mode(db, mode=payload.get("mode"), disaster_mode=payload.get("disaster_mode"), read_only=payload.get("read_only"), reason=str(payload.get("reason") or ""), actor_id=uid)
        elif action == "mission_control_refresh":
            data = mission_control_snapshot(db)
        elif action == "action_inbox_refresh":
            data = action_inbox_snapshot(db)
        elif action == "incident_status_update":
            data = update_incident_status(
                db, payload.get("incident_id"), str(payload.get("status") or ""), uid
            )
        elif action == "campaign_status_update":
            data = set_campaign_status(
                db, payload.get("campaign_id"), str(payload.get("status") or ""), actor_id=uid
            )
        elif action == "automation_retry":
            data = retry_automation_message(
                db, str(payload.get("outbox_id") or ""), actor_id=uid
            )
        elif action == "ticket_admin_reply":
            data = append_ticket_message(
                db, payload.get("ticket_id"), "admin", uid, str(payload.get("text") or "")
            )
        elif action == "ticket_admin_status_update":
            data = set_ticket_status(
                db, payload.get("ticket_id"), str(payload.get("status") or "")
            )
        elif action == "shift_handoff_create":
            data = create_shift_handoff(
                db,
                from_admin_id=uid,
                to_admin_id=payload.get("to_admin_id"),
                summary=str(payload.get("summary") or ""),
                pending_items=payload.get("pending_items"),
                risks=payload.get("risks"),
                decisions=payload.get("decisions"),
                next_actions=payload.get("next_actions"),
                due_at=str(payload.get("due_at") or "") or None,
            )
        elif action == "shift_handoff_status_update":
            data = update_shift_handoff(
                db, payload.get("handoff_id"), admin_id=uid,
                status=str(payload.get("status") or ""), note=str(payload.get("note") or ""),
            )
        elif action == "experiment_create":
            data = create_experiment(
                db, name=str(payload.get("name") or ""), hypothesis=str(payload.get("hypothesis") or ""),
                variants=payload.get("variants"), primary_metric=str(payload.get("primary_metric") or "purchase"),
                created_by=uid, holdout_percent=float(payload.get("holdout_percent", 10) or 10),
                conversion_window_hours=int(payload.get("conversion_window_hours", 168) or 168),
                min_sample_per_variant=int(payload.get("min_sample_per_variant", 100) or 100),
                stop_loss_percent=float(payload.get("stop_loss_percent", 25) or 25),
                starts_at=str(payload.get("starts_at") or "") or None,
                ends_at=str(payload.get("ends_at") or "") or None,
            )
        elif action == "experiment_status_update":
            data = set_experiment_status(
                db, payload.get("experiment_id"), status=str(payload.get("status") or ""), changed_by=uid,
            )
        else:
            data = risk_profile(db, uid)

        emit_event(db, uid, f"miniapp.{action}", {"entity_id": data.get("id") if isinstance(data, dict) else None})
        operations.setdefault("miniapp_actions", []).append({"user_id": uid, "action": action, "created_at": utc_iso()})
        operations["miniapp_actions"] = operations["miniapp_actions"][-5000:]
        response = {"ok": True, "action": action, "data": data}
        if request_id:
            idempotency[cache_key] = {
                "action": action,
                "request_fingerprint": request_fingerprint,
                "response": response,
                "created_at": utc_iso(),
            }
            if len(idempotency) > 5000:
                db["miniapp_idempotency_records"] = dict(list(idempotency.items())[-4000:])
        return response

    try:
        result = with_db(mutate)
    except Exception:
        abort_idempotency(uid, request_id, token=reservation.token)
        raise
    complete_idempotency(
        uid, request_id, action=action, fingerprint=request_fingerprint,
        token=reservation.token, response=result, ttl_seconds=86_400,
    )
    return result


def handle_miniapp_action(init_data: str, body: dict[str, Any], bot_token: str, *, max_age_seconds: int = 900) -> dict[str, Any]:
    identity = validate_init_data(init_data, bot_token, max_age_seconds=max_age_seconds)
    return handle_miniapp_action_for_identity(identity, body)
