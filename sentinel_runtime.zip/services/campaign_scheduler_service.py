from __future__ import annotations

import logging
from typing import Any

from telegram import Bot

from config import SETTINGS
from core.async_db import async_with_db
from modules.campaign_studio import claim_due_campaigns, mark_scheduled_campaign_result
from modules.incident_center import record_incident
from modules.management_suite import automation_settings
from services.campaign_delivery_service import dispatch_marketing_campaign

logger = logging.getLogger(__name__)


async def run_campaign_scheduler(
    bot: Bot,
    *,
    bot_username: str = "",
    batch_limit: int | None = None,
) -> dict[str, int]:
    """Claim and publish campaigns independently from hourly CRM automation."""
    counts = {"campaign_scheduled": 0, "campaign_failed": 0}
    settings = await async_with_db(automation_settings)
    if not settings.get("enabled") or not settings.get("campaign_scheduler_enabled", True):
        return counts

    limit = int(batch_limit or settings.get("campaign_scheduler_batch", 10) or 10)
    due = await async_with_db(lambda db: claim_due_campaigns(db, limit=limit))
    for event in due:
        campaign_id = str(event.get("campaign_id") or "")
        actor_raw = str(event.get("actor_id") or "")
        actor_id = int(actor_raw) if actor_raw.isdigit() else int(SETTINGS.admin_ids[0])
        lease = {
            "expected_attempt": event.get("attempt"),
            "expected_version": event.get("version"),
            "expected_claimed_at": event.get("claimed_at"),
        }
        try:
            result = await dispatch_marketing_campaign(
                bot,
                campaign_id,
                actor_id,
                bot_username=bot_username,
            )
            duplicate_reason = str(result.get("duplicate_reason") or "")
            success = (
                (not result.get("duplicate") and not result.get("errors"))
                or duplicate_reason == "already_dispatched"
            )
            detail = (
                duplicate_reason
                if result.get("duplicate")
                else "; ".join(str(item) for item in result.get("errors", []))
            )
            await async_with_db(
                lambda db, cid=campaign_id, claim=lease, ok=success, error=detail: mark_scheduled_campaign_result(
                    db,
                    cid,
                    success=ok,
                    error="" if ok else error,
                    **claim,
                )
            )
            counts["campaign_scheduled" if success else "campaign_failed"] += 1
        except Exception as exc:
            logger.exception("Scheduled campaign dispatch failed for %s", campaign_id)
            error_detail = f"{exc.__class__.__name__}: {exc}"

            def mark_failure(
                db: dict[str, Any], *, cid: str = campaign_id,
                claim: dict[str, Any] = lease, detail: str = error_detail,
            ) -> None:
                row = mark_scheduled_campaign_result(
                    db,
                    cid,
                    success=False,
                    error=detail,
                    **claim,
                )
                record_incident(
                    db,
                    source="campaign_scheduler",
                    kind="scheduled_campaign_failed",
                    detail=f"{cid}: {detail}",
                    severity=(
                        "critical"
                        if str(row.get("schedule_status") or "") == "dead_letter"
                        else "warning"
                    ),
                    metadata={
                        "campaign_id": cid,
                        "attempt": int(row.get("schedule_attempts", 0) or 0),
                        "status": str(row.get("schedule_status") or ""),
                    },
                    dedupe_minutes=5,
                )

            try:
                await async_with_db(mark_failure)
            except Exception:
                # The durable claim expires and can be retried. Failure to save
                # this incident must not discard the remaining claimed batch.
                logger.exception("Could not persist campaign failure for %s", campaign_id)
            counts["campaign_failed"] += 1
    return counts
