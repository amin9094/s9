from __future__ import annotations

import io
import logging
from typing import Any

from telegram import Bot, InlineKeyboardMarkup

from ui.button_factory import InlineKeyboardButton

try:
    from telegram import InputFile
except ImportError:  # Offline test shim; production PTB always provides InputFile.
    class InputFile:  # type: ignore[no-redef]
        def __init__(self, obj: Any, filename: str | None = None):
            self.input_file_content = obj
            self.filename = filename

from telegram.constants import ParseMode

from core.async_db import async_with_db
from modules.automation_outbox import (
    claim_due_automation_messages,
    mark_automation_message_result,
)

logger = logging.getLogger(__name__)


def _reply_markup(payload: dict[str, Any]) -> InlineKeyboardMarkup | None:
    rows: list[list[InlineKeyboardButton]] = []
    for raw_row in payload.get("buttons", []):
        if not isinstance(raw_row, list):
            continue
        buttons: list[InlineKeyboardButton] = []
        for item in raw_row:
            if not isinstance(item, dict):
                continue
            label = str(item.get("label") or "").strip()[:64]
            if not label:
                continue
            callback = str(item.get("callback_data") or "").strip()
            url = str(item.get("url") or "").strip()
            if callback:
                buttons.append(InlineKeyboardButton(label, callback_data=callback[:64]))
            elif url.startswith(("https://", "http://", "tg://")):
                buttons.append(InlineKeyboardButton(label, url=url))
        if buttons:
            rows.append(buttons)
    return InlineKeyboardMarkup(rows) if rows else None


async def _attachment_input(attachment: dict[str, Any]) -> tuple[Any, str]:
    file_id = str(attachment.get("file_id") or "").strip()
    kind = str(attachment.get("type") or "document").strip().lower()
    if file_id:
        return file_id, kind
    storage_id = str(attachment.get("storage_id") or "").strip()
    if not storage_id:
        raise ValueError("Automation attachment is unavailable.")
    from modules.support_attachment_storage import attachment_record, read_support_attachment
    row = await async_with_db(lambda db: attachment_record(db, storage_id))
    if not row:
        raise ValueError("Automation attachment was not found.")
    data = read_support_attachment(row)
    if data is None:
        raise ValueError("Automation attachment is corrupted or missing.")
    filename = str(row.get("file_name") or f"attachment-{storage_id}")
    return InputFile(io.BytesIO(data), filename=filename), kind


async def _deliver_payload(bot: Bot, recipient: int, payload: dict[str, Any]) -> None:
    text = str(payload.get("text") or "").strip()
    parse_mode = ParseMode.HTML if str(payload.get("parse_mode") or "HTML") == "HTML" else None
    markup = _reply_markup(payload)
    attachment = payload.get("attachment") if isinstance(payload.get("attachment"), dict) else None
    if not attachment:
        if not text:
            raise ValueError("Automation message text is empty.")
        await bot.send_message(
            chat_id=recipient, text=text[:4096], parse_mode=parse_mode,
            disable_web_page_preview=bool(payload.get("disable_web_page_preview", True)), reply_markup=markup,
        )
        return
    media, kind = await _attachment_input(attachment)
    caption = text[:1000] if text else str(attachment.get("caption") or "")[:1000]
    kwargs = {"chat_id": recipient, "caption": caption or None, "parse_mode": parse_mode, "reply_markup": markup}
    if kind == "photo":
        await bot.send_photo(photo=media, **kwargs)
    elif kind == "video":
        await bot.send_video(video=media, **kwargs)
    elif kind == "voice":
        await bot.send_voice(voice=media, **kwargs)
    elif kind == "audio":
        await bot.send_audio(audio=media, **kwargs)
    else:
        await bot.send_document(document=media, **kwargs)


async def deliver_automation_outbox(
    bot: Bot,
    *,
    limit: int = 50,
) -> dict[str, int]:
    """Deliver claimed messages with consistent retry and dead-letter behavior."""
    counts = {"sent": 0, "failed": 0}
    rows = await async_with_db(lambda db: claim_due_automation_messages(db, limit=limit))
    for row in rows:
        payload = dict(row.get("payload") or {})
        try:
            await _deliver_payload(bot, int(str(row.get("recipient_id") or "")), payload)
            await async_with_db(
                lambda db, row_id=str(row["id"]): mark_automation_message_result(
                    db,
                    row_id,
                    success=True,
                )
            )
            counts["sent"] += 1
        except Exception as exc:
            logger.warning(
                "Automation outbox delivery failed id=%s kind=%s error=%s",
                row.get("id"),
                row.get("kind"),
                exc.__class__.__name__,
            )
            await async_with_db(
                lambda db, row_id=str(row["id"]), error=exc: mark_automation_message_result(
                    db,
                    row_id,
                    success=False,
                    detail=f"{error.__class__.__name__}: {error}",
                )
            )
            counts["failed"] += 1
    return counts

