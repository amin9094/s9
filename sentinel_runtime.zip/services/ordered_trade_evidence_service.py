"""Bounded public trade evidence for an OB's original departure candle."""

from __future__ import annotations

from decimal import Decimal as D
from hashlib import sha256
import asyncio
import threading
import time

from repositories.v2.common import json_dump


_RATE_LOCK = threading.Lock()
_NEXT_REQUEST = 0.0


async def _public_history_slot():
    """Space requests across event loops below the public endpoint rate limit."""
    global _NEXT_REQUEST
    with _RATE_LOCK:
        now = time.monotonic()
        slot = max(now, _NEXT_REQUEST)
        _NEXT_REQUEST = slot + .12
    await asyncio.sleep(max(0, slot - now))


def departure_from_trades(ob, departure, rows, *, available_ms):
    if departure.provider != "okx" or departure.product != "spot" or departure.volume_kind != "traded":
        raise ValueError("ORDERED_TRADE_MARKET_UNSUPPORTED")
    if (ob.symbol, ob.provider, ob.venue, ob.product, ob.timeframe) != (
        departure.symbol, departure.provider, departure.venue, departure.product, departure.timeframe
    ) or not departure.is_closed or available_ms < departure.end_ms or not departure.symbol.endswith("USDT"):
        raise ValueError("ORDERED_TRADE_PROVENANCE_INVALID")
    pair = departure.symbol[:-4] + "-USDT"
    trades = []
    seen = set()
    for row in rows:
        if row.get("instId") != pair:
            raise ValueError("ORDERED_TRADE_MARKET_MISMATCH")
        key = str(row["tradeId"])
        stamp, value, quantity = int(row["ts"]), D(row["px"]), D(row["sz"])
        if key in seen or not value.is_finite() or value <= 0 or not quantity.is_finite() or quantity <= 0:
            raise ValueError("ORDERED_TRADE_VALUES_OR_DUPLICATES_INVALID")
        seen.add(key)
        if departure.start_ms <= stamp < departure.end_ms:
            trades.append((stamp, int(key), value, quantity))
    trades.sort()
    if not trades or sum(t[3] for t in trades) != departure.volume:
        raise ValueError("ORDERED_TRADE_VOLUME_COVERAGE_UNPROVEN")
    if (trades[0][2], max(t[2] for t in trades), min(t[2] for t in trades), trades[-1][2]) != (
        departure.open, departure.high, departure.low, departure.close
    ):
        raise ValueError("ORDERED_TRADE_OHLC_DISAGREEMENT")
    direction = "BUY" if departure.close > departure.open else "SELL"
    exit_index = next((i for i, t in enumerate(trades)
                       if (t[2] > ob.high if direction == "BUY" else t[2] < ob.low)), None)
    if exit_index is None:
        raise ValueError("ORDERED_TRADE_NO_FULL_DEPARTURE")
    no_reentry = not any(ob.low <= t[2] <= ob.high for t in trades[exit_index + 1:])
    return {"ob_source_id": ob.source_id, "departure_source_id": departure.source_id,
            "fully_exited_ms": trades[exit_index][0], "no_reentry": no_reentry, "complete_coverage": True,
            "observed_through_ms": departure.end_ms, "available_ms": available_ms,
            "basis": "ORDERED_EXECUTED_TRADES_RECONCILED_TO_CLOSED_NATIVE_CANDLE",
            "trade_count": len(trades), "trade_ids": [str(t[1]) for t in trades],
            "content_hash": sha256(json_dump(rows).encode()).hexdigest(), "is_bid_ask_fill_proof": False}


async def okx_departure_proof(ob, departure, *, max_pages=15):
    from services.canonical_market_service import _request

    if departure.provider != "okx" or not departure.symbol.endswith("USDT"):
        return None
    pair = departure.symbol[:-4] + "-USDT"
    rows, cursor, pagination_type = {}, departure.end_ms, "2"
    for _ in range(max(1, min(15, max_pages))):
        await _public_history_slot()
        result = await _request("https://www.okx.com/api/v5/market/history-trades",
                                {"instId": pair, "type": pagination_type, "after": str(cursor), "limit": "100"})
        if result.get("code") != "0" or not result.get("data"):
            return None
        page = result["data"]
        for row in page:
            rows[str(row["tradeId"])] = row
        oldest = min(page, key=lambda row: (int(row["ts"]), int(row["tradeId"])))
        if int(oldest["ts"]) < departure.start_ms:
            try:
                return departure_from_trades(ob, departure, list(rows.values()), available_ms=int(time.time() * 1000))
            except ValueError:
                return None
        next_cursor = int(oldest["tradeId"])
        if pagination_type == "1" and next_cursor >= cursor:
            return None
        cursor, pagination_type = next_cursor, "1"
    return None  # A capped/incomplete tape cannot become a proof.
