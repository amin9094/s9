from __future__ import annotations

from typing import Any

from core.db import read_db_sections, with_db, with_db_read
from core.utils import utc_iso
from config import SETTINGS, is_primary_admin
from modules.admin_access import (
    PERMISSION_AI_CHANNEL_CONTENT,
    PERMISSION_AI_COMMAND_CENTER,
    PERMISSION_AI_CONFIRM_STANDARD_ACTIONS,
    PERMISSION_AI_CONFIRM_SENSITIVE_ACTIONS,
    PERMISSION_AI_CRM_ANALYSIS,
    PERMISSION_AI_MANAGEMENT_REPORTS,
    PERMISSION_AI_RISK_SUPERVISION,
    PERMISSION_AI_SIGNAL_ANALYSIS,
    PERMISSION_AI_SYSTEM_MONITORING,
    PERMISSION_AI_TICKET_ASSISTANT,
    PERMISSION_AI_USER_BEHAVIOR,
    PERMISSION_ANNOUNCEMENTS,
    PERMISSION_CAMPAIGNS,
    PERMISSION_SYSTEM_CONTROL,
    PERMISSION_SIGNAL_TEMPLATES,
    PERMISSION_CHANNEL_MANAGEMENT,
    PERMISSION_CHANNEL_POSTS_EDIT,
    PERMISSION_CHANNEL_POSTS_DELETE,
    PERMISSION_CHANNEL_PIN_MANAGE,
    PERMISSION_SIGNALS,
    PERMISSION_ADMIN_MANAGEMENT,
    PERMISSION_EDUCATION,
    PERMISSION_PAID_EDUCATION,
    PERMISSION_MISSIONS,
    PERMISSION_CONTESTS,
    PERMISSION_EDUCATION_CREATE,
    PERMISSION_EDUCATION_EDIT,
    PERMISSION_EDUCATION_PUBLISH,
    PERMISSION_EDUCATION_DELETE,
    PERMISSION_EDUCATION_PRICE_MANAGE,
    PERMISSION_MISSION_CREATE,
    PERMISSION_MISSION_PUBLISH,
    PERMISSION_MISSION_REWARD_MANAGE,
    PERMISSION_MISSION_DELETE,
    PERMISSION_CONTEST_PUBLISH,
    PERMISSION_CONTEST_END,
    PERMISSION_SIGNAL_APPROVE,
    PERMISSION_SIGNAL_BOARD_MANAGE,
    approve_delegated_admin,
    reject_delegated_admin,
    PERMISSION_TICKETS,
    AI_SCOPE_PERMISSIONS,
    has_permission,
)
from modules.campaign_studio import create_marketing_campaign
from modules.admin_command_os import admin_command_center_snapshot, admin_global_search
from modules.automation_v2 import (
    create_automation_rule, list_automation_rules, process_automation_event, update_automation_rule,
)
from modules.gemini_ads import (
    ai_ad_summary, approve_ai_ad, create_ai_ad_campaign, generate_ai_ad_image, schedule_ai_ad,
)
from modules.admin_ai_assets import (
    apply_asset_to_signal_template, enqueue_channel_operation, enqueue_signal_refresh,
    reset_ai_signal_template, update_signal_template_layout,
)
from modules.gemini_admin_control import set_ai_execution_enabled
from modules.ai_action_firewall import is_human_confirmation
from modules.ai_undo import restore_undo_snapshot
from modules.ai_signal_lab import create_strategy_version, promote_candidate_to_review, queue_shadow_scan
from modules.education import create_lesson, delete_lesson, set_lesson_status, update_lesson
from modules.missions import create_mission, delete_mission, toggle_mission, update_mission
from modules.contest import (
    end_candle_contest, end_chart_contest, end_price_contest, start_candle_contest,
    start_chart_contest, start_price_contest,
)
from modules.gemini_ai import (
    admin_ai_query, build_daily_manager_report, gemini_live_health, reject_ai_proposal,
    set_user_ai_access_mode, toggle_user_ai_access_mode, user_ai_review, normalize_ai_control_target, resolve_ai_identifier,
)
from modules.operations_governance import create_governance_request
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action

_SCOPE_PERMISSION = AI_SCOPE_PERMISSIONS



def _permissions_snapshot() -> dict[str, Any]:
    return read_db_sections(("delegated_admins", "admin_shifts", "users"))


def _require(ctx: ActionContext, *permissions: str) -> None:
    db = _permissions_snapshot()
    if not any(has_permission(db, ctx.user_id, permission) for permission in permissions):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")


def _require_human(ctx: ActionContext) -> None:
    if not is_human_confirmation(ctx.transport):
        raise PermissionError("HUMAN_CONFIRMATION_REQUIRED")


@action("admin_command_center_snapshot", mutation=False, idempotency_required=False, admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_command_center_snapshot_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_AI_COMMAND_CENTER, PERMISSION_AI_MANAGEMENT_REPORTS)
    return with_db_read(lambda db: admin_command_center_snapshot(db, ctx.user_id))


@action("admin_global_search", mutation=False, idempotency_required=False, admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_global_search_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_AI_COMMAND_CENTER)
    query = str(ctx.payload.get("query") or "").strip()
    return with_db_read(lambda db: admin_global_search(
        db, ctx.user_id, query, domain=str(ctx.payload.get("domain") or ""),
        limit=int(ctx.payload.get("limit") or 30),
    ))


@action("automation_v2_rule_list", mutation=False, idempotency_required=False, admin_only=True, permission="automations")
def automation_v2_rule_list_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, "automations")
    enabled = ctx.payload.get("enabled")
    normalized = None if enabled is None else bool(enabled)
    return with_db_read(lambda db: {"rules": list_automation_rules(db, enabled=normalized)})


@action("automation_v2_rule_create", admin_only=True, permission="automations")
def automation_v2_rule_create_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, "automations", PERMISSION_AI_CONFIRM_STANDARD_ACTIONS)
    return with_db(lambda db: {"rule": create_automation_rule(
        db, name=str(ctx.payload.get("name") or ""), trigger=str(ctx.payload.get("trigger") or ""),
        conditions=ctx.payload.get("conditions"), actions=list(ctx.payload.get("actions") or []),
        guards=ctx.payload.get("guards") if isinstance(ctx.payload.get("guards"), dict) else {},
        actor_id=ctx.user_id, enabled=bool(ctx.payload.get("enabled", False)),
    )})


@action("automation_v2_rule_update", admin_only=True, permission="automations")
def automation_v2_rule_update_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, "automations", PERMISSION_AI_CONFIRM_STANDARD_ACTIONS)
    changes = ctx.payload.get("changes") if isinstance(ctx.payload.get("changes"), dict) else {}
    return with_db(lambda db: {"rule": update_automation_rule(db, str(ctx.payload.get("rule_id") or ""), changes, actor_id=ctx.user_id)})


@action("automation_v2_rule_test", admin_only=True, permission="automations")
def automation_v2_rule_test_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, "automations")
    event = dict(ctx.payload.get("event") or {}) if isinstance(ctx.payload.get("event"), dict) else {}
    event["dry_run"] = True
    return with_db(lambda db: process_automation_event(
        db, str(ctx.payload.get("trigger") or "custom"), event,
        actor_id=ctx.user_id, test_rule_id=str(ctx.payload.get("rule_id") or ""),
    ))


@action("ai_ad_campaign_create", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def ai_ad_campaign_create_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_CAMPAIGNS, PERMISSION_AI_CHANNEL_CONTENT)
    return with_db(lambda db: {"campaign": create_ai_ad_campaign(
        db, actor_id=ctx.user_id, name=str(ctx.payload.get("name") or ""),
        product=str(ctx.payload.get("product") or ""), objective=str(ctx.payload.get("objective") or ""),
        audience=str(ctx.payload.get("audience") or "all"), delivery=str(ctx.payload.get("delivery") or "draft"),
        tone=str(ctx.payload.get("tone") or "premium"), call_to_action=str(ctx.payload.get("call_to_action") or ""),
        language=str(ctx.payload.get("language") or "fa"), brand_notes=str(ctx.payload.get("brand_notes") or ""),
    )})


@action("ai_ad_image_generate", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def ai_ad_image_generate_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_CAMPAIGNS, PERMISSION_AI_CHANNEL_CONTENT)
    return with_db(lambda db: generate_ai_ad_image(
        db, str(ctx.payload.get("campaign_id") or ""), actor_id=ctx.user_id,
        prompt=str(ctx.payload.get("prompt") or ""), aspect_ratio=str(ctx.payload.get("aspect_ratio") or "1:1"),
    ))


@action("ai_ad_summary", mutation=False, idempotency_required=False, admin_only=True, permission=PERMISSION_CAMPAIGNS)
def ai_ad_summary_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_CAMPAIGNS)
    return with_db_read(lambda db: {"campaign": ai_ad_summary(db, str(ctx.payload.get("campaign_id") or ""))})


@action("ai_ad_approve", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def ai_ad_approve_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    _require(ctx, PERMISSION_CAMPAIGNS, PERMISSION_AI_CONFIRM_SENSITIVE_ACTIONS)
    return with_db(lambda db: {"campaign": approve_ai_ad(db, str(ctx.payload.get("campaign_id") or ""), actor_id=ctx.user_id)})


@action("ai_ad_schedule", admin_only=True, permission=PERMISSION_CAMPAIGNS)
def ai_ad_schedule_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    _require(ctx, PERMISSION_CAMPAIGNS, PERMISSION_AI_CONFIRM_SENSITIVE_ACTIONS)
    return with_db(lambda db: {"campaign": schedule_ai_ad(
        db, str(ctx.payload.get("campaign_id") or ""), scheduled_for=ctx.payload.get("scheduled_for"),
        actor_id=ctx.user_id, priority=int(ctx.payload.get("priority") or 3),
    )})


@action("user_ai_query")
def user_ai_query_action(ctx: ActionContext) -> dict[str, Any]:
    # Backwards-compatible action name. Users do not get free-form chat; the
    # backend runs the fixed account/behavior review only.
    return user_ai_review(ctx.user_id, language=str(ctx.payload.get("language") or "fa"))


@action("user_ai_review")
def user_ai_review_action(ctx: ActionContext) -> dict[str, Any]:
    return user_ai_review(ctx.user_id, language=str(ctx.payload.get("language") or "fa"))


@action("admin_ai_query", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_query_action(ctx: ActionContext) -> dict[str, Any]:
    scope = str(ctx.payload.get("scope") or "management").strip().lower()
    permission = _SCOPE_PERMISSION.get(scope)
    if not permission:
        raise ValueError("AI_SCOPE_INVALID")
    _require(ctx, permission)
    return admin_ai_query(
        ctx.user_id,
        str(ctx.payload.get("question") or ""),
        scope=scope,
        target_user_id=ctx.payload.get("target_user_id"),
        language=str(ctx.payload.get("language") or "fa"),
    )


@action("admin_ai_health_test", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_health_test_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_AI_SYSTEM_MONITORING)
    return {"health": gemini_live_health(force=True, generation_test=bool(ctx.payload.get("generation_test", True)))}


@action("admin_ai_user_access_toggle", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_user_access_toggle_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_AI_CONFIRM_STANDARD_ACTIONS)
    mode = str(ctx.payload.get("mode") or "").strip().lower()
    row = set_user_ai_access_mode(ctx.user_id, mode) if mode else toggle_user_ai_access_mode(ctx.user_id)
    return {"settings": row}


@action("admin_ai_daily_report", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_daily_report_action(ctx: ActionContext) -> dict[str, Any]:
    _require(ctx, PERMISSION_AI_MANAGEMENT_REPORTS)
    return build_daily_manager_report(
        ctx.user_id, language=str(ctx.payload.get("language") or "fa"),
        force=bool(ctx.payload.get("force", False)),
    )


@action("admin_ai_proposal_reject", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_proposal_reject_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    _require(ctx, PERMISSION_AI_CONFIRM_STANDARD_ACTIONS)
    return reject_ai_proposal(
        ctx.payload.get("proposal_id"), ctx.user_id,
        reason=str(ctx.payload.get("reason") or ""),
    )


def _approve_proposal(db: dict[str, Any], proposal_id: int, actor_id: str) -> dict[str, Any]:
    proposal = next(
        (row for row in db.setdefault("ai_pending_proposals", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == proposal_id),
        None,
    )
    if not proposal:
        raise ValueError("AI_PROPOSAL_NOT_FOUND")
    if str(proposal.get("status") or "pending") != "pending":
        raise ValueError("AI_PROPOSAL_ALREADY_RESOLVED")
    kind = str(proposal.get("type") or "")
    payload = proposal.get("payload") if isinstance(proposal.get("payload"), dict) else {}
    result: dict[str, Any]
    if kind == "channel_draft":
        title = str(payload.get("title") or proposal.get("title") or "پیش‌نویس هوش مصنوعی")[:160]
        message = str(payload.get("message") or payload.get("text") or proposal.get("reason") or "").strip()[:3500]
        if len(message) < 3:
            raise ValueError("AI_DRAFT_CONTENT_REQUIRED")
        row = {
            "id": f"AI-DRAFT-{proposal_id}", "title": title, "text": message,
            "status": "draft", "source": "gemini_admin_copilot", "created_by": actor_id,
            "created_at": utc_iso(), "ai_proposal_id": proposal_id,
        }
        db.setdefault("announcements", []).append(row)
        result = {"draft": row}
    elif kind == "crm_campaign_draft":
        row = create_marketing_campaign(
            db,
            name=str(payload.get("name") or proposal.get("title") or "کمپین هوشمند")[:100],
            category=str(payload.get("category") or "retention"),
            audience=str(payload.get("audience") or "inactive_user"),
            message=str(payload.get("message") or proposal.get("reason") or "پیام پیشنهادی Sentinel")[:3500],
            delivery="draft", created_by=actor_id,
            objective=str(payload.get("objective") or proposal.get("reason") or "")[:500],
            tracking={"source": "gemini_admin_copilot", "medium": "telegram", "creative": f"ai-{proposal_id}"},
        )
        result = {"campaign": row}
    elif kind == "ticket_reply_draft":
        ticket_id = resolve_ai_identifier(payload.get("ticket_id"), "ticket")
        if not ticket_id:
            raise ValueError("TICKET_ID_REQUIRED")
        row = {
            "id": f"AI-TICKET-{proposal_id}", "ticket_id": ticket_id,
            "text": str(payload.get("text") or payload.get("message") or proposal.get("reason") or "")[:3000],
            "status": "draft", "created_by": actor_id, "created_at": utc_iso(),
        }
        db.setdefault("ai_ticket_drafts", []).append(row)
        result = {"ticket_draft": row}
    elif kind == "module_change_proposal":
        module, field = normalize_ai_control_target(payload.get("module"), payload.get("field"))
        request = create_governance_request(
            db, action="control_change", payload={"module": module, "field": field, "value": payload.get("value")},
            requested_by=actor_id, risk_level="high", title=str(proposal.get("title") or "AI control proposal")[:200],
            description=str(proposal.get("reason") or "")[:1000], target_type="control_field",
            target_id=f"{module}.{field}", source="gemini_admin_copilot",
            dedupe_key=f"ai-control:{proposal_id}:{module}:{field}",
        )
        result = {"governance_request": request}
    elif kind == "report_note":
        row = {
            "id": f"AI-NOTE-{proposal_id}", "title": str(proposal.get("title") or "گزارش هوش مصنوعی")[:200],
            "text": str(payload.get("text") or proposal.get("reason") or "")[:5000],
            "created_by": actor_id, "created_at": utc_iso(),
        }
        db.setdefault("ai_report_notes", []).append(row)
        result = {"report_note": row}
    else:
        raise ValueError("AI_PROPOSAL_TYPE_BLOCKED")
    proposal.update({"status": "approved", "resolved_by": actor_id, "resolved_at": utc_iso(), "result": result})
    db.setdefault("ai_audit_log", []).append({
        "action": "ai_proposal_approve", "proposal_id": proposal_id,
        "proposal_type": kind, "actor_id": actor_id, "created_at": utc_iso(),
    })
    db["ai_audit_log"] = db["ai_audit_log"][-5000:]
    return {"proposal": dict(proposal), **result}


@action("admin_ai_proposal_approve", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_proposal_approve_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    proposal_id = int(ctx.payload.get("proposal_id") or 0)
    if proposal_id <= 0:
        raise ValueError("AI_PROPOSAL_ID_REQUIRED")
    _require(ctx, PERMISSION_AI_CONFIRM_STANDARD_ACTIONS)
    snapshot = read_db_sections(("ai_pending_proposals",))
    proposal = next((row for row in snapshot.get("ai_pending_proposals", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == proposal_id), None)
    if not proposal:
        raise ValueError("AI_PROPOSAL_NOT_FOUND")
    kind = str(proposal.get("type") or "")
    required = {
        "channel_draft": (PERMISSION_AI_CHANNEL_CONTENT, PERMISSION_ANNOUNCEMENTS),
        "crm_campaign_draft": (PERMISSION_AI_CRM_ANALYSIS, PERMISSION_CAMPAIGNS),
        "ticket_reply_draft": (PERMISSION_AI_TICKET_ASSISTANT, PERMISSION_TICKETS),
        "module_change_proposal": (PERMISSION_SYSTEM_CONTROL,),
        "report_note": (PERMISSION_AI_MANAGEMENT_REPORTS,),
    }.get(kind)
    if not required:
        raise ValueError("AI_PROPOSAL_TYPE_BLOCKED")
    for permission in required:
        _require(ctx, permission)
    return with_db(lambda db: _approve_proposal(db, proposal_id, ctx.user_id))


@action("admin_ai_execution_toggle", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_execution_toggle_action(ctx: ActionContext) -> dict[str, Any]:
    if not is_primary_admin(ctx.user_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    return {"settings": set_ai_execution_enabled(ctx.user_id, bool(ctx.payload.get("enabled", True)))}


@action("admin_ai_command_approve", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_command_approve_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    if not is_primary_admin(ctx.user_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    command_id = int(ctx.payload.get("command_id") or 0)
    if command_id <= 0:
        raise ValueError("AI_ADMIN_COMMAND_ID_REQUIRED")
    from services.ai_control_service import approve_queued_ai_command
    return approve_queued_ai_command(command_id, ctx.user_id, human_confirmation_source=str(ctx.transport.get("source") or ""))


@action("admin_ai_command_reject", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_command_reject_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    if not is_primary_admin(ctx.user_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    command_id = int(ctx.payload.get("command_id") or 0)
    if command_id <= 0:
        raise ValueError("AI_ADMIN_COMMAND_ID_REQUIRED")
    from services.ai_control_service import reject_queued_ai_command
    return {"command": reject_queued_ai_command(command_id, ctx.user_id, reason=str(ctx.payload.get("reason") or ""), human_confirmation_source=str(ctx.transport.get("source") or ""))}


@action("delegated_admin_approve", admin_only=True, permission=PERMISSION_ADMIN_MANAGEMENT)
def delegated_admin_approve_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    if not is_primary_admin(ctx.user_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    user_id = ctx.payload.get("user_id")
    if not user_id:
        raise ValueError("ADMIN_ID_REQUIRED")
    return with_db(lambda db: {"admin": approve_delegated_admin(db, user_id, ctx.user_id)})


@action("delegated_admin_reject", admin_only=True, permission=PERMISSION_ADMIN_MANAGEMENT)
def delegated_admin_reject_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    if not is_primary_admin(ctx.user_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    user_id = ctx.payload.get("user_id")
    if not user_id:
        raise ValueError("ADMIN_ID_REQUIRED")
    return with_db(lambda db: {"admin": reject_delegated_admin(db, user_id, ctx.user_id, reason=str(ctx.payload.get("reason") or ""))})


@action("ai_signal_template_apply_asset", admin_only=True, permission=PERMISSION_SIGNAL_TEMPLATES)
def ai_signal_template_apply_asset_action(ctx: ActionContext) -> dict[str, Any]:
    return with_db(lambda db: apply_asset_to_signal_template(
        db, ctx.user_id, side=str(ctx.payload.get("side") or ""),
        asset_id=ctx.payload.get("asset_id") or "latest", autodetect=bool(ctx.payload.get("autodetect", True)),
    ))


@action("ai_signal_template_layout_update", admin_only=True, permission=PERMISSION_SIGNAL_TEMPLATES)
def ai_signal_template_layout_update_action(ctx: ActionContext) -> dict[str, Any]:
    return with_db(lambda db: update_signal_template_layout(db, ctx.user_id, dict(ctx.payload)))


@action("ai_signal_template_reset", admin_only=True, permission=PERMISSION_SIGNAL_TEMPLATES)
def ai_signal_template_reset_action(ctx: ActionContext) -> dict[str, Any]:
    return with_db(lambda db: reset_ai_signal_template(
        db, ctx.user_id, side=str(ctx.payload.get("side") or ""),
        background=bool(ctx.payload.get("background", True)), layout=bool(ctx.payload.get("layout", True)),
    ))


@action("ai_channel_message_operation", admin_only=True)
def ai_channel_message_operation_action(ctx: ActionContext) -> dict[str, Any]:
    operation = str(ctx.payload.get("operation") or "").strip().lower()
    if operation in {"edit_text", "edit_media"}:
        _require(ctx, PERMISSION_CHANNEL_POSTS_EDIT)
    elif operation == "delete":
        _require(ctx, PERMISSION_CHANNEL_POSTS_DELETE)
    elif operation in {"pin", "unpin"}:
        _require(ctx, PERMISSION_CHANNEL_PIN_MANAGE)
    else:
        raise ValueError("CHANNEL_OPERATION_INVALID")
    return with_db(lambda db: {"operation": enqueue_channel_operation(db, ctx.user_id, dict(ctx.payload))})


@action("ai_signal_refresh_channel", admin_only=True, permission=PERMISSION_SIGNAL_BOARD_MANAGE)
def ai_signal_refresh_channel_action(ctx: ActionContext) -> dict[str, Any]:
    signal_id = ctx.payload.get("signal_id")
    if not signal_id:
        raise ValueError("SIGNAL_ID_REQUIRED")
    return with_db(lambda db: {"refresh": enqueue_signal_refresh(db, ctx.user_id, signal_id)})


@action("ai_lesson_create", admin_only=True, permission=PERMISSION_EDUCATION_CREATE)
def ai_lesson_create_action(ctx: ActionContext) -> dict[str, Any]:
    access_type = str(ctx.payload.get("access_type") or "free").lower()
    paid = access_type not in {"free", "public"}
    if paid:
        if not (is_primary_admin(ctx.user_id) and SETTINGS.gemini_primary_admin_full_bot_access):
            _require(ctx, PERMISSION_EDUCATION_PRICE_MANAGE)
        price = max(0, int(ctx.payload.get("price") or 0))
        if price <= 0:
            raise ValueError("PAID_LESSON_PRICE_REQUIRED")
    else:
        access_type = "free"
        price = 0
    return with_db(lambda db: {"lesson": create_lesson(
        db,
        category=str(ctx.payload.get("category") or "عمومی"),
        title=str(ctx.payload.get("title") or ""),
        access_type=access_type,
        price=price,
        text=str(ctx.payload.get("text") or ""),
        course=str(ctx.payload.get("course") or ""),
        chapter=str(ctx.payload.get("chapter") or "فصل ۱"),
        duration_minutes=int(ctx.payload.get("duration_minutes") or 5),
        status=str(ctx.payload.get("status") or "draft"),
        actor_id=ctx.user_id,
    )})


@action("ai_lesson_update", admin_only=True, permission=PERMISSION_EDUCATION_EDIT)
def ai_lesson_update_action(ctx: ActionContext) -> dict[str, Any]:
    lesson_id = ctx.payload.get("lesson_id")
    if not lesson_id:
        raise ValueError("LESSON_ID_REQUIRED")
    changes = {key: ctx.payload[key] for key in (
        "category", "course", "chapter", "title", "text", "duration_minutes", "active", "position", "quiz",
    ) if key in ctx.payload}
    if "access_type" in ctx.payload or "price" in ctx.payload:
        _require(ctx, PERMISSION_EDUCATION_PRICE_MANAGE)
        if "access_type" in ctx.payload:
            changes["access_type"] = str(ctx.payload.get("access_type") or "free")
        if "price" in ctx.payload:
            changes["price"] = max(0, int(ctx.payload.get("price") or 0))
    if "status" in ctx.payload:
        _require(ctx, PERMISSION_EDUCATION_PUBLISH)
        changes["status"] = str(ctx.payload.get("status") or "draft")
    return with_db(lambda db: {"lesson": update_lesson(db, lesson_id, **changes)})


@action("ai_lesson_status", admin_only=True, permission=PERMISSION_EDUCATION_PUBLISH)
def ai_lesson_status_action(ctx: ActionContext) -> dict[str, Any]:
    return with_db(lambda db: {"lesson": set_lesson_status(db, ctx.payload.get("lesson_id"), str(ctx.payload.get("status") or "draft"))})


@action("ai_lesson_delete", admin_only=True, permission=PERMISSION_EDUCATION_DELETE)
def ai_lesson_delete_action(ctx: ActionContext) -> dict[str, Any]:
    removed = with_db(lambda db: delete_lesson(db, ctx.payload.get("lesson_id")))
    if not removed:
        raise ValueError("LESSON_NOT_FOUND")
    return {"lesson": removed}


@action("ai_idea_create", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def ai_idea_create_action(ctx: ActionContext) -> dict[str, Any]:
    """Persist a Gemini-created idea in the owner's actionable backlog."""
    _require(ctx, PERMISSION_AI_COMMAND_CENTER)
    title = str(ctx.payload.get("title") or "").strip()[:160]
    description = str(ctx.payload.get("description") or "").strip()[:4000]
    if not title or not description:
        raise ValueError("AI_IDEA_TITLE_AND_DESCRIPTION_REQUIRED")
    raw_steps = ctx.payload.get("implementation_steps")
    steps = [str(item).strip()[:500] for item in raw_steps if str(item).strip()] if isinstance(raw_steps, list) else []

    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        idea_id = int(db.get("next_ai_idea_id", 1) or 1)
        row = {
            "id": idea_id,
            "title": title,
            "category": str(ctx.payload.get("category") or "product")[:80],
            "description": description,
            "implementation_steps": steps[:20],
            "priority": str(ctx.payload.get("priority") or "medium")[:24],
            "related_feature": str(ctx.payload.get("related_feature") or "")[:120],
            "status": str(ctx.payload.get("status") or "backlog")[:24],
            "created_by": str(ctx.user_id),
            "created_at": utc_iso(),
            "source": "gemini_primary_admin",
        }
        db.setdefault("ai_idea_backlog", []).append(row)
        db["ai_idea_backlog"] = db["ai_idea_backlog"][-2000:]
        db["next_ai_idea_id"] = idea_id + 1
        db.setdefault("ai_audit_log", []).append({
            "action": "ai_idea_create", "idea_id": idea_id,
            "actor_id": str(ctx.user_id), "created_at": utc_iso(),
        })
        db["ai_audit_log"] = db["ai_audit_log"][-5000:]
        return {"idea": dict(row), "message": f"idea {idea_id} saved"}

    return with_db(mutate)


@action("ai_mission_create", admin_only=True, permission=PERMISSION_MISSION_CREATE)
def ai_mission_create_action(ctx: ActionContext) -> dict[str, Any]:
    reward = int(ctx.payload.get("reward") or 0)
    random_bonus_max = int(ctx.payload.get("random_bonus_max") or 0)
    if reward > 0 or random_bonus_max > 0:
        _require(ctx, PERMISSION_MISSION_REWARD_MANAGE)
    return with_db(lambda db: {"mission": create_mission(
        db, title=str(ctx.payload.get("title") or ""), reward=reward,
        event=str(ctx.payload.get("event") or "daily_login"), target=int(ctx.payload.get("target") or 1),
        period=str(ctx.payload.get("period") or "one_time"), description=str(ctx.payload.get("description") or ""),
        active=bool(ctx.payload.get("active", True)), starts_at=ctx.payload.get("starts_at"),
        ends_at=ctx.payload.get("ends_at"), badge=str(ctx.payload.get("badge") or ""),
        random_bonus_max=random_bonus_max, actor_id=ctx.user_id,
    )})


@action("ai_mission_update", admin_only=True, permission=PERMISSION_MISSION_CREATE)
def ai_mission_update_action(ctx: ActionContext) -> dict[str, Any]:
    mission_id = ctx.payload.get("mission_id")
    if not mission_id:
        raise ValueError("MISSION_ID_REQUIRED")
    changes = {key: ctx.payload[key] for key in (
        "title", "description", "event", "target", "period", "starts_at", "ends_at", "badge",
    ) if key in ctx.payload}
    if "reward" in ctx.payload or "random_bonus_max" in ctx.payload:
        _require(ctx, PERMISSION_MISSION_REWARD_MANAGE)
        if "reward" in ctx.payload:
            changes["reward"] = max(0, int(ctx.payload.get("reward") or 0))
        if "random_bonus_max" in ctx.payload:
            changes["random_bonus_max"] = max(0, int(ctx.payload.get("random_bonus_max") or 0))
    if "active" in ctx.payload:
        _require(ctx, PERMISSION_MISSION_PUBLISH)
        changes["active"] = bool(ctx.payload.get("active"))
    return with_db(lambda db: {"mission": update_mission(db, mission_id, **changes)})


@action("ai_mission_toggle", admin_only=True, permission=PERMISSION_MISSION_PUBLISH)
def ai_mission_toggle_action(ctx: ActionContext) -> dict[str, Any]:
    return with_db(lambda db: {"mission": toggle_mission(db, ctx.payload.get("mission_id"))})


@action("ai_mission_delete", admin_only=True, permission=PERMISSION_MISSION_DELETE)
def ai_mission_delete_action(ctx: ActionContext) -> dict[str, Any]:
    removed = with_db(lambda db: delete_mission(db, ctx.payload.get("mission_id")))
    if not removed:
        raise ValueError("MISSION_NOT_FOUND")
    return {"mission": removed}


@action("ai_contest_start", admin_only=True, permission=PERMISSION_CONTEST_PUBLISH)
def ai_contest_start_action(ctx: ActionContext) -> dict[str, Any]:
    kind = str(ctx.payload.get("kind") or "price").lower()
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        if kind == "price":
            row = start_price_contest(
                db, str(ctx.payload.get("symbol") or "XAUUSD"), int(ctx.payload.get("duration_minutes") or 60),
                question=str(ctx.payload.get("question") or ""), reward_points=int(ctx.payload.get("reward_points") or 5),
            )
        elif kind == "chart":
            row = start_chart_contest(
                db, str(ctx.payload.get("question") or "جهت بعدی بازار؟"), None,
                duration_minutes=int(ctx.payload.get("duration_minutes") or 1440), reward_points=int(ctx.payload.get("reward_points") or 5),
            )
        elif kind == "candle":
            row = start_candle_contest(db, duration_minutes=int(ctx.payload.get("duration_minutes") or 1440))
        else:
            raise ValueError("CONTEST_KIND_INVALID")
        return {"contest": row}
    return with_db(mutate)


@action("ai_contest_end", admin_only=True, permission=PERMISSION_CONTEST_END)
def ai_contest_end_action(ctx: ActionContext) -> dict[str, Any]:
    kind = str(ctx.payload.get("kind") or "price").lower()
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        if kind == "price":
            contest, results = end_price_contest(db, float(ctx.payload.get("final_price")))
        elif kind == "chart":
            contest, results = end_chart_contest(db, str(ctx.payload.get("correct_choice") or "").upper())
        elif kind == "candle":
            contest, results = end_candle_contest(db, float(ctx.payload.get("final_price")))
        else:
            raise ValueError("CONTEST_KIND_INVALID")
        if not contest:
            raise ValueError("ACTIVE_CONTEST_NOT_FOUND")
        return {"contest": contest, "results": results}
    return with_db(mutate)


@action("admin_ai_undo_restore", admin_only=True, permission=PERMISSION_AI_COMMAND_CENTER)
def admin_ai_undo_restore_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    if not is_primary_admin(ctx.user_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    token = str(ctx.payload.get("token") or "").strip()
    if not token:
        raise ValueError("AI_UNDO_TOKEN_REQUIRED")
    return {"undo": restore_undo_snapshot(token, ctx.user_id, automatic=False)}


@action("ai_signal_lab_strategy_create", admin_only=True, permission=PERMISSION_AI_SIGNAL_ANALYSIS)
def ai_signal_lab_strategy_create_action(ctx: ActionContext) -> dict[str, Any]:
    name = str(ctx.payload.get("name") or "").strip()
    rules = ctx.payload.get("rules") if isinstance(ctx.payload.get("rules"), dict) else {}
    status = str(ctx.payload.get("status") or "shadow")
    return with_db(lambda db: {"strategy": create_strategy_version(
        db, name=name, rules=rules, actor_id=ctx.user_id, status=status,
    )})


@action("ai_signal_lab_scan_queue", admin_only=True, permission=PERMISSION_AI_SIGNAL_ANALYSIS)
def ai_signal_lab_scan_queue_action(ctx: ActionContext) -> dict[str, Any]:
    symbols = ctx.payload.get("symbols") if isinstance(ctx.payload.get("symbols"), list) else []
    timeframes = ctx.payload.get("timeframes") if isinstance(ctx.payload.get("timeframes"), list) else None
    strategy_id = int(ctx.payload.get("strategy_id") or 0)
    return with_db(lambda db: {"run": queue_shadow_scan(
        db, strategy_id=strategy_id, symbols=symbols, actor_id=ctx.user_id, timeframes=timeframes,
    )})


@action("ai_signal_lab_candidate_to_review", admin_only=True, permission=PERMISSION_SIGNAL_APPROVE)
def ai_signal_lab_candidate_to_review_action(ctx: ActionContext) -> dict[str, Any]:
    _require_human(ctx)
    candidate_id = int(ctx.payload.get("candidate_id") or 0)
    if candidate_id <= 0:
        raise ValueError("SIGNAL_LAB_CANDIDATE_ID_REQUIRED")
    target = str(ctx.payload.get("target") or "public")
    return with_db(lambda db: promote_candidate_to_review(
        db, candidate_id=candidate_id, actor_id=ctx.user_id, target=target,
    ))
