from __future__ import annotations

from typing import Any

from core.db import with_db
from modules.admin_access import (
    PERMISSION_BUSINESS_INBOX,
    PERMISSION_CONTENT_FACTORY,
    PERMISSION_DEVELOPER_API,
    PERMISSION_PARTNERS,
    PERMISSION_PUBLISHER,
    PERMISSION_PUBLIC_PERFORMANCE,
    PERMISSION_SYSTEM_CONTROL,
    PERMISSION_WORKSPACES,
    PERMISSION_SYSTEM_HEALTH_VIEW,
    PERMISSION_CHANNEL_LINKS_MANAGE,
    PERMISSION_PUBLISHER_QUEUE_MANAGE,
    PERMISSION_WEBHOOK_MANAGE,
)
from modules.platform_expansion import (
    classify_business_message,
    close_paper_trade,
    configure_prop_challenge,
    create_paper_account,
    create_partner,
    create_workspace,
    enqueue_publication,
    local_copilot_answer,
    local_market_intelligence,
    open_paper_trade,
    paper_trade_action,
    paper_arena_snapshot,
    partner_dashboard,
    platform_dashboard,
    prop_guardian_snapshot,
    register_publisher_channel,
    register_webhook,
    render_content,
    set_publication_status,
    update_device_state,
    verified_public_performance,
)
from services.actions_v2.context import ActionContext
from services.actions_v2.registry import action


def _run(operation):
    return with_db(operation)


@action("copilot_query", mutation=False, idempotency_required=False)
def copilot_query(ctx: ActionContext) -> dict[str, Any]:
    question = str(ctx.payload.get("question") or "").strip()
    return _run(lambda db: local_copilot_answer(db, ctx.user_id, question))


@action("risk_coach_refresh", mutation=False, idempotency_required=False)
def risk_coach_refresh(ctx: ActionContext) -> dict[str, Any]:
    from services.risk_coach_service import consolidated_behavioral_report
    return consolidated_behavioral_report(ctx.user_id)


@action("paper_arena_refresh", mutation=False, idempotency_required=False)
def paper_arena_refresh(ctx: ActionContext) -> dict[str, Any]:
    return _run(lambda db: paper_arena_snapshot(db, ctx.user_id))


@action("paper_account_create")
def paper_account_create(ctx: ActionContext) -> dict[str, Any]:
    return _run(
        lambda db: create_paper_account(
            db,
            ctx.user_id,
            str(ctx.payload.get("title") or "حساب آزمایشی"),
            float(ctx.payload.get("starting_balance") or 10_000),
        )
    )


@action("paper_trade_open")
def paper_trade_open(ctx: ActionContext) -> dict[str, Any]:
    required = ("account_id", "symbol", "side", "entry", "stop")
    if any(ctx.payload.get(key) in {None, ""} for key in required):
        raise ValueError("PAPER_TRADE_FIELDS_REQUIRED")
    targets = ctx.payload.get("targets") if isinstance(ctx.payload.get("targets"), list) else None
    if not targets and ctx.payload.get("target") in {None, ""}:
        raise ValueError("PAPER_TRADE_TARGETS_REQUIRED")
    return _run(
        lambda db: open_paper_trade(
            db,
            ctx.user_id,
            ctx.payload["account_id"],
            symbol=str(ctx.payload["symbol"]),
            side=str(ctx.payload["side"]),
            entry=float(ctx.payload["entry"]),
            stop=float(ctx.payload["stop"]),
            target=float(ctx.payload["target"]) if ctx.payload.get("target") not in {None, ""} else None,
            targets=[float(value) for value in targets] if targets else None,
            target_allocations=ctx.payload.get("target_allocations") if isinstance(ctx.payload.get("target_allocations"), list) else None,
            risk_percent=float(ctx.payload.get("risk_percent") or 1),
            signal_id=ctx.payload.get("signal_id"),
        )
    )


@action("paper_trade_close")
def paper_trade_close(ctx: ActionContext) -> dict[str, Any]:
    if ctx.payload.get("trade_id") in {None, ""} or ctx.payload.get("exit_price") in {None, ""}:
        raise ValueError("PAPER_TRADE_CLOSE_FIELDS_REQUIRED")
    return _run(lambda db: close_paper_trade(db, ctx.user_id, ctx.payload["trade_id"], float(ctx.payload["exit_price"])))


@action("paper_trade_action")
def paper_trade_manage(ctx: ActionContext) -> dict[str, Any]:
    if ctx.payload.get("trade_id") in {None, ""} or not str(ctx.payload.get("trade_action") or "").strip():
        raise ValueError("PAPER_TRADE_ACTION_FIELDS_REQUIRED")
    return _run(lambda db: paper_trade_action(
        db,
        ctx.user_id,
        ctx.payload["trade_id"],
        str(ctx.payload["trade_action"]),
        price=float(ctx.payload["price"]) if ctx.payload.get("price") not in {None, ""} else None,
        target_index=int(ctx.payload["target_index"]) if ctx.payload.get("target_index") not in {None, ""} else None,
        fraction=float(ctx.payload["fraction"]) if ctx.payload.get("fraction") not in {None, ""} else None,
        new_stop=float(ctx.payload["new_stop"]) if ctx.payload.get("new_stop") not in {None, ""} else None,
        targets=[float(value) for value in ctx.payload.get("targets", [])] if isinstance(ctx.payload.get("targets"), list) else None,
        reason=str(ctx.payload.get("reason") or ""),
    ))


@action("prop_challenge_configure")
def prop_challenge_configure(ctx: ActionContext) -> dict[str, Any]:
    if ctx.payload.get("account_id") in {None, ""}:
        raise ValueError("PAPER_ACCOUNT_REQUIRED")
    rules = ctx.payload.get("rules") if isinstance(ctx.payload.get("rules"), dict) else {}
    return _run(lambda db: configure_prop_challenge(db, ctx.user_id, ctx.payload["account_id"], rules))


@action("prop_guardian_refresh", mutation=False, idempotency_required=False)
def prop_guardian_refresh(ctx: ActionContext) -> dict[str, Any]:
    if ctx.payload.get("account_id") in {None, ""}:
        raise ValueError("PAPER_ACCOUNT_REQUIRED")
    return _run(
        lambda db: prop_guardian_snapshot(
            db,
            ctx.user_id,
            ctx.payload["account_id"],
            float(ctx.payload.get("candidate_risk_percent") or 0),
        )
    )


@action("market_intelligence_v2_refresh", mutation=False, idempotency_required=False)
def market_intelligence_v2_refresh(ctx: ActionContext) -> dict[str, Any]:
    return _run(local_market_intelligence)


@action("device_state_update")
def device_state_update(ctx: ActionContext) -> dict[str, Any]:
    device_id = str(ctx.payload.get("device_id") or "")
    state = ctx.payload.get("state") if isinstance(ctx.payload.get("state"), dict) else {}
    return _run(lambda db: update_device_state(db, ctx.user_id, device_id, state))


@action("business_message_classify")
def business_message_classify(ctx: ActionContext) -> dict[str, Any]:
    return _run(
        lambda db: classify_business_message(
            db,
            ctx.user_id,
            str(ctx.payload.get("text") or ""),
            source=str(ctx.payload.get("source") or "miniapp"),
        )
    )


@action("platform_dashboard_refresh", mutation=False, idempotency_required=False, admin_only=True, permission=PERMISSION_SYSTEM_HEALTH_VIEW)
def platform_dashboard_refresh(ctx: ActionContext) -> dict[str, Any]:
    return _run(platform_dashboard)


@action("publisher_channel_upsert", admin_only=True, permission=PERMISSION_CHANNEL_LINKS_MANAGE)
def publisher_channel_upsert(ctx: ActionContext) -> dict[str, Any]:
    return _run(
        lambda db: register_publisher_channel(
            db,
            ctx.user_id,
            chat_id=str(ctx.payload.get("chat_id") or ""),
            title=str(ctx.payload.get("title") or ""),
            language=str(ctx.payload.get("language") or "fa"),
            channel_type=str(ctx.payload.get("channel_type") or "public"),
            template_key=str(ctx.payload.get("template_key") or "signal_public"),
            approval_required=bool(ctx.payload.get("approval_required", True)),
        )
    )


@action("publication_enqueue", admin_only=True, permission=PERMISSION_PUBLISHER_QUEUE_MANAGE)
def publication_enqueue(ctx: ActionContext) -> dict[str, Any]:
    channel_ids = ctx.payload.get("channel_ids") if isinstance(ctx.payload.get("channel_ids"), list) else []
    jobs = _run(
        lambda db: enqueue_publication(
            db,
            ctx.user_id,
            channel_ids=channel_ids,
            content=str(ctx.payload.get("content") or ""),
            content_type=str(ctx.payload.get("content_type") or "text"),
            scheduled_at=ctx.payload.get("scheduled_at"),
            reference_type=str(ctx.payload.get("reference_type") or ""),
            reference_id=ctx.payload.get("reference_id"),
        )
    )
    return {"items": jobs, "count": len(jobs)}


@action("publication_status_update", admin_only=True, permission=PERMISSION_PUBLISHER_QUEUE_MANAGE)
def publication_status_update(ctx: ActionContext) -> dict[str, Any]:
    return _run(
        lambda db: set_publication_status(
            db,
            ctx.user_id,
            ctx.payload.get("job_id"),
            str(ctx.payload.get("status") or ""),
        )
    )


@action("partner_create", admin_only=True, permission=PERMISSION_PARTNERS)
def partner_create(ctx: ActionContext) -> dict[str, Any]:
    return _run(
        lambda db: create_partner(
            db,
            ctx.user_id,
            name=str(ctx.payload.get("name") or ""),
            channel=str(ctx.payload.get("channel") or ""),
            commission_mode=str(ctx.payload.get("commission_mode") or "points"),
            commission_value=float(ctx.payload.get("commission_value") or 0),
        )
    )


@action("partner_dashboard_refresh", mutation=False, idempotency_required=False, admin_only=True, permission=PERMISSION_PARTNERS)
def partner_dashboard_refresh(ctx: ActionContext) -> dict[str, Any]:
    return _run(partner_dashboard)


@action("public_performance_snapshot", admin_only=True, permission=PERMISSION_PUBLIC_PERFORMANCE)
def public_performance_snapshot(ctx: ActionContext) -> dict[str, Any]:
    return _run(lambda db: verified_public_performance(db, persist=True, actor_id=ctx.user_id))


@action("content_render", admin_only=True, permission=PERMISSION_CONTENT_FACTORY)
def content_render(ctx: ActionContext) -> dict[str, Any]:
    values = ctx.payload.get("values") if isinstance(ctx.payload.get("values"), dict) else {}
    return _run(lambda db: render_content(db, ctx.user_id, str(ctx.payload.get("template_key") or ""), values))


@action("business_inbox_admin_classify", admin_only=True, permission=PERMISSION_BUSINESS_INBOX)
def business_inbox_admin_classify(ctx: ActionContext) -> dict[str, Any]:
    return _run(
        lambda db: classify_business_message(
            db,
            str(ctx.payload.get("user_id") or ctx.user_id),
            str(ctx.payload.get("text") or ""),
            source=str(ctx.payload.get("source") or "admin"),
        )
    )


@action("webhook_register", admin_only=True, permission=PERMISSION_WEBHOOK_MANAGE)
def webhook_register(ctx: ActionContext) -> dict[str, Any]:
    events = ctx.payload.get("events") if isinstance(ctx.payload.get("events"), list) else []
    return _run(
        lambda db: register_webhook(
            db,
            ctx.user_id,
            url=str(ctx.payload.get("url") or ""),
            events=events,
            secret=str(ctx.payload.get("secret") or "") or None,
        )
    )


@action("workspace_create", admin_only=True, permission=PERMISSION_WORKSPACES)
def workspace_create(ctx: ActionContext) -> dict[str, Any]:
    return _run(
        lambda db: create_workspace(
            db,
            ctx.user_id,
            name=str(ctx.payload.get("name") or ""),
            slug=str(ctx.payload.get("slug") or ""),
            brand_name=str(ctx.payload.get("brand_name") or "SENTINEL"),
        )
    )
