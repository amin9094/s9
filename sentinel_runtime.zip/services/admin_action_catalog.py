from __future__ import annotations

"""Human-facing Mini App catalog for shared administrator actions.

The action registry remains the authorization/execution source of truth.  This
catalog only describes how an allowed action should be presented and collected
in the Mini App.  Keeping the labels and field contracts server-side prevents
an old cached frontend from claiming that a permission is executable when no
usable form exists.
"""

from copy import deepcopy
from typing import Any


def _f(
    name: str,
    label_fa: str,
    *,
    kind: str = "text",
    required: bool = False,
    label_en: str = "",
    placeholder: str = "",
    options: list[tuple[str, str]] | None = None,
    default: Any = None,
    help_fa: str = "",
    help_en: str = "",
) -> dict[str, Any]:
    row: dict[str, Any] = {
        "name": name,
        "label_fa": label_fa,
        "label_en": label_en or label_fa,
        "type": kind,
        "required": required,
    }
    if placeholder:
        row["placeholder"] = placeholder
    if options:
        row["options"] = [{"value": value, "label": label} for value, label in options]
    if default is not None:
        row["default"] = default
    if help_fa:
        row["help_fa"] = help_fa
        row["help_en"] = help_en or help_fa
    return row


def _item(
    label_fa: str,
    description_fa: str,
    group: str,
    *,
    fields: list[dict[str, Any]] | None = None,
    mode: str = "form",
    confirmation_fa: str = "",
    confirmation_en: str = "",
    label_en: str = "",
    description_en: str = "",
    group_en: str = "",
    refresh: list[str] | None = None,
) -> dict[str, Any]:
    return {
        "label_fa": label_fa,
        "label_en": label_en or label_fa,
        "description_fa": description_fa,
        "description_en": description_en or description_fa,
        "group": group,
        "group_en": group_en or group,
        "ui_state": "ready",
        "ui_mode": mode,
        "fields": fields or [],
        "confirmation_fa": confirmation_fa,
        "confirmation_en": confirmation_en or confirmation_fa,
        "refresh": refresh or [],
    }


ADMIN_ACTION_CATALOG: dict[str, dict[str, Any]] = {
    "payment_approve": _item("تأیید پرداخت", "تأیید رسید و فعال‌سازی اشتراک کاربر.", "پرداخت", fields=[_f("order_id", "شناسه سفارش", required=True)], confirmation_fa="پرداخت تأیید و VIP فعال شود؟", refresh=["adminOrders", "overview"]),
    "payment_reject": _item("رد پرداخت", "رد رسید همراه با دلیل قابل مشاهده برای کاربر.", "پرداخت", fields=[_f("order_id", "شناسه سفارش", required=True), _f("reason", "دلیل رد", kind="textarea", required=True)], confirmation_fa="رسید رد شود؟", refresh=["adminOrders", "overview"]),
    "platform_dashboard_refresh": _item("تازه‌سازی وضعیت پلتفرم", "نمایش وضعیت سرویس‌ها، ذخیره‌سازی و هزینه‌های اجرایی.", "سامانه", mode="inspect", refresh=["adminPlatform"]),
    "control_change": _item("تغییر تنظیم ماژول", "همان تنظیم مشترک ربات و مینی‌اپ را تغییر می‌دهد؛ تغییرات حساس وارد صف حاکمیت می‌شوند.", "سامانه", fields=[_f("module", "کلید ماژول", required=True), _f("field", "کلید تنظیم", required=True), _f("value", "مقدار جدید", required=True)], refresh=["adminPlatform", "overview"]),
    "control_reset": _item("بازنشانی ماژول", "تنظیمات یک ماژول را به مقادیر پیش‌فرض بازمی‌گرداند.", "سامانه", fields=[_f("module", "کلید ماژول", required=True)], confirmation_fa="ماژول بازنشانی شود؟", refresh=["adminPlatform", "overview"]),
    "control_preset": _item("Preset سراسری ماژول‌ها", "درخواست تغییر هم‌زمان همه ماژول‌ها را در صف حاکمیت ثبت می‌کند.", "سامانه", fields=[_f("preset", "Preset", kind="select", options=[("default", "پیش‌فرض"), ("safe", "ایمن"), ("full", "کامل")], required=True)], confirmation_fa="درخواست Preset سراسری ثبت شود؟", refresh=["adminPlatform"]),
    "governance_request_approve": _item("تأیید درخواست حاکمیت", "یک مرحله تأیید برای تغییر حساس ثبت می‌کند.", "عملیات", fields=[_f("request_id", "شناسه درخواست", required=True)], refresh=["adminPlatform"]),
    "governance_request_reject": _item("رد درخواست حاکمیت", "درخواست حساس را همراه با دلیل رد می‌کند.", "عملیات", fields=[_f("request_id", "شناسه درخواست", required=True), _f("reason", "دلیل رد", kind="textarea")], refresh=["adminPlatform"]),
    "governance_request_apply": _item("اجرای درخواست تأییدشده", "تغییر تأییدشده را روی دیتابیس مشترک ربات و مینی‌اپ اعمال می‌کند.", "عملیات", fields=[_f("request_id", "شناسه درخواست", required=True)], confirmation_fa="عملیات تأییدشده اجرا شود؟", refresh=["adminPlatform", "overview"]),
    "governance_request_retry": _item("تلاش مجدد درخواست ناموفق", "درخواست ناموفق را برای اجرای دوباره آماده می‌کند.", "عملیات", fields=[_f("request_id", "شناسه درخواست", required=True)], refresh=["adminPlatform"]),
    "publisher_channel_upsert": _item("ثبت یا ویرایش کانال ناشر", "کانال مقصد و قالب انتشار را در ناشر چندکاناله ثبت می‌کند.", "انتشار", fields=[
        _f("chat_id", "شناسه کانال", required=True, placeholder="-1001234567890"), _f("title", "عنوان کانال", required=True),
        _f("language", "زبان", kind="select", options=[("fa", "فارسی"), ("en", "English")], default="fa"),
        _f("channel_type", "نوع کانال", kind="select", options=[("public", "عمومی"), ("private", "خصوصی")], default="public"),
        _f("template_key", "کلید قالب", default="signal_public"), _f("approval_required", "نیازمند تأیید", kind="checkbox", default=True),
    ], refresh=["adminPlatform"]),
    "publication_enqueue": _item("افزودن محتوا به صف انتشار", "متن یا محتوای آماده را برای یک یا چند کانال زمان‌بندی می‌کند.", "انتشار", fields=[
        _f("channel_ids", "شناسه کانال‌ها", kind="csv", required=True, placeholder="1, 2"),
        _f("content", "محتوا", kind="textarea", required=True),
        _f("content_type", "نوع محتوا", kind="select", options=[("text", "متن"), ("announcement", "اعلان"), ("signal", "سیگنال")], default="text"),
        _f("scheduled_at", "زمان انتشار ISO", placeholder="2026-07-25T18:30:00+00:00"),
        _f("reference_type", "نوع مرجع"), _f("reference_id", "شناسه مرجع"),
    ], refresh=["adminPlatform"]),
    "publication_status_update": _item("تغییر وضعیت انتشار", "یک آیتم صف انتشار را تأیید، لغو یا دوباره فعال می‌کند.", "انتشار", fields=[
        _f("job_id", "شناسه آیتم", required=True),
        _f("status", "وضعیت", kind="select", required=True, options=[("pending", "در انتظار"), ("approved", "تأییدشده"), ("cancelled", "لغوشده"), ("retry", "تلاش مجدد")]),
    ], refresh=["adminPlatform"]),
    "partner_create": _item("افزودن همکار", "همکار تبلیغاتی یا فروش را همراه با روش محاسبه کمیسیون ثبت می‌کند.", "همکاران", fields=[
        _f("name", "نام همکار", required=True), _f("channel", "کانال یا راه ارتباطی", required=True),
        _f("commission_mode", "نوع کمیسیون", kind="select", options=[("points", "امتیاز"), ("percent", "درصد"), ("fixed", "ثابت")], default="points"),
        _f("commission_value", "مقدار کمیسیون", kind="number", default=0),
    ], refresh=["adminPlatform"]),
    "partner_dashboard_refresh": _item("داشبورد همکاران", "خلاصه عملکرد، ارجاع‌ها و اعتبار همکاران را نمایش می‌دهد.", "همکاران", mode="inspect"),
    "public_performance_snapshot": _item("ثبت تصویر عملکرد عمومی", "یک Snapshot قابل راستی‌آزمایی از عملکرد عمومی ایجاد می‌کند.", "شفافیت", mode="confirm", confirmation_fa="Snapshot جدید عملکرد عمومی ساخته شود؟"),
    "content_render": _item("ساخت محتوا از قالب", "یک قالب کارخانه محتوا را با مقادیر داده‌شده رندر می‌کند.", "محتوا", fields=[
        _f("template_key", "کلید قالب", required=True), _f("values", "مقادیر قالب (JSON)", kind="json", required=True, default={}),
    ]),
    "business_inbox_admin_classify": _item("دسته‌بندی پیام کسب‌وکار", "پیام ورودی را به سرنخ، پشتیبانی، فروش یا سایر دسته‌ها تحلیل می‌کند.", "صندوق کسب‌وکار", fields=[
        _f("user_id", "شناسه کاربر", required=True), _f("text", "متن پیام", kind="textarea", required=True), _f("source", "منبع", default="admin"),
    ]),
    "webhook_register": _item("ثبت Webhook", "آدرس امن دریافت رخدادهای انتخاب‌شده را ثبت می‌کند.", "توسعه‌دهندگان", fields=[
        _f("url", "آدرس HTTPS", required=True, placeholder="https://example.com/sentinel-hook"),
        _f("events", "رخدادها", kind="csv", required=True, placeholder="signal.created, ticket.message_added"),
        _f("secret", "کلید امضا", kind="password", help_fa="خالی بگذارید تا سامانه کلید امن بسازد."),
    ], confirmation_fa="Webhook ثبت شود؟"),
    "workspace_create": _item("ساخت فضای کاری", "یک فضای کاری مستقل برای برند یا تیم جدید می‌سازد.", "فضای کاری", fields=[
        _f("name", "نام فضای کاری", required=True), _f("slug", "شناسه لاتین", required=True, placeholder="sentinel-team"), _f("brand_name", "نام برند", default="SENTINEL"),
    ]),
    "runtime_mode_update": _item("تغییر حالت اجرا", "حالت عادی، فقط‌خواندنی، نگهداری یا استیجینگ را تنظیم می‌کند.", "سامانه", fields=[
        _f("mode", "حالت", kind="select", required=True, options=[("normal", "عادی"), ("safe", "ایمن - فقط خواندنی"), ("maintenance", "نگهداری"), ("read_only", "فقط خواندنی"), ("staging", "استیجینگ")]),
        _f("reason", "دلیل تغییر", kind="textarea", required=True),
    ], confirmation_fa="حالت اجرای کل سامانه تغییر کند؟", refresh=["overview", "adminOps"]),
    "miniapp_runtime_toggle": _item("روشن یا خاموش‌کردن مینی‌اپ", "دکمه مینی‌اپ و دسترسی کاربران را بدون Redeploy کنترل می‌کند.", "سامانه", fields=[
        _f("enabled", "مینی‌اپ فعال باشد", kind="checkbox", default=True), _f("reason", "دلیل", kind="textarea"),
    ], confirmation_fa="وضعیت دسترسی کاربران به مینی‌اپ تغییر کند؟", refresh=["overview", "adminOps"]),
    "integration_reconcile": _item("هماهنگ‌سازی ربات و مینی‌اپ", "Projectionهای سیگنال، VIP، تیکت و ژورنال را دوباره تطبیق می‌دهد.", "سامانه", mode="confirm", confirmation_fa="هماهنگ‌سازی کامل اجرا شود؟", refresh=["overview", "adminIntegration"]),
    "mission_control_refresh": _item("مرکز عملیات", "شاخص‌های فوری، رخدادها و وضعیت شیفت را تازه می‌کند.", "عملیات", mode="inspect"),
    "action_inbox_refresh": _item("صندوق اقدام مدیر", "موارد نیازمند تصمیم مدیر را به‌صورت یکجا نمایش می‌دهد.", "عملیات", mode="inspect"),
    "incident_status_update": _item("تغییر وضعیت رخداد", "رخداد عملیاتی را دریافت، در حال بررسی یا حل‌شده علامت می‌زند.", "عملیات", fields=[
        _f("incident_id", "شناسه رخداد", required=True), _f("status", "وضعیت", kind="select", required=True, options=[("open", "باز"), ("acknowledged", "دریافت شد"), ("investigating", "در حال بررسی"), ("resolved", "حل شد")]),
    ], refresh=["adminOps"]),
    "campaign_create": _item("ساخت کمپین", "کمپین بازاریابی را با مخاطب، پیام و مقصد مشخص می‌سازد.", "کمپین", fields=[
        _f("name", "نام کمپین", required=True), _f("category", "دسته", required=True), _f("audience", "مخاطب", required=True),
        _f("message", "پیام", kind="textarea", required=True), _f("delivery", "مقصد", required=True), _f("objective", "هدف"),
    ], refresh=["adminCampaigns"]),
    "campaign_delivery_update": _item("تغییر مقصد کمپین", "روش یا مقصد تحویل کمپین موجود را اصلاح می‌کند.", "کمپین", fields=[
        _f("campaign_id", "شناسه کمپین", required=True), _f("delivery", "مقصد جدید", required=True, placeholder="public / private / bot"),
    ], refresh=["adminCampaigns"]),
    "campaign_schedule": _item("زمان‌بندی کمپین", "کمپین را برای زمان مشخص وارد صف پایدار می‌کند.", "کمپین", fields=[
        _f("campaign_id", "شناسه کمپین", required=True), _f("scheduled_for", "زمان ISO", required=True), _f("priority", "اولویت ۱ تا ۵", kind="number", default=3),
    ], refresh=["adminCampaigns"]),
    "campaign_status_update": _item("تغییر وضعیت کمپین", "کمپین را فعال، متوقف یا بایگانی می‌کند.", "کمپین", fields=[
        _f("campaign_id", "شناسه کمپین", required=True), _f("status", "وضعیت", kind="select", required=True, options=[("draft", "پیش‌نویس"), ("active", "فعال"), ("paused", "متوقف"), ("completed", "تکمیل"), ("archived", "بایگانی")]),
    ], refresh=["adminCampaigns"]),
    "signal_cycle_rollover": _item("بستن و شروع دوره جدید", "دوره فعال را بدون حذف تاریخچه می‌بندد و دوره جدیدی با نام دلخواه آغاز می‌کند.", "دوره‌های سیگنال", fields=[_f("name", "نام دوره جدید", required=True, placeholder="کمپین تبدیل ۱۰۰ به ۱۰۰۰")], confirmation_fa="دوره فعلی بسته و دوره جدید آغاز شود؟", refresh=["adminSignalCycles", "signals", "overview"]),
    "signal_cycle_close": _item("بستن دوره فعلی", "دوره فعال را می‌بندد؛ هیچ سیگنال یا گزارشی حذف نمی‌شود.", "دوره‌های سیگنال", mode="confirm", confirmation_fa="دوره فعلی بدون حذف تاریخچه بسته شود؟", refresh=["adminSignalCycles", "signals", "overview"]),
    "signal_cycle_start": _item("شروع دوره جدید", "پس از بسته‌شدن دوره قبلی، یک دوره نام‌دار با شماره‌گذاری تازه آغاز می‌کند.", "دوره‌های سیگنال", fields=[_f("name", "نام دوره جدید", required=True, placeholder="کمپین تبدیل ۱۰۰ به ۱۰۰۰")], refresh=["adminSignalCycles", "signals", "overview"]),
    "signal_cycle_rename": _item("تغییر نام دوره", "نام یک دوره فعال یا بسته‌شده را بدون دست‌زدن به سیگنال‌ها تغییر می‌دهد.", "دوره‌های سیگنال", fields=[_f("cycle_id", "شناسه دوره", kind="number", required=True), _f("name", "نام جدید", required=True)], refresh=["adminSignalCycles"]),
    "miniapp_signal_publish": _item("ارسال سیگنال", "سیگنال را از صف مشترک در کانال و مینی‌اپ منتشر می‌کند.", "سیگنال", mode="native", refresh=["adminSignalJobs", "signals", "feed"]),
    "miniapp_announcement_publish": _item("انتشار اعلان", "اعلان را از صف پایدار برای کانال عمومی یا خصوصی ارسال می‌کند.", "اعلان", mode="native", refresh=["adminCampaigns", "feed"]),
    "automation_retry": _item("تلاش مجدد اعلان ناموفق", "پیام Retry یا Dead-letter را دوباره در صف قرار می‌دهد.", "اتوماسیون", fields=[_f("message_id", "شناسه پیام صف", required=True)], confirmation_fa="شمارنده خطا پاک و ارسال دوباره آغاز شود؟", refresh=["adminOps"]),
    "ticket_admin_reply": _item("پاسخ تیکت", "پاسخ متنی یا ضمیمه را در گفت‌وگوی مشترک ثبت می‌کند.", "پشتیبانی", mode="native", refresh=["adminTickets", "tickets"]),
    "ticket_admin_status_update": _item("وضعیت تیکت", "وضعیت تیکت را به‌روزرسانی می‌کند.", "پشتیبانی", mode="native", refresh=["adminTickets", "tickets"]),
    "ticket_admin_assign": _item("تخصیص تیکت", "رسیدگی تیکت را به یک مدیر مشخص واگذار می‌کند.", "پشتیبانی", fields=[_f("ticket_id", "شماره تیکت", required=True), _f("admin_id", "شناسه مدیر", required=True)], refresh=["adminTickets"]),
    "ticket_admin_priority_update": _item("تغییر اولویت تیکت", "اولویت و مهلت SLA تیکت را به‌روز می‌کند.", "پشتیبانی", fields=[_f("ticket_id", "شماره تیکت", required=True), _f("priority", "اولویت", kind="select", required=True, options=[("low", "کم"), ("normal", "عادی"), ("high", "مهم"), ("urgent", "فوری")])], refresh=["adminTickets"]),
    "ticket_admin_internal_note": _item("یادداشت داخلی تیکت", "یادداشتی ثبت می‌کند که کاربر آن را نمی‌بیند.", "پشتیبانی", fields=[_f("ticket_id", "شماره تیکت", required=True), _f("text", "یادداشت داخلی", kind="textarea", required=True)], refresh=["adminTickets"]),
    "shift_handoff_create": _item("تحویل شیفت", "خلاصه و موارد باز را برای مدیر شیفت بعدی ثبت می‌کند.", "عملیات", mode="native", refresh=["adminOps"]),
    "shift_handoff_status_update": _item("وضعیت تحویل شیفت", "تحویل شیفت را دریافت یا تکمیل می‌کند.", "عملیات", mode="native", refresh=["adminOps"]),
    "experiment_create": _item("آزمایش رشد جدید", "فرضیه، گروه کنترل و شاخص موفقیت را ثبت می‌کند.", "کمپین", mode="native", refresh=["adminExperiments"]),
    "experiment_status_update": _item("وضعیت آزمایش", "آزمایش را شروع، متوقف یا تکمیل می‌کند.", "کمپین", mode="native", refresh=["adminExperiments"]),
    "prop_template_create": _item("قالب قوانین پراپ", "محدودیت‌های یک شرکت پراپ را برای پایش ریسک ثبت می‌کند.", "ریسک", mode="native", refresh=["risk"]),
    "signal_job_retry": _item("تلاش مجدد انتشار سیگنال", "انتشار ناموفق را با همان شناسه و بدون ساخت Duplicate دوباره اجرا می‌کند.", "سیگنال", fields=[_f("job_id", "شناسه صف", required=True)], confirmation_fa="این سیگنال دوباره در صف قرار گیرد؟", refresh=["adminSignalJobs"]),
    "signal_job_cancel": _item("لغو انتشار سیگنال", "آیتمی که هنوز ارسال نشده را لغو می‌کند.", "سیگنال", fields=[_f("job_id", "شناسه صف", required=True), _f("reason", "دلیل لغو", kind="textarea")], confirmation_fa="انتشار این سیگنال لغو شود؟", refresh=["adminSignalJobs"]),
    "signal_job_update": _item("ویرایش سیگنال در صف", "قبل از ارسال، مقصد، زمان یا داده‌های سیگنال را اصلاح می‌کند.", "سیگنال", fields=[
        _f("job_id", "شناسه صف", required=True), _f("target", "مقصد", kind="select", options=[("public", "عمومی"), ("private", "VIP"), ("both", "هر دو")]),
        _f("run_at", "زمان جدید ISO"), _f("payload", "فیلدهای سیگنال (JSON)", kind="json", default={}),
    ], refresh=["adminSignalJobs"]),
    "admin_command_center_snapshot": _item("نمای زنده مرکز فرماندهی", "اقدام‌های فوری، شاخص‌ها و پیشنهادهای هوشمند را نمایش می‌دهد.", "فرماندهی", mode="inspect", refresh=["overview", "adminOps"]),
    "admin_global_search": _item("جست‌وجوی سراسری ادمین", "در کاربران، رسید، سیگنال، تیکت، CRM، تبلیغ، آموزش، اتوماسیون، لاگ و سیستم با رعایت مجوز جست‌وجو می‌کند.", "فرماندهی", fields=[
        _f("query", "عبارت جست‌وجو", required=True),
        _f("domain", "حوزه اختیاری", placeholder="users / payments / signals / tickets / automation"),
        _f("limit", "حداکثر نتیجه", kind="number", default=30),
    ], mode="inspect"),
    "automation_v2_rule_list": _item("فهرست قوانین اتوماسیون V2", "قوانین فعال و پیش‌نویس موتور اتوماسیون جدید را نمایش می‌دهد.", "اتوماسیون پیشرفته", mode="inspect"),
    "automation_v2_rule_create": _item("ساخت قانون اتوماسیون V2", "Trigger، شرط‌های تو‌در‌تو، Actionها و Guardها را به‌صورت یک قانون نسخه‌دار ثبت می‌کند.", "اتوماسیون پیشرفته", fields=[
        _f("name", "نام قانون", required=True), _f("trigger", "Trigger", required=True),
        _f("conditions", "شرط‌ها (JSON)", kind="json", default=[]),
        _f("actions", "Actionها (JSON)", kind="json", required=True, default=[]),
        _f("guards", "Guardها (JSON)", kind="json", default={}),
        _f("enabled", "از ابتدا فعال باشد", kind="checkbox", default=False),
    ], refresh=["adminOps"]),
    "automation_v2_rule_update": _item("ویرایش قانون اتوماسیون V2", "یک قانون موجود را با نسخه‌بندی و Audit اصلاح می‌کند.", "اتوماسیون پیشرفته", fields=[
        _f("rule_id", "شناسه قانون", required=True), _f("changes", "تغییرات (JSON)", kind="json", required=True, default={}),
    ], refresh=["adminOps"]),
    "automation_v2_rule_test": _item("Dry Run اتوماسیون V2", "قانون را روی یک رخداد آزمایشی بدون ارسال واقعی اجرا می‌کند.", "اتوماسیون پیشرفته", fields=[
        _f("rule_id", "شناسه قانون", required=True), _f("trigger", "Trigger", required=True),
        _f("event", "رخداد آزمایشی (JSON)", kind="json", required=True, default={}),
    ], mode="inspect"),
    "ai_ad_campaign_create": _item("ساخت تبلیغ با Gemini", "Gemini سه متن تبلیغاتی می‌سازد و نسخه منتخب را به‌صورت پیش‌نویس کمپین ثبت می‌کند.", "تبلیغات Gemini", fields=[
        _f("name", "نام تبلیغ", required=True), _f("product", "محصول یا خدمت", required=True),
        _f("objective", "هدف تبلیغ", required=True), _f("audience", "مخاطب", default="all"),
        _f("delivery", "مقصد", default="draft"), _f("tone", "لحن", default="premium"),
        _f("call_to_action", "دعوت به اقدام"), _f("language", "زبان", default="fa"),
        _f("brand_notes", "یادداشت برند", kind="textarea"),
    ], refresh=["adminCampaigns"]),
    "ai_ad_image_generate": _item("ساخت تصویر تبلیغ با Gemini", "تصویر برندشده را در فضای امن تولید، هش و QA می‌کند و به کمپین متصل می‌سازد.", "تبلیغات Gemini", fields=[
        _f("campaign_id", "شناسه کمپین", required=True), _f("prompt", "پرامپت تصویر", kind="textarea"),
        _f("aspect_ratio", "نسبت تصویر", default="1:1"),
    ], refresh=["adminCampaigns"]),
    "ai_ad_summary": _item("بررسی تبلیغ Gemini", "متن، تصویر، QA، وضعیت و زمان‌بندی تبلیغ را نمایش می‌دهد.", "تبلیغات Gemini", fields=[_f("campaign_id", "شناسه کمپین", required=True)], mode="inspect"),
    "ai_ad_approve": _item("تأیید انسانی تبلیغ", "تبلیغی که QA را گذرانده برای انتشار تأیید می‌کند.", "تبلیغات Gemini", fields=[_f("campaign_id", "شناسه کمپین", required=True)], confirmation_fa="تبلیغ پس از بررسی انسانی تأیید شود؟", refresh=["adminCampaigns"]),
    "ai_ad_schedule": _item("زمان‌بندی تبلیغ Gemini", "تبلیغ تأییدشده را در صف پایدار انتشار قرار می‌دهد.", "تبلیغات Gemini", fields=[
        _f("campaign_id", "شناسه کمپین", required=True), _f("scheduled_for", "زمان ISO", required=True),
        _f("priority", "اولویت ۱ تا ۵", kind="number", default=3),
    ], confirmation_fa="تبلیغ در زمان مشخص وارد صف انتشار شود؟", refresh=["adminCampaigns"]),
}


_GROUP_EN = {
    "پرداخت": "Payments", "سامانه": "System", "انتشار": "Publishing", "همکاران": "Partners",
    "فرماندهی": "Command OS", "اتوماسیون پیشرفته": "Advanced Automation", "تبلیغات Gemini": "Gemini Ads",
    "شفافیت": "Transparency", "محتوا": "Content", "صندوق کسب‌وکار": "Business Inbox",
    "توسعه‌دهندگان": "Developers", "فضای کاری": "Workspace", "عملیات": "Operations",
    "کمپین": "Campaigns", "دوره‌های سیگنال": "Signal Periods", "سیگنال": "Signals",
    "اعلان": "Announcements", "اتوماسیون": "Automation", "پشتیبانی": "Support", "ریسک": "Risk",
    "سایر": "Other",
}

_FIELD_EN = {
    "شناسه سفارش": "Order ID", "دلیل رد": "Rejection reason", "شناسه کانال": "Channel ID",
    "کلید ماژول": "Module key", "کلید تنظیم": "Setting key", "مقدار جدید": "New value",
    "Preset": "Preset", "شناسه درخواست": "Request ID",
    "عنوان کانال": "Channel title", "زبان": "Language", "نوع کانال": "Channel type",
    "کلید قالب": "Template key", "نیازمند تأیید": "Approval required", "شناسه کانال‌ها": "Channel IDs",
    "محتوا": "Content", "نوع محتوا": "Content type", "زمان انتشار ISO": "ISO publish time",
    "نوع مرجع": "Reference type", "شناسه مرجع": "Reference ID", "شناسه آیتم": "Item ID",
    "وضعیت": "Status", "نام همکار": "Partner name", "کانال یا راه ارتباطی": "Channel or contact method",
    "نوع کمیسیون": "Commission mode", "مقدار کمیسیون": "Commission value", "مقادیر قالب (JSON)": "Template values (JSON)",
    "شناسه کاربر": "User ID", "متن پیام": "Message text", "منبع": "Source", "آدرس HTTPS": "HTTPS URL",
    "رخدادها": "Events", "کلید امضا": "Signing secret", "نام فضای کاری": "Workspace name",
    "شناسه لاتین": "Latin slug", "نام برند": "Brand name", "حالت": "Mode", "دلیل تغییر": "Change reason",
    "مینی‌اپ فعال باشد": "Mini App enabled", "دلیل": "Reason", "شناسه رخداد": "Incident ID",
    "نام کمپین": "Campaign name", "دسته": "Category", "مخاطب": "Audience", "پیام": "Message",
    "مقصد": "Destination", "هدف": "Objective", "شناسه کمپین": "Campaign ID", "مقصد جدید": "New destination",
    "زمان ISO": "ISO time", "اولویت ۱ تا ۵": "Priority 1 to 5", "نام دوره جدید": "New period name",
    "شناسه دوره": "Period ID", "نام جدید": "New name", "شناسه پیام صف": "Queue message ID",
    "شماره تیکت": "Ticket ID", "شناسه مدیر": "Admin ID", "اولویت": "Priority",
    "یادداشت داخلی": "Internal note", "شناسه صف": "Queue ID", "دلیل لغو": "Cancellation reason",
    "زمان جدید ISO": "New ISO time", "فیلدهای سیگنال (JSON)": "Signal fields (JSON)",
    "عبارت جست‌وجو": "Search query", "حوزه اختیاری": "Optional domain", "حداکثر نتیجه": "Maximum results",
    "نام قانون": "Rule name", "Trigger": "Trigger", "شرط‌ها (JSON)": "Conditions (JSON)",
    "Actionها (JSON)": "Actions (JSON)", "Guardها (JSON)": "Guards (JSON)", "از ابتدا فعال باشد": "Enable immediately",
    "شناسه قانون": "Rule ID", "تغییرات (JSON)": "Changes (JSON)", "رخداد آزمایشی (JSON)": "Test event (JSON)",
    "نام تبلیغ": "Advertisement name", "محصول یا خدمت": "Product or service", "هدف تبلیغ": "Advertising objective",
    "لحن": "Tone", "دعوت به اقدام": "Call to action", "یادداشت برند": "Brand notes",
    "پرامپت تصویر": "Image prompt", "نسبت تصویر": "Aspect ratio",
}

_OPTION_EN = {
    "فارسی": "Persian", "عمومی": "Public", "خصوصی": "Private", "متن": "Text", "اعلان": "Announcement",
    "پیش‌فرض": "Default", "ایمن": "Safe", "کامل": "Full",
    "سیگنال": "Signal", "در انتظار": "Pending", "تأییدشده": "Approved", "لغوشده": "Cancelled",
    "تلاش مجدد": "Retry", "امتیاز": "Points", "درصد": "Percent", "ثابت": "Fixed", "عادی": "Normal",
    "ایمن - فقط خواندنی": "Safe — read only", "نگهداری": "Maintenance", "فقط خواندنی": "Read only",
    "استیجینگ": "Staging", "باز": "Open", "دریافت شد": "Acknowledged", "در حال بررسی": "Investigating",
    "حل شد": "Resolved", "پیش‌نویس": "Draft", "فعال": "Active", "متوقف": "Paused", "تکمیل": "Completed",
    "بایگانی": "Archived", "کم": "Low", "مهم": "High", "فوری": "Urgent", "هر دو": "Both",
}

_ACTION_EN = {
    "payment_approve": ("Approve payment", "Approve the receipt and activate the user's subscription.", "Activate VIP after approving this payment?"),
    "payment_reject": ("Reject payment", "Reject the receipt with a reason visible to the user.", "Reject this receipt?"),
    "platform_dashboard_refresh": ("Refresh platform status", "Show service, storage and operating-cost status.", ""),
    "control_change": ("Change module setting", "Change the shared bot and Mini App module setting; sensitive changes enter governance review.", ""),
    "control_reset": ("Reset module", "Restore one module to its canonical defaults.", "Reset this module?"),
    "control_preset": ("Global module preset", "Submit a governed request to update all module settings.", "Submit the global preset request?"),
    "governance_request_approve": ("Approve governance request", "Record an approval for a sensitive operation.", ""),
    "governance_request_reject": ("Reject governance request", "Reject a sensitive operation with a reason.", ""),
    "governance_request_apply": ("Apply approved request", "Apply the approved operation to the shared bot and Mini App state.", "Apply this approved operation?"),
    "governance_request_retry": ("Retry failed request", "Prepare a failed governance request for another execution attempt.", ""),
    "publisher_channel_upsert": ("Add or edit publisher channel", "Register a destination channel and publishing template in the multi-channel publisher.", ""),
    "publication_enqueue": ("Add content to publishing queue", "Schedule prepared content for one or more channels.", ""),
    "publication_status_update": ("Update publication status", "Approve, cancel or reactivate a publishing queue item.", ""),
    "partner_create": ("Add partner", "Register an advertising or sales partner with a commission model.", ""),
    "partner_dashboard_refresh": ("Partner dashboard", "Show partner performance, referrals and credit summary.", ""),
    "public_performance_snapshot": ("Create public performance snapshot", "Create a verifiable snapshot of public performance.", "Create a new public-performance snapshot?"),
    "content_render": ("Render content from template", "Render a content-factory template with the supplied values.", ""),
    "business_inbox_admin_classify": ("Classify business message", "Classify an inbound message as lead, support, sales or another category.", ""),
    "webhook_register": ("Register webhook", "Register a secure endpoint for selected events.", "Register this webhook?"),
    "workspace_create": ("Create workspace", "Create an isolated workspace for a new brand or team.", ""),
    "runtime_mode_update": ("Change runtime mode", "Set normal, read-only, maintenance or staging mode.", "Change the runtime mode for the entire system?"),
    "miniapp_runtime_toggle": ("Enable or disable Mini App", "Control the Mini App button and user access without redeploying.", "Change Mini App access for users?"),
    "integration_reconcile": ("Reconcile bot and Mini App", "Rebuild and reconcile signal, VIP, ticket and journal projections.", "Run a full reconciliation?"),
    "mission_control_refresh": ("Mission control", "Refresh urgent metrics, incidents and shift status.", ""),
    "action_inbox_refresh": ("Admin action inbox", "Show all items requiring an administrator decision.", ""),
    "incident_status_update": ("Update incident status", "Mark an operational incident acknowledged, investigating or resolved.", ""),
    "campaign_create": ("Create campaign", "Create a marketing campaign with audience, message and destination.", ""),
    "campaign_delivery_update": ("Change campaign destination", "Update the delivery method or destination of an existing campaign.", ""),
    "campaign_schedule": ("Schedule campaign", "Place a campaign in the durable queue for a specified time.", ""),
    "campaign_status_update": ("Update campaign status", "Activate, pause, complete or archive a campaign.", ""),
    "signal_cycle_rollover": ("Close and start new period", "Close the active period without deleting history and start a named period.", "Close the current period and start a new one?"),
    "signal_cycle_close": ("Close current period", "Close the active period without deleting any signal or report.", "Close the current period without deleting history?"),
    "signal_cycle_start": ("Start new period", "Start a named period with fresh numbering after the previous period is closed.", ""),
    "signal_cycle_rename": ("Rename period", "Rename an active or closed period without changing its signals.", ""),
    "miniapp_signal_publish": ("Publish signal", "Publish a signal through the shared queue to channels and the Mini App.", ""),
    "miniapp_announcement_publish": ("Publish announcement", "Send an announcement through the durable queue to a public or private channel.", ""),
    "automation_retry": ("Retry failed notification", "Return a retry or dead-letter message to the queue.", "Clear the error counter and retry delivery?"),
    "ticket_admin_reply": ("Reply to ticket", "Add a text or attachment reply to the shared conversation.", ""),
    "ticket_admin_status_update": ("Update ticket status", "Update the ticket status.", ""),
    "ticket_admin_assign": ("Assign ticket", "Assign ticket handling to a specific administrator.", ""),
    "ticket_admin_priority_update": ("Update ticket priority", "Update ticket priority and SLA deadline.", ""),
    "ticket_admin_internal_note": ("Add internal ticket note", "Add a note that is not visible to the user.", ""),
    "shift_handoff_create": ("Create shift handoff", "Record the summary and open items for the next shift administrator.", ""),
    "shift_handoff_status_update": ("Update shift handoff", "Acknowledge or complete a shift handoff.", ""),
    "experiment_create": ("Create growth experiment", "Record the hypothesis, control group and success metric.", ""),
    "experiment_status_update": ("Update experiment status", "Start, pause or complete an experiment.", ""),
    "prop_template_create": ("Create Prop rule template", "Register a Prop firm's limits for risk monitoring.", ""),
    "signal_job_retry": ("Retry signal publication", "Retry failed publication with the same identifier and no duplicate.", "Queue this signal for retry?"),
    "signal_job_cancel": ("Cancel signal publication", "Cancel an item that has not been sent yet.", "Cancel publication of this signal?"),
    "signal_job_update": ("Edit queued signal", "Edit destination, schedule or signal data before delivery.", ""),
    "admin_command_center_snapshot": ("Live command-center snapshot", "Show urgent actions, live metrics and smart recommendations.", ""),
    "admin_global_search": ("Admin global search", "Search all authorized Sentinel domains with permission-aware results.", ""),
    "automation_v2_rule_list": ("List Automation V2 rules", "Show active and draft rules from the new automation engine.", ""),
    "automation_v2_rule_create": ("Create Automation V2 rule", "Create a versioned trigger-condition-action rule with guards.", ""),
    "automation_v2_rule_update": ("Update Automation V2 rule", "Update an existing rule with audit and versioning.", ""),
    "automation_v2_rule_test": ("Dry-run Automation V2 rule", "Test a rule against an event without real delivery.", ""),
    "ai_ad_campaign_create": ("Create Gemini advertisement", "Generate three ad-copy options and save the selected draft campaign.", ""),
    "ai_ad_image_generate": ("Generate Gemini ad image", "Generate, hash, QA and attach a brand-safe image to the campaign.", ""),
    "ai_ad_summary": ("Review Gemini advertisement", "Inspect copy, image, QA status and scheduling information.", ""),
    "ai_ad_approve": ("Human-approve Gemini advertisement", "Approve an advertisement that passed QA.", "Approve this advertisement after human review?"),
    "ai_ad_schedule": ("Schedule Gemini advertisement", "Queue an approved advertisement for durable publishing.", "Schedule this advertisement for publishing?"),
}


def _apply_english_catalog() -> None:
    for action_name, item in ADMIN_ACTION_CATALOG.items():
        label, description, confirmation = _ACTION_EN[action_name]
        item["label_en"] = label
        item["description_en"] = description
        item["group_en"] = _GROUP_EN.get(str(item.get("group") or ""), "Other")
        item["confirmation_en"] = confirmation
        for field in item.get("fields") or []:
            fa_label = str(field.get("label_fa") or "")
            field["label_en"] = _FIELD_EN.get(fa_label, field.get("label_en") or fa_label)
            if field.get("help_fa"):
                field["help_en"] = {
                    "خالی بگذارید تا سامانه کلید امن بسازد.": "Leave blank to generate a secure secret automatically.",
                }.get(str(field.get("help_fa")), str(field.get("help_fa")))
            if isinstance(field.get("placeholder"), str) and any("\u0600" <= ch <= "\u06ff" for ch in field["placeholder"]):
                field["placeholder_en"] = {
                    "کمپین تبدیل ۱۰۰ به ۱۰۰۰": "100 to 1000 campaign",
                }.get(field["placeholder"], "")
            for option in field.get("options") or []:
                fa_option = str(option.get("label") or "")
                option["label_fa"] = fa_option
                option["label_en"] = _OPTION_EN.get(fa_option, fa_option)


_apply_english_catalog()


def catalog_entry(action_name: str) -> dict[str, Any]:
    item = ADMIN_ACTION_CATALOG.get(str(action_name))
    if item:
        return deepcopy(item)
    return {
        "label_fa": "عملیات مدیریتی",
        "label_en": "Admin operation",
        "description_fa": "این عملیات از فرم عمومی JSON رجیستری مشترک اجرا می‌شود.",
        "description_en": "This shared action is available through the generic JSON form.",
        "group": "سایر",
        "group_en": "Other",
        "ui_state": "ready",
        "ui_mode": "json",
        "fields": [],
        "confirmation_fa": "",
        "confirmation_en": "",
        "refresh": [],
    }
