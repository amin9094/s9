from __future__ import annotations

import logging
from typing import Any

from core.db import with_db
from repositories.v2.commerce import CommerceRepository

logger = logging.getLogger(__name__)


def _legacy_order(row: dict[str, Any], receipt: dict[str, Any] | None = None) -> dict[str, Any]:
    receipt = receipt or {}
    order_id = str(row.get("id") or row.get("order_id") or "")
    projected = {
        **row,
        "id": order_id,
        "order_id": order_id,
        "user_id": int(row.get("user_id")) if str(row.get("user_id") or "").isdigit() else row.get("user_id"),
        "price": int(row.get("amount_toman") or row.get("price") or 0),
        "amount_toman": int(row.get("amount_toman") or row.get("price") or 0),
        "normalized_order": True,
        "normalized_order_id": order_id,
        "normalized_updated_at": str(row.get("updated_at") or ""),
        "receipt_id": str(row.get("receipt_id") or row.get("receipt_key") or ""),
        "receipt_storage_backend": receipt.get("storage_backend") or row.get("receipt_storage_backend"),
        "receipt_object_key": receipt.get("object_key") or row.get("receipt_object_key"),
        "receipt_bucket": receipt.get("bucket") or row.get("receipt_bucket"),
        "receipt_path": receipt.get("path") or row.get("receipt_path"),
        "receipt_checksum": receipt.get("checksum") or row.get("receipt_checksum"),
        "receipt_mime": receipt.get("mime") or row.get("receipt_mime"),
        "receipt_size_bytes": receipt.get("size_bytes") or row.get("receipt_size_bytes"),
    }
    return projected


def merge_order_row(db: dict[str, Any], order: dict[str, Any], receipt: dict[str, Any] | None = None) -> bool:
    rows = db.setdefault("vip_orders", [])
    if not isinstance(rows, list):
        rows = []
        db["vip_orders"] = rows
    projected = _legacy_order(order, receipt)
    oid = str(projected["order_id"])
    for index, current in enumerate(rows):
        if isinstance(current, dict) and str(current.get("order_id") or current.get("id") or "") == oid:
            preserved = {
                key: current.get(key)
                for key in (
                    "admin_notified_at", "admin_notification_attempts", "admin_notification_last_error",
                    "admin_notification_next_retry_at", "user_notified_at", "user_notification_attempts",
                    "user_notification_last_error", "user_notification_next_retry_at", "refund_status",
                    "refunded_at", "refunded_by",
                )
                if current.get(key) is not None and projected.get(key) is None
            }
            replacement = {**current, **projected, **preserved}
            if replacement == current:
                return False
            rows[index] = replacement
            return True
    rows.append(projected)
    return True


def project_normalized_order_to_legacy(order_id: int | str) -> dict[str, Any] | None:
    """Deprecated read-only compatibility shim.

    Since v8.15.0 normalized storage is the single source of truth. No legacy
    order copy is written. The normalized row is returned for old callers.
    """
    repo = CommerceRepository()
    order = repo.get(order_id)
    if not order:
        return None
    receipt_id = str(order.get("receipt_id") or order.get("receipt_key") or "")
    receipt = repo.get_receipt_admin(receipt_id) if receipt_id else None
    return _legacy_order(order, receipt)

def project_all_normalized_orders_to_legacy(*, limit: int = 5000) -> int:
    """Legacy materialization is disabled; retained for API compatibility."""
    return 0

def mark_projected_order_notification(order_id: int | str, *, audience: str, success: bool, error: str = "") -> None:
    """Persist delivery outcomes on the authoritative normalized order."""
    CommerceRepository().mark_notification(order_id, audience=audience, success=success, error=error)
