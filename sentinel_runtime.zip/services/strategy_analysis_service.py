"""Explicit admin analysis, with real spread/precision prerequisites."""

from __future__ import annotations

import time
from decimal import Decimal

from core.async_runtime import run_blocking
from modules.canonical_market import ANALYSIS_TIMEFRAMES
from services.canonical_market_service import historical_bars
from services.market_data_issues import data_block, safe_market_error


async def research_analysis(symbol, timeframe, *, instrument=None, parameters=None, engine_parameters=(),
                            provider=None, expected_venue=None, expected_product=None):
    if timeframe not in ANALYSIS_TIMEFRAMES:
        raise ValueError("ANALYSIS_TIMEFRAME_UNAPPROVED")
    from services.canonical_market_service import CORE_SYMBOLS, kraken_rest_pair

    symbol = str(symbol).upper().strip().replace("/", "")
    if symbol not in CORE_SYMBOLS and not symbol.endswith("USDT"):
        raise ValueError("CRYPTO_USDT_MARKET_REQUIRED")
    from services.canonical_market_service import MarketUnavailable
    try:
        bars = await historical_bars(symbol, timeframe, limit=300, **({"provider":provider} if provider else {}))
    except MarketUnavailable as exc:
        return data_block(safe_market_error(exc),symbol=symbol,timeframe=timeframe)
    if not bars:
        return data_block('MARKET_BARS_EMPTY',symbol=symbol,timeframe=timeframe)
    if (provider is not None and bars[-1].provider != provider
            or expected_venue is not None and bars[-1].venue != expected_venue
            or expected_product is not None and bars[-1].product != expected_product):
        return data_block('CHART_ANALYSIS_MARKET_IDENTITY_MISMATCH',symbol=symbol,timeframe=timeframe,
                          provider=bars[-1].provider,product=bars[-1].product)
    if symbol in CORE_SYMBOLS and instrument is None:
        # Analysis is independent of execution: no guessed spread, grid or POC.
        from modules.strategies.common import Parameters
        from modules.strategies.observations import ObservationContext,evaluate_observations
        context = ObservationContext(tuple(bars),int(time.time()*1000),parameters or Parameters(),tuple(engine_parameters))
        try:
            result = await run_blocking(evaluate_observations,context,timeout=20)
        except ValueError as exc:
            allowed = {'INDICATOR_WARMUP_INCOMPLETE','MARKET_DATA_STALE_OR_SESSION_CLOSED',
                       'DELAYED_ANALYSIS_SOURCE','ENGINE_PROFILE_SELECTION_INVALID'}
            reason = str(exc) if str(exc) in allowed else 'INVALID_ANALYSIS_CANDLES'
            return data_block(reason,symbol=symbol,timeframe=timeframe,provider=bars[-1].provider)
        from repositories.v2.market_evidence import MarketEvidenceRepository
        try:
            await run_blocking(lambda:MarketEvidenceRepository().save_candles(bars),timeout=15)
        except ValueError as exc:
            if str(exc) not in {'CLOSED_CANDLE_CORRECTION_REQUIRES_REVIEW','CANDLE_PROVENANCE_CHANGE_REQUIRES_REVIEW'}:
                raise
            return data_block(str(exc),symbol=symbol,timeframe=timeframe,provider=bars[-1].provider)
        if symbol == 'XAUUSD':
            from services.market_reference_service import gold_reference
            try:
                result['independent_reference'] = await gold_reference(symbol)
            except Exception:
                result['independent_reference'] = {'state':'UNAVAILABLE','execution_eligible':False}
        return result
    if symbol in {"US30", "US100", "NAS100"} and bars[-1].product != "cfd":
        return data_block('REQUESTED_CFD_HISTORY_UNAVAILABLE_CASH_INDEX_IS_DIFFERENT_PRODUCT',
                          symbol=symbol,timeframe=timeframe,provider=bars[-1].provider,product=bars[-1].product)
    if instrument is None and bars[-1].provider == "kraken":
        from services.canonical_market_service import _request

        pair = kraken_rest_pair(symbol)
        metadata = await _request("https://api.kraken.com/0/public/AssetPairs", {"pair": pair})
        ticker = await _request("https://api.kraken.com/0/public/Ticker", {"pair": pair})
        details = next(iter((metadata.get("result") or {}).values()), None)
        book = next(iter((ticker.get("result") or {}).values()), None)
        if details and book and details.get("tick_size"):
            spread = Decimal(str(book["a"][0])) - Decimal(str(book["b"][0]))
            instrument = {
                "verified": spread >= 0,
                "provider": "kraken",
                "tick_size": details["tick_size"],
                "spread": str(spread),
                "quote_time_kind": "REST_RECEIPT_ONLY_NOT_VERIFIED_ENTRY",
            }
    if instrument is None and bars[-1].provider == "okx":
        from services.canonical_market_service import _crypto_base, _request

        pair = _crypto_base(symbol) + "-USDT"
        metadata = await _request("https://www.okx.com/api/v5/public/instruments", {"instType": "SPOT", "instId": pair})
        ticker = await _request("https://www.okx.com/api/v5/market/ticker", {"instId": pair})
        details = next(
            (row for row in metadata.get("data") or [] if row.get("instId") == pair and row.get("state") == "live"),
            None,
        )
        book = next((row for row in ticker.get("data") or [] if row.get("instId") == pair), None)
        if metadata.get("code") == ticker.get("code") == "0" and details and book and details.get("tickSz"):
            spread = Decimal(str(book["askPx"])) - Decimal(str(book["bidPx"]))
            age = int(time.time() * 1000) - int(book["ts"])
            instrument = {
                "verified": spread >= 0 and 0 <= age <= 5000,
                "provider": "okx",
                "tick_size": details["tickSz"],
                "spread": str(spread),
                "quote_time_kind": "NATIVE_REST_SNAPSHOT_NOT_VERIFIED_ENTRY",
            }
    # No guessed FX spread, precision, or missing broker/venue equivalence.
    if not instrument or not instrument.get("verified") or instrument.get("provider") != bars[-1].provider:
        return data_block('MATCHING_SPREAD_AND_TICK_SIZE_UNVERIFIED',symbol=symbol,timeframe=timeframe,
                          provider=bars[-1].provider,data_gap='SOURCE_BOUND_SPREAD_AND_NATIVE_PRICE_GRID_REQUIRED')
    from modules.strategy_engines import Context, Parameters, evaluate_all
    from services.strategy_quote_owner import current_owner
    owner=current_owner()
    owner_ready=bool(owner and await owner.ensure(symbol,bars[-1].provider,instrument['tick_size']))

    # Native minute OHLCV supports a labeled profile estimate. Fetch one source
    # only, bounded to six pages; missing causal windows remain explicit review.
    profile_bars = {}
    before = None
    for _ in range(6):
        try:
            minute = await historical_bars(symbol, "1m", limit=300, before_ms=before, provider=bars[-1].provider)
        except (ValueError, RuntimeError):
            break
        if not minute or minute[0].start_ms == before:
            break
        for bar in minute:
            if bar.is_closed:
                profile_bars[bar.start_ms] = bar
        oldest = min(bar.start_ms for bar in minute)
        if oldest <= bars[0].start_ms or before is not None and oldest >= before:
            break
        before = oldest
    profile = tuple(profile_bars[key] for key in sorted(profile_bars))
    cutoff = max(bar.available_ms for bar in (*bars, *profile))
    context = Context(tuple(bars), cutoff, Decimal(str(instrument["tick_size"])), Decimal(str(instrument["spread"])),
                      parameters=parameters or Parameters(),
                      profile_candles=profile, ob_departure_proofs=tuple(instrument.get("ob_departure_proofs") or ()),
                      pip_size=Decimal(str(instrument["pip_size"])) if instrument.get("pip_size") else None)
    if engine_parameters:
        from dataclasses import replace
        context = replace(context, engine_parameters=tuple(engine_parameters))
    # Profile ingestion must not move the chart observation cutoff into an
    # unobserved gap. Refresh the same provider's current bar after pagination.
    if owner_ready or profile and cutoff > max(bar.available_ms for bar in bars):
        from dataclasses import replace

        from services.canonical_market_service import _historical_bars

        refreshed = await _historical_bars(symbol, timeframe, limit=300, provider=bars[-1].provider)
        if refreshed:
            cutoff = max(bar.available_ms for bar in (*refreshed, *profile))
            context = replace(context, candles=tuple(refreshed), cutoff_ms=cutoff)
    if owner_ready:
        from dataclasses import replace
        journal=owner.journal_for(symbol,bars[-1].provider)
        known=next((frame.quote for frame in reversed(journal.rows) if frame.quote.event_ms<=context.cutoff_ms and not frame.snapshot),None) if journal and not journal.failure else None
        if known and known.fresh(int(time.time()*1000)):
            context=replace(context,current_quote=known,spread=known.ask-known.bid)
    from repositories.v2.market_evidence import MarketEvidenceRepository

    context.validate()
    await run_blocking(lambda: MarketEvidenceRepository().save_candles([*context.candles, *profile]), timeout=15)
    result = await run_blocking(evaluate_all, context, timeout=20)
    if bars[-1].provider == "okx":
        from dataclasses import replace

        from services.ordered_trade_evidence_service import okx_departure_proof

        unresolved = [row for row in result["results"] if row.get("reason") == "OB_FIRST_DEPARTURE_ORDER_UNPROVEN"][-3:]
        proofs = list(context.ob_departure_proofs)
        for row in unresolved:
            index = next((i for i, bar in enumerate(context.closed) if bar.source_id == row["ob_source_id"]), None)
            if index is None or index + 1 >= len(context.closed):
                continue
            proof = await okx_departure_proof(context.closed[index], context.closed[index + 1])
            if proof:
                proofs.append(proof)
        if len(proofs) > len(context.ob_departure_proofs):
            # Trade-history receipt is new evidence. Refresh current coverage
            # before advancing the cutoff; never pretend it was known earlier.
            from services.canonical_market_service import _historical_bars

            refreshed = await _historical_bars(symbol, timeframe, limit=300, provider=bars[-1].provider)
            if refreshed:
                context = replace(context, candles=tuple(refreshed), ob_departure_proofs=tuple(proofs),
                                  cutoff_ms=max(*(bar.available_ms for bar in refreshed),
                                                *(proof["available_ms"] for proof in proofs)))
                context.validate()
                await run_blocking(lambda: MarketEvidenceRepository().save_candles(context.candles), timeout=15)
                result = await run_blocking(evaluate_all, context, timeout=20)
    return result
