"""Bounded public TSETMC REST reads for the private administrator equity desk."""

from __future__ import annotations

import asyncio
import time
from urllib.parse import quote

from core.http_client import request
from modules.iran_equities import (
    EQUITY_TYPES,
    analyze_daily,
    daily_bars,
    instrument,
    instrument_code,
    search_hit,
    search_query,
)
from modules.iran_equity_intraday import analyze_h4, h4_bars

_CACHE = {}
_INFLIGHT = {}
_H4_CACHE = {}  # Reconciled bars only, bounded by instrument and trading date.
_H4_BATCH_DAYS = 12
BASE = "https://cdn.tsetmc.com/api/"


class IranEquityUnavailable(RuntimeError):
    pass


async def _fetch(path, ttl):
    cached = _CACHE.get(path)
    if cached and cached[0] > time.monotonic():
        if cached[2]:
            raise IranEquityUnavailable(cached[2])
        return cached[1]
    key = (asyncio.get_running_loop(), path)
    task = _INFLIGHT.get(key)
    if task is None:

        async def work():
            try:
                response = await request("GET", BASE + path, retries=0, timeout_seconds=12)
                if len(response.content) > 12_000_000:
                    raise ValueError("RESPONSE_TOO_LARGE")
                data = response.json()
                if not isinstance(data, dict):
                    raise ValueError("INVALID_RESPONSE")
                if len(_CACHE) >= 128:
                    _CACHE.pop(next(iter(_CACHE)))
                _CACHE[path] = (time.monotonic() + ttl, data, None)
                return data
            except Exception:
                # The source may be blocked from this host. Never leak raw
                # transport errors, disable TLS, proxy around blocks or fake data.
                if len(_CACHE) >= 128:
                    _CACHE.pop(next(iter(_CACHE)))
                _CACHE[path] = (time.monotonic() + 30, None, "TSETMC_SOURCE_UNAVAILABLE")
                raise IranEquityUnavailable("TSETMC_SOURCE_UNAVAILABLE") from None
            finally:
                _INFLIGHT.pop(key, None)

        task = asyncio.create_task(work())
        _INFLIGHT[key] = task
    return await asyncio.shield(task)


async def search_instruments(query):
    query = search_query(query)
    data = await _fetch("Instrument/GetInstrumentSearch/" + quote(query, safe=""), 300)
    rows = data.get("instrumentSearch")
    if not isinstance(rows, list) or len(rows) > 10000:
        raise IranEquityUnavailable("TSETMC_SEARCH_CONTRACT_INVALID")
    found = {}
    for row in rows:
        try:
            item = search_hit(row)
        except ValueError:
            continue
        # Search does not promise yVal/flow. Missing classification must not
        # erase a valid result, nor become a guess based on its Persian name.
        kind = str(row.get("yVal", "")).strip()
        if kind and kind not in EQUITY_TYPES:
            continue
        found[item["ins_code"]] = item
        if len(found) == 40:
            break
    return {
        "items": list(found.values()),
        "provider": "tsetmc",
        "currency": "IRR",
        "supported_product": "iran_cash_equity",
        "classification_required_before_chart": True,
        "api_key_required": False,
    }


async def _intraday_page(code, daily, history, before_ms, now):
    eligible = [d for d in daily if before_ms is None or d.start_ms < before_ms]
    days = eligible[-_H4_BATCH_DAYS:]
    rows = {str(r['dEven']): r for r in history['closingPriceDaily']}
    if code not in _H4_CACHE:
        if len(_H4_CACHE) >= 16:
            _H4_CACHE.pop(next(iter(_H4_CACHE)))
        _H4_CACHE[code] = {}
    cache = _H4_CACHE[code]
    semaphore = asyncio.Semaphore(4)

    def fingerprint(day):
        row = rows[day.date.replace('-', '')]
        return tuple(str(row.get(k)) for k in ('priceFirst','priceMax','priceMin','pDrCotVal',
                                              'pClosing','priceYesterday','qTotTran5J','zTotTran','qTotCap'))

    async def load(day):
        key = day.date
        cached = cache.get(key)
        if cached and cached[0] > time.monotonic() and cached[1] == fingerprint(day):
            return cached[2]
        async with semaphore:
            path = f"Trade/GetTradeHistory/{code}/{key.replace('-', '')}/false"
            raw = await _fetch(path, 300)
            from core.async_runtime import run_blocking
            try:
                bars = await run_blocking(h4_bars, raw, rows[key.replace('-', '')], day, code, now, timeout=10)
            finally:
                # Retain the small reconciled candles, not months of raw trades.
                _CACHE.pop(path, None)
        # Invalidate a prior cached day on contract failure, never retain it as proof.
        if len(cache) >= 180:
            cache.pop(min(cache))
        cache[key] = (time.monotonic() + (86400 if day.is_closed else 30), fingerprint(day), bars)
        return bars

    try:
        async with asyncio.timeout(24):
            pages = await asyncio.gather(*(load(d) for d in days), return_exceptions=True)
            for result in pages:
                if isinstance(result, BaseException):
                    raise result
    except (ValueError, TimeoutError) as exc:
        for day in days:
            cache.pop(day.date, None)
        raise IranEquityUnavailable('IR_EQUITY_INTRADAY_INCOMPLETE') from exc
    page = [b for group in pages for b in group if before_ms is None or b.start_ms < before_ms]
    # Analysis must have an uninterrupted suffix of verified trading dates.
    suffix = []
    for day in reversed(daily):
        cached = cache.get(day.date)
        if not cached or cached[0] <= time.monotonic() or cached[1] != fingerprint(day):
            break
        suffix[0:0] = cached[2]
    analysis = analyze_h4(suffix, daily, now)
    has_earlier_days = len(eligible) > len(days)
    return page, analysis, has_earlier_days


async def equity_chart(code, *, limit=300, before_ms=None, timeframe='1d'):
    code = instrument_code(code)
    if timeframe not in {'4h', '1d'}:
        raise ValueError('IR_EQUITY_TIMEFRAME_INVALID')
    now = int(time.time() * 1000)
    if not isinstance(limit, int) or isinstance(limit, bool) or not 1 <= limit <= 500:
        raise ValueError("IR_EQUITY_LIMIT_INVALID")
    if before_ms is not None and (
        not isinstance(before_ms, int) or isinstance(before_ms, bool) or not 0 < before_ms <= now + 1000
    ):
        raise ValueError("IR_EQUITY_CURSOR_INVALID")
    identity_raw = await _fetch("Instrument/GetInstrumentInfo/" + code, 3600)
    try:
        identity = instrument(identity_raw.get("instrumentInfo"), expected_code=code)
    except ValueError as exc:
        raise IranEquityUnavailable(str(exc)) from None
    # Verify the cash-equity identity before spending a history request.
    history = await _fetch("ClosingPrice/GetClosingPriceDailyList/" + code + "/0", 300)
    try:
        bars, skipped = daily_bars(history, code, now)
    except ValueError as exc:
        raise IranEquityUnavailable(str(exc)) from None
    if timeframe == '4h':
        eligible, analysis, more_days = await _intraday_page(code, bars, history, before_ms, now)
    else:
        eligible = [b for b in bars if before_ms is None or b.start_ms < before_ms]
        analysis = None
        more_days = False
    selected = eligible[-limit:]
    from core.async_runtime import run_blocking

    if analysis is None:
        analysis = await run_blocking(analyze_daily, bars, now, timeout=10)
    return {
        **identity,
        "bars": [b.chart_bar() for b in selected],
        "timeframe": timeframe,
        "has_more": more_days or len(eligible) > len(selected),
        "history_batch_days": _H4_BATCH_DAYS if timeframe == '4h' else None,
        "bucket_alignment": 'TEHRAN_MIDNIGHT_4H' if timeframe == '4h' else 'TEHRAN_CALENDAR_DAY',
        "intraday_reconciliation": 'DAILY_COUNT_VOLUME_VALUE_OHLC' if timeframe == '4h' else None,
        "timezone": "Asia/Tehran",
        "display_price_precision": min(
            8, max(-v.normalize().as_tuple().exponent for b in bars for v in (b.open, b.high, b.low, b.close))
        ),
        "adjustment": "UNADJUSTED",
        "close_basis": "LAST_TRADE",
        "volume_kind": "RECONCILED_TRADES" if timeframe == '4h' else "REPORTED_DAILY_TRADED",
        "volume_unit": "shares",
        "skipped_nontrading_days": skipped,
        "latest_trade_date": bars[-1].date,
        "last_closed_ms": max((b.end_ms for b in eligible if b.is_closed), default=None),
        "observed_ms": now,
        "poll_seconds": 300,
        "state": analysis["state"],
        "analysis": analysis,
        "source_url": "https://www.tsetmc.com/instInfo/" + code,
        "execution_eligible": False,
        "publicly_approved": False,
        "session_calendar_verified": False,
    }
