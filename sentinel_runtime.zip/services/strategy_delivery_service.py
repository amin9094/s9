"""Private proposals and individually approved Telegram events; no auto approval."""

import asyncio
import time

from config import SETTINGS
from core.async_runtime import run_blocking
from modules.setup_lifecycle import SetupPlan
from repositories.v2.common import content_hash, json_load
from repositories.v2.setup_proposals import SetupRepository
from repositories.v2.strategy_live import StrategyLiveRepository


def channel_target(audience):
    target={'telegram_public':SETTINGS.public_channel_id,'telegram_private':SETTINGS.private_channel_id}.get(audience)
    if not target:
        raise ValueError('TELEGRAM_SIGNAL_CHANNEL_UNCONFIGURED')
    return str(int(target))


def event_content(repository, row, event_id):
    if event_id=='SIGNAL':
        return row['payload']['plan_hash'], None
    with repository.engine.transaction(read_only=True) as cursor:
        event=cursor.execute('SELECT * FROM s9_setup_events WHERE setup_id=? AND id=?',(row['id'],event_id)).fetchone()
    if not event:
        raise ValueError('EVENT_NOT_FOUND')
    event['payload']=json_load(event['payload'])
    return content_hash(event['payload']),event


def authorize_telegram_event(user_id, setup_id, body):
    from core.db import read_db_sections
    from modules.admin_access import has_permission
    permission='signals' if body.get('event_id','SIGNAL')=='SIGNAL' else 'signal_results'
    if not has_permission(read_db_sections(('delegated_admins','admin_shifts')),user_id,permission):
        raise PermissionError('FORBIDDEN')
    audience=body['audience']
    target=channel_target(audience)
    repository=SetupRepository()
    live=StrategyLiveRepository(repository.engine)
    with repository.engine.atomic():
        row=repository.get(setup_id)
        if not row or row['plan_version']!=body['version']:
            raise ValueError('STALE_PLAN_APPROVAL')
        event_id=body.get('event_id') or 'SIGNAL'
        if event_id=='SIGNAL':
            if row['payload']['state']['phase']!='PROPOSED_PRETOUCH' or row['payload'].get('tracking_state')=='NEEDS_REVIEW':
                raise ValueError('INITIAL_SIGNAL_MUST_PRECEDE_FIRST_TOUCH')
        else:
            with repository.engine.transaction(read_only=True) as cursor:
                sent=cursor.execute("SELECT payload FROM s9_deliveries WHERE setup_id=? AND plan_version=? AND event_id='SIGNAL' AND audience=? AND target_id=? AND state='SENT'",
                                    (setup_id,body['version'],audience,target)).fetchone()
            if not sent or json_load(sent['payload']).get('detail')!='DELIVERED':
                raise ValueError('INITIAL_SIGNAL_DELIVERY_REQUIRED')
        digest,_=event_content(repository,row,event_id)
        approval=repository.approve(setup_id,version=body['version'],actor=user_id,audience=audience,event_id=event_id)
        delivery=live.enqueue(setup_id=setup_id,version=body['version'],event_id=event_id,audience=audience,
                              target_id=target,content_hash=digest,actor=str(user_id))
        with repository.engine.transaction(read_only=True) as cursor:
            current=cursor.execute('SELECT state FROM s9_deliveries WHERE id=?',(delivery,)).fetchone()['state']
    return {'approval_id':approval,'delivery_id':delivery,'audience':audience,'state':'QUEUED_NOT_SENT' if current=='PENDING' else current}


def delivery_text(row, *, event=None, private=False):
    p=row['payload']['plan']
    if event is None:
        title='پیشنهاد سیگنال برای بررسی ادمین' if private else 'طرح معاملاتی تأییدشده توسط ادمین'
        lines=[title,f"{p['symbol']} · {p['timeframe']} · {p['direction']}",
               f"سبک: {p['engine']} / {p['submodel']}",f"Entry: {p['entry']} · SL: {p['stop']}",
               f"TP1: {p['tp1']} · TP2: {p['tp2']}"]
        if p.get('tp3') is not None:
            lines.append(f"TP3: {p['tp3']}")
        lines.extend([f"Setup: {row['id']} · v{row['plan_version']}",'ورود برنامه‌ریزی‌شده است؛ اجرای معامله در بروکر انجام نشده است.'])
        if private:
            lines.append('انتشار عمومی و هر تغییر وضعیت، تأیید جداگانهٔ ادمین می‌خواهد.')
        return '\n'.join(lines)
    return '\n'.join(['رویداد سیگنال — تأییدشده توسط ادمین',f"{p['symbol']} · {p['timeframe']} · {p['direction']}",
                      f"رویداد: {event['event_type']}",f"Setup: {row['id']} · v{row['plan_version']}",
                      'این ثبتِ وضعیت سیگنال است؛ رسید اجرای سفارش بروکر نیست.'])


async def deliver_cycle(bot, owner, *, repository=None, live_repository=None):
    if owner is None:
        return {'state':'QUOTE_OWNER_UNAVAILABLE','sent':0}
    repository=repository or owner.repository
    live=live_repository or owner.live
    claimed=await run_blocking(live.claim,timeout=5)
    sent=0
    for intent in claimed:
        transmitted=False
        try:
            row=await run_blocking(repository.get,intent['setup_id'],timeout=5)
            if not row or row['plan_version']!=intent['plan_version']:
                raise ValueError('DELIVERY_PLAN_VERSION_CHANGED')
            plan=SetupPlan.from_dict(row['payload']['plan'])
            digest,event=await run_blocking(event_content,repository,row,intent['event_id'],timeout=5)
            if digest!=intent['content_hash'] or plan.plan_hash!=row['payload']['plan_hash']:
                raise ValueError('DELIVERY_CONTENT_HASH_CHANGED')
            private=intent['audience']=='admin'
            if private:
                allowed=await run_blocking(owner.admin_ids_for,'signals',timeout=5)
                if intent['target_id'] not in {str(int(v)) for v in allowed}:
                    raise ValueError('DELIVERY_RECIPIENT_PERMISSION_REVOKED')
            else:
                from services.setup_review_service import can_publish_approved_delivery
                if not await run_blocking(can_publish_approved_delivery,intent,timeout=5):
                    raise ValueError('DELIVERY_APPROVAL_OR_PERMISSION_REVOKED')
                if channel_target(intent['audience'])!=intent['target_id']:
                    raise ValueError('DELIVERY_CHANNEL_CONFIGURATION_CHANGED')
            if event is None:
                if row['payload']['state']['phase']!='PROPOSED_PRETOUCH' or row['payload'].get('tracking_state')=='NEEDS_REVIEW':
                    raise ValueError('INITIAL_SIGNAL_MUST_PRECEDE_FIRST_TOUCH')
                epoch=row['payload']['freshness_proof'].get('epoch','')
                preflight=await owner.freshness(plan,epoch=epoch,start_ms=plan.evidence_cutoff_ms,through_ms=int(time.time()*1000))
                owner.pre_send_proof(plan, epoch=epoch, verified_through_ms=preflight['observed_through_ms'])
            async with asyncio.timeout(10):
                transmitted=True
                message=await bot.send_message(chat_id=int(intent['target_id']),text=delivery_text(row,event=event,private=private))
            delivered_ms=int(time.time()*1000)
        except asyncio.CancelledError:
            # A cancelled in-flight send remains SENDING: never auto duplicate it.
            raise
        except Exception as exc:
            from telegram.error import BadRequest, Forbidden, RetryAfter
            retry=getattr(exc,'retry_after',0)
            retry=retry.total_seconds() if hasattr(retry,'total_seconds') else retry
            status='PENDING' if isinstance(exc,RetryAfter) else 'FAILED' if isinstance(exc,(BadRequest,Forbidden)) else 'UNCERTAIN' if transmitted else 'REVOKED'
            await run_blocking(live.finish_delivery,intent['id'],status,retry_seconds=retry,
                               detail=str(exc) if isinstance(exc,ValueError) else type(exc).__name__,timeout=5)
            continue
        # Once a receipt is known, complete verification/correction even if the
        # caller is cancelled. Unknown receipts remain UNCERTAIN, never retried.
        completion=asyncio.create_task(_complete_delivery(bot,owner,repository,live,intent,row,plan,event,
                                                         private,epoch if event is None else None,message,delivered_ms))
        try:
            await asyncio.shield(completion)
        except asyncio.CancelledError:
            await completion
            raise
        sent+=1
    return {'state':'DELIVERY_CYCLE','sent':sent}


async def _correct_late_message(bot, intent, row, message):
    """Withdraw a known late/unproven entry notice in the same destination."""
    text='\n'.join(['⛔ سیگنال ورود معتبر نیست — ارسال پیش از ورود تأیید نشد.',
                    'قیمت به محدوده رسیده یا پیوستگی داده تأیید نشده است؛ منتظر ورود این ستاپ نباشید.',
                    f"Setup: {row['id']} · v{row['plan_version']}",
                    'این پیام نیازمند بررسی ادمین است.'])
    try:
        async with asyncio.timeout(5):
            await bot.edit_message_text(chat_id=int(intent['target_id']),message_id=message.message_id,text=text)
        return 'INVALID_NOTICE_EDITED'
    except Exception:
        try:
            async with asyncio.timeout(5):
                await bot.delete_message(chat_id=int(intent['target_id']),message_id=message.message_id)
            return 'INVALID_NOTICE_DELETED'
        except Exception:
            return 'INVALID_NOTICE_CORRECTION_FAILED'


async def _complete_delivery(bot,owner,repository,live,intent,row,plan,event,private,epoch,message,delivered_ms):
    detail='DELIVERED'
    verification=None
    try:
        if event is None:
            proof=await owner.freshness(plan,epoch=epoch,start_ms=plan.evidence_cutoff_ms,through_ms=delivered_ms)
            verification={**proof,'receipt_observed_ms':delivered_ms,'delivery_qualified':True}
            if private:
                await run_blocking(repository.record_admin_delivery,row['id'],delivered_ms=delivered_ms,
                                   untouched_through_ms=proof['observed_through_ms'],proof=proof,timeout=5)
    except Exception:
        detail='DELIVERED_BUT_PRETOUCH_UNPROVEN'
        correction=await _correct_late_message(bot,intent,row,message)
        verification={'delivery_qualified':False,'receipt_observed_ms':delivered_ms,'notification_correction':correction}
        await run_blocking(repository.require_tracking_review,row['id'],reason=detail,now_ms=delivered_ms,timeout=5)
    # Persist the known receipt before any optional admin notice can fail.
    await run_blocking(live.finish_delivery,intent['id'],'SENT',message_id=message.message_id,detail=detail,
                       verification=verification,timeout=5)
    if detail!='DELIVERED':
        await owner._notice(row,'NEEDS_REVIEW',detail+':'+verification['notification_correction'])
