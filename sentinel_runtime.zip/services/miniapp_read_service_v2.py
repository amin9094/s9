from __future__ import annotations

import logging
import math
import re
from datetime import UTC, datetime
from typing import Any

from config import SETTINGS, is_primary_admin
from core.db import read_db_sections, with_db
from core.storage.engine import DatabaseEngine, normalized_engine
from core.utils import parse_dt
from core.webapp_auth import TelegramWebAppIdentity
from modules.admin_access import ALL_PERMISSIONS, PERMISSION_SIGNAL_BOARD_MANAGE, PERMISSION_SIGNALS, get_delegated_admin, has_permission, is_any_admin
from services.access_policy import enabled_feature_payload
from modules.i18n import user_language
from modules.miniapp_product import vip_catalog
from modules.notification_router import notification_preferences
from modules.product_intelligence import onboarding_snapshot
from modules.rules import current_rules, user_has_accepted_rules
from core.domain import is_vip
from repositories.v2.accounts import AccountRepository
from repositories.v2.commerce import CommerceRepository
from repositories.v2.journal import JournalRepository
from repositories.v2.positions import PositionRepository
from repositories.v2.preferences import PreferenceRepository
from repositories.v2.signals import SignalRepository
from repositories.v2.support import SupportRepository
from modules.signal_status import normalize_signal_status, signal_is_final, signal_status_rank
from modules.signal_engine import signal_rr_snapshot
from modules.signal_portal import list_signal_cycles, signal_cycle_detail, signal_cycle_summary
from modules.market_scope import classify_market_symbol
from modules.prop_rules_v2 import PropRuleEngine
from modules.data_confidence import DataConfidenceService
from modules.market_analytics.correlation import CorrelationService
from repositories.v2.common import content_hash, utc_iso
from services import miniapp_v2_service as legacy

logger = logging.getLogger(__name__)

# Compatibility-only domains. Core trading/financial reads are normalized SQL.
_SHELL_SECTIONS = (
    "users", "user_profiles", "user_points", "vip_users", "vip_plans", "vip_settings", "discount_codes",
    "settings", "admin_control_center", "rules", "rules_settings", "rules_acceptances", "delegated_admins",
    "admin_shifts", "user_notification_preferences", "miniapp_onboarding",
)


def _repos() -> tuple[DatabaseEngine, AccountRepository, PositionRepository, SignalRepository, JournalRepository, CommerceRepository, SupportRepository, PreferenceRepository]:
    engine = normalized_engine()
    return (
        engine, AccountRepository(engine), PositionRepository(engine), SignalRepository(engine),
        JournalRepository(engine), CommerceRepository(engine), SupportRepository(engine), PreferenceRepository(engine),
    )


def _safe_shell(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    db = read_db_sections(_SHELL_SECTIONS)
    uid = str(identity.user_id)
    preferences = PreferenceRepository()
    language = user_language(db, uid) or "fa"
    profile = db.get("user_profiles", {}).get(uid, {})
    if not isinstance(profile, dict):
        profile = {}
    users = db.get("users", {}) if isinstance(db.get("users"), dict) else {}
    user = users.get(uid, {}) if isinstance(users.get(uid), dict) else {}
    normalized_entitlement = CommerceRepository().entitlement_for_user(uid)
    vip_active = bool(normalized_entitlement and normalized_entitlement.get("active")) or is_vip(db, uid)
    notifications = notification_preferences(db, uid)
    onboarding = preferences.get(uid, "miniapp_onboarding", None)
    if not isinstance(onboarding, dict):
        onboarding = onboarding_snapshot(db, uid)
    onboarding = dict(onboarding or {})
    # Self-heal setups saved by releases that persisted answers/account data but
    # omitted the normalized completion flag. This migration is intentionally
    # conservative: an account plus the essential answers is enough evidence
    # that the user completed setup and must not be prompted again.
    existing_account = AccountRepository().get(uid)
    inferred_complete = bool(
        existing_account
        and float(existing_account.get("balance") or 0) > 0
        and str(onboarding.get("experience") or "").strip()
        and str(onboarding.get("goal") or "").strip()
    )
    if inferred_complete and not onboarding.get("completed"):
        onboarding = {
            **onboarding,
            "completed": True,
            "completed_at": onboarding.get("completed_at") or existing_account.get("created_at") or utc_iso(),
            "setup_version": max(2, int(onboarding.get("setup_version") or 0)),
            "account_name": onboarding.get("account_name") or existing_account.get("name"),
            "balance": float(onboarding.get("balance") or existing_account.get("balance") or 0),
            "equity": float(onboarding.get("equity") or existing_account.get("equity") or existing_account.get("balance") or 0),
        }
        preferences.set(uid, "miniapp_onboarding", onboarding)
    rules = current_rules(db, language)
    primary_admin = is_primary_admin(uid)
    delegated = get_delegated_admin(db, uid)
    delegated_permissions = delegated.get("permissions", []) if isinstance(delegated, dict) else []
    permissions = list(ALL_PERMISSIONS) if primary_admin else [
        str(item) for item in delegated_permissions if str(item) in ALL_PERMISSIONS
    ]
    role = "owner" if primary_admin else "admin" if is_any_admin(db, uid) else "user"
    return {
        "db": db,
        "uid": uid,
        "language": language,
        "user": {
            "id": identity.user_id,
            "username": identity.username or str(profile.get("username") or user.get("username") or ""),
            "first_name": identity.first_name or str(profile.get("first_name") or user.get("first_name") or ""),
            "last_name": identity.last_name or str(profile.get("last_name") or user.get("last_name") or ""),
            "language": language,
            "role": role,
            "is_admin": role in {"owner", "admin"},
            "permissions": permissions,
        },
        "points": max(0, int((db.get("user_points", {}) or {}).get(uid, 0) or 0)),
        "vip_active": vip_active,
        "vip_expires_at": (__import__("core.membership_bridge", fromlist=["later_membership"]).later_membership((db.get("vip_users", {}) or {}).get(uid), normalized_entitlement) or {}).get("expires_at"),
        "vip_entitlement_source": "normalized" if normalized_entitlement and normalized_entitlement.get("active") else "legacy",
        "notifications": notifications,
        "onboarding": onboarding,
        "features": enabled_feature_payload(db),
        "commerce": vip_catalog(db, uid, vip_active=vip_active),
        "rules": {**rules, "language": language, "accepted": (not rules.get("enabled", True) or not rules.get("text") or int(rules.get("version") or 0) <= 0 or user_has_accepted_rules(db, uid, language))},
        "admin_available": is_any_admin(db, uid),
        "admin": {"available": role in {"owner", "admin"}, "role": role, "permissions": permissions},
        "miniapp_runtime": __import__("modules.miniapp_runtime", fromlist=["miniapp_runtime_state"]).miniapp_runtime_state(db),
    }


def access_context(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    """Return the minimum server-authoritative access data needed by streams."""
    shell = _safe_shell(identity)
    user = shell.get("user") if isinstance(shell.get("user"), dict) else {}
    return {
        "vip_active": bool(shell.get("vip_active")),
        "is_admin": bool(user.get("is_admin")),
        "role": str(user.get("role") or "user"),
    }


def _safe_mt5_connectors(engine: Any, user_id: int | str, account_id: str | int | None = None) -> list[dict[str, Any]]:
    try:
        from repositories.v2.mt5_connectors import MT5ConnectorRepository
        return MT5ConnectorRepository(engine).list_for_user(user_id, account_id)
    except Exception:
        return []


def _safe_prop_guardian(engine: Any, user_id: int | str, account_id: str | int | None = None) -> dict[str, Any]:
    try:
        from services.prop_guardian_service import account_guardian_snapshot, prop_guardian_dashboard
        if account_id not in {None, ""}:
            return account_guardian_snapshot(user_id, account_id, record=False, engine=engine)
        return prop_guardian_dashboard(user_id, record=False, engine=engine)
    except Exception as exc:
        return {"status": "unavailable", "reason": str(exc), "accounts": []}


def _safe_risk_coach(user_id: int | str) -> dict[str, Any]:
    try:
        from services.risk_coach_service import consolidated_behavioral_report
        return consolidated_behavioral_report(user_id)
    except Exception as exc:
        return {"status": "unavailable", "reason": str(exc), "findings": [], "recommendations": []}


def _safe_daily_plan(engine: Any, user_id: int | str, account_id: str | int) -> dict[str, Any] | None:
    try:
        from services.risk_coach_service import get_or_create_daily_plan
        return get_or_create_daily_plan(user_id, account_id, engine=engine)
    except Exception:
        return None


def _account_risk(user_id: int | str, account_id: str | int | None = None) -> dict[str, Any]:
    engine, accounts, positions, *_ = _repos()
    rule_engine = PropRuleEngine(engine)
    templates = rule_engine.list_templates()
    rows = accounts.list_for_user(user_id)
    selected = accounts.get(user_id, account_id) if account_id is not None else accounts.get(user_id)
    from modules.broker_readonly import authorized_account_reference
    for account in [*rows, *([selected] if selected else [])]:
        try:
            account["broker_account_reference"] = authorized_account_reference(user_id, str(account["id"]))
            account["broker_sync_available"] = True
        except ValueError:
            account["broker_sync_available"] = False
    if not selected:
        return {
            "accounts": rows, "selected_account": None, "exposure": {"open_count": 0, "risk_percent": 0.0, "risk_money": 0.0},
            "portfolio_exposure": {"open_count": 0, "risk_percent": 0.0, "risk_money": 0.0},
            "prop": {"decision": "unconfigured", "hard_blocks": [], "warnings": [], "metrics": {}},
            "what_if": {}, "correlation": {"kind": "rolling_pearson", "items": []}, "positions": [],
            "prop_templates": templates,
            "mt5_connectors": _safe_mt5_connectors(engine, user_id),
            "prop_guardian": _safe_prop_guardian(engine, user_id),
            "risk_coach": _safe_risk_coach(user_id),
        }
    exposure = positions.active_exposure(user_id, selected["id"])
    portfolio = positions.active_exposure(user_id)
    decision = rule_engine.evaluate(user_id=user_id, account_id=selected["id"], record=False)
    active = positions.list_for_user(user_id, account_id=selected["id"], status="active", limit=100)
    # Aggregate every active position; the UI's 100-row page is not the total.
    worst_case = -float(exposure["risk_money"])
    projected_equity = float(selected["equity"]) + worst_case
    reference = float(decision.metrics["total_drawdown_reference"])
    projected_drawdown = max(0.0, (reference - projected_equity) / max(reference, 1e-9) * 100)

    symbols = [str(row.get("symbol") or "") for row in active["items"] if str(row.get("symbol") or "").strip()]
    correlation = CorrelationService(engine).rolling(symbols) if len(set(symbols)) >= 2 else {
        "kind": "rolling_pearson", "symbols": sorted(set(symbols)), "windows": {},
        "generated_at": utc_iso(), "confidence": 0.0, "status": "insufficient_symbols",
    }
    confidence_service = DataConfidenceService(engine)
    account_confidence = {
        field: confidence_service.get("trading_account", str(selected["id"]), field)
        for field in ("balance", "equity", "floating_pnl")
    }
    with engine.transaction(read_only=True) as cursor:
        broker_row = cursor.execute(
            "SELECT payload FROM v8_broker_snapshots WHERE account_id=? ORDER BY observed_at DESC LIMIT 1",
            (str(selected["id"]),),
        ).fetchone()
    from repositories.v2.common import json_load
    broker_snapshot = json_load(broker_row.get("payload"), {}) if broker_row else None
    return {
        "accounts": rows,
        "selected_account": selected,
        "exposure": {
            **exposure,
            "open_risk_percent": float(exposure.get("risk_percent") or 0),
            "open_risk_money": float(exposure.get("risk_money") or 0),
            "open_trades": int(exposure.get("open_count") or 0),
            "daily_risk_percent": float(decision.metrics.get("daily_loss_percent") or 0),
            "remaining_daily_risk_percent": max(0.0, float(decision.metrics.get("daily_loss_limit_percent") or 0) - float(decision.metrics.get("daily_loss_percent") or 0)),
        },
        "account_exposure": {
            **exposure,
            "open_risk_percent": float(exposure.get("risk_percent") or 0),
            "open_trades": int(exposure.get("open_count") or 0),
        },
        "portfolio_exposure": {
            "open_count": int(portfolio.get("open_count") or 0),
            "risk_percent": float(portfolio.get("risk_percent") or 0),
            "risk_money": float(portfolio.get("risk_money") or 0),
        },
        "prop": {
            "decision": decision.decision, "status": "safe" if decision.allowed and not decision.warnings else ("warning" if decision.allowed else "blocked"),
            "hard_blocks": list(decision.hard_blocks), "warnings": list(decision.warnings), "metrics": decision.metrics,
            "template_id": decision.template_id, "rules_version": decision.rules_version, "breaches": list(decision.hard_blocks),
            "daily_loss_used_percent": float(decision.metrics.get("daily_loss_percent") or 0),
            "daily_loss_remaining_percent": max(0.0, float(decision.metrics.get("daily_loss_limit_percent") or 0) - float(decision.metrics.get("daily_loss_percent") or 0)),
            "total_drawdown_percent": float(decision.metrics.get("total_drawdown_percent") or 0),
            "total_loss_remaining_percent": max(0.0, float(decision.metrics.get("total_loss_limit_percent") or 0) - float(decision.metrics.get("total_drawdown_percent") or 0)),
            "profit_progress_percent": float(decision.metrics.get("profit_progress_percent") or 0),
            "trading_days": int(decision.metrics.get("trading_days") or 0),
            "min_trading_days": int(decision.metrics.get("min_trading_days") or 0),
        },
        "what_if": {
            "all_stops_pnl": worst_case, "all_stops_loss_amount": worst_case,
            "equity_after_all_stops": float(selected.get("equity") or 0) + worst_case,
            "worst_case_equity": float(selected.get("equity") or 0) + worst_case,
            "worst_case_drawdown_percent": projected_drawdown,
            "would_breach_total_loss": projected_drawdown >= float(decision.metrics["total_loss_limit_percent"]),
        },
        "correlation": correlation,
        "data_confidence": account_confidence,
        "broker_snapshot": broker_snapshot,
        "prop_templates": templates,
        "positions": active["items"],
        "default_account": selected,
        "weekly_risk": __import__("services.risk_coach_service", fromlist=["weekly_signal_risk_summary"]).weekly_signal_risk_summary(user_id, selected),
        "mt5_connectors": _safe_mt5_connectors(engine, user_id, selected["id"]),
        "prop_guardian": _safe_prop_guardian(engine, user_id, selected["id"]),
        "risk_coach": _safe_risk_coach(user_id),
        "daily_plan": _safe_daily_plan(engine, user_id, selected["id"]),
        "next_cursor": active.get("next_cursor"),
    }


def _journal_stats(engine: DatabaseEngine, user_id: int | str) -> dict[str, Any]:
    with engine.transaction(read_only=True) as cursor:
        rows = cursor.execute(
            """SELECT status,pnl_amount,pnl_percent,payload FROM v8_journal_entries
               WHERE user_id=? AND status!='archived' ORDER BY opened_at,id""",
            (str(user_id),),
        ).fetchall()
    wins = losses = closed = 0
    net_pnl = pnl_sum = costs = r_net = r_won = r_lost = 0.0
    equity_curve = peak = max_drawdown = 0.0
    channel_entries = personal_entries = r_count = 0
    from repositories.v2.common import json_load
    for db_row in rows:
        payload = json_load(db_row.get("payload"), {}) or {}
        status = str(db_row.get("status") or payload.get("status") or "").lower()
        pnl_amount = float(db_row.get("pnl_amount") or payload.get("pnl_amount") or 0)
        pnl_percent = float(db_row.get("pnl_percent") or payload.get("pnl_percent") or 0)
        result_r = payload.get("result_r")
        reason_type = str(payload.get("entry_reason_type") or "")
        if reason_type == "channel_signal" or str(payload.get("source") or "") in {"channel_signal", "signal_taken"}:
            channel_entries += 1
        else:
            personal_entries += 1
        costs += float(payload.get("fees") or 0) + float(payload.get("commission") or 0) + float(payload.get("swap") or 0)
        if status == "closed":
            closed += 1; net_pnl += pnl_amount; pnl_sum += pnl_percent
            score = float(result_r) if result_r not in {None, ""} else pnl_percent
            if score > 0: wins += 1
            elif score < 0: losses += 1
            if result_r not in {None, ""}:
                rv = float(result_r); r_count += 1; r_net += rv
                if rv > 0: r_won += rv
                elif rv < 0: r_lost += abs(rv)
            equity_curve += pnl_percent; peak = max(peak, equity_curve); max_drawdown = max(max_drawdown, peak - equity_curve)
    return {
        "total": len(rows), "closed": closed, "open": sum(1 for row in rows if str(row.get("status") or "") in {"open", "partial"}),
        "wins": wins, "losses": losses, "win_rate": round(wins / closed * 100, 2) if closed else 0.0,
        "net_pnl": round(net_pnl, 4), "pnl_sum": round(pnl_sum, 4), "avg_pnl_percent": round(pnl_sum / closed, 4) if closed else 0.0,
        "costs": round(costs, 4), "max_drawdown": round(max_drawdown, 4),
        "r_count": r_count, "r_net": round(r_net, 4), "r_won": round(r_won, 4), "r_lost": round(r_lost, 4),
        "avg_r": round(r_net / r_count, 4) if r_count else 0.0,
        "profit_factor_r": round(r_won / r_lost, 4) if r_lost else round(r_won, 4),
        "channel_signal_entries": channel_entries, "personal_entries": personal_entries,
    }


def _float_value(value: Any) -> float | None:
    """Return a finite float or ``None`` for missing/unsafe numeric input."""
    try:
        if value in {None, ""}:
            return None
        parsed = float(str(value).replace(",", "").strip())
        return parsed if math.isfinite(parsed) else None
    except (TypeError, ValueError):
        return None


def _numeric_values(value: Any) -> list[float]:
    values = value if isinstance(value, list) else [value]
    result: list[float] = []
    for item in values:
        if isinstance(item, dict):
            item = item.get("price") or item.get("value") or item.get("target")
        if isinstance(item, str):
            grouped = re.fullmatch(r"[0-9]{1,3}(?:,[0-9]{3})+(?:\.[0-9]+)?", item.strip())
            scalar = _float_value(item) if "," not in item or grouped else None
            fragments = [scalar] if scalar is not None else [part for part in re.split(r"[\s,;/|–—-]+", item.strip()) if part]
        else:
            fragments = [item]
        for fragment in fragments:
            parsed = _float_value(fragment)
            if parsed is not None:
                result.append(parsed)
    return result


def _signal_live_metrics(row: dict[str, Any], quote: dict[str, Any] | None) -> dict[str, Any]:
    entries = _numeric_values(row.get("entries"))
    if not entries:
        entries = _numeric_values(row.get("entry_price") or row.get("entry"))
    entry_min = _float_value(row.get("entry_min"))
    entry_max = _float_value(row.get("entry_max"))
    if entry_min is not None:
        entries.append(entry_min)
    if entry_max is not None:
        entries.append(entry_max)
    entries = sorted(set(entries))
    low = min(entries) if entries else None
    high = max(entries) if entries else None
    rr_metrics = signal_rr_snapshot(row)
    reference = rr_metrics["rr_entry"]
    current = _float_value((quote or {}).get("price"))
    inside = bool(current is not None and low is not None and high is not None and low <= current <= high)
    nearest = None
    if current is not None and low is not None and high is not None:
        nearest = low if current < low else high if current > high else current
    distance = None
    signed_distance = None
    if current not in {None, 0} and nearest is not None:
        signed_distance = ((nearest - current) / abs(current)) * 100.0
        distance = abs(signed_distance)
    side = str(row.get("side") or "buy").lower()
    is_sell = side in {"sell", "short"}
    waiting_for_entry = bool(
        current is not None and low is not None and high is not None
        and ((not is_sell and current < low) or (is_sell and current > high))
    )
    passed_entry = bool(current is not None and low is not None and high is not None and not inside and not waiting_for_entry)
    if inside:
        activation_text_fa = "نقطه ورود فعال شده"
        activation_text_en = "Entry zone is active"
        entry_status = "active"
    elif waiting_for_entry and distance is not None:
        activation_text_fa = f"{distance:.3f}٪ تا فعال‌شدن نقطه ورود"
        activation_text_en = f"{distance:.3f}% until entry activation"
        entry_status = "waiting"
    elif passed_entry and distance is not None:
        activation_text_fa = f"قیمت {distance:.3f}٪ از محدوده ورود عبور کرده"
        activation_text_en = f"Price moved {distance:.3f}% beyond the entry zone"
        entry_status = "passed"
    else:
        activation_text_fa = "قیمت لحظه‌ای در دسترس نیست"
        activation_text_en = "Live price unavailable"
        entry_status = "unavailable"
    return {
        "current_price": current,
        "entry_low": low,
        "entry_high": high,
        "entry_reference": reference,
        "inside_entry_zone": inside,
        "entry_status": entry_status,
        "waiting_for_entry": waiting_for_entry,
        "passed_entry": passed_entry,
        "distance_from_entry_percent": round(distance, 5) if distance is not None else None,
        "signed_distance_from_entry_percent": round(signed_distance, 5) if signed_distance is not None else None,
        "activation_text_fa": activation_text_fa,
        "activation_text_en": activation_text_en,
        "side": side,
        **rr_metrics,
        "updated_at": (quote or {}).get("updated_at"),
        "provider": (quote or {}).get("provider") or (quote or {}).get("source"),
        "stale": bool((quote or {}).get("stale", False)),
    }


def _signal_dto(row: dict[str, Any], choice: dict[str, Any] | None = None, quote: dict[str, Any] | None = None) -> dict[str, Any]:
    allowed = {
        "id", "display_number", "symbol", "side", "status", "market_category", "created_at", "updated_at",
        "entries", "entry", "entry_price", "entry_min", "entry_max", "stop", "stop_loss", "targets", "take_profits",
        "risk", "risk_percent", "rr", "timeframe", "session", "note", "analysis", "revision", "result",
        "provider", "analyst", "expires_at", "closed_at", "evidence_hash", "trust_passport",
        "target", "destination", "requested_channels", "delivered_channels",
    }
    result = {key: row.get(key) for key in allowed if key in row}
    result["market_category"] = _signal_market(row)
    result["access_tier"] = _signal_access_tier(row)
    result["status"] = normalize_signal_status(row.get("status"))
    result["is_final"] = signal_is_final(row)
    result["highest_target_hit"] = int(row.get("highest_target_hit") or 0)
    result["lifecycle_history"] = list(row.get("lifecycle_history") or [])[-20:]
    result["quote"] = dict(quote or {})
    result["entry_state"] = _signal_live_metrics(row, quote)
    result["risk_reward"] = result["entry_state"].get("risk_reward")
    result["target_rr"] = result["entry_state"].get("target_rr") or []
    if choice:
        result["choice"] = choice
        result["decision_locked"] = str(choice.get("choice") or "") in {"taken", "skipped"}
    else:
        result["decision_locked"] = False
    return result


def _signal_choices(user_id: int | str) -> dict[str, dict[str, Any]]:
    raw = PreferenceRepository().get(user_id, "user_signal_choices", {})
    if not isinstance(raw, dict):
        return {}
    return {str(key): value for key, value in raw.items() if isinstance(value, dict)}


def _visible_signal(row: dict[str, Any], vip_active: bool) -> bool:
    delivered = row.get("delivered_channels")
    if isinstance(delivered, list) and delivered:
        channels = {str(item).lower() for item in delivered}
        return "public" in channels or (vip_active and "private" in channels)
    target = str(row.get("target") or row.get("destination") or row.get("visibility") or "public").lower()
    return target in {"public", "both", "all", ""} or (vip_active and target in {"private", "vip"})


def _signal_access_tier(row: dict[str, Any]) -> str:
    delivered = row.get("delivered_channels")
    if isinstance(delivered, list) and delivered:
        channels = {str(item).lower() for item in delivered}
        if "private" in channels and "public" not in channels:
            return "vip"
        if {"public", "private"}.issubset(channels):
            return "public_vip"
        return "public"
    target = str(row.get("target") or row.get("destination") or row.get("visibility") or "public").lower()
    if target in {"private", "vip"}:
        return "vip"
    if target in {"both", "all"}:
        return "public_vip"
    return "public"


def _signal_market(row: dict[str, Any]) -> str:
    market = str(row.get("market_category") or row.get("market") or "").strip().lower()
    if market in {"crypto", "cryptocurrency", "digital_asset"}:
        return "crypto"
    if market in {"forex", "fx", "gold", "metals", "indices", "commodity"}:
        return "forex"
    symbol = str(row.get("symbol") or "").strip()
    classified = classify_market_symbol(symbol)
    if classified in {"crypto", "forex"}:
        return classified
    return market or "forex"


def overview(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    shell = _safe_shell(identity)
    engine, accounts, positions, signals_repo, journal_repo, commerce, support, _ = _repos()
    uid = str(identity.user_id)
    signal_page = signals_repo.list(limit=6)
    choices = _signal_choices(uid)
    signal_page["items"] = [row for row in signal_page["items"] if _visible_signal(row, shell["vip_active"])]
    risk_data = _account_risk(uid)
    tickets_page = support.list_for_user(uid, limit=20)
    open_tickets = sum(1 for row in tickets_page["items"] if str(row.get("status")) in {"open", "pending", "answered"})
    pending_orders = 0
    with engine.transaction(read_only=True) as cursor:
        order_counts = cursor.execute(
            "SELECT COUNT(*) AS total,SUM(CASE WHEN status IN ('pending','approving','needs_receipt') THEN 1 ELSE 0 END) AS pending FROM v8_vip_orders WHERE user_id=?",
            (uid,),
        ).fetchone() or {}
        signal_counts = cursor.execute(
            """SELECT COUNT(*) AS total,
               SUM(CASE WHEN market_category='forex' THEN 1 ELSE 0 END) AS forex,
               SUM(CASE WHEN market_category='crypto' THEN 1 ELSE 0 END) AS crypto
               FROM v8_signals WHERE status NOT IN ('closed','cancelled','expired','stopped','tp','win','loss')"""
        ).fetchone() or {}
    pending_orders = int(order_counts.get("pending") or 0)
    today_actions: list[dict[str, Any]] = []
    if not shell["onboarding"].get("completed"):
        today_actions.append({"type": "onboarding", "priority": "high", "target": "onboarding"})
    if risk_data["prop"].get("hard_blocks"):
        today_actions.append({"type": "prop_breach", "priority": "critical", "target": "risk", "breaches": risk_data["prop"]["hard_blocks"]})
    if pending_orders:
        today_actions.append({"type": "pending_order", "priority": "normal", "count": pending_orders, "target": "orders"})
    if open_tickets:
        today_actions.append({"type": "open_ticket", "priority": "normal", "count": open_tickets, "target": "support"})
    from services.live_market_service import live_quotes_for_symbols
    quote_map = live_quotes_for_symbols([str(row.get("symbol") or "") for row in signal_page["items"]])
    from modules.reward_wallet import wallet_unread_keys
    # Reuse shell data already fetched; do not reload the users/coupon collections.
    reward_db = {**(shell.get("db") or {}), **read_db_sections(("user_rewards",))}
    unread_rewards = len(wallet_unread_keys(reward_db, uid))
    return {
        "user": shell["user"],
        "account": {
            "unread_rewards": unread_rewards,
            "points": shell["points"], "vip_active": shell["vip_active"], "vip_expires_at": shell["vip_expires_at"],
            "orders_total": int(order_counts.get("total") or 0), "pending_orders": pending_orders,
            "open_tickets": open_tickets, "active_signals": int(signal_counts.get("total") or 0),
            "active_forex_signals": int(signal_counts.get("forex") or 0), "active_crypto_signals": int(signal_counts.get("crypto") or 0),
        },
        "risk": risk_data,
        "recent_signals": [
            _signal_dto(row, choices.get(str(row.get("id"))), quote_map.get(str(row.get("symbol") or "").upper().replace("/", "")))
            for row in signal_page["items"]
        ],
        "journal_stats": _journal_stats(engine, uid),
        "revision_count": 0,
        "today_actions": today_actions,
        "notifications": shell["notifications"], "onboarding": shell["onboarding"],
        "bot_username": SETTINGS.bot_username, "features": shell["features"], "commerce": shell["commerce"],
        "rules": shell["rules"], "admin_available": shell["admin_available"], "admin": shell["admin"],
        "miniapp_runtime": shell.get("miniapp_runtime", {"enabled": True}), "generated_at": utc_iso(),
        "data_contract": "v8-normalized-row-level",
    }


def signals(
    identity: TelegramWebAppIdentity,
    *,
    cursor: str | None = None,
    limit: int = 20,
    status: str = "",
    market: str = "",
    scope: str = "",
    query: str = "",
    live: bool = False,
) -> dict[str, Any]:
    requested = max(1, min(int(limit or 20), 100))
    shell = _safe_shell(identity)
    choices = _signal_choices(identity.user_id)
    clean_scope = str(scope or "all").strip().lower()
    if clean_scope not in {"all", "public", "vip"}:
        clean_scope = "all"

    # Cursor-safe canonical pagination: consume database pages until enough
    # visible unique rows are collected. The returned cursor always points to
    # the last database row consumed, so filtering/deduplication cannot skip
    # records or reorder the keyset between requests.
    repo = SignalRepository()
    scan_cursor = cursor
    consumed_cursor = cursor
    unique: dict[str, dict[str, Any]] = {}
    exhausted = False
    scan_pages = 0
    while len(unique) < requested and not exhausted and scan_pages < 8:
        raw = repo.list(cursor=scan_cursor, limit=min(100, max(requested * 3, 30)), status=status, market=market, search=query)
        scan_pages += 1
        rows = raw.get("items") or []
        consumed_cursor = raw.get("next_cursor") or consumed_cursor
        for row in rows:
            if not _visible_signal(row, shell["vip_active"]):
                continue
            tier = _signal_access_tier(row)
            if clean_scope == "public" and tier == "vip":
                continue
            if clean_scope == "vip" and tier != "vip":
                continue
            deliveries = row.get("deliveries") if isinstance(row.get("deliveries"), list) else []
            message_keys = sorted(
                f"{item.get('chat_id')}:{item.get('message_id')}"
                for item in deliveries if isinstance(item, dict) and item.get("chat_id") and item.get("message_id")
            )
            key = "|".join(message_keys) or f"{row.get('cycle_id','')}:{row.get('display_number','')}:{_signal_market(row)}:{row.get('symbol','')}"
            current = unique.get(key)
            if current is None or (str(row.get("updated_at") or ""), str(row.get("id") or "")) > (str(current.get("updated_at") or ""), str(current.get("id") or "")):
                unique[key] = row
        scan_cursor = raw.get("next_cursor")
        exhausted = not bool(scan_cursor)

    visible = list(unique.values())
    visible.sort(key=lambda row: (str(row.get("created_at") or ""), str(row.get("id") or "")), reverse=True)
    visible = visible[:requested]
    from services.live_market_service import live_quotes_for_symbols
    quote_map = live_quotes_for_symbols([str(row.get("symbol") or "") for row in visible], force=live)
    items = [
        _signal_dto(row, choices.get(str(row.get("id"))), quote_map.get(str(row.get("symbol") or "").upper().replace("/", "")))
        for row in visible
    ]
    return {
        "items": items,
        "next_cursor": None if exhausted else consumed_cursor,
        "limit": requested,
        "access": {"vip_active": bool(shell["vip_active"]), "scope": clean_scope},
        "groups": {
            "public": sum(1 for row in items if row.get("access_tier") != "vip"),
            "vip": sum(1 for row in items if row.get("access_tier") == "vip"),
            "forex": sum(1 for row in items if row.get("market_category") == "forex"),
            "crypto": sum(1 for row in items if row.get("market_category") == "crypto"),
            "active": sum(1 for row in items if not row.get("is_final")),
        },
        "scan_pages": scan_pages,
    }


def _gate_reason(item: Any, *, severity: str) -> dict[str, Any]:
    if isinstance(item, dict):
        code = str(item.get("code") or item.get("rule") or item.get("reason") or "RISK_NOTICE")
        params = item.get("params") if isinstance(item.get("params"), dict) else {
            key: value for key, value in item.items() if key not in {"code", "rule", "reason", "severity"}
        }
        return {"code": code, "params": params, "severity": severity}
    return {"code": str(item or "RISK_NOTICE"), "params": {}, "severity": severity}


def _normalized_gate_payload(decision: Any | None, *, account: dict[str, Any] | None) -> dict[str, Any]:
    if not account:
        return {
            "status": "yellow",
            "can_execute": False,
            "reasons": [{"code": "TRADING_ACCOUNT_REQUIRED", "params": {}, "severity": "warning"}],
            "hard_blocks": [],
            "warnings": [{"code": "TRADING_ACCOUNT_REQUIRED"}],
            "metrics": {},
            "configured": False,
        }
    hard = list(getattr(decision, "hard_blocks", ()) or ())
    warnings = list(getattr(decision, "warnings", ()) or ())
    allowed = bool(getattr(decision, "allowed", not hard))
    status = "red" if hard or not allowed else "yellow" if warnings else "green"
    reasons = [*(_gate_reason(item, severity="block") for item in hard), *(_gate_reason(item, severity="warning") for item in warnings)]
    if not reasons:
        reasons = [{"code": "ALL_RISK_CHECKS_PASSED", "params": {}, "severity": "safe"}]
    return {
        "status": status,
        "can_execute": allowed,
        "reasons": reasons,
        "hard_blocks": hard,
        "warnings": warnings,
        "metrics": dict(getattr(decision, "metrics", {}) or {}),
        "template_id": str(getattr(decision, "template_id", "") or ""),
        "rules_version": int(getattr(decision, "rules_version", 0) or 0),
        "configured": True,
    }


def _signal_news_currencies(symbol: str) -> set[str]:
    clean = re.sub(r"[^A-Z0-9]", "", str(symbol or "").upper())
    aliases: dict[str, set[str]] = {
        "XAUUSD": {"USD"}, "XAGUSD": {"USD"}, "US100": {"USD"}, "US30": {"USD"}, "SPX500": {"USD"},
        "GER40": {"EUR"}, "DE40": {"EUR"}, "UK100": {"GBP"}, "JP225": {"JPY"},
        "BTCUSD": {"USD"}, "BTCUSDT": {"USD"}, "ETHUSD": {"USD"}, "ETHUSDT": {"USD"},
    }
    if clean in aliases:
        return aliases[clean]
    currencies: set[str] = set()
    if len(clean) >= 6 and clean[:3].isalpha() and clean[3:6].isalpha():
        currencies.update({clean[:3], clean[3:6]})
    if clean.endswith("USDT"):
        currencies.update({"USD", "USDT"})
    return {value for value in currencies if value}


def _nearby_news_for_signal(user_id: int | str, signal: dict[str, Any], *, window_hours: int = 12) -> dict[str, Any]:
    db = read_db_sections(("economic_calendar",))
    root = db.get("economic_calendar") if isinstance(db.get("economic_calendar"), dict) else {}
    rows = [dict(item) for item in root.get("cached_events", []) if isinstance(item, dict)]
    now = datetime.now(UTC)
    currencies = _signal_news_currencies(str(signal.get("symbol") or ""))
    output: list[dict[str, Any]] = []
    for event in rows:
        event_dt = parse_dt(str(event.get("datetime") or event.get("date") or event.get("time") or ""))
        if not event_dt:
            continue
        delta = (event_dt - now).total_seconds()
        if abs(delta) > max(1, int(window_hours)) * 3600:
            continue
        currency = str(event.get("currency") or event.get("country") or "").upper().strip()
        if currencies and currency and currency not in currencies:
            continue
        output.append({
            "title": str(event.get("title") or event.get("event") or "Economic event"),
            "currency": currency,
            "importance": str(event.get("importance") or event.get("impact") or ""),
            "datetime": event_dt.isoformat(),
            "minutes_from_now": round(delta / 60),
        })
    output.sort(key=lambda item: abs(int(item.get("minutes_from_now") or 0)))
    return {
        "items": output[:10],
        "status": "ready" if rows else "calendar_not_synced",
        "window_hours": max(1, int(window_hours)),
        "calendar_updated_at": root.get("cached_events_updated_at"),
        "currencies": sorted(currencies),
    }


def _normalized_trust_passport(repo: SignalRepository, signal: dict[str, Any]) -> dict[str, Any]:
    replay = repo.replay(signal.get("id"))
    timeline = replay.get("timeline") if isinstance(replay.get("timeline"), list) else []
    ordered = sorted(timeline, key=lambda item: int(item.get("revision_number") or item.get("revision") or 0))
    revisions: list[dict[str, Any]] = []
    chain_valid = True
    previous_hash = ""
    for index, item in enumerate(ordered, start=1):
        current_hash = str(item.get("current_hash") or "")
        expected_previous = str(item.get("previous_hash") or "")
        if previous_hash and expected_previous and previous_hash != expected_previous:
            chain_valid = False
        revisions.append({
            "revision": int(item.get("revision_number") or item.get("revision") or index),
            "changed_fields": list(item.get("changed_fields") or []),
            "reason": str(item.get("reason") or item.get("change_type") or "updated"),
            "created_at": item.get("changed_at") or item.get("created_at") or signal.get("updated_at") or signal.get("created_at"),
            "hash": current_hash,
        })
        if current_hash:
            previous_hash = current_hash
    if not revisions:
        revisions.append({
            "revision": int(signal.get("revision") or 1),
            "changed_fields": ["created"],
            "reason": "created",
            "created_at": signal.get("created_at") or signal.get("updated_at") or utc_iso(),
            "hash": str(signal.get("evidence_hash") or content_hash(signal)),
        })
    outcome = replay.get("outcome") if isinstance(replay.get("outcome"), dict) else {}
    evidence_hash = str(outcome.get("evidence_hash") or signal.get("evidence_hash") or content_hash({
        "signal": signal,
        "revisions": revisions,
    }))
    return {
        "signal_id": str(signal.get("id") or ""),
        "display_number": int(signal.get("display_number") or 0),
        "symbol": str(signal.get("symbol") or ""),
        "revision": max(int(item.get("revision") or 1) for item in revisions),
        "revision_chain_valid": chain_valid,
        "revisions": revisions,
        "evidence_hash": evidence_hash,
        "outcome": outcome,
    }


def signal_detail(identity: TelegramWebAppIdentity, signal_id: int | str, *, account_id: int | str | None = None, live: bool = False) -> dict[str, Any]:
    engine = normalized_engine(); repo = SignalRepository(engine); signal = repo.get(signal_id)
    if not signal:
        raise ValueError("SIGNAL_NOT_FOUND")
    shell = _safe_shell(identity)
    if not _visible_signal(signal, shell["vip_active"]):
        raise PermissionError("SIGNAL_ACCESS_DENIED")
    account = AccountRepository(engine).get(identity.user_id, account_id)
    decision = None
    if account:
        candidate = {
            "signal_status": signal.get("status"), "symbol": signal.get("symbol"),
            "actual_entry": signal.get("entry_price") or signal.get("entry") or signal.get("entry_min"),
            "actual_stop": signal.get("stop_loss") or signal.get("stop"),
            "risk_percent": signal.get("risk_percent") or signal.get("risk") or account.get("default_risk_percent") or 1,
        }
        decision = PropRuleEngine(engine).evaluate(
            user_id=identity.user_id,
            account_id=account["id"],
            candidate=candidate,
            record=False,
        )
    gate = _normalized_gate_payload(decision, account=account)
    positions = PositionRepository(engine).active_for_signal(identity.user_id, signal_id)
    from services.live_market_service import live_quotes_for_symbols
    quote_map = live_quotes_for_symbols([str(signal.get("symbol") or "")], force=live)
    quote = quote_map.get(str(signal.get("symbol") or "").upper().replace("/", ""))
    dto = _signal_dto(signal, _signal_choices(identity.user_id).get(str(signal_id)), quote)
    news = _nearby_news_for_signal(identity.user_id, signal)
    chart_photo_file_id = str(signal.get("chart_photo_file_id") or "").strip()
    result_chart_photo_file_id = str(signal.get("result_chart_photo_file_id") or "").strip()
    lifecycle_history = [item for item in (signal.get("lifecycle_history") or []) if isinstance(item, dict)][-30:]
    return {
        **dto,
        "note": str(signal.get("note") or signal.get("analysis") or "")[:8000],
        "pretrade_gate": gate,
        "nearby_news": news["items"],
        "nearby_news_meta": {key: value for key, value in news.items() if key != "items"},
        "trust_passport": _normalized_trust_passport(repo, signal),
        "positions": positions,
        "lifecycle_report": lifecycle_history,
        "media": {
            "chart_available": bool(chart_photo_file_id),
            "chart_url": f"./api/v1/signals/{signal_id}/chart" if chart_photo_file_id else "",
            "result_chart_available": bool(result_chart_photo_file_id),
            "result_chart_url": f"./api/v1/signals/{signal_id}/result-chart" if result_chart_photo_file_id else "",
            "result_chart_caption": str(signal.get("result_chart_caption") or "")[:1500],
            "result_chart_added_at": signal.get("result_chart_added_at"),
            "status_key": str(signal.get("status") or "open").lower(),
        },
        "data_confidence": DataConfidenceService(engine).get("signal", str(signal_id), "price"),
    }


def signal_replay_detail(identity: TelegramWebAppIdentity, signal_id: int | str) -> dict[str, Any]:
    replay = SignalRepository().replay(signal_id)
    if not _visible_signal(replay["signal"], _safe_shell(identity)["vip_active"]):
        raise PermissionError("SIGNAL_ACCESS_DENIED")
    replay["signal"] = _signal_dto(replay["signal"])
    return replay


def signal_share_card_detail(identity: TelegramWebAppIdentity, signal_id: int | str) -> dict[str, Any]:
    replay = SignalRepository().replay(signal_id)
    signal = replay["signal"]
    if not _visible_signal(signal, _safe_shell(identity)["vip_active"]):
        raise PermissionError("SIGNAL_ACCESS_DENIED")
    outcome = replay.get("outcome") or {}
    return {
        "signal_id": str(signal_id),
        "title": f"SENTINEL · {signal.get('symbol') or ''}",
        "symbol": signal.get("symbol"), "side": signal.get("side"), "status": signal.get("status"),
        "display_number": signal.get("display_number"), "entry": signal.get("entry") or signal.get("entry_price"),
        "stop": signal.get("stop") or signal.get("stop_loss"),
        "targets": signal.get("targets") or signal.get("take_profits") or [],
        "result_r": outcome.get("result_r"), "evidence_hash": outcome.get("evidence_hash"),
        "revision_count": replay.get("revision_count", 0),
        "generated_at": utc_iso(),
    }


def risk(identity: TelegramWebAppIdentity, *, account_id: int | str | None = None) -> dict[str, Any]:
    return _account_risk(identity.user_id, account_id)


def journal(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 30, status: str = "", symbol: str = "", query: str = "") -> dict[str, Any]:
    from services.unified_journal_service import sync_legacy_journal_to_normalized

    sync_legacy_journal_to_normalized(identity.user_id)
    engine = normalized_engine(); repo = JournalRepository(engine)
    page = repo.list_for_user(identity.user_id, cursor=cursor, limit=limit, status=status, symbol=symbol)
    needle = str(query or "").strip().casefold()
    if needle:
        page["items"] = [row for row in page["items"] if needle in f"{row.get('symbol','')} {row.get('setup','')} {row.get('entry_reason','')} {row.get('note','')}".casefold()]
    page["stats"] = _journal_stats(engine, identity.user_id)
    from services.risk_coach_service import consolidated_behavioral_report
    page["behavioral_review"] = consolidated_behavioral_report(identity.user_id)
    from modules.trading_coach import trading_coach_snapshot
    page["trading_coach"] = trading_coach_snapshot(read_db_sections(("trade_journal",)), identity.user_id)
    return page


def feed(identity: TelegramWebAppIdentity, *, limit: int = 50) -> dict[str, Any]:
    from services.channel_feed_service import channel_feed
    shell = _safe_shell(identity)
    return channel_feed(identity.user_id, vip_active=shell["vip_active"], limit=limit)


def market(identity: TelegramWebAppIdentity, *, live: bool = False) -> dict[str, Any]:
    from services.live_market_service import live_market_snapshot

    try:
        result = live_market_snapshot(identity.user_id, force=live)
        failed = result.get("failed_quotes") if isinstance(result.get("failed_quotes"), list) else []
        if failed:
            # Recover individual provider failures from the durable market
            # snapshot. A single unavailable symbol must not empty the whole
            # market page or make a user's watchlist look broken.
            try:
                cached = legacy.market(identity)
                cache_rows = cached.get("quotes") if isinstance(cached.get("quotes"), list) else []
                cache_map = {str(row.get("symbol") or "").upper(): row for row in cache_rows if isinstance(row, dict)}
                live_symbols = {str(row.get("symbol") or "").upper() for row in result.get("quotes", []) if isinstance(row, dict)}
                unresolved: list[dict[str, Any]] = []
                recovered: list[str] = []
                for failure in failed:
                    symbol = str(failure.get("symbol") or "").upper()
                    row = cache_map.get(symbol)
                    if not row or symbol in live_symbols:
                        unresolved.append(failure)
                        continue
                    result.setdefault("quotes", []).append({
                        **dict(row), "symbol": symbol, "stale": True, "delayed": True,
                        "provider": str(row.get("provider") or row.get("source") or "cached snapshot"),
                        "source": str(row.get("source") or "cached snapshot"), "ok": True,
                    })
                    recovered.append(symbol)
                result["failed_quotes"] = unresolved
                if recovered:
                    result["degraded"] = True
                    result["recovered_from_cache"] = recovered
            except Exception as exc:
                logger.debug("Mini App quote cache recovery failed: %s", exc, exc_info=True)
        return result
    except Exception:
        # Provider outages must degrade to the durable cached snapshot rather
        # than fail the complete Mini App market workspace.
        cached = legacy.market(identity)
        cached["live"] = False
        cached["degraded"] = True
        return cached


def calendar(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 40, currency: str = "", impact: str = "", query: str = "") -> dict[str, Any]:
    # Economic events are provider-owned cache rows; their storage is already read-only bounded.
    return legacy.calendar(identity, cursor=0, limit=limit, currency=currency, impact=impact, query=query)


def orders(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 20, status: str = "", query: str = "") -> dict[str, Any]:
    page = CommerceRepository().list_for_user(identity.user_id, cursor=cursor, limit=limit, status=status)
    needle = str(query or "").strip().casefold()
    if needle:
        page["items"] = [row for row in page["items"] if needle in f"{row.get('id','')} {row.get('plan_name','')} {row.get('status','')}".casefold()]
    page["items"] = [_user_order_dto(row) for row in page["items"]]
    return page


def _user_order_dto(row: dict[str, Any]) -> dict[str, Any]:
    allowed = {"id", "plan_id", "plan_name", "status", "payment_method", "amount_toman", "usdt_amount", "quote_id", "transaction_hash", "created_at", "updated_at", "approved_at", "rejection_reason", "cancel_reason"}
    return {key: row.get(key) for key in allowed if key in row}


def order(identity: TelegramWebAppIdentity, order_id: str) -> dict[str, Any]:
    row = CommerceRepository().get(order_id, user_id=identity.user_id)
    if not row:
        raise ValueError("ORDER_NOT_FOUND")
    return _user_order_dto(row)


def tickets(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 20, status: str = "", query: str = "") -> dict[str, Any]:
    from services.unified_support_service import list_user_tickets

    rows = list_user_tickets(identity.user_id, status=status, query=query, limit=500)
    offset = 0
    try:
        offset = max(0, int(cursor or 0))
    except (TypeError, ValueError):
        offset = 0
    size = max(1, min(int(limit or 20), 100))
    items = rows[offset: offset + size]
    next_cursor = str(offset + size) if offset + size < len(rows) else None
    return {"items": items, "next_cursor": next_cursor, "limit": size, "total": len(rows)}


def ticket(identity: TelegramWebAppIdentity, ticket_id: int | str) -> dict[str, Any]:
    from services.unified_support_service import get_user_ticket

    row = get_user_ticket(identity.user_id, ticket_id)
    if not row:
        raise ValueError("TICKET_NOT_FOUND")
    return row


def track_record(identity: TelegramWebAppIdentity, *, symbol: str = "", market_filter: str = "", cursor: str | None = None, limit: int = 20) -> dict[str, Any]:
    return SignalRepository().track_record(cursor=cursor, limit=limit, symbol=symbol, market=market_filter)


def revisions(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 50, signal_id: str | None = None) -> dict[str, Any]:
    return SignalRepository().revisions(signal_id, cursor=cursor, limit=limit)


def global_search(identity: TelegramWebAppIdentity, query: str, *, limit: int = 30) -> dict[str, Any]:
    clean = str(query or "").strip()
    if len(clean) < 2:
        return {"items": [], "query": clean, "total": 0}
    signal_page = SignalRepository().list(limit=min(limit, 50), search=clean)
    journal_page = JournalRepository().list_for_user(identity.user_id, limit=min(limit, 50))
    needle = clean.casefold(); items: list[dict[str, Any]] = []
    for row in signal_page["items"]:
        items.append({"type": "signal", "id": row["id"], "title": f"{row.get('symbol')} · #{row.get('display_number')}", "subtitle": row.get("status"), "target": f"signal:{row['id']}"})
    for row in journal_page["items"]:
        if needle in f"{row.get('symbol','')} {row.get('setup','')} {row.get('note','')}".casefold():
            items.append({"type": "journal", "id": row["id"], "title": f"{row.get('symbol')} · {row.get('side')}", "subtitle": row.get("status"), "target": "journal"})
    return {"items": items[:limit], "query": clean, "total": min(len(items), limit)}


def _require_admin_permission(identity: TelegramWebAppIdentity, permission: str) -> dict[str, Any]:
    shell = _safe_shell(identity)
    admin = shell.get("admin") if isinstance(shell.get("admin"), dict) else {}
    if not admin.get("available") or permission not in set(admin.get("permissions") or []):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")
    return shell


def admin_orders(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 50, status: str = "", query: str = "") -> dict[str, Any]:
    from modules.admin_access import (
        PERMISSION_PAYMENTS, PERMISSION_PAYMENT_DASHBOARD_VIEW, PERMISSION_PAYMENT_TRANSACTIONS_VIEW,
        PERMISSION_PAYMENT_RECEIPTS_VIEW, PERMISSION_PAYMENT_MANUAL_REVIEW, PERMISSION_PAYMENT_TXID_VIEW, PERMISSION_PAYMENT_TXID_VERIFY,
    )

    shell = _require_any_admin_permission(
        identity, PERMISSION_PAYMENTS, PERMISSION_PAYMENT_DASHBOARD_VIEW,
        PERMISSION_PAYMENT_TRANSACTIONS_VIEW, PERMISSION_PAYMENT_RECEIPTS_VIEW, PERMISSION_PAYMENT_MANUAL_REVIEW, PERMISSION_PAYMENT_TXID_VIEW, PERMISSION_PAYMENT_TXID_VERIFY,
    )
    admin = shell.get("admin") if isinstance(shell.get("admin"), dict) else {}
    granted = {str(item) for item in admin.get("permissions") or []}
    owner = str(admin.get("role") or "") == "owner"
    can_txid = owner or PERMISSION_PAYMENTS in granted or PERMISSION_PAYMENT_TXID_VIEW in granted or PERMISSION_PAYMENT_TXID_VERIFY in granted or PERMISSION_PAYMENT_MANUAL_REVIEW in granted
    can_receipt = owner or PERMISSION_PAYMENTS in granted or PERMISSION_PAYMENT_RECEIPTS_VIEW in granted or PERMISSION_PAYMENT_MANUAL_REVIEW in granted
    page = CommerceRepository().list_all_orders(cursor=cursor, limit=limit, status=status, query=query)
    safe_items: list[dict[str, Any]] = []
    for row in page.get("items", []):
        safe_items.append({
            "id": row.get("id"), "user_id": row.get("user_id"), "plan_id": row.get("plan_id"),
            "plan_name": row.get("plan_name"), "status": row.get("status"),
            "payment_method": row.get("payment_method"), "amount_toman": row.get("amount_toman"),
            "usdt_amount": row.get("usdt_amount"), "transaction_hash": row.get("transaction_hash") if can_txid else None,
            "receipt_attached": bool(row.get("receipt_key") or row.get("receipt_id") or row.get("receipt_attached")) if can_receipt else False,
            "verification_status": row.get("verification_status"),
            "payment_card_number": row.get("payment_card_number") if can_receipt else None,
            "payment_card_owner": row.get("payment_card_owner") if can_receipt else None,
            "created_at": row.get("created_at"), "updated_at": row.get("updated_at"),
            "approved_at": row.get("approved_at"), "rejection_reason": row.get("rejection_reason"),
        })
    page["items"] = safe_items
    return page


def admin_order(identity: TelegramWebAppIdentity, order_id: str) -> dict[str, Any]:
    from modules.admin_access import (
        PERMISSION_PAYMENTS, PERMISSION_PAYMENT_DASHBOARD_VIEW, PERMISSION_PAYMENT_TRANSACTIONS_VIEW,
        PERMISSION_PAYMENT_RECEIPTS_VIEW, PERMISSION_PAYMENT_MANUAL_REVIEW, PERMISSION_PAYMENT_TXID_VIEW, PERMISSION_PAYMENT_TXID_VERIFY,
    )

    shell = _require_any_admin_permission(
        identity, PERMISSION_PAYMENTS, PERMISSION_PAYMENT_DASHBOARD_VIEW,
        PERMISSION_PAYMENT_TRANSACTIONS_VIEW, PERMISSION_PAYMENT_RECEIPTS_VIEW, PERMISSION_PAYMENT_MANUAL_REVIEW, PERMISSION_PAYMENT_TXID_VIEW, PERMISSION_PAYMENT_TXID_VERIFY,
    )
    admin = shell.get("admin") if isinstance(shell.get("admin"), dict) else {}
    granted = {str(item) for item in admin.get("permissions") or []}
    owner = str(admin.get("role") or "") == "owner"
    can_approve = owner or PERMISSION_PAYMENTS in granted or "payment_receipt_approve" in granted or PERMISSION_PAYMENT_MANUAL_REVIEW in granted
    can_reject = owner or PERMISSION_PAYMENTS in granted or "payment_receipt_reject" in granted or PERMISSION_PAYMENT_MANUAL_REVIEW in granted
    can_receipt = owner or PERMISSION_PAYMENTS in granted or PERMISSION_PAYMENT_RECEIPTS_VIEW in granted or PERMISSION_PAYMENT_MANUAL_REVIEW in granted
    can_txid = owner or PERMISSION_PAYMENTS in granted or PERMISSION_PAYMENT_TXID_VIEW in granted or PERMISSION_PAYMENT_TXID_VERIFY in granted or PERMISSION_PAYMENT_MANUAL_REVIEW in granted
    repo = CommerceRepository()
    row = repo.get(order_id)
    if not row:
        raise ValueError("ORDER_NOT_FOUND")
    receipt_id = str(row.get("receipt_key") or row.get("receipt_id") or "")
    receipt = repo.get_receipt_admin(receipt_id) if receipt_id and can_receipt else None
    return {
        "id": row.get("id"), "user_id": row.get("user_id"), "plan_id": row.get("plan_id"),
        "plan_name": row.get("plan_name"), "status": row.get("status"),
        "payment_method": row.get("payment_method"), "amount_toman": row.get("amount_toman"),
        "usdt_amount": row.get("usdt_amount"), "transaction_hash": row.get("transaction_hash") if can_txid else None,
        "created_at": row.get("created_at"), "updated_at": row.get("updated_at"),
        "approved_at": row.get("approved_at"), "rejection_reason": row.get("rejection_reason"),
        "permissions": {"approve": can_approve, "reject": can_reject},
        "receipt": ({
            "id": receipt.get("id"), "mime_type": receipt.get("mime_type"),
            "size_bytes": receipt.get("size_bytes"), "checksum": receipt.get("checksum"),
            "created_at": receipt.get("created_at"), "status": receipt.get("status"),
            "view_url": f"./api/v1/admin/orders/{row.get('id')}/receipt",
        } if receipt else None),
    }


def admin_tickets(
    identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 50, status: str = "",
    query: str = "", priority: str = "", assigned_admin: str = "", overdue_only: bool = False,
) -> dict[str, Any]:
    from modules.admin_access import PERMISSION_TICKETS_VIEW
    from services.unified_support_service import list_admin_tickets

    _require_admin_permission(identity, PERMISSION_TICKETS_VIEW)
    rows = list_admin_tickets(
        status=status, query=query, priority=priority, assigned_admin=assigned_admin,
        overdue_only=bool(overdue_only), limit=1000,
    )
    try:
        offset = max(0, int(cursor or 0))
    except (TypeError, ValueError):
        offset = 0
    size = max(1, min(int(limit or 50), 100))
    items = rows[offset: offset + size]
    return {
        "items": items, "limit": size, "total": len(rows),
        "next_cursor": str(offset + size) if offset + size < len(rows) else None,
    }


def admin_ticket(identity: TelegramWebAppIdentity, ticket_id: int | str) -> dict[str, Any]:
    from modules.admin_access import PERMISSION_TICKETS_VIEW
    from services.unified_support_service import get_admin_ticket

    _require_admin_permission(identity, PERMISSION_TICKETS_VIEW)
    row = get_admin_ticket(ticket_id)
    if not row:
        raise ValueError("TICKET_NOT_FOUND")
    return row



def _require_any_admin_permission(identity: TelegramWebAppIdentity, *permissions: str) -> dict[str, Any]:
    shell = _safe_shell(identity)
    admin = shell.get("admin") if isinstance(shell.get("admin"), dict) else {}
    if not admin.get("available"):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")
    shell_permissions = {str(value) for value in admin.get("permissions", [])}
    if any(str(permission) in shell_permissions for permission in permissions):
        return shell
    db = read_db_sections(("delegated_admins", "admin_shifts"))
    if not any(has_permission(db, identity.user_id, str(permission)) for permission in permissions):
        raise PermissionError("ADMIN_PERMISSION_REQUIRED")
    return shell


def _admin_user_dto(db: dict[str, Any], uid: str, row: dict[str, Any]) -> dict[str, Any]:
    from modules.advanced_features import active_ban

    vip = (db.get("vip_users") or {}).get(uid, {}) if isinstance(db.get("vip_users"), dict) else {}
    ban = active_ban(db, uid)
    return {
        "user_id": uid,
        "username": str(row.get("username") or ""),
        "first_name": str(row.get("first_name") or ""),
        "last_name": str(row.get("last_name") or ""),
        "language": str(row.get("language") or "fa"),
        "created_at": row.get("created_at"),
        "last_seen_at": row.get("last_seen_at"),
        "points": int((db.get("user_points") or {}).get(uid, 0) or 0),
        "vip_active": bool(vip),
        "vip_expires_at": vip.get("expires_at") if isinstance(vip, dict) else None,
        "banned": bool(ban),
        "ban": dict(ban) if isinstance(ban, dict) else None,
    }


def admin_users(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 50, query: str = "", status: str = "") -> dict[str, Any]:
    from modules.admin_access import PERMISSION_USERS_VIEW

    _require_admin_permission(identity, PERMISSION_USERS_VIEW)
    db = read_db_sections(("users", "user_points", "vip_users", "user_bans", "delegated_admins", "admin_shifts"))
    users = db.get("users") if isinstance(db.get("users"), dict) else {}
    rows = [_admin_user_dto(db, str(uid), row) for uid, row in users.items() if isinstance(row, dict)]
    needle = str(query or "").strip().casefold().lstrip("@")
    if needle:
        rows = [row for row in rows if needle in f"{row['user_id']} {row['username']} {row['first_name']} {row['last_name']}".casefold()]
    clean_status = str(status or "").strip().lower()
    if clean_status == "vip":
        rows = [row for row in rows if row["vip_active"]]
    elif clean_status == "banned":
        rows = [row for row in rows if row["banned"]]
    elif clean_status == "active":
        rows = [row for row in rows if not row["banned"]]
    rows.sort(key=lambda row: (str(row.get("last_seen_at") or row.get("created_at") or ""), int(row["user_id"]) if str(row["user_id"]).isdigit() else 0), reverse=True)
    try:
        offset = max(0, int(cursor or 0))
    except (TypeError, ValueError):
        offset = 0
    size = max(1, min(int(limit or 50), 100))
    return {"items": rows[offset:offset + size], "total": len(rows), "limit": size, "next_cursor": str(offset + size) if offset + size < len(rows) else None}


def admin_user(identity: TelegramWebAppIdentity, user_id: int | str) -> dict[str, Any]:
    page = admin_users(identity, query=str(user_id), limit=100)
    row = next((item for item in page.get("items", []) if str(item.get("user_id")) == str(user_id)), None)
    if not row:
        raise ValueError("USER_NOT_FOUND")
    return row


def admin_delegated_admins(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    from modules.admin_access import ADMIN_ROLE_PRESETS, ALL_PERMISSIONS, OWNER_ONLY_PERMISSIONS, PERMISSION_ADMIN_MANAGEMENT, PERMISSION_LABELS, delegated_admins

    _require_admin_permission(identity, PERMISSION_ADMIN_MANAGEMENT)
    db = read_db_sections(("delegated_admins", "users", "admin_shifts"))
    users = db.get("users") if isinstance(db.get("users"), dict) else {}
    items = []
    for uid, row in delegated_admins(db).items():
        user = users.get(str(uid), {}) if isinstance(users.get(str(uid)), dict) else {}
        items.append({
            **dict(row),
            "user_id": str(uid),
            "username": str(user.get("username") or ""),
            "first_name": str(user.get("first_name") or ""),
        })
    items.sort(key=lambda row: int(row.get("user_id") or 0))
    return {
        "items": items,
        "total": len(items),
        "permissions": [
            {"value": value, "label": PERMISSION_LABELS.get(value, value), "owner_only": value in OWNER_ONLY_PERMISSIONS}
            for value in ALL_PERMISSIONS
        ],
        "role_presets": [
            {"key": key, "label": spec.get("label", key), "description": spec.get("description", ""),
             "permissions": list(spec.get("permissions", ())) }
            for key, spec in ADMIN_ROLE_PRESETS.items()
        ],
        "is_primary_admin": is_primary_admin(identity.user_id),
        "primary_admin_id": int(SETTINGS.primary_admin_id),
        "pending_count": sum(1 for row in items if str(row.get("approval_status") or "approved") == "pending"),
    }


def _admin_signal_dto(row: dict[str, Any], *, archived: bool = False) -> dict[str, Any]:
    return {
        "id": row.get("id"), "display_number": row.get("display_number") or row.get("id"),
        "symbol": row.get("symbol"), "side": str(row.get("side") or "").upper(),
        "entry": row.get("entry"), "entries": row.get("entries") or ([row.get("entry")] if row.get("entry") is not None else []),
        "targets": row.get("targets") or [], "stop": row.get("stop") or row.get("stop_loss"),
        "risk": row.get("risk") or row.get("risk_percent"), "status": str(row.get("status") or "open"),
        "note": row.get("update_note") or row.get("note") or row.get("analysis") or "",
        "created_at": row.get("created_at"), "updated_at": row.get("updated_at"), "result_at": row.get("result_at"),
        "admin_id": row.get("admin_id"), "archived": bool(archived),
        "can_edit": str(row.get("status") or "open") not in {"target", "tp1", "tp2", "tp3", "tp4", "tp5", "stop", "cancelled", "no_entry", "manual_close"},
    }


def admin_signals(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 50, status: str = "", query: str = "") -> dict[str, Any]:
    from modules.admin_access import (
        PERMISSION_SIGNAL_DELETE, PERMISSION_SIGNAL_EDIT, PERMISSION_SIGNAL_METRICS_EDIT,
        PERMISSION_SIGNAL_STATUS_MANAGE, PERMISSION_SIGNALS_VIEW,
    )

    _require_any_admin_permission(
        identity, PERMISSION_SIGNALS_VIEW, PERMISSION_SIGNAL_EDIT,
        PERMISSION_SIGNAL_STATUS_MANAGE, PERMISSION_SIGNAL_METRICS_EDIT, PERMISSION_SIGNAL_DELETE,
    )
    db = read_db_sections(("signals", "signal_archive", "delegated_admins", "admin_shifts"))
    rows = [_admin_signal_dto(row) for row in db.get("signals", []) if isinstance(row, dict)]
    rows += [_admin_signal_dto(row, archived=True) for row in db.get("signal_archive", []) if isinstance(row, dict)]
    clean_status = str(status or "").strip().lower()
    if clean_status:
        rows = [row for row in rows if str(row.get("status") or "").lower() == clean_status]
    needle = str(query or "").strip().casefold()
    if needle:
        rows = [row for row in rows if needle in f"{row.get('id','')} {row.get('display_number','')} {row.get('symbol','')} {row.get('side','')} {row.get('status','')}".casefold()]
    rows.sort(key=lambda row: (str(row.get("created_at") or ""), int(row.get("id") or 0)), reverse=True)
    try:
        offset = max(0, int(cursor or 0))
    except (TypeError, ValueError):
        offset = 0
    size = max(1, min(int(limit or 50), 100))
    return {"items": rows[offset:offset + size], "total": len(rows), "limit": size, "next_cursor": str(offset + size) if offset + size < len(rows) else None}


def admin_signal(identity: TelegramWebAppIdentity, signal_id: int | str) -> dict[str, Any]:
    page = admin_signals(identity, query=str(signal_id), limit=100)
    row = next((item for item in page.get("items", []) if str(item.get("id")) == str(signal_id)), None)
    if not row:
        raise ValueError("SIGNAL_NOT_FOUND")
    return row

def _signal_job_dto(row: dict[str, Any], signal: dict[str, Any] | None = None) -> dict[str, Any]:
    payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
    signal = signal if isinstance(signal, dict) else {}
    delivered = signal.get("delivered_channels") if isinstance(signal.get("delivered_channels"), list) else (row.get("delivered_channels") if isinstance(row.get("delivered_channels"), list) else [])
    return {
        "id": row.get("id"), "status": str(row.get("status") or "pending"),
        "target": str(row.get("target") or "public"), "run_at": row.get("run_at"),
        "created_at": row.get("created_at"), "updated_at": row.get("updated_at"),
        "attempts": int(row.get("attempts", 0) or 0), "max_attempts": int(row.get("max_attempts", 3) or 3),
        "last_error": str(row.get("last_error") or row.get("error") or ""),
        "signal_id": row.get("signal_id"), "delivered_channels": delivered,
        "deliveries": signal.get("deliveries") or row.get("deliveries") or [],
        "can_retry": str(row.get("status") or "") in {"retrying", "dead", "failed", "cancelled"},
        "can_cancel": str(row.get("status") or "") not in {"sent", "cancelled"},
        "can_edit": str(row.get("status") or "") in {"pending", "retrying", "dead", "failed"},
        "symbol": str(payload.get("symbol") or ""), "side": str(payload.get("side") or "").upper(),
        "entries": payload.get("entries") or ([payload.get("entry")] if payload.get("entry") is not None else []),
        "targets": payload.get("targets") or [], "stop": payload.get("stop"), "risk": payload.get("risk"),
        "timeframe": payload.get("timeframe"), "note": payload.get("note") or payload.get("analysis") or "",
    }


def admin_signal_jobs(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 50, status: str = "", query: str = "") -> dict[str, Any]:
    from modules.admin_access import PERMISSION_SIGNAL_SCHEDULE
    _require_admin_permission(identity, PERMISSION_SIGNAL_SCHEDULE)
    snapshot = read_db_sections(("scheduled_signals", "signals"))
    rows = [dict(row) for row in snapshot.get("scheduled_signals", []) if isinstance(row, dict)]
    signals = {str(row.get("id")): row for row in snapshot.get("signals", []) if isinstance(row, dict)}
    clean_status = str(status or "").strip().lower()
    if clean_status:
        rows = [row for row in rows if str(row.get("status") or "pending").lower() == clean_status]
    needle = str(query or "").strip().casefold()
    if needle:
        rows = [row for row in rows if needle in f"{row.get('id','')} {row.get('target','')} {(row.get('payload') or {}).get('symbol','')} {(row.get('payload') or {}).get('side','')}".casefold()]
    rows.sort(key=lambda row: (str(row.get("created_at") or row.get("run_at") or ""), int(row.get("id", 0) or 0)), reverse=True)
    try:
        offset = max(0, int(cursor or 0))
    except (TypeError, ValueError):
        offset = 0
    size = max(1, min(int(limit or 50), 100))
    page = rows[offset:offset + size]
    return {"items": [_signal_job_dto(row, signals.get(str(row.get("signal_id")))) for row in page], "total": len(rows), "limit": size,
            "next_cursor": str(offset + size) if offset + size < len(rows) else None}


def admin_signal_job(identity: TelegramWebAppIdentity, job_id: int | str) -> dict[str, Any]:
    from modules.admin_access import PERMISSION_SIGNAL_SCHEDULE
    _require_admin_permission(identity, PERMISSION_SIGNAL_SCHEDULE)
    wanted = str(job_id)
    snapshot = read_db_sections(("scheduled_signals", "signals"))
    row = next((row for row in snapshot.get("scheduled_signals", []) if isinstance(row, dict) and str(row.get("id")) == wanted), None)
    if not row:
        raise ValueError("SIGNAL_JOB_NOT_FOUND")
    signal = next((item for item in snapshot.get("signals", []) if isinstance(item, dict) and str(item.get("id")) == str(row.get("signal_id"))), None)
    return _signal_job_dto(dict(row), signal)


def admin_signal_templates(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    from modules.admin_access import PERMISSION_SIGNAL_TEMPLATES
    from modules.signal_template_editor import (
        signal_template_background_info, signal_template_layout,
    )

    _require_admin_permission(identity, PERMISSION_SIGNAL_TEMPLATES)
    db = read_db_sections(("signal_template_settings", "signal_template_backgrounds"))
    return {
        side: {
            "layout": signal_template_layout(db, side),
            "background": signal_template_background_info(db, side),
        }
        for side in ("buy", "sell")
    }


def admin_store_signal_template(
    identity: TelegramWebAppIdentity,
    side: str,
    payload: bytes,
    *,
    original_name: str = "template",
) -> dict[str, Any]:
    from modules.admin_access import PERMISSION_SIGNAL_TEMPLATES
    from modules.signal_template_editor import store_signal_template_background

    _require_admin_permission(identity, PERMISSION_SIGNAL_TEMPLATES)
    return with_db(lambda db: store_signal_template_background(db, side, payload, original_name=original_name))


def admin_reset_signal_template(identity: TelegramWebAppIdentity, side: str) -> dict[str, Any]:
    from modules.admin_access import PERMISSION_SIGNAL_TEMPLATES
    from modules.signal_template_editor import reset_signal_template_background

    _require_admin_permission(identity, PERMISSION_SIGNAL_TEMPLATES)
    return with_db(lambda db: reset_signal_template_background(db, side))


def admin_operations(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    payload = legacy.admin_operations(identity)
    from modules.operations_intelligence import operations_command_center_snapshot
    from core.observability import snapshot as observability_snapshot
    db = read_db_sections(("provider_health", "operations", "feature_flags", "feature_flag_audit", "users", "vip", "vip_users", "signals", "payments"))
    payload["operations_intelligence"] = operations_command_center_snapshot(db, observability=observability_snapshot())
    return payload


def admin_audit_logs(identity: TelegramWebAppIdentity, *, cursor: str | None = None, limit: int = 50, query: str = "", action: str = "") -> dict[str, Any]:
    return legacy.admin_audit_logs(identity, cursor=0, limit=limit, query=query, action=action)


def admin_experiments(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    return legacy.admin_experiments(identity)


def admin_experiment_detail(identity: TelegramWebAppIdentity, experiment_id: int) -> dict[str, Any]:
    return legacy.admin_experiment_detail(identity, experiment_id)


def _require_campaign_admin(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    from modules.admin_access import PERMISSION_CAMPAIGNS, has_permission

    db = read_db_sections((
        "users", "user_profiles", "vip_users", "vip_orders", "marketing_campaigns",
        "campaign_events", "campaign_audience_snapshots", "broadcast_queue",
        "public_channel_links", "public_channel_link_events", "public_channel_attribution_users",
        "growth_links", "growth_link_events", "discount_codes", "discount_events",
        "discount_campaigns", "user_activity", "crm_activities", "affiliate_commissions",
        "settings", "admin_control_center", "delegated_admins",
    ))
    if not is_any_admin(db, identity.user_id) or not has_permission(
        db, identity.user_id, PERMISSION_CAMPAIGNS
    ):
        raise PermissionError("ADMIN_CAMPAIGNS_REQUIRED")
    return db


def admin_campaigns(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    from modules.campaign_studio import campaign_studio_summary, marketing_campaign_report

    db = _require_campaign_admin(identity)
    summary = campaign_studio_summary(db)
    rows: list[dict[str, Any]] = []
    for campaign in summary.get("latest", []):
        try:
            report = marketing_campaign_report(db, campaign.get("id"))
            rows.append({
                **dict(campaign),
                "metrics": {
                    key: report.get(key)
                    for key in (
                        "audience_size", "sent", "failed", "reached", "approved_orders",
                        "revenue", "cost", "conversion_rate", "delivery_success_rate",
                    )
                },
                "measurement": report.get("measurement", {}),
            })
        except ValueError:
            continue
    return {
        "summary": {key: value for key, value in summary.items() if key != "latest"},
        "items": rows,
        "generated_at": utc_iso(),
    }


def admin_campaign_detail(identity: TelegramWebAppIdentity, campaign_id: str) -> dict[str, Any]:
    from modules.campaign_studio import marketing_campaign_report

    report = marketing_campaign_report(_require_campaign_admin(identity), campaign_id)
    campaign = report.pop("campaign", {})
    return {**campaign, "metrics": report, "measurement": report.get("measurement", {})}



def _contest_user_entry(contest: dict[str, Any], kind: str, user_id: int | str) -> dict[str, Any] | None:
    uid = str(user_id)
    source_key = "participants" if kind == "price" else "answers"
    source = contest.get(source_key) if isinstance(contest.get(source_key), dict) else {}
    row = source.get(uid)
    return dict(row) if isinstance(row, dict) else None


def _contest_card(contest: dict[str, Any] | None, kind: str, user_id: int | str) -> dict[str, Any] | None:
    if not isinstance(contest, dict) or not contest.get("id"):
        return None
    entry = _contest_user_entry(contest, kind, user_id)
    source_key = "participants" if kind == "price" else "answers"
    source = contest.get(source_key) if isinstance(contest.get(source_key), dict) else {}
    reward_points = int(contest.get("reward_points", 0) or 0)
    reward_by_rank = contest.get("reward_by_rank") if isinstance(contest.get("reward_by_rank"), dict) else {}
    answer: Any = None
    submitted_at = ""
    if entry:
        answer = entry.get("guess") if kind in {"price", "candle"} else entry.get("choice")
        submitted_at = str(entry.get("submitted_at") or "")
    image_available = bool(str(contest.get("photo_file_id") or "").strip()) and kind in {"price", "chart"}
    question = str(contest.get("question") or "").strip()
    if kind == "news_direction" and not question:
        question = str(contest.get("news_name") or "").strip()
    return {
        "id": str(contest.get("id")),
        "kind": kind,
        "status": str(contest.get("status") or "active"),
        "active": str(contest.get("status") or "active") == "active" and bool(contest.get("active", True)),
        "question": question,
        "symbol": str(contest.get("symbol") or ""),
        "news_name": str(contest.get("news_name") or ""),
        "created_at": contest.get("created_at"),
        "ends_at": contest.get("ends_at"),
        "reward_points": reward_points,
        "prize_by_rank": contest.get("prize_by_rank", {}),
        "reward_by_rank": {str(k): int(v or 0) for k, v in reward_by_rank.items()},
        "participants_count": len(source),
        "participated": entry is not None,
        "my_answer": answer,
        "submitted_at": submitted_at,
        "image_available": image_available,
        "image_url": f"./api/v1/contests/{kind}/image" if image_available else "",
    }


def _contest_history_row(contest: dict[str, Any], user_id: int | str) -> dict[str, Any] | None:
    kind = str(contest.get("type") or "").strip().lower()
    if kind == "news":
        kind = "news_direction"
    if kind not in {"price", "chart", "candle", "news_direction"}:
        contest_id = str(contest.get("id") or "")
        if contest_id.startswith("price_"):
            kind = "price"
        elif contest_id.startswith("chart_"):
            kind = "chart"
        elif contest_id.startswith("candle_"):
            kind = "candle"
        elif contest_id.startswith("news_"):
            kind = "news_direction"
        else:
            return None
    entry = _contest_user_entry(contest, kind, user_id)
    uid = str(user_id)
    won = False
    rank: int | None = None
    points = 0
    prize = {}
    if kind in {"price", "candle"}:
        for row in contest.get("results", []) if isinstance(contest.get("results"), list) else []:
            if isinstance(row, dict) and str(row.get("uid")) == uid:
                rank = int(row.get("rank") or 0) or None
                points = int(row.get("points") or 0)
                prize=dict(row.get("prize") or {})
                won = points > 0 or bool(prize)
                if entry is None:
                    entry = {"guess": row.get("guess")}
                break
    else:
        winners = {str(item) for item in contest.get("winners", []) if item not in {None, ""}}
        won = uid in winners
        points = int(contest.get("reward_points", 0) or 0) if won else 0
    if entry is None and not won:
        return None
    answer = entry.get("guess") if kind in {"price", "candle"} and entry else entry.get("choice") if entry else None
    return {
        "id": str(contest.get("id") or ""),
        "kind": kind,
        "question": str(contest.get("question") or contest.get("news_name") or ""),
        "symbol": str(contest.get("symbol") or ""),
        "closed_at": contest.get("closed_at") or contest.get("ends_at"),
        "my_answer": answer,
        "won": won,
        "rank": rank,
        "points": points,
        "prize": prize,
        "final_price": contest.get("final_price"),
        "correct_answer": contest.get("answer"),
    }


def contests(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    """User-facing contest snapshot shared with the Telegram contest engine."""
    from modules.contest import (
        get_open_candle_contest,
        get_open_chart_contest,
        get_open_news_direction_contest,
        get_open_price_contest,
    )

    db = read_db_sections((
        "contests", "chart_contest", "candle_contest", "news_direction_contest",
        "contest_history", "admin_control_center",
    ))
    uid = str(identity.user_id)
    active = [
        _contest_card(get_open_price_contest(db), "price", uid),
        _contest_card(get_open_chart_contest(db), "chart", uid),
        _contest_card(get_open_candle_contest(db), "candle", uid),
        _contest_card(get_open_news_direction_contest(db), "news_direction", uid),
    ]
    active = [row for row in active if row and row.get("active")]

    candidates: list[dict[str, Any]] = []
    history = db.get("contest_history") if isinstance(db.get("contest_history"), list) else []
    candidates.extend(row for row in history if isinstance(row, dict))
    candidates.extend(
        row for row in db.get("contests", [])
        if isinstance(row, dict) and str(row.get("status") or "") == "closed"
    )
    for key, kind in (("chart_contest", "chart"), ("candle_contest", "candle"), ("news_direction_contest", "news_direction")):
        row = db.get(key)
        if isinstance(row, dict) and row.get("id") and str(row.get("status") or "") == "closed":
            candidates.append({**row, "type": row.get("type") or kind})
    seen: set[str] = set()
    recent_results: list[dict[str, Any]] = []
    for row in reversed(candidates):
        contest_id = str(row.get("id") or "")
        if not contest_id or contest_id in seen:
            continue
        seen.add(contest_id)
        item = _contest_history_row(row, uid)
        if item:
            recent_results.append(item)
        if len(recent_results) >= 20:
            break
    return {
        "items": active,
        "active_count": len(active),
        "joined_count": sum(1 for row in active if row.get("participated")),
        "recent_results": recent_results,
        "source": "shared_telegram_contest_engine",
        "generated_at": utc_iso(),
    }


def contest_image_file_id(identity: TelegramWebAppIdentity, kind: str) -> str:
    """Return the active contest's Telegram image id without exposing it to clients."""
    from modules.contest import get_open_chart_contest, get_open_price_contest

    normalized = str(kind or "").strip().lower()
    db = read_db_sections(("contests", "chart_contest"))
    if normalized == "price":
        contest = get_open_price_contest(db)
    elif normalized == "chart":
        contest = get_open_chart_contest(db)
    else:
        return ""
    return str((contest or {}).get("photo_file_id") or "").strip()

def expansion(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    """No-cost expansion snapshot for the next-generation Mini App pages."""
    from modules.platform_expansion import (
        local_market_intelligence,
        paper_arena_snapshot,
        prop_guardian_snapshot,
        verified_public_performance,
    )
    from modules.platform_registry import platform_matrix

    db = read_db_sections((
        "enterprise_control", "platform_registry", "platform_settings", "signals",
        "journal_entries", "user_journal", "journal", "paper_accounts", "paper_trades",
        "prop_challenges", "market_prices", "price_cache", "crypto_prices", "stock_prices",
        "iran_prices_cache", "economic_events", "market_news", "provider_health",
        "public_performance_snapshots", "miniapp_device_state",
    ))
    uid = str(identity.user_id)
    payload: dict[str, Any] = {"matrix": platform_matrix(db), "generated_at": utc_iso()}
    builders = {
        "risk_coach": lambda: __import__("services.risk_coach_service", fromlist=["consolidated_behavioral_report"]).consolidated_behavioral_report(uid),
        "paper_arena": lambda: paper_arena_snapshot(db, uid),
        "market_intelligence": lambda: local_market_intelligence(db),
        "public_performance": lambda: verified_public_performance(db),
    }
    for key, builder in builders.items():
        try:
            payload[key] = builder()
        except (ValueError, PermissionError) as exc:
            payload[key] = {"status": "unavailable", "reason": str(exc)}
    paper = payload.get("paper_arena") if isinstance(payload.get("paper_arena"), dict) else {}
    prop_accounts: list[dict[str, Any]] = []
    for account in paper.get("accounts", []) if isinstance(paper.get("accounts"), list) else []:
        try:
            prop_accounts.append({
                "account_id": account.get("id"),
                "title": account.get("title"),
                **prop_guardian_snapshot(db, uid, account.get("id")),
            })
        except (ValueError, PermissionError) as exc:
            prop_accounts.append({"account_id": account.get("id"), "status": "unavailable", "reason": str(exc)})
    paper_guardian = {
        "status": "blocked" if any(row.get("status") == "blocked" for row in prop_accounts)
        else "warning" if any(row.get("status") in {"warning", "unavailable"} for row in prop_accounts)
        else "safe" if prop_accounts else "unconfigured",
        "accounts": prop_accounts,
        "source": "paper_prop_guardian",
    }
    payload["paper_prop_guardian"] = paper_guardian
    try:
        from services.prop_guardian_service import prop_guardian_dashboard
        normalized_guardian = prop_guardian_dashboard(uid, record=False)
        # Keep the established expansion contract for users that only have a
        # paper/legacy Prop account, while connected normalized accounts always
        # take precedence.
        payload["prop_guardian"] = normalized_guardian if normalized_guardian.get("accounts") else paper_guardian
    except (ValueError, PermissionError) as exc:
        payload["prop_guardian"] = paper_guardian if prop_accounts else {
            "status": "unavailable", "reason": str(exc), "accounts": []
        }
    return payload


def admin_integration(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    """Admin-only Telegram Bot ↔ Mini App integration contract and health."""
    from modules.admin_access import PERMISSION_INTEGRATION_HEALTH_VIEW, has_permission
    from services.integration_health_service import integration_snapshot

    db = read_db_sections(("delegated_admins", "admin_shifts", "settings", "admin_control_center"))
    if not is_any_admin(db, identity.user_id) or not has_permission(db, identity.user_id, PERMISSION_INTEGRATION_HEALTH_VIEW):
        raise PermissionError("ADMIN_SYSTEM_CONTROL_REQUIRED")
    return integration_snapshot()


def admin_capabilities(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    """Return the live Mini App admin action inventory for this exact admin.

    The action registry is the same registry used by ``POST /api/v1/actions``;
    exposing this read-only inventory makes the Mini App permission matrix
    authoritative instead of a hand-maintained UI list.
    """
    from modules.admin_access import PERMISSION_LABELS
    from services.actions_v2 import action_specs
    from services.admin_action_catalog import catalog_entry

    shell = _safe_shell(identity)
    admin = shell.get("admin") if isinstance(shell.get("admin"), dict) else {}
    if not admin.get("available"):
        raise PermissionError("ADMIN_REQUIRED")
    role = str(admin.get("role") or "admin")
    granted = {str(item) for item in admin.get("permissions") or []}
    owner = role == "owner"
    permission_db = read_db_sections(("delegated_admins", "admin_shifts"))
    items: list[dict[str, Any]] = []
    groups: dict[str, int] = {}
    for name, spec in sorted(action_specs().items()):
        if not spec.admin_only:
            continue
        permission = str(spec.permission or "")
        available = owner or not permission or has_permission(permission_db, identity.user_id, permission)
        if not available:
            continue
        label = str(PERMISSION_LABELS.get(permission) or permission or "مدیریت")
        groups[label] = groups.get(label, 0) + 1
        presentation = catalog_entry(name)
        items.append({
            "action": name,
            "permission": permission,
            "permission_label": label,
            "mutation": bool(spec.mutation),
            "idempotency_required": bool(spec.idempotency_required),
            "available": True,
            **presentation,
        })
    return {
        "role": role,
        "permissions": sorted(granted),
        "actions": items,
        "groups": [{"label": key, "count": value} for key, value in sorted(groups.items())],
        "total_actions": len(items),
        "source": "shared_actions_v2_registry",
        "generated_at": utc_iso(),
    }


def admin_signal_cycles(
    identity: TelegramWebAppIdentity,
    *,
    cursor: int = 0,
    limit: int = 50,
) -> dict[str, Any]:
    db = read_db_sections((
        "signal_cycle", "signals", "signal_archive", "scheduled_signals",
        "delegated_admins", "admin_shifts", "settings",
    ))
    if not is_any_admin(db, identity.user_id) or not has_permission(db, identity.user_id, PERMISSION_SIGNAL_BOARD_MANAGE):
        raise PermissionError("ADMIN_SIGNALS_REQUIRED")
    rows = list_signal_cycles(db, limit=1000)
    page = legacy._page(rows, cursor=cursor, limit=limit)
    current_id = int((db.get("signal_cycle") or {}).get("current_id", 1) or 1)
    page["current"] = signal_cycle_summary(db, current_id)
    page["source"] = "named_signal_periods"
    page["generated_at"] = utc_iso()
    return page


def admin_signal_cycle_detail(
    identity: TelegramWebAppIdentity,
    cycle_id: int | str,
    *,
    cursor: int = 0,
    limit: int = 100,
) -> dict[str, Any]:
    db = read_db_sections((
        "signal_cycle", "signals", "signal_archive", "scheduled_signals",
        "delegated_admins", "admin_shifts", "settings",
    ))
    if not is_any_admin(db, identity.user_id) or not has_permission(db, identity.user_id, PERMISSION_SIGNAL_BOARD_MANAGE):
        raise PermissionError("ADMIN_SIGNALS_REQUIRED")
    return signal_cycle_detail(db, cycle_id, offset=cursor, limit=limit)


def admin_platform(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    """Admin-only platform, dependency and cost-control dashboard."""
    from modules.admin_access import PERMISSION_SYSTEM_HEALTH_VIEW, has_permission
    from modules.platform_expansion import platform_dashboard
    from modules.admin_control_center import (
        MODULES as CONTROL_MODULES, capability_status, control_summary, ensure_control_center,
        is_free_mode_locked, module_state as control_module_state,
    )
    from modules.operations_governance import governance_dashboard

    db = read_db_sections((
        "enterprise_control", "platform_registry", "platform_settings", "delegated_admins",
        "admin_shifts", "paper_accounts", "paper_trades", "publisher_channels", "publisher_queue",
        "partners", "partner_events", "developer_webhooks", "webhook_outbox", "workspaces",
        "operations_governance",
    ))
    if not is_any_admin(db, identity.user_id) or not has_permission(db, identity.user_id, PERMISSION_SYSTEM_HEALTH_VIEW):
        raise PermissionError("ADMIN_SYSTEM_CONTROL_REQUIRED")
    ensure_control_center(db)
    modules: list[dict[str, Any]] = []
    for module in CONTROL_MODULES:
        state = control_module_state(db, module.key)
        fields = []
        for field in module.fields:
            status = capability_status(module.key, field.key)
            fields.append({
                "key": field.key, "label": field.label, "kind": field.kind,
                "value": state.get(field.key, field.default), "default": field.default,
                "minimum": field.minimum, "maximum": field.maximum, "choices": list(field.choices),
                "help_text": field.help_text, "capability_status": status,
                "editable": status != "planned" and not is_free_mode_locked(module.key, field.key),
                "free_mode_locked": is_free_mode_locked(module.key, field.key),
            })
        modules.append({
            "key": module.key, "label": module.label, "category": module.category,
            "description": module.description, "enabled": bool(state.get("enabled", True)),
            "fields": fields, "connected_fields": sum(1 for field in fields if field["capability_status"] != "planned"),
        })
    payload = platform_dashboard(db)
    payload["control_summary"] = control_summary(db)
    payload["control_modules"] = modules
    payload["control_categories"] = sorted({module.category for module in CONTROL_MODULES})
    payload["governance"] = governance_dashboard(db)
    payload["sync_contract"] = {
        "source": "enterprise_control", "telegram_bot": True, "miniapp": True,
        "write_path": "shared_actions_v2_registry", "module_count": len(modules),
    }
    return payload


def ai_assistant(identity: TelegramWebAppIdentity, *, limit: int = 30) -> dict[str, Any]:
    from modules.gemini_ai import ai_history
    return ai_history(identity.user_id, admin=False, limit=limit)


def admin_ai_center(identity: TelegramWebAppIdentity, *, limit: int = 50) -> dict[str, Any]:
    from modules.admin_access import (
        PERMISSION_AI_COMMAND_CENTER, PERMISSION_AI_MANAGEMENT_REPORTS, PERMISSION_AI_CRM_ANALYSIS,
        PERMISSION_AI_USER_BEHAVIOR, PERMISSION_AI_CHANNEL_CONTENT, PERMISSION_AI_TICKET_ASSISTANT,
        PERMISSION_AI_SIGNAL_ANALYSIS, PERMISSION_AI_RISK_SUPERVISION, PERMISSION_AI_SYSTEM_MONITORING,
        PERMISSION_AI_CONFIRM_STANDARD_ACTIONS, PERMISSION_AI_CONFIRM_SENSITIVE_ACTIONS,
    )
    from modules.gemini_ai import ai_history

    shell = _require_admin_permission(identity, PERMISSION_AI_COMMAND_CENTER)
    granted = set((shell.get("admin") or {}).get("permissions") or [])
    role = str((shell.get("admin") or {}).get("role") or "admin")
    def can(permission: str) -> bool:
        return role == "owner" or permission in granted
    payload = ai_history(identity.user_id, admin=True, limit=limit)
    payload["scopes"] = [
        {"key": "management", "label_fa": "گزارش مدیریتی", "enabled": can(PERMISSION_AI_MANAGEMENT_REPORTS)},
        {"key": "crm", "label_fa": "CRM هوشمند", "enabled": can(PERMISSION_AI_CRM_ANALYSIS)},
        {"key": "user_behavior", "label_fa": "رفتار کاربران", "enabled": can(PERMISSION_AI_USER_BEHAVIOR)},
        {"key": "channel", "label_fa": "کنترل کانال", "enabled": can(PERMISSION_AI_CHANNEL_CONTENT)},
        {"key": "tickets", "label_fa": "تیکت‌ها", "enabled": can(PERMISSION_AI_TICKET_ASSISTANT)},
        {"key": "signals", "label_fa": "سیگنال‌ها", "enabled": can(PERMISSION_AI_SIGNAL_ANALYSIS)},
        {"key": "risk", "label_fa": "ریسک و پراپ", "enabled": can(PERMISSION_AI_RISK_SUPERVISION)},
        {"key": "system", "label_fa": "سلامت فنی", "enabled": can(PERMISSION_AI_SYSTEM_MONITORING)},
        {"key": "knowledge", "label_fa": "پایگاه دانش Sentinel", "enabled": can(PERMISSION_AI_MANAGEMENT_REPORTS)},
    ]
    payload["can_confirm_standard"] = can(PERMISSION_AI_CONFIRM_STANDARD_ACTIONS)
    payload["can_confirm_sensitive"] = can(PERMISSION_AI_CONFIRM_SENSITIVE_ACTIONS)
    payload["is_primary_admin"] = is_primary_admin(identity.user_id)
    payload["primary_admin_id"] = int(SETTINGS.primary_admin_id)
    payload["execution_settings"] = payload.get("execution_settings") or {}
    payload["pending_commands"] = [
        dict(row) for row in (payload.get("commands") or [])
        if str(row.get("status") or "").startswith("pending")
    ] if payload["is_primary_admin"] else []
    if payload["is_primary_admin"]:
        from modules.admin_access import pending_delegated_admins
        access_db = read_db_sections(("delegated_admins",))
        payload["pending_admins"] = pending_delegated_admins(access_db)
    else:
        payload["pending_admins"] = []
    return payload


def admin_vip_plans(identity: TelegramWebAppIdentity) -> dict[str, Any]:
    from modules.admin_access import (
        PERMISSION_VIP_SETTINGS, PERMISSION_VIP_PLAN_VIEW, PERMISSION_VIP_PLAN_CREATE,
        PERMISSION_VIP_PLAN_EDIT, PERMISSION_VIP_PLAN_ACTIVATE, PERMISSION_VIP_PLAN_ARCHIVE,
        PERMISSION_VIP_PLAN_DELETE,
    )
    from modules.sales_growth import ensure_vip_plans

    shell = _require_any_admin_permission(
        identity, PERMISSION_VIP_SETTINGS, PERMISSION_VIP_PLAN_VIEW, PERMISSION_VIP_PLAN_CREATE,
        PERMISSION_VIP_PLAN_EDIT, PERMISSION_VIP_PLAN_ACTIVATE, PERMISSION_VIP_PLAN_ARCHIVE, PERMISSION_VIP_PLAN_DELETE,
    )
    granted = set((shell.get("admin") or {}).get("permissions") or [])
    role = str((shell.get("admin") or {}).get("role") or "admin")
    db = read_db_sections(("vip_plans", "vip_settings", "vip_orders", "delegated_admins", "admin_shifts"))
    plans = [dict(row) for row in ensure_vip_plans(db)]
    plans.sort(key=lambda row: (bool(row.get("archived")), int(row.get("sort_order", 100) or 100), int(row.get("id", 0) or 0)))
    def can(permission: str) -> bool:
        return role == "owner" or permission in granted or PERMISSION_VIP_SETTINGS in granted
    return {
        "items": plans, "total": len(plans),
        "settings": {
            "card_number": str((db.get("vip_settings") or {}).get("card_number") or ""),
            "owner_name": str((db.get("vip_settings") or {}).get("owner_name") or ""),
            "price": int((db.get("vip_settings") or {}).get("price", 0) or 0),
            "duration_days": int((db.get("vip_settings") or {}).get("duration_days", 30) or 30),
        },
        "permissions": {
            "settings": can(PERMISSION_VIP_SETTINGS),
            "create": can(PERMISSION_VIP_PLAN_CREATE), "edit": can(PERMISSION_VIP_PLAN_EDIT),
            "activate": can(PERMISSION_VIP_PLAN_ACTIVATE), "archive": can(PERMISSION_VIP_PLAN_ARCHIVE),
            "delete": can(PERMISSION_VIP_PLAN_DELETE),
        },
    }


def user_hub(identity: TelegramWebAppIdentity, *, cursor=0, limit=20) -> dict[str, Any]:
    """Read only the signed-in user's rewards; never accept a client user id."""
    from modules.reward_wallet import wallet_items, point_summary, reward_source_label, reward_seen_key, wallet_unread_keys
    from modules.missions import mission_available, mission_progress_snapshot
    from modules.prize_delivery import prize_label
    db=read_db_sections(('users','vip_users','user_points','point_history','user_rewards','discount_codes',
        'user_referrals','missions','user_missions','settings','lessons','education_orders','lesson_progress','reward_shop_claims','economic_events'))
    uid=str(identity.user_id)
    language='en' if str(db.get('users',{}).get(uid,{}).get('language'))=='en' else 'fa'
    items=wallet_items(db,uid)
    unread = wallet_unread_keys(db, uid)
    for item in items:
        item["seen_key"] = reward_seen_key(item)
        item["unread"] = item["seen_key"] in unread
        item['source_label']=reward_source_label(item.get('source'),language)
        if item.get('type')=='discount' and language=='en':
            item['title']='Discount code'
            coupon=db.get('discount_codes',{}).get(item.get('code'),{})
            if coupon.get('discount_type')=='fixed':item['detail']=f"{int(coupon.get('fixed_amount',0)):,} IRT | {item['code']}"
    missions=[{'id':m['id'],'title':m.get('title'),'description':m.get('description'),'period':m.get('period'),
               'ends_at':m.get('ends_at'),'prize_label':prize_label(m.get('prize') or {'points':m.get('reward',0)},language),
               'progress':mission_progress_snapshot(db,uid,m)} for m in db.get('missions',[]) if mission_available(m)]
    from services.reward_claims import available_rewards
    available=[{key:item.get(key) for key in ('id','name','description','points','type','value','discountPct','expires_at','per_user_limit','stock','prize')} for item in available_rewards(db,uid)]
    ranked=sorted(db.get('user_points',{}).items(),key=lambda pair:(-int(pair[1]),str(pair[0])))
    leaders=[{'rank':index+1,'name':str(db.get('users',{}).get(str(member),{}).get('username') or db.get('users',{}).get(str(member),{}).get('first_name') or 'SENTINEL'),
              'points':int(points),'is_me':str(member)==uid} for index,(member,points) in enumerate(ranked[:10])]
    referral=db.get('user_referrals',{}).get(uid,{})
    return {'leaderboard':leaders,'my_rank':next((i+1 for i,(member,_) in enumerate(ranked) if str(member)==uid),None),'wallet':items,'unread_rewards':len(unread),'points':point_summary(db,uid,cursor=cursor,limit=limit,language=language),'available':available,'missions':missions,
            'referral':{'code':referral.get('code',''),'invited':len(set(map(str,referral.get('invited',[])))),'buyers':len(set(map(str,referral.get('purchasers',[]))))},
            'generated_at':utc_iso()}
