from __future__ import annotations

from typing import Any

from core.db import read_db_sections
from repositories.v2.preferences import PreferenceRepository

_SECTIONS = (
    "signals",
    "announcements",
    "market_intelligence",
    "market_news",
    "publisher_queue",
)


def _rows(value: Any) -> list[dict[str, Any]]:
    if isinstance(value, list):
        return [row for row in value if isinstance(row, dict)]
    if isinstance(value, dict):
        return [row for row in value.values() if isinstance(row, dict)]
    return []


def _when(row: dict[str, Any]) -> str:
    for key in ("published_at", "sent_at", "created_at", "updated_at", "generated_at", "date"):
        if row.get(key):
            return str(row[key])
    return ""


def _visible_destination(row: dict[str, Any], vip_active: bool) -> bool:
    destination = str(
        row.get("destination")
        or row.get("target")
        or row.get("channel_type")
        or "public"
    ).lower()
    delivered = row.get("delivered_channels")
    if isinstance(delivered, list) and delivered:
        channels = {str(item).lower() for item in delivered}
        return "public" in channels or (vip_active and "private" in channels)
    return destination in {"public", "both", "all", ""} or (
        vip_active and destination in {"private", "vip"}
    )


def _access_tier(row: dict[str, Any]) -> str:
    delivered = row.get("delivered_channels")
    if isinstance(delivered, list) and delivered:
        channels = {str(item).lower() for item in delivered}
        if "private" in channels and "public" not in channels:
            return "vip"
        if {"public", "private"}.issubset(channels):
            return "public_vip"
        return "public"
    destination = str(
        row.get("destination") or row.get("target") or row.get("channel_type") or "public"
    ).lower()
    if destination in {"private", "vip"}:
        return "vip"
    if destination in {"both", "all"}:
        return "public_vip"
    return "public"


def _market(row: dict[str, Any]) -> str:
    value = str(row.get("market_category") or row.get("market") or "").lower()
    if value in {"crypto", "cryptocurrency", "digital_asset"}:
        return "crypto"
    if value in {"forex", "fx", "gold", "metals", "indices", "commodity"}:
        return "forex"
    symbol = str(row.get("symbol") or "").upper().replace("/", "")
    return "crypto" if symbol.endswith(("USDT", "USDC", "BTC", "ETH")) else (value or "forex")


def channel_feed(user_id: int | str, *, vip_active: bool, limit: int = 50) -> dict[str, Any]:
    """Return a single, visibility-aware timeline of channel publications.

    The channel database remains the source of truth. The Mini App receives
    only public rows plus private/VIP rows for users with an active entitlement.
    """
    size = max(1, min(int(limit or 50), 100))
    db = read_db_sections(_SECTIONS)
    choices = PreferenceRepository().get(user_id, "user_signal_choices", {})
    choices = choices if isinstance(choices, dict) else {}
    items: list[dict[str, Any]] = []

    for row in _rows(db.get("signals")):
        if not _visible_destination(row, vip_active):
            continue
        signal_id = str(row.get("id") or "")
        items.append(
            {
                "id": f"signal:{signal_id}",
                "type": "signal",
                "signal_id": signal_id,
                "title": f"{str(row.get('symbol') or '').upper()} · {str(row.get('side') or '').upper()}",
                "summary": str(row.get("note") or row.get("analysis") or "")[:700],
                "symbol": str(row.get("symbol") or "").upper(),
                "side": str(row.get("side") or "").upper(),
                "status": str(row.get("status") or "open"),
                "created_at": _when(row),
                "destination": str(row.get("target") or row.get("destination") or "public"),
                "access_tier": _access_tier(row),
                "market_category": _market(row),
                "priority": "high",
                "choice": choices.get(signal_id) if isinstance(choices.get(signal_id), dict) else None,
            }
        )

    for row in _rows(db.get("announcements")):
        if str(row.get("status") or "").lower() not in {"sent", "partial"}:
            continue
        if not _visible_destination(row, vip_active):
            continue
        items.append(
            {
                "id": f"announcement:{row.get('id')}",
                "type": "announcement",
                "title": str(row.get("title") or "اعلان کانال"),
                "summary": str(row.get("text") or row.get("caption") or "")[:1200],
                "content_type": str(row.get("content_type") or "message"),
                "status": str(row.get("status") or "sent"),
                "created_at": _when(row),
                "destination": str(row.get("destination") or "public"),
                "access_tier": _access_tier(row),
                "priority": str(row.get("priority") or "normal"),
            }
        )

    intelligence = db.get("market_intelligence")
    intelligence = intelligence if isinstance(intelligence, dict) else {}
    for row in _rows(intelligence.get("briefings")) + _rows(intelligence.get("calendar_publications")):
        if str(row.get("status") or "").lower() not in {"sent", "published", "partial"}:
            continue
        if not _visible_destination(row, vip_active):
            continue
        items.append(
            {
                "id": f"market:{row.get('id') or _when(row)}",
                "type": "market",
                "title": str(row.get("title") or row.get("headline") or "گزارش بازار"),
                "summary": str(row.get("summary") or row.get("text") or row.get("content") or "")[:1200],
                "status": str(row.get("status") or "published"),
                "created_at": _when(row),
                "destination": str(row.get("destination") or "public"),
                "access_tier": _access_tier(row),
                "priority": str(row.get("impact") or row.get("priority") or "normal"),
            }
        )

    for row in _rows(db.get("market_news")):
        published = str(row.get("status") or "").lower() in {"sent", "published"} or bool(
            row.get("published_to_channel") or row.get("deliveries")
        )
        if not published or not _visible_destination(row, vip_active):
            continue
        items.append(
            {
                "id": f"news:{row.get('id') or _when(row)}",
                "type": "news",
                "title": str(row.get("title") or row.get("headline") or "خبر بازار"),
                "summary": str(row.get("summary") or row.get("text") or row.get("description") or "")[:1200],
                "status": "published",
                "created_at": _when(row),
                "destination": str(row.get("destination") or "public"),
                "access_tier": _access_tier(row),
                "priority": str(row.get("impact") or row.get("priority") or "normal"),
                "source": str(row.get("source") or ""),
            }
        )

    for row in _rows(db.get("publisher_queue")):
        if str(row.get("status") or "").lower() not in {"sent", "published", "partial"}:
            continue
        if not _visible_destination(row, vip_active):
            continue
        items.append(
            {
                "id": f"publication:{row.get('id')}",
                "type": str(row.get("content_type") or "publication"),
                "title": str(row.get("title") or "انتشار کانال"),
                "summary": str(row.get("content") or row.get("text") or "")[:1200],
                "status": str(row.get("status") or "sent"),
                "created_at": _when(row),
                "destination": str(row.get("destination") or row.get("channel_type") or "public"),
                "access_tier": _access_tier(row),
                "priority": str(row.get("priority") or "normal"),
            }
        )

    deduplicated: dict[str, dict[str, Any]] = {}
    for item in items:
        deduplicated[str(item["id"])] = item
    ordered = sorted(deduplicated.values(), key=lambda row: (str(row.get("created_at") or ""), str(row.get("id") or "")), reverse=True)
    visible = ordered[:size]
    return {
        "items": visible,
        "total": len(ordered),
        "limit": size,
        "vip_scope": bool(vip_active),
        "groups": {
            "public": sum(1 for row in visible if row.get("access_tier") != "vip"),
            "vip": sum(1 for row in visible if row.get("access_tier") == "vip"),
            "signals": sum(1 for row in visible if row.get("type") == "signal"),
            "news": sum(1 for row in visible if row.get("type") in {"news", "market"}),
            "announcements": sum(1 for row in visible if row.get("type") in {"announcement", "publication"}),
        },
    }
