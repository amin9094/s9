from __future__ import annotations

from datetime import UTC, datetime
from typing import Any

from modules.incident_center import incident_summary
from modules.provider_health import provider_health_summary


def _state(ok: bool | None, *, disabled: bool = False, degraded: bool = False) -> str:
    if disabled:
        return "disabled"
    if ok is False:
        return "offline"
    if degraded:
        return "degraded"
    if ok is True:
        return "healthy"
    return "unknown"


def _age_seconds(value: Any, *, now: datetime | None = None) -> int | None:
    if not value:
        return None
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
        if parsed.tzinfo is None:
            parsed = parsed.replace(tzinfo=UTC)
        current = (now or datetime.now(UTC)).astimezone(UTC)
        return max(0, int((current - parsed.astimezone(UTC)).total_seconds()))
    except (TypeError, ValueError):
        return None


def build_system_center_snapshot(
    db: dict[str, Any],
    *,
    observability: dict[str, Any] | None = None,
    readiness: dict[str, Any] | None = None,
    google_sheets: dict[str, Any] | None = None,
    latest_backup: dict[str, Any] | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    """Build one read-only operations snapshot for admin UX and diagnostics.

    This function is intentionally pure: external checks are performed by the
    caller and supplied as snapshots. A broken provider/Google/backup probe can
    therefore never prevent the System Center screen from rendering.
    """
    obs = dict(observability or {})
    ready = dict(readiness or {})
    checks = dict(ready.get("checks") or {})
    google = dict(google_sheets or {})
    backup = dict(latest_backup or {})

    jobs = {
        str(name): dict(row)
        for name, row in (obs.get("jobs") or {}).items()
        if isinstance(row, dict)
    }
    failed_jobs = [name for name, row in jobs.items() if str(row.get("status")) in {"failed", "degraded"}]
    running_jobs = [name for name, row in jobs.items() if str(row.get("status")) == "running"]
    ok_jobs = [name for name, row in jobs.items() if str(row.get("status")) == "ok"]

    incidents = incident_summary(db)
    providers = provider_health_summary(db)
    provider_degraded = int(providers.get("degraded", 0) or 0) + int(providers.get("offline", 0) or 0)

    google_enabled = bool(google.get("enabled"))
    google_configured = bool(google.get("configured"))
    google_pending = len(google.get("pending_sections") or [])
    google_error = str(google.get("error") or google.get("last_primary_error") or "")
    google_degraded = bool(google_enabled and (not google_configured or google_error or google_pending >= 20))

    backup_age = _age_seconds(backup.get("created_at"), now=now)
    backup_state = "unknown"
    if backup:
        backup_state = "healthy" if backup_age is not None and backup_age <= 26 * 3600 else "degraded"

    components = {
        "telegram": {
            "state": _state(checks.get("telegram") and checks.get("telegram_transport_running", True)),
            "detail": "transport ready" if checks.get("telegram") else "authentication/readiness check failed",
        },
        "database": {
            "state": _state(checks.get("database")),
            "detail": "primary database ready" if checks.get("database") else "database readiness check failed",
        },
        "job_queue": {
            "state": _state(checks.get("job_queue"), degraded=bool(failed_jobs)),
            "detail": f"{len(ok_jobs)} ok · {len(running_jobs)} running · {len(failed_jobs)} degraded/failed",
        },
        "google_sheets": {
            "state": _state(google_configured, disabled=not google_enabled, degraded=google_degraded),
            "detail": f"pending={google_pending}" + (f" · {google_error[:120]}" if google_error else ""),
        },
        "providers": {
            "state": _state(True, degraded=provider_degraded > 0),
            "detail": f"{int(providers.get('healthy', 0) or 0)}/{int(providers.get('total', 0) or 0)} healthy",
        },
        "backup": {
            "state": backup_state,
            "detail": "no backup metadata" if not backup else f"age_seconds={backup_age if backup_age is not None else 'unknown'}",
        },
    }

    required_states = [row["state"] for key, row in components.items() if key != "google_sheets" or google_enabled]
    if int(incidents.get("critical", 0) or 0) > 0 or "offline" in required_states:
        overall = "critical"
    elif int(incidents.get("warning", 0) or 0) > 0 or any(state in {"degraded", "unknown"} for state in required_states):
        overall = "degraded"
    else:
        overall = "healthy"

    return {
        "overall": overall,
        "components": components,
        "uptime_seconds": int(obs.get("uptime_seconds", ready.get("uptime_seconds", 0)) or 0),
        "jobs": {
            "total": len(jobs),
            "ok": len(ok_jobs),
            "running": len(running_jobs),
            "failed": len(failed_jobs),
            "failed_names": failed_jobs[:10],
        },
        "incidents": incidents,
        "providers": providers,
        "google_sheets": google,
        "backup": {**backup, "age_seconds": backup_age},
        "readiness": ready,
        "recent_errors": list(obs.get("recent_errors") or [])[-5:],
    }
