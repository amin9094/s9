"""Separate setup evidence by strategy/version; target hits are not trade profits."""

from __future__ import annotations

from collections import Counter
from decimal import Decimal

from modules.canonical_market import Quote
from modules.setup_lifecycle import ENGINES, SetupPlan

FAMILIES = {
    "indicators": "اندیکاتورها",
    "sweep_fvg": "نقدینگی / CHoCH / FVG",
    "order_block": "اردربلاک و حجم",
    "fibonacci": "فیبوناچی؛ تأیید مشترک / سابقه",
    "fibonacci_pullback": "فیبوناچی؛ شکست و پولبک آزمایشی",
}
SAMPLE_KINDS = {"unclassified", "observed_quotes", "shadow_forward", "historical_simulation"}
CLASSIFICATION_FIELDS = (
    "engine",
    "submodel",
    "rule_version",
    "profile_id",
    "sample_kind",
    "symbol",
    "timeframe",
    "direction",
    "provider",
    "venue",
    "product",
)


def _valid_entry(locked, payload, events):
    state = payload["state"]
    entry_ms = state["entry_ms"]
    for event in events.values():
        if event["event_type"] != state["phase"] or event["event_ms"] != entry_ms:
            continue
        evidence = event["payload"]
        if state["phase"] == "MANUAL_ADMIN_ENTRY":
            return bool(
                evidence == payload.get("manual_entry")
                and evidence.get("actor")
                and evidence.get("reason")
                and evidence.get("confirmed_ms") == entry_ms
            )
        try:
            quote = Quote(**evidence["quote"])
            executable = quote.ask if locked.direction == "BUY" else quote.bid
            return (
                quote.fresh(quote.received_ms)
                and quote.event_ms == entry_ms
                and quote.tick_size == locked.tick_size
                and executable == locked.entry
                and all(
                    getattr(quote, key) == getattr(locked, key) for key in ("symbol", "provider", "venue", "product")
                )
            )
        except (KeyError, TypeError, ValueError, ArithmeticError):
            return False
    return False


def classify_plan(plan, *, profile_id="unrecorded", sample_kind="unclassified"):
    if sample_kind not in SAMPLE_KINDS:
        raise ValueError("FEEDBACK_SAMPLE_KIND_INVALID")
    if not isinstance(profile_id, str) or not profile_id.strip() or len(profile_id) > 160:
        raise ValueError("FEEDBACK_PROFILE_INVALID")
    data = plan.as_dict()
    return {
        "schema_version": 1,
        **{key: data[key] for key in CLASSIFICATION_FIELDS if key not in {"profile_id", "sample_kind"}},
        "profile_id": profile_id.strip(),
        "sample_kind": sample_kind,
    }


def admin_exit_result(locked, payload, events):
    rows = payload.get("admin_exits") or []
    if not rows:
        return None
    amount, gross, costs = Decimal(0), Decimal(0), Decimal(0)
    all_costs_known = True
    last_ms = payload["state"]["entry_ms"]
    for row in rows:
        event = events.get(row.get("event_id"))
        content = {key: value for key, value in row.items() if key != "event_id"}
        if not event or event["event_type"] != "ADMIN_EXIT" or event["payload"] != content:
            raise ValueError("ADMIN_EXIT_EVIDENCE_INVALID")
        if not row.get("actor") or not row.get("reason") or row.get("is_broker_execution") is not False or event["event_ms"] != row["confirmed_ms"] or row["confirmed_ms"] < last_ms:
            raise ValueError("ADMIN_EXIT_EVIDENCE_INVALID")
        allocation, reference = Decimal(row["percentage_original"]), Decimal(row["reference_price"])
        if not allocation.is_finite() or not 0 < allocation <= 100 or not reference.is_finite() or reference <= 0:
            raise ValueError("ADMIN_EXIT_EVIDENCE_INVALID")
        amount += allocation
        sign = Decimal(1) if locked.direction == "BUY" else Decimal(-1)
        gross += allocation / 100 * sign * (reference - locked.entry) / abs(locked.entry - locked.stop)
        declared = row.get("cost_in_initial_r")
        if declared is None:
            all_costs_known = False
        else:
            cost = Decimal(declared)
            if not cost.is_finite() or cost < 0:
                raise ValueError("ADMIN_EXIT_EVIDENCE_INVALID")
            costs += cost
        last_ms = row["confirmed_ms"]
    if amount > 100:
        raise ValueError("ADMIN_EXIT_EVIDENCE_INVALID")
    return {"closed": amount == 100, "closed_initial_volume_percent": str(amount), "gross_planned_r": str(gross),
            "net_planned_r": str(gross - costs) if all_costs_known else None,
            "basis": "DECLARED_EXITS_LOCKED_INITIAL_RISK", "is_broker_execution": False}


def feedback_snapshot(rows):
    """Consume repository snapshots, never candle-inferred wins or LLM scores.

    Percentages use only closed, entered plans in the exact same cohort.
    Pending/cancelled/no-entry/ambiguous plans cannot inflate a denominator.
    TP1 followed by SL remains a TP1 hit AND a stop hit, not a declared win.
    Partial exits, fees and realised-R require the separately specified exit
    policy; this report deliberately cannot fabricate them.
    """
    groups = {}
    for row in rows:
        payload = row["payload"]
        plan = payload["plan"]
        locked = SetupPlan.from_dict(plan)
        if locked.plan_hash != payload["plan_hash"]:
            raise ValueError("PLAN_IMMUTABILITY_VIOLATION")
        if plan["engine"] not in ENGINES:
            raise ValueError("FEEDBACK_ENGINE_INVALID")
        category = payload.get("classification") or {
            "schema_version": 1,
            **{key: plan[key] for key in CLASSIFICATION_FIELDS if key not in {"profile_id", "sample_kind"}},
            "profile_id": "unrecorded",
            "sample_kind": "unclassified",
        }
        # Old records are explicitly unclassified rather than guessed live.
        if category.get("sample_kind") not in SAMPLE_KINDS:
            raise ValueError("FEEDBACK_SAMPLE_KIND_INVALID")
        if any(category.get(key) != plan[key] for key in CLASSIFICATION_FIELDS if key in plan):
            raise ValueError("FEEDBACK_CLASSIFICATION_MISMATCH")
        phase = payload["state"]["phase"]
        entry_kind = phase if phase in {"VERIFIED_ENTRY", "MANUAL_ADMIN_ENTRY"} else "NO_CONFIRMED_ENTRY"
        identity = tuple(category[key] for key in CLASSIFICATION_FIELDS) + (entry_kind,)
        bucket = groups.setdefault(
            identity,
            {
                "classification": {**category, "entry_kind": entry_kind},
                "proposals": 0,
                "entered": 0,
                "closed_entered": 0,
                "open_entered": 0,
                "cancelled": 0,
                "needs_review": 0,
                "invalid_outcome_evidence": 0,
                "closed_target_hits": {"TP1": 0, "TP2": 0, "TP3": 0},
                "target_eligible_closed": {"TP1": 0, "TP2": 0, "TP3": 0},
                "closed_stop_hits": 0,
                "admin_managed_closed": 0,
                "admin_declared_gross_wins": 0,
                "admin_declared_net_known": 0,
                "admin_declared_net_wins": 0,
                "admin_declared_gross_r_sum": "0",
                "reasons": Counter(),
            },
        )
        bucket["proposals"] += 1
        bucket["cancelled"] += phase == "CANCELLED"
        bucket["needs_review"] += phase == "NEEDS_REVIEW"
        reason = payload["state"].get("reason")
        if reason:
            bucket["reasons"][str(reason)] += 1
        entry_ms = payload["state"].get("entry_ms")
        if entry_kind == "NO_CONFIRMED_ENTRY" or not entry_ms:
            if payload.get("detected_outcomes"):
                bucket["invalid_outcome_evidence"] += 1
            continue
        events = {event["id"]: event for event in row.get("events", [])}
        if not _valid_entry(locked, payload, events):
            bucket["invalid_outcome_evidence"] += 1
            continue
        bucket["entered"] += 1
        try:
            management = admin_exit_result(locked, payload, events)
        except (ValueError, ArithmeticError):
            management = None
            bucket["invalid_outcome_evidence"] += 1
        if management and management["closed"]:
            bucket["admin_managed_closed"] += 1
            gross = Decimal(management["gross_planned_r"])
            bucket["admin_declared_gross_wins"] += gross > 0
            bucket["admin_declared_gross_r_sum"] = str(Decimal(bucket["admin_declared_gross_r_sum"]) + gross)
            if management["net_planned_r"] is not None:
                bucket["admin_declared_net_known"] += 1
                bucket["admin_declared_net_wins"] += Decimal(management["net_planned_r"]) > 0
        hits = set()
        bad = False
        for kind, event_id in (payload.get("detected_outcomes") or {}).items():
            event = events.get(event_id)
            if kind not in {"TP1", "TP2", "TP3", "SL"} or not event or event["event_type"] != kind:
                bad = True
                continue
            evidence = event["payload"]
            quote = evidence.get("quote") or {}
            try:
                canonical_quote = Quote(**quote)
                executable = canonical_quote.bid if locked.direction == "BUY" else canonical_quote.ask
                level = locked.stop if kind == "SL" else getattr(locked, kind.lower())
                sign = Decimal(1) if locked.direction == "BUY" else Decimal(-1)
                crossed = sign * (executable - level) <= 0 if kind == "SL" else sign * (executable - level) >= 0
                valid_quote = (
                    canonical_quote.fresh(canonical_quote.received_ms)
                    and canonical_quote.tick_size == locked.tick_size
                    and Decimal(str(evidence["level"])) == level
                    and crossed
                )
            except (KeyError, TypeError, ValueError, ArithmeticError):
                valid_quote = False
            if (
                not valid_quote
                or event["event_ms"] <= entry_ms
                or evidence.get("entry_kind") != entry_kind
                or any(quote.get(key) != plan[key] for key in ("symbol", "provider", "venue", "product"))
                or quote.get("event_ms") != event["event_ms"]
                or quote.get("quality_flags")
            ):
                bad = True
                continue
            hits.add(kind)
        final_target = "TP3" if plan.get("tp3") is not None else "TP2"
        if bad or payload.get("outcome_closed") and not ({"SL", final_target} & hits):
            bucket["invalid_outcome_evidence"] += 1
            continue
        if not payload.get("outcome_closed"):
            bucket["open_entered"] += 1
            continue
        bucket["closed_entered"] += 1
        bucket["closed_stop_hits"] += "SL" in hits
        for target in bucket["closed_target_hits"]:
            bucket["closed_target_hits"][target] += target in hits
            bucket["target_eligible_closed"][target] += plan.get(target.lower()) is not None

    result = []
    for bucket in groups.values():
        denominator = bucket["closed_entered"]
        bucket["closed_target_hit_rate_percent"] = {
            target: round(count * 100 / bucket["target_eligible_closed"][target], 2)
            if bucket["target_eligible_closed"][target]
            else None
            for target, count in bucket["closed_target_hits"].items()
        }
        bucket["closed_stop_hit_rate_percent"] = (
            round(bucket["closed_stop_hits"] * 100 / denominator, 2) if denominator else None
        )
        bucket["reasons"] = dict(bucket["reasons"])
        count = bucket["admin_managed_closed"]
        net_count = bucket["admin_declared_net_known"]
        bucket["admin_declared_gross_win_rate_percent"] = round(bucket["admin_declared_gross_wins"] * 100 / count, 2) if count else None
        bucket["admin_declared_net_win_rate_percent"] = round(bucket["admin_declared_net_wins"] * 100 / net_count, 2) if net_count else None
        result.append(bucket)
    result.sort(key=lambda row: tuple(str(row["classification"][key]) for key in CLASSIFICATION_FIELDS))
    return {
        "families": [
            {
                "engine": engine,
                "title_fa": title,
                "groups": [row for row in result if row["classification"]["engine"] == engine],
            }
            for engine, title in FAMILIES.items()
        ],
        "denominator": "CLOSED_ENTERED_PLANS_IN_THE_SAME_COHORT",
        "missing_rate_value": None,
        "is_broker_performance": False,
        "realised_r_state": "DECLARED_ADMIN_EXIT_LEDGER_SEPARATE_FROM_BROKER_EXECUTIONS",
        "win_rate_state": "TARGET_HITS_AND_DECLARED_GROSS_NET_RESULTS_SEPARATE",
    }
