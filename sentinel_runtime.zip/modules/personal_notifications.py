"""Project new personal events into the existing durable delivery queue."""
from __future__ import annotations
from core.utils import utc_iso
from core.domain import is_vip
from modules.broadcast_queue import enqueue_broadcast
from modules.notification_router import should_notify


def initialize_personal_notifications(db):
    return db.setdefault('notification_defaults', {}).setdefault('experience_started_at', utc_iso())


def queue_personal_notifications(db, limit=10):
    since = initialize_personal_notifications(db)
    users = db.get('users', {})
    signals = {str(r.get('id')):r for r in db.get('signals', []) if isinstance(r,dict)}
    candidates = []
    for row in signals.values():
        candidates.append((row,'signals',f"📡 سیگنال جدید #{row.get('display_number') or row.get('id')} | {row.get('symbol','')}\nاز منوی سیگنال‌ها مشاهده کنید.",None,row))
    for row in db.get('signal_outcome_events', []):
        signal = signals.get(str(row.get('signal_id')))
        if not signal: continue
        event = str(row.get('event') or row.get('status') or '').lower()
        kind = 'risk_free' if 'risk' in event or 'breakeven' in event else 'sl' if 'stop' in event or event == 'sl' else 'tp' if 'target' in event or event.startswith('tp') else 'results'
        candidates.append((row,kind,f"📈 به‌روزرسانی سیگنال #{signal.get('display_number') or signal.get('id')} | {signal.get('symbol','')}\nوضعیت: {row.get('status','')}\nاز منوی سیگنال‌ها مشاهده کنید.",None,signal))
    for row in db.get('user_rewards', []):
        candidates.append((row,'reward','🎁 پاداش جدیدی در «جایزه‌های من» ثبت شد.',[str(row.get('user_id'))],None))
    for row in db.get('lessons', []):
        if isinstance(row,dict) and row.get('active',True) and row.get('status','published') not in {'draft','disabled'}:
            candidates.append((row,'education',f"🎓 آموزش جدید: {str(row.get('title') or '')[:150]}\nاز منوی آموزش مشاهده کنید.",None,None))
    queued = 0
    for row,kind,text,recipients,signal in candidates:
        if row.get('personal_notification_queued') or str(row.get('created_at') or '') < since: continue
        if sum(j.get('status') not in {'completed','cancelled'} for j in db.get('broadcast_queue',[])) >= 180: break
        market = str((signal or {}).get('market_category') or '')
        symbol = str((signal or {}).get('symbol') or '').upper()
        if symbol.startswith(('XAU','XAG')): market='gold'
        elif symbol in {'USOIL','UKOIL','WTI','BRENT','NGAS'}: market='energy'
        allowed=[]
        for uid in recipients if recipients is not None else users:
            if not str(uid).isdigit(): continue
            if signal:
                delivered=set(signal.get('delivered_channels') or [])
                if not delivered:
                    delivered={str(d.get('channel')) for d in signal.get('deliveries',[])}
                if 'public' not in delivered and not ('private' in delivered and is_vip(db,uid)): continue
            if should_notify(db,uid,kind,market=market,symbol=symbol): allowed.append(uid)
        if allowed:
            job=enqueue_broadcast(db,admin_id=0,segment='personal_notification',recipients=allowed,message=text)
            job['notification_event']={'kind':kind,'market':market,'symbol':symbol,'signal_id':str(signal.get('id')) if signal else ''}
            job['completion_notified']=True
        row['personal_notification_queued']=utc_iso()
        queued+=1
        if queued>=limit:break
    return queued
