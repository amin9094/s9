from __future__ import annotations

import json
import logging
import secrets
import shutil
from datetime import UTC, datetime, timedelta
from pathlib import Path
from typing import Any

from config import is_primary_admin
from core.db import next_id, validate_database_payload
from core.utils import parse_dt, utc_iso, utc_now
from modules.outcome_engine import record_outcome_event
from modules.prices import normalize_tracking_symbol
from modules.signal_engine import enrich_signal_payload, normalize_entries, update_execution
from modules.signal_versioning import append_signal_version, ensure_initial_version

logger = logging.getLogger(__name__)

SIGNAL_LIFECYCLE_LABELS = {
    "open": "فعال / در انتظار ورود",
    "entry_hit": "ورود انجام شد",
    "tp1": "تارگت ۱",
    "tp2": "تارگت ۲",
    "tp3": "تارگت ۳",
    "tp4": "تارگت ۴",
    "tp5": "تارگت ۵",
    "tp6": "تارگت ۶",
    "tp7": "تارگت ۷",
    "tp8": "تارگت ۸",
    "tp9": "تارگت ۹",
    "tp10": "تارگت ۱۰",
    "target_complete": "تمام تارگت‌ها لمس شد",
    "breakeven": "ریسک‌فری / سر‌به‌سر",
    "partial_close": "بستن بخشی از معامله",
    "manual_close": "بستن دستی",
    "no_entry": "ورود داده نشد",
    "stop": "استاپ",
    "cancelled": "لغوشده",
    "expired": "منقضی‌شده",
}
FINAL_SIGNAL_STATUSES = {"target_complete", "manual_close", "no_entry", "stop", "cancelled", "expired"}

AUTOMATION_DEFAULTS: dict[str, Any] = {
    "enabled": True,
    "vip_reminders_enabled": True,
    "vip_reminder_days": [7, 3, 1, 0],
    "renewal_discount_percent": 15,
    "renewal_code_expiry_days": 7,
    "early_renewal_bonus_days": 2,
    "inactive_enabled": False,
    "inactive_days": 30,
    "inactive_discount_percent": 10,
    "pending_payment_enabled": True,
    "pending_payment_hours": 3,
    "high_points_enabled": False,
    "high_points_threshold": 1000,
    "high_points_discount_percent": 10,
    "crm_enabled": True,
    "crm_auto_stage_enabled": True,
    "crm_welcome_enabled": True,
    "crm_welcome_delay_minutes": 10,
    "crm_abandoned_checkout_enabled": True,
    "crm_abandoned_checkout_hours": 2,
    "crm_churn_risk_enabled": True,
    "crm_churn_risk_days": 21,
    "crm_high_value_enabled": True,
    "crm_high_value_threshold": 5000000,
    "crm_lead_alert_enabled": True,
    "crm_lead_alert_threshold": 70,
    "crm_quiet_hours_enabled": True,
    "crm_quiet_start_hour": 23,
    "crm_quiet_end_hour": 8,
    "crm_timezone": "Asia/Tehran",
    "crm_daily_contact_cap": 3,
    "crm_max_batch": 200,
    "crm_max_attempts": 5,
    "crm_retry_base_minutes": 5,
    "campaign_scheduler_enabled": True,
    "campaign_scheduler_batch": 10,
}

APPROVAL_DEFAULTS: dict[str, Any] = {
    "enabled": False,
    "operations": [],
    "payment_threshold": 10_000_000,
    "expires_minutes": 30,
}


def _find_signal(db: dict[str, Any], signal_id: int | str) -> dict[str, Any]:
    target = int(signal_id)
    for row in reversed(db.get("signals", [])):
        if isinstance(row, dict) and int(row.get("id", 0) or 0) == target:
            return row
    raise ValueError("سیگنال پیدا نشد")


def signal_status_label(status: str) -> str:
    return SIGNAL_LIFECYCLE_LABELS.get(str(status), str(status))


def set_signal_lifecycle(
    db: dict[str, Any],
    signal_id: int | str,
    status: str,
    admin_id: int | str,
    *,
    profit_percent: float | None = None,
    rr: float | None = None,
    note: str = "",
    price: float | None = None,
    close_percent: float | None = None,
    source: str = "admin",
) -> dict[str, Any]:
    if status not in SIGNAL_LIFECYCLE_LABELS:
        raise ValueError("وضعیت سیگنال نامعتبر است")
    row = _find_signal(db, signal_id)
    previous = str(row.get("status") or "open")
    if previous in FINAL_SIGNAL_STATUSES:
        raise ValueError("نتیجه این سیگنال نهایی شده است؛ برای اصلاح ابتدا نتیجه را ری‌استارت کنید")
    target_index = int(status[2:]) if status.startswith("tp") and status[2:].isdigit() else 0
    highest_before = int(row.get("highest_target_hit", 0) or 0)
    if target_index and target_index <= highest_before:
        raise ValueError(f"TP{target_index} قبلاً برای این سیگنال ثبت شده است")
    duplicate_fields = {
        "entry_hit": "entry_hit_at",
        "breakeven": "breakeven_at",
    }
    marker = duplicate_fields.get(status)
    if marker and row.get(marker):
        raise ValueError("این وضعیت قبلاً برای سیگنال ثبت شده است")
    if previous == status and status != "partial_close":
        raise ValueError("این وضعیت قبلاً برای سیگنال ثبت شده است")
    effective_status = status
    if target_index and target_index > len(row.get("targets", [])):
        raise ValueError("شماره تارگت بیشتر از تعداد اهداف سیگنال است")
    if target_index and target_index >= len(row.get("targets", [])) > 0:
        effective_status = "target_complete"
    now = utc_iso()
    history = row.setdefault("lifecycle_history", [])
    history.append(
        {
            "from": previous,
            "to": effective_status,
            "event": status,
            "admin_id": str(admin_id),
            "at": now,
            "price": price,
            "profit_percent": profit_percent,
            "rr": rr,
            "note": str(note or "")[:1000],
            "source": source,
        }
    )
    row["lifecycle_history"] = history[-100:]
    row["status"] = effective_status
    row["updated_at"] = now
    row["last_status_admin_id"] = str(admin_id)
    row["last_status_source"] = source
    row["last_status_event"] = status
    if status == "entry_hit" and not row.get("entry_hit_at"):
        row["entry_hit_at"] = now
        row["entry_hit_price"] = price
        pending_fill = dict(row.pop("tracking_pending_fill", {}) or {})
        filled_entries = list(pending_fill.get("filled_entries") or row.get("entries") or [row.get("entry")])
        fill_percent = float(pending_fill.get("filled_percent", 100.0 if len(filled_entries) <= 1 else 0.0) or 0.0)
        average_fill = pending_fill.get("average_fill_price") or price
        update_execution(
            row,
            filled_percent=fill_percent,
            filled_entries=[str(item) for item in filled_entries if item is not None],
            average_fill_price=float(average_fill) if average_fill is not None else None,
        )
    if status.startswith("tp") and status[2:].isdigit():
        index = int(status[2:])
        row["highest_target_hit"] = max(index, int(row.get("highest_target_hit", 0) or 0))
        row[f"tp{index}_hit_at"] = now
        row[f"tp{index}_hit_price"] = price
        plan = [float(value) for value in row.get("partial_close_plan", [])]
        if plan:
            update_execution(row, closed_percent=sum(plan[:index]), last_price=price)
        if index >= int(row.get("breakeven_after_tp", 1) or 1) and not row.get("breakeven_at"):
            row.setdefault("breakeven_recommended_at", now)
        trailing = row.get("trailing_stop", {})
        if isinstance(trailing, dict) and index >= int(trailing.get("activate_after_tp", 1) or 1):
            trailing["active"] = bool(trailing.get("enabled"))
            trailing["last_price"] = price
    if status == "breakeven":
        row["breakeven_at"] = now
    if status == "partial_close":
        row["partial_close_at"] = now
        closes = row.setdefault("partial_closes", [])
        execution = row.setdefault("execution", {})
        already_closed = float(execution.get("closed_percent", 0.0) or 0.0)
        requested = float(close_percent if close_percent is not None else 0.0)
        close_percent = requested if 0 < requested <= 100 else min(25.0, 100.0 - already_closed)
        remaining = max(0.0, 100.0 - min(100.0, already_closed + close_percent))
        closes.append(
            {
                "price": price,
                "percent": round(close_percent, 4),
                "remaining_percent": round(remaining, 4),
                "admin_id": str(admin_id),
                "note": str(note or "")[:1000],
                "created_at": now,
            }
        )
        row["partial_closes"] = closes[-20:]
        update_execution(row, closed_percent=100.0 - remaining, last_price=price)
    if effective_status in FINAL_SIGNAL_STATUSES:
        row["result_at"] = now
        row["result_admin_id"] = str(admin_id)
    if profit_percent is not None:
        row["profit_percent"] = round(float(profit_percent), 4)
    if rr is not None:
        row["rr"] = round(float(rr), 4)
    if note:
        row["result_note"] = str(note)[:1000]
    try:
        from modules.admin_control_center import module_state
        from modules.smart_followup import create_followup

        if bool(module_state(db, "signals").get("smart_followup", True)) and status in {"entry_hit", "breakeven", "stop"} | {f"tp{i}" for i in range(1, 11)}:
            create_followup(db, row, status, actor_id=admin_id, message=note)
    except Exception:
        # Lifecycle updates must remain transactional even if optional follow-up
        # bookkeeping cannot be written.
        logger.exception("Could not create optional smart follow-up for signal %s", row.get("id"))
    record_outcome_event(db, row, actor_id=admin_id, event=f"lifecycle:{status}")
    return row


def set_signal_result_media(
    db: dict[str, Any],
    signal_id: int | str,
    admin_id: int | str,
    *,
    photo_file_id: str,
    photo_unique_id: str = "",
    width: int = 0,
    height: int = 0,
    caption: str = "",
    lifecycle_status: str = "",
    source: str = "admin_result_chart",
) -> dict[str, Any]:
    """Attach the evidence chart used to verify a terminal signal result."""
    clean_file_id = str(photo_file_id or "").strip()
    if not clean_file_id:
        raise ValueError("عکس نتیجه سیگنال الزامی است")
    row = (
        set_signal_lifecycle(db, signal_id, lifecycle_status, admin_id, note=caption, source=source)
        if lifecycle_status
        else _find_signal(db, signal_id)
    )
    if str(row.get("status") or "open") not in FINAL_SIGNAL_STATUSES:
        raise ValueError("عکس نتیجه فقط برای سیگنال نهایی قابل ثبت است")
    now = utc_iso()
    row["result_chart_photo_file_id"] = clean_file_id
    row["result_chart_photo_unique_id"] = str(photo_unique_id or "")[:300]
    row["result_chart_photo_width"] = max(0, int(width or 0))
    row["result_chart_photo_height"] = max(0, int(height or 0))
    row["result_chart_caption"] = str(caption or "")[:1500]
    row["result_chart_added_by"] = str(admin_id)
    row["result_chart_added_at"] = now
    row["updated_at"] = now
    record_outcome_event(db, row, actor_id=admin_id, event="result_media_attached")
    return row


def set_signal_result_media_deliveries(
    db: dict[str, Any], signal_id: int | str, deliveries: list[dict[str, Any]]
) -> dict[str, Any]:
    row = _find_signal(db, signal_id)
    row["result_chart_deliveries"] = [dict(item) for item in deliveries if isinstance(item, dict)][-10:]
    row["updated_at"] = utc_iso()
    return row


def set_signal_metrics(
    db: dict[str, Any],
    signal_id: int | str,
    admin_id: int | str,
    *,
    profit_percent: float,
    rr: float,
    max_favorable: float | None = None,
    max_adverse: float | None = None,
    note: str = "",
) -> dict[str, Any]:
    row = _find_signal(db, signal_id)
    row["profit_percent"] = round(float(profit_percent), 4)
    row["rr"] = round(float(rr), 4)
    row["max_favorable_percent"] = None if max_favorable is None else round(float(max_favorable), 4)
    row["max_adverse_percent"] = None if max_adverse is None else round(float(max_adverse), 4)
    row["result_note"] = str(note or "")[:1000]
    row["metrics_updated_at"] = utc_iso()
    row["metrics_admin_id"] = str(admin_id)
    record_outcome_event(db, row, actor_id=admin_id, event="metrics_updated")
    return row


def edit_signal(
    db: dict[str, Any],
    signal_id: int | str,
    admin_id: int | str,
    field: str,
    value: Any,
) -> dict[str, Any]:
    is_target_edit = str(field).startswith("target_") and str(field)[7:].isdigit()
    allowed = {"stop", "add_target", "note", "entry"}
    if field not in allowed and not is_target_edit:
        raise ValueError("فیلد ویرایش نامعتبر است")
    row = _find_signal(db, signal_id)
    if str(row.get("status") or "open") in FINAL_SIGNAL_STATUSES:
        raise ValueError("سیگنال نهایی‌شده را نمی‌توان ویرایش کرد")
    ensure_initial_version(row, actor_id=admin_id, reason="baseline")
    before_snapshot = dict(row.get("versions", [{}])[-1].get("snapshot") or {})

    old_value: Any
    if field == "note":
        old_value = row.get("update_note")
        new_value: Any = str(value).strip()[:1000]
        if not new_value:
            raise ValueError("متن بروزرسانی خالی است")
        row["update_note"] = new_value
    else:
        from modules.signal import normalize_signal_price, validate_signal_levels, validate_signal_targets

        entry = str(row.get("entry") or "")
        stop = str(row.get("stop") or "")
        targets = [str(item) for item in row.get("targets", [])]
        side = str(row.get("side") or "")
        clean = normalize_signal_price(str(value), "قیمت")
        if field == "add_target":
            old_value = list(targets)
            if clean in targets:
                raise ValueError("این هدف قبلاً ثبت شده است")
            if len(targets) >= 10:
                raise ValueError("حداکثر ۱۰ هدف مجاز است")
            proposed_targets = [*targets, clean]
            if stop == entry:
                validate_signal_targets(entry, proposed_targets, side)
            else:
                validate_signal_levels(entry, proposed_targets, stop, side)
            row["targets"] = proposed_targets
            new_value = list(proposed_targets)
        elif is_target_edit:
            target_index = int(str(field).split("_", 1)[1])
            if target_index < 1 or target_index > len(targets):
                raise ValueError("شماره تارگت نامعتبر است")
            old_value = targets[target_index - 1]
            proposed_targets = list(targets)
            proposed_targets[target_index - 1] = clean
            if len(set(proposed_targets)) != len(proposed_targets):
                raise ValueError("قیمت تارگت‌ها نباید تکراری باشد")
            if stop == entry:
                validate_signal_targets(entry, proposed_targets, side)
            else:
                validate_signal_levels(entry, proposed_targets, stop, side)
            row["targets"] = proposed_targets
            new_value = clean
        elif field == "entry":
            old_value = entry
            proposed_entry = clean
            if stop == proposed_entry:
                validate_signal_targets(proposed_entry, targets, side)
            else:
                validate_signal_levels(proposed_entry, targets, stop, side)
            row["entry"] = proposed_entry
            row["entries"] = [proposed_entry]
            row["entry_mode"] = "single"
            new_value = proposed_entry
        else:
            old_value = stop
            proposed_stop = clean
            if proposed_stop == entry:
                validate_signal_targets(entry, targets, side)
            else:
                validate_signal_levels(entry, targets, proposed_stop, side)
            row["stop"] = proposed_stop
            new_value = proposed_stop

    now = utc_iso()
    row.setdefault("edit_history", []).append(
        {
            "field": field,
            "old": old_value,
            "new": new_value,
            "admin_id": str(admin_id),
            "at": now,
        }
    )
    row["edit_history"] = row["edit_history"][-50:]
    row["updated_at"] = now
    row["last_edited_at"] = now
    row["last_edited_by"] = str(admin_id)
    field_times = row.setdefault("field_edit_times", {})
    timestamp_key = field
    if field == "add_target":
        timestamp_key = f"target_{len(row.get('targets', []))}"
    field_times[timestamp_key] = now
    enriched = enrich_signal_payload(row)
    row.clear()
    row.update(enriched)
    append_signal_version(
        row,
        actor_id=admin_id,
        reason=f"edit:{field}",
        before=before_snapshot,
        revision_store=db.setdefault("signal_revisions", []),
    )
    db.setdefault("signal_versions", {})[str(row.get("id"))] = list(row.get("versions") or [])
    return row


def delete_signal_permanently(
    db: dict[str, Any],
    signal_id: int | str,
    admin_id: int | str,
) -> dict[str, Any]:
    """Remove a signal and all user-facing references without reusing its ids."""
    target = int(signal_id)
    current = [row for row in db.get("signals", []) if isinstance(row, dict)]
    archived = [row for row in db.get("signal_archive", []) if isinstance(row, dict)]
    matches = [row for row in [*current, *archived] if int(row.get("id", 0) or 0) == target]
    if not matches:
        raise ValueError("سیگنال پیدا نشد")
    signal = dict(matches[-1])
    db["signals"] = [row for row in current if int(row.get("id", 0) or 0) != target]
    db["signal_archive"] = [row for row in archived if int(row.get("id", 0) or 0) != target]

    removed_choices = 0
    for rows in db.get("user_signal_choices", {}).values():
        if isinstance(rows, dict) and rows.pop(str(target), None) is not None:
            removed_choices += 1

    detached_schedules = 0
    for scheduled in db.get("scheduled_signals", []):
        if not isinstance(scheduled, dict) or int(scheduled.get("signal_id", 0) or 0) != target:
            continue
        scheduled["deleted_signal_id"] = target
        scheduled["signal_id"] = None
        scheduled["signal_deleted_at"] = utc_iso()
        scheduled["signal_deleted_by"] = str(admin_id)
        detached_schedules += 1

    db.setdefault("signal_versions", {}).pop(str(target), None)
    for section in ("signal_revisions", "signal_outcomes", "signal_events"):
        if isinstance(db.get(section), list):
            db[section] = [r for r in db[section] if not isinstance(r, dict) or str(r.get("signal_id")) != str(target)]
    db.setdefault("signal_deletion_audit", {})[str(target)] = {"deleted_by": str(admin_id), "deleted_at": utc_iso()}
    from modules.signal_portal import renumber_public_signals
    renumber_public_signals(db)

    return {
        "signal": signal,
        "removed_current": sum(1 for row in current if int(row.get("id", 0) or 0) == target),
        "removed_archive": sum(1 for row in archived if int(row.get("id", 0) or 0) == target),
        "removed_choices": removed_choices,
        "detached_schedules": detached_schedules,
    }


def analyst_performance(db: dict[str, Any]) -> list[dict[str, Any]]:
    from modules.analyst_dashboard import all_analyst_dashboards

    output: list[dict[str, Any]] = []
    for item in all_analyst_dashboards(db):
        symbols = item.get("symbols", {})
        output.append(
            {
                **item,
                "total": int(item.get("signals", 0) or 0),
                "closed": int(item.get("settled", 0) or 0),
                "stops": int(item.get("losses", 0) or 0),
                "cancelled": 0,
                "average_rr": float(item.get("expectancy_r", 0) or 0),
                "profit_sum": float(item.get("net_r", 0) or 0),
                "best_symbol": next(iter(symbols), "-"),
            }
        )
    return output


def tracking_candidates(db: dict[str, Any], prices: dict[str, Any]) -> list[dict[str, Any]]:
    """Detect lifecycle events using snapshots or OHLC ranges.

    Multiple entry levels are tracked independently. Fresh non-ambiguous OHLC data
    may be auto-published; snapshots, stale data, and candles crossing conflicting
    levels always require review.
    """
    proposals: list[dict[str, Any]] = []
    for row in db.get("signals", []):
        if not isinstance(row, dict) or row.get("status") in FINAL_SIGNAL_STATUSES:
            continue
        try:
            symbol = str(row.get("market_symbol") or "") or normalize_tracking_symbol(str(row.get("symbol") or ""))
        except ValueError:
            row["tracking_supported"] = False
            row["tracking_error"] = "unsupported_symbol"
            continue
        row["market_symbol"] = symbol
        row["tracking_supported"] = True
        raw_market = prices.get(symbol)
        if raw_market is None:
            continue
        is_mapping = isinstance(raw_market, dict)
        stale = False
        opened_at = None
        closed_at = None
        if is_mapping:
            try:
                low = float(raw_market.get("low"))
                high = float(raw_market.get("high"))
                current = float(raw_market.get("close", raw_market.get("price")))
            except (TypeError, ValueError):
                continue
            source = str(raw_market.get("source") or "range")
            interval = str(raw_market.get("interval") or "")
            stale = bool(raw_market.get("stale", False))
            opened_at = parse_dt(raw_market.get("opened_at"))
            closed_at = parse_dt(raw_market.get("closed_at") or raw_market.get("market_timestamp"))
        else:
            try:
                current = float(raw_market)
            except (TypeError, ValueError):
                continue
            low = high = current
            source = "snapshot"
            interval = "snapshot"
        is_snapshot = not is_mapping or interval.strip().lower() == "snapshot" or source.strip().lower().startswith("snapshot")
        signal_created = parse_dt(row.get("created_at"))
        last_processed = parse_dt(row.get("last_processed_market_timestamp"))
        if closed_at and signal_created and closed_at < signal_created:
            continue
        # Aggregated OHLC windows that begin before signal publication can
        # contain a pre-publication TP/SL touch.  Skip them until the provider
        # returns a fully post-publication window.
        if not is_snapshot and opened_at and signal_created and opened_at < signal_created:
            continue
        if closed_at and last_processed and closed_at <= last_processed:
            continue
        if low > high:
            low, high = high, low
        try:
            entries_text = normalize_entries(row.get("entries") or row.get("entry") or "")
            entries = [float(value) for value in entries_text]
            stop = float(row.get("stop"))
            targets = [float(value) for value in row.get("targets", [])]
        except (TypeError, ValueError):
            continue
        side = str(row.get("side") or "").lower()
        if side not in {"buy", "sell"}:
            continue

        if is_snapshot:
            touched = [
                entries_text[index] for index, level in enumerate(entries) if (current <= level if side == "buy" else current >= level)
            ]
        else:
            touched = [entries_text[index] for index, level in enumerate(entries) if low <= level <= high]
        execution = row.setdefault("execution", {})
        existing = [str(item) for item in execution.get("filled_entries", [])]
        merged = list(dict.fromkeys(existing + touched))
        if merged:
            filled_percent = len(merged) / max(1, len(entries_text)) * 100
            average_fill = sum(float(item) for item in merged) / len(merged)
            row["tracking_pending_fill"] = {
                "filled_entries": merged,
                "filled_percent": round(filled_percent, 4),
                "average_fill_price": average_fill,
            }
            # Unapproved observed OHLC cannot change public execution/position fills.
            # Keep the pending observation private until an explicit admin action.

        entered = bool(row.get("entry_hit_at"))
        event: str | None = None
        ambiguous = False
        secondary_events: list[str] = []
        if not entered and touched:
            event = "entry_hit"
            stop_hit = low <= stop if side == "buy" else high >= stop
            target_hits = [index for index, target in enumerate(targets, start=1) if (high >= target if side == "buy" else low <= target)]
            if stop_hit:
                secondary_events.append("stop")
            if target_hits:
                secondary_events.append(f"tp{max(target_hits)}")
            ambiguous = bool(secondary_events)
        elif entered:
            stop_hit = low <= stop if side == "buy" else high >= stop
            highest_done = int(row.get("highest_target_hit", 0) or 0)
            target_hits = [
                index
                for index, target in enumerate(targets, start=1)
                if index > highest_done and (high >= target if side == "buy" else low <= target)
            ]
            if stop_hit and target_hits:
                event = "stop"
                secondary_events.append(f"tp{max(target_hits)}")
                ambiguous = True
            elif stop_hit:
                event = "stop"
            elif target_hits:
                event = f"tp{max(target_hits)}"

        row["tracking_last_checked_at"] = utc_iso()
        if closed_at:
            row["last_processed_market_timestamp"] = utc_iso(closed_at)
        row["tracking_last_range"] = {"low": low, "high": high, "close": current, "source": source, "interval": interval}
        if event is None:
            continue
        proposal_key = f"{event}:{','.join(merged)}" if event == "entry_hit" else event
        if row.get("tracking_last_proposal") == proposal_key:
            continue
        row["tracking_last_proposal"] = proposal_key
        pending = dict(row.get("tracking_pending_fill", {}) or {})
        proposals.append(
            {
                "signal_id": int(row["id"]),
                "display_number": int(row.get("display_number", 0) or row["id"]),
                "symbol": symbol,
                "event": event,
                "price": current,
                "low": low,
                "high": high,
                "source": source,
                "interval": interval,
                "stale": stale,
                "snapshot": is_snapshot,
                "ambiguous": ambiguous,
                "auto_publish_safe": not ambiguous and not stale and not is_snapshot,
                "secondary_events": secondary_events,
                "filled_entries": pending.get("filled_entries", []),
                "filled_percent": pending.get("filled_percent", 0.0),
                "average_fill_price": pending.get("average_fill_price"),
            }
        )
    return proposals


def store_tracking_proposals(db: dict[str, Any], proposals: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Persist tracker recommendations so accept/reject decisions are auditable."""
    rows = db.setdefault("signal_tracking_proposals", [])
    stored: list[dict[str, Any]] = []
    for proposal in proposals:
        signal_id = int(proposal.get("signal_id", 0) or 0)
        event = str(proposal.get("event") or "")
        key = f"{signal_id}:{event}:{proposal.get('price')}:{proposal.get('low')}:{proposal.get('high')}"
        existing = next(
            (item for item in reversed(rows) if isinstance(item, dict) and item.get("proposal_key") == key),
            None,
        )
        if existing is None:
            existing = {
                **dict(proposal),
                "proposal_key": key,
                "status": "pending",
                "created_at": utc_iso(),
                "resolved_at": None,
                "resolved_by": None,
                "resolution_note": "",
            }
            rows.append(existing)
        stored.append(existing)
    db["signal_tracking_proposals"] = rows[-5000:]
    return stored


def resolve_tracking_proposal(
    db: dict[str, Any],
    signal_id: int | str,
    event: str,
    *,
    status: str,
    admin_id: int | str,
    note: str = "",
) -> dict[str, Any]:
    if status not in {"accepted", "rejected", "expired", "superseded"}:
        raise ValueError("وضعیت پیشنهاد معتبر نیست")
    sid = int(signal_id)
    match = next(
        (
            row
            for row in reversed(db.get("signal_tracking_proposals", []))
            if isinstance(row, dict)
            and int(row.get("signal_id", 0) or 0) == sid
            and str(row.get("event") or "") == str(event)
            and row.get("status") == "pending"
        ),
        None,
    )
    if match is None:
        # Preserve the audit trail even for proposals created by older releases.
        match = {
            "signal_id": sid,
            "event": str(event),
            "proposal_key": f"legacy:{sid}:{event}:{utc_iso()}",
            "created_at": utc_iso(),
        }
        db.setdefault("signal_tracking_proposals", []).append(match)
    match.update(
        {
            "status": status,
            "resolved_at": utc_iso(),
            "resolved_by": str(admin_id),
            "resolution_note": str(note or "")[:1000],
        }
    )
    return match


def ensure_crm_profile(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    uid = str(user_id)
    profile = db.setdefault("crm_profiles", {}).setdefault(
        uid,
        {
            "tags": [],
            "notes": [],
            "status": "normal",
            "assigned_admin": "",
            "follow_up_at": None,
            "custom_fields": {},
            "follow_up_history": [],
            "created_at": utc_iso(),
            "updated_at": utc_iso(),
        },
    )
    return profile


def add_crm_note(db: dict[str, Any], user_id: int | str, admin_id: int | str, text: str) -> dict[str, Any]:
    value = str(text or "").strip()
    if not value:
        raise ValueError("یادداشت خالی است")
    profile = ensure_crm_profile(db, user_id)
    note = {"text": value[:2000], "admin_id": str(admin_id), "created_at": utc_iso()}
    profile.setdefault("notes", []).append(note)
    profile["notes"] = profile["notes"][-100:]
    profile["updated_at"] = utc_iso()
    from modules.crm_automation import record_crm_activity

    record_crm_activity(db, user_id, "note", actor_id=admin_id, detail=value)
    return note


def toggle_crm_tag(db: dict[str, Any], user_id: int | str, tag: str) -> dict[str, Any]:
    value = str(tag or "").strip()[:60]
    if not value:
        raise ValueError("برچسب خالی است")
    profile = ensure_crm_profile(db, user_id)
    tags = list(profile.get("tags", []))
    removed = value in tags
    if removed:
        tags.remove(value)
    else:
        if len(tags) >= 20:
            raise ValueError("حداکثر ۲۰ برچسب مجاز است")
        tags.append(value)
    profile["tags"] = tags
    profile["updated_at"] = utc_iso()
    from modules.crm_automation import record_crm_activity

    record_crm_activity(db, user_id, "tag_removed" if removed else "tag_added", detail=value)
    return profile


def set_crm_follow_up(
    db: dict[str, Any],
    user_id: int | str,
    admin_id: int | str,
    value: str | datetime | None,
    *,
    note: str = "",
    priority: str = "normal",
    follow_up_type: str = "call",
    repeat: str = "none",
) -> dict[str, Any]:
    profile = ensure_crm_profile(db, user_id)
    if priority not in {"low", "normal", "high", "urgent"}:
        raise ValueError("اولویت پیگیری نامعتبر است")
    if follow_up_type not in {"call", "message", "payment", "renewal", "support", "other"}:
        raise ValueError("نوع پیگیری نامعتبر است")
    if repeat not in {"none", "daily", "weekly", "monthly"}:
        raise ValueError("تکرار پیگیری نامعتبر است")
    if value:
        parsed = value.astimezone(UTC) if isinstance(value, datetime) else parse_dt(value)
        if parsed is None:
            raise ValueError("زمان پیگیری نامعتبر است")
        profile["follow_up_at"] = utc_iso(parsed)
        profile["follow_up_notified_at"] = None
        profile["follow_up_note"] = str(note or "")[:1000]
        profile["follow_up_priority"] = priority
        profile["follow_up_type"] = follow_up_type
        profile["follow_up_repeat"] = repeat
        profile["follow_up_status"] = "scheduled"
    else:
        if profile.get("follow_up_at"):
            profile.setdefault("follow_up_history", []).append(
                {
                    "scheduled_at": profile.get("follow_up_at"),
                    "note": profile.get("follow_up_note", ""),
                    "status": "completed",
                    "completed_at": utc_iso(),
                    "admin_id": str(admin_id),
                }
            )
            profile["follow_up_history"] = profile["follow_up_history"][-100:]
        profile["follow_up_at"] = None
        profile["follow_up_notified_at"] = None
        profile["follow_up_status"] = "completed"
    profile["assigned_admin"] = str(admin_id)
    profile["updated_at"] = utc_iso()
    from modules.crm_automation import record_crm_activity

    record_crm_activity(
        db,
        user_id,
        "followup_scheduled" if value else "followup_completed",
        actor_id=admin_id,
        detail=str(note or profile.get("follow_up_note") or ""),
        metadata={"priority": priority, "type": follow_up_type, "repeat": repeat, "at": profile.get("follow_up_at")},
    )
    return profile


def snooze_crm_follow_up(db: dict[str, Any], user_id: int | str, admin_id: int | str, *, minutes: int) -> dict[str, Any]:
    profile = ensure_crm_profile(db, user_id)
    delay = max(5, min(int(minutes), 60 * 24 * 30))
    profile["follow_up_at"] = utc_iso(utc_now() + timedelta(minutes=delay))
    profile["follow_up_notified_at"] = None
    profile["follow_up_status"] = "scheduled"
    profile["assigned_admin"] = str(admin_id)
    profile["updated_at"] = utc_iso()
    from modules.crm_automation import record_crm_activity

    record_crm_activity(db, user_id, "followup_snoozed", actor_id=admin_id, detail=f"{delay} دقیقه")
    return profile


def complete_crm_follow_up(db: dict[str, Any], user_id: int | str, admin_id: int | str, *, outcome: str = "completed") -> dict[str, Any]:
    profile = ensure_crm_profile(db, user_id)
    repeat = str(profile.get("follow_up_repeat") or "none")
    scheduled_at = parse_dt(profile.get("follow_up_at")) or utc_now()
    profile.setdefault("follow_up_history", []).append(
        {
            "scheduled_at": profile.get("follow_up_at"),
            "note": profile.get("follow_up_note", ""),
            "priority": profile.get("follow_up_priority", "normal"),
            "type": profile.get("follow_up_type", "call"),
            "status": str(outcome or "completed")[:40],
            "completed_at": utc_iso(),
            "admin_id": str(admin_id),
        }
    )
    profile["follow_up_history"] = profile["follow_up_history"][-100:]
    if repeat == "daily":
        next_at = scheduled_at + timedelta(days=1)
    elif repeat == "weekly":
        next_at = scheduled_at + timedelta(days=7)
    elif repeat == "monthly":
        next_at = scheduled_at + timedelta(days=30)
    else:
        next_at = None
    profile["follow_up_at"] = utc_iso(next_at) if next_at else None
    profile["follow_up_notified_at"] = None
    profile["follow_up_status"] = "scheduled" if next_at else "completed"
    profile["assigned_admin"] = str(admin_id)
    profile["updated_at"] = utc_iso()
    from modules.crm_automation import record_crm_activity

    record_crm_activity(db, user_id, "followup_completed", actor_id=admin_id, detail=str(outcome or "completed"))
    return profile


def crm_summary(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    uid = str(user_id)
    profile = ensure_crm_profile(db, uid)
    try:
        from modules.crm_engine import refresh_crm_profile

        automation_profile = refresh_crm_profile(db, uid)
    except Exception:
        automation_profile = {"lead_score": 0, "stage": "lead", "stage_label": "سرنخ"}
    try:
        from modules.user_intelligence import build_user_profile

        intelligence = build_user_profile(db, uid)
    except Exception:
        intelligence = {"segments": [], "segment_labels": [], "primary_category": "", "primary_category_label": ""}
    orders = [row for row in db.get("vip_orders", []) if str(row.get("user_id")) == uid]
    approved = [row for row in orders if row.get("status") == "approved"]
    education_orders = [row for row in db.get("education_orders", []) if str(row.get("user_id")) == uid]
    paid_edu = [row for row in education_orders if row.get("status") == "approved"]
    tickets = [row for row in db.get("tickets", []) if str(row.get("user_id")) == uid]
    rewards = [row for row in db.get("user_rewards", []) if str(row.get("user_id")) == uid]
    referral = db.get("user_referrals", {}).get(uid, {})
    return {
        "profile": profile,
        "vip_orders": len(orders),
        "vip_approved": len(approved),
        "vip_spend": sum(int(row.get("price", 0) or 0) for row in approved),
        "education_orders": len(education_orders),
        "education_spend": sum(int(row.get("price", 0) or 0) for row in paid_edu),
        "tickets": len(tickets),
        "open_tickets": sum(1 for row in tickets if row.get("status") == "open"),
        "rewards": len(rewards),
        "referrals": len(referral.get("invited", [])) if isinstance(referral, dict) else 0,
        "last_order_at": max((str(row.get("created_at") or "") for row in orders + education_orders), default=""),
        "segments": list(intelligence.get("segments", [])),
        "segment_labels": list(intelligence.get("segment_labels", [])),
        "primary_category": str(intelligence.get("primary_category") or ""),
        "primary_category_label": str(intelligence.get("primary_category_label") or ""),
        "lead_score": int(automation_profile.get("lead_score", 0) or 0),
        "stage": str(automation_profile.get("stage") or "lead"),
        "stage_label": str(automation_profile.get("stage_label") or "سرنخ"),
        "behavior_persona": str(
            automation_profile.get("behavior_persona")
            or intelligence.get("behavior_persona")
            or "explorer"
        ),
        "engagement_score": int(
            automation_profile.get("engagement_score")
            or intelligence.get("engagement_score")
            or 0
        ),
        "purchase_intent_score": int(
            automation_profile.get("purchase_intent_score")
            or intelligence.get("purchase_intent_score")
            or 0
        ),
        "churn_risk_score": int(
            automation_profile.get("churn_risk_score")
            or intelligence.get("churn_risk_score")
            or 0
        ),
        "recency_days": int(
            automation_profile["recency_days"]
            if automation_profile.get("recency_days") is not None
            else intelligence.get("recency_days", 999)
        ),
    }


def automation_settings(db: dict[str, Any]) -> dict[str, Any]:
    settings = db.setdefault("automation_settings", {})
    for key, value in AUTOMATION_DEFAULTS.items():
        settings.setdefault(key, value.copy() if isinstance(value, list) else value)
    return settings


def update_automation_setting(db: dict[str, Any], key: str, value: Any) -> dict[str, Any]:
    settings = automation_settings(db)
    if key not in AUTOMATION_DEFAULTS:
        raise ValueError("تنظیم اتوماسیون نامعتبر است")
    if key.endswith("_enabled") or key == "enabled":
        settings[key] = bool(value)
    elif key == "vip_reminder_days":
        days = sorted({max(0, min(90, int(x))) for x in value}, reverse=True)
        if not days:
            raise ValueError("حداقل یک روز یادآوری لازم است")
        settings[key] = days
    elif key == "crm_timezone":
        clean = str(value or "").strip()
        if clean not in {"Asia/Tehran", "UTC"}:
            raise ValueError("منطقه زمانی اتوماسیون معتبر نیست")
        settings[key] = clean
    else:
        number = int(value)
        if "percent" in key and not 0 <= number <= 100:
            raise ValueError("درصد باید بین صفر تا صد باشد")
        if number < 0:
            raise ValueError("مقدار منفی مجاز نیست")
        if key in {"crm_quiet_start_hour", "crm_quiet_end_hour"} and number > 23:
            raise ValueError("ساعت باید بین ۰ تا ۲۳ باشد")
        if key == "crm_daily_contact_cap" and not 1 <= number <= 20:
            raise ValueError("سقف تماس روزانه باید بین ۱ تا ۲۰ باشد")
        if key == "crm_max_batch" and not 1 <= number <= 1000:
            raise ValueError("اندازه بچ CRM باید بین ۱ تا ۱۰۰۰ باشد")
        if key == "crm_max_attempts" and not 1 <= number <= 10:
            raise ValueError("تعداد تلاش باید بین ۱ تا ۱۰ باشد")
        if key == "crm_retry_base_minutes" and not 1 <= number <= 240:
            raise ValueError("فاصله Retry باید بین ۱ تا ۲۴۰ دقیقه باشد")
        if key == "campaign_scheduler_batch" and not 1 <= number <= 50:
            raise ValueError("بچ کمپین باید بین ۱ تا ۵۰ باشد")
        settings[key] = number
    settings["updated_at"] = utc_iso()
    return settings


def renewal_events(db: dict[str, Any]) -> list[dict[str, Any]]:
    settings = automation_settings(db)
    if not settings.get("enabled") or not settings.get("vip_reminders_enabled"):
        return []
    now = utc_now()
    days_set = {int(x) for x in settings.get("vip_reminder_days", [])}
    events: list[dict[str, Any]] = []
    for uid, vip in db.get("vip_users", {}).items():
        if not isinstance(vip, dict):
            continue
        expiry = parse_dt(vip.get("expires_at"))
        if expiry is None:
            continue
        days_left = (expiry.date() - now.date()).days
        if days_left not in days_set:
            continue
        sent = vip.setdefault("renewal_reminders", {})
        key = f"{expiry.date().isoformat()}:{days_left}"
        previous = sent.get(key, {})
        if isinstance(previous, dict):
            status = previous.get("status")
            if status == "sent":
                continue
            created_at = parse_dt(previous.get("created_at"))
            if status == "pending" and created_at is not None and now - created_at < timedelta(minutes=30):
                continue
        sent[key] = {
            "status": "pending",
            "created_at": utc_iso(),
            "code": str(previous.get("code") or "") if isinstance(previous, dict) else "",
        }
        events.append(
            {
                "user_id": int(uid),
                "days_left": days_left,
                "expiry": utc_iso(expiry),
                "key": key,
                "code": str(previous.get("code") or "") if isinstance(previous, dict) else "",
            }
        )
    return events


def mark_renewal_event(db: dict[str, Any], user_id: int | str, key: str, *, success: bool, code: str = "", error: str = "") -> None:
    vip = db.get("vip_users", {}).get(str(user_id), {})
    record = vip.setdefault("renewal_reminders", {}).setdefault(key, {})
    record.update({"status": "sent" if success else "failed", "sent_at": utc_iso(), "code": code, "error": error[:300]})


def inactive_automation_events(db: dict[str, Any]) -> list[dict[str, Any]]:
    settings = automation_settings(db)
    if not settings.get("enabled") or not settings.get("inactive_enabled"):
        return []
    threshold = int(settings.get("inactive_days", 30) or 30)
    now = utc_now()
    events = []
    log = db.setdefault("automation_log", {})
    for uid, user in db.get("users", {}).items():
        if not isinstance(user, dict):
            continue
        last_seen = parse_dt(user.get("last_seen_at") or user.get("created_at"))
        if last_seen is None or (now - last_seen).days < threshold:
            continue
        key = f"inactive:{uid}:{now.date().isoformat()}"
        if log.get(key):
            continue
        log[key] = {"status": "pending", "created_at": utc_iso()}
        events.append({"user_id": int(uid), "key": key, "inactive_days": (now - last_seen).days})
    return events


def mark_automation_log(db: dict[str, Any], key: str, *, success: bool, detail: str = "") -> None:
    db.setdefault("automation_log", {}).setdefault(key, {}).update(
        {"status": "sent" if success else "failed", "updated_at": utc_iso(), "detail": detail[:500]}
    )


def issue_custom_discount(
    db: dict[str, Any],
    user_id: int | str,
    percent: int,
    *,
    expires_days: int,
    source: str,
) -> dict[str, Any]:
    value = int(percent)
    if not 1 <= value <= 100:
        raise ValueError("درصد تخفیف باید بین ۱ تا ۱۰۰ باشد")
    uid = str(user_id)
    if not uid.isdigit() or int(uid) <= 0:
        raise ValueError("شناسه کاربر نامعتبر است")
    codes = db.setdefault("discount_codes", {})
    for attempt in range(10):
        code = f"VRX{value}{secrets.token_hex(8).upper()}"
        if code not in codes:
            break
    else:
        raise ValueError('ساخت کد یکتا ممکن نشد؛ دوباره تلاش کنید.')
    item = {
        "code": code,
        "percent": value,
        "status": "active",
        "assigned_to": uid,
        "expires_at": utc_iso(utc_now() + timedelta(days=max(1, int(expires_days)))),
        "reserved_order_id": None,
        "created_at": utc_iso(),
        "used_at": None,
        "used_by": "",
        "source": source,
        "pool": False,
        "assigned_at": utc_iso(),
        "issued_via": source,
    }
    codes[code] = item
    db.setdefault("discount_history", []).append(
        {
            "action": "issued_custom",
            "code": code,
            "percent": value,
            "user_id": uid,
            "issued_via": source,
            "created_at": utc_iso(),
        }
    )
    db["discount_history"] = db["discount_history"][-2000:]
    return item


def approval_settings(db: dict[str, Any]) -> dict[str, Any]:
    settings = db.setdefault("approval_settings", {})
    for key, value in APPROVAL_DEFAULTS.items():
        settings.setdefault(key, value.copy() if isinstance(value, list) else value)
    return settings


def operation_requires_approval(db: dict[str, Any], operation: str) -> bool:
    settings = approval_settings(db)
    return bool(settings.get("enabled")) and operation in set(settings.get("operations") or [])


def create_pending_approval(
    db: dict[str, Any],
    operation: str,
    payload: dict[str, Any],
    requested_by: int | str,
    *,
    description: str,
) -> dict[str, Any]:
    settings = approval_settings(db)
    token = secrets.token_urlsafe(8).replace("-", "").replace("_", "")[:12]
    expires_at = utc_now() + timedelta(minutes=int(settings.get("expires_minutes", 30) or 30))
    row = {
        "id": next_id(db, "admin_approval"),
        "token": token,
        "operation": operation,
        "payload": payload,
        "description": str(description)[:1000],
        "requested_by": str(requested_by),
        "status": "pending",
        "created_at": utc_iso(),
        "expires_at": utc_iso(expires_at),
        "approved_by": None,
        "approved_at": None,
        "executed_at": None,
    }
    db.setdefault("pending_admin_actions", []).append(row)
    db["pending_admin_actions"] = db["pending_admin_actions"][-500:]
    return row


def resolve_pending_approval(db: dict[str, Any], token: str, admin_id: int | str, approve: bool) -> dict[str, Any]:
    if not is_primary_admin(admin_id):
        raise PermissionError("تأیید مرحلهٔ دوم فقط در اختیار ادمین اصلی است.")
    for row in reversed(db.get("pending_admin_actions", [])):
        if not isinstance(row, dict) or row.get("token") != token:
            continue
        if row.get("status") != "pending":
            raise ValueError("این درخواست قبلاً تعیین تکلیف شده است")
        if approve and str(row.get("requested_by")) == str(admin_id):
            raise ValueError("درخواست‌کننده نمی‌تواند تأییدکننده همان عملیات باشد")
        expiry = parse_dt(row.get("expires_at"))
        if expiry is not None and expiry <= utc_now():
            row["status"] = "expired"
            raise ValueError("مهلت تأیید این عملیات تمام شده است")
        row["status"] = "approved" if approve else "rejected"
        row["approved_by"] = str(admin_id)
        row["approved_at"] = utc_iso()
        return row
    raise ValueError("درخواست تأیید پیدا نشد")


def pending_approvals(db: dict[str, Any]) -> list[dict[str, Any]]:
    rows = []
    for row in db.get("pending_admin_actions", []):
        if not isinstance(row, dict) or row.get("status") != "pending":
            continue
        expiry = parse_dt(row.get("expires_at"))
        if expiry is not None and expiry <= utc_now():
            row["status"] = "expired"
            continue
        rows.append(row)
    rows.sort(key=lambda item: int(item.get("id", 0)), reverse=True)
    return rows


def set_admin_shift(
    db: dict[str, Any],
    admin_id: int | str,
    days: list[int],
    start: str,
    end: str,
    timezone: str,
    changed_by: int | str,
) -> dict[str, Any]:
    day_values = sorted({int(day) for day in days})
    if not day_values or any(day < 0 or day > 6 for day in day_values):
        raise ValueError("روزهای شیفت نامعتبر است")
    for value in (start, end):
        parts = value.split(":")
        if len(parts) != 2 or not all(part.isdigit() for part in parts):
            raise ValueError("ساعت باید به شکل HH:MM باشد")
        hour, minute = map(int, parts)
        if not 0 <= hour <= 23 or not 0 <= minute <= 59:
            raise ValueError("ساعت نامعتبر است")
    row = {
        "admin_id": str(admin_id),
        "days": day_values,
        "start": start,
        "end": end,
        "timezone": timezone,
        "enabled": True,
        "changed_by": str(changed_by),
        "updated_at": utc_iso(),
    }
    db.setdefault("admin_shifts", {})[str(admin_id)] = row
    return row


def toggle_admin_shift(db: dict[str, Any], admin_id: int | str) -> dict[str, Any]:
    row = db.setdefault("admin_shifts", {}).get(str(admin_id))
    if not isinstance(row, dict):
        raise ValueError("برای این ادمین هنوز شیفتی ثبت نشده است")
    row["enabled"] = not bool(row.get("enabled", True))
    row["updated_at"] = utc_iso()
    return row


def is_admin_on_shift(db: dict[str, Any], admin_id: int | str, *, now=None) -> bool:
    row = db.get("admin_shifts", {}).get(str(admin_id))
    if not isinstance(row, dict) or not row.get("enabled", True):
        return True
    from zoneinfo import ZoneInfo

    current = now or utc_now()
    try:
        local = current.astimezone(ZoneInfo(str(row.get("timezone") or "UTC")))
    except Exception:
        local = current
    days = {int(day) for day in row.get("days", [])}
    start_h, start_m = map(int, str(row.get("start", "00:00")).split(":"))
    end_h, end_m = map(int, str(row.get("end", "23:59")).split(":"))
    minute = local.hour * 60 + local.minute
    start_min = start_h * 60 + start_m
    end_min = end_h * 60 + end_m
    if start_min <= end_min:
        return local.weekday() in days and start_min <= minute <= end_min
    if minute >= start_min:
        return local.weekday() in days
    return minute <= end_min and (local.weekday() - 1) % 7 in days


def create_backup(db: dict[str, Any], backup_dir: Path, *, label: str = "manual") -> Path:
    backup_dir.mkdir(parents=True, exist_ok=True)
    stamp = utc_now().strftime("%Y%m%d-%H%M%S-%f")
    safe_label = "".join(ch for ch in label.lower() if ch.isalnum() or ch in {"-", "_"})[:30] or "manual"
    target = backup_dir / f"database-{stamp}-{safe_label}.json"
    payload = validate_database_payload(db)
    target.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")
    return target


def list_backups(backup_dir: Path, limit: int = 20) -> list[Path]:
    if not backup_dir.exists():
        return []
    return sorted(backup_dir.glob("database-*.json"), key=lambda path: path.stat().st_mtime, reverse=True)[:limit]


def load_backup(path: Path, backup_dir: Path) -> dict[str, Any]:
    resolved = path.resolve()
    root = backup_dir.resolve()
    if root not in resolved.parents or not resolved.is_file() or resolved.suffix.lower() != ".json":
        raise ValueError("فایل بکاپ معتبر نیست")
    raw = json.loads(resolved.read_text(encoding="utf-8"))
    return validate_database_payload(raw)


def copy_database_backup(source: Path, backup_dir: Path, label: str = "file") -> Path:
    backup_dir.mkdir(parents=True, exist_ok=True)
    target = backup_dir / f"database-{utc_now().strftime('%Y%m%d-%H%M%S')}-{label}.json"
    shutil.copy2(source, target)
    return target


def create_education_order(
    db: dict[str, Any],
    user_id: int | str,
    lesson_id: int | str,
    receipt_file_id: str,
) -> dict[str, Any]:
    lesson = next((item for item in db.get("lessons", []) if int(item.get("id", 0) or 0) == int(lesson_id)), None)
    if not lesson:
        raise ValueError("آموزش پیدا نشد")
    if str(lesson.get("access_type") or ("paid" if lesson.get("paid") else "free")) != "paid":
        raise ValueError("این آموزش رایگان است")
    price = int(lesson.get("price", 0) or 0)
    if price <= 0:
        raise ValueError("قیمت آموزش تنظیم نشده است")
    uid = str(user_id)
    if str(lesson_id) in db.get("education_access", {}).get(uid, {}):
        raise ValueError("دسترسی این آموزش قبلاً برای شما فعال شده است")
    existing = next(
        (
            row
            for row in reversed(db.get("education_orders", []))
            if str(row.get("user_id")) == uid and int(row.get("lesson_id", 0) or 0) == int(lesson_id) and row.get("status") == "pending"
        ),
        None,
    )
    if existing:
        raise ValueError("برای این آموزش یک پرداخت در انتظار بررسی دارید")
    row = {
        "order_id": f"EDU-{next_id(db, 'education_order'):06d}",
        "user_id": int(uid),
        "lesson_id": int(lesson_id),
        "lesson_title": str(lesson.get("title") or "")[:150],
        "price": price,
        "receipt_file_id": receipt_file_id,
        "status": "pending",
        "created_at": utc_iso(),
        "reviewed_at": None,
        "reviewed_by": None,
    }
    db.setdefault("education_orders", []).append(row)
    db["education_orders"] = db["education_orders"][-3000:]
    from modules.user_intelligence import record_user_activity, refresh_user_profile

    record_user_activity(
        db,
        uid,
        "education_order_created",
        source="education",
        detail=row["order_id"],
        metadata={"lesson_id": row["lesson_id"], "price": row["price"]},
    )
    refresh_user_profile(db, uid)
    return row


def find_education_order(db: dict[str, Any], order_id: str) -> dict[str, Any] | None:
    return next((row for row in db.get("education_orders", []) if row.get("order_id") == order_id), None)


def approve_education_order(db: dict[str, Any], order_id: str, admin_id: int | str, approve: bool) -> dict[str, Any]:
    row = find_education_order(db, order_id)
    if row is None:
        raise ValueError("سفارش آموزش پیدا نشد")
    if row.get("status") != "pending":
        raise ValueError("این سفارش قبلاً بررسی شده است")
    row["status"] = "approved" if approve else "rejected"
    row["reviewed_at"] = utc_iso()
    row["reviewed_by"] = str(admin_id)
    uid = str(row["user_id"])
    if approve:
        lesson_id = str(row["lesson_id"])
        db.setdefault("education_access", {}).setdefault(uid, {})[lesson_id] = {
            "order_id": order_id,
            "granted_at": utc_iso(),
            "granted_by": str(admin_id),
        }
    from modules.user_intelligence import record_user_activity, refresh_user_profile

    record_user_activity(
        db,
        uid,
        "education_order_approved" if approve else "education_order_rejected",
        source="education",
        detail=order_id,
        metadata={"lesson_id": row.get("lesson_id"), "price": int(row.get("price", 0) or 0)},
    )
    refresh_user_profile(db, uid)
    return row


def has_education_access(db: dict[str, Any], user_id: int | str, lesson: dict[str, Any]) -> bool:
    access_type = str(lesson.get("access_type") or ("paid" if lesson.get("paid") else "free"))
    if access_type == "free":
        return True
    return str(lesson.get("id")) in db.get("education_access", {}).get(str(user_id), {})
