from __future__ import annotations

import html
import logging
import math
import re
import time
from datetime import UTC, date, datetime, timedelta, tzinfo
from typing import Any
from zoneinfo import ZoneInfo

from config import SETTINGS
from core.async_primitives import LoopLocalLock
from core.http_client import get_json
from core.utils import parse_dt, utc_iso

logger = logging.getLogger(__name__)

PRIMARY_URL = "https://nfs.faireconomy.media/ff_calendar_thisweek.json"
FALLBACK_URL = "https://cdn-nfs.faireconomy.media/ff_calendar_thisweek.json"
_CACHE_SECONDS = 1800
_CACHE: tuple[float, list[dict[str, Any]]] | None = None
_FETCH_LOCK = LoopLocalLock()

_IMPACT_ORDER = {"high": 3, "medium": 2, "low": 1, "holiday": 0, "non-economic": 0, "": 0}
_CURRENCY_FLAGS = {
    "USD": "🇺🇸",
    "EUR": "🇪🇺",
    "GBP": "🇬🇧",
    "JPY": "🇯🇵",
    "CAD": "🇨🇦",
    "AUD": "🇦🇺",
    "NZD": "🇳🇿",
    "CHF": "🇨🇭",
    "CNY": "🇨🇳",
}
_PERSIAN_ALIASES = {
    "Non-Farm Employment Change": "اشتغال غیرکشاورزی آمریکا (NFP)",
    "Unemployment Rate": "نرخ بیکاری",
    "CPI m/m": "تورم مصرف‌کننده ماهانه",
    "CPI y/y": "تورم مصرف‌کننده سالانه",
    "Core CPI m/m": "تورم هسته ماهانه",
    "Core PCE Price Index m/m": "تورم هسته PCE",
    "Federal Funds Rate": "تصمیم نرخ بهره فدرال رزرو",
    "FOMC Press Conference": "کنفرانس خبری فدرال رزرو",
    "ECB Press Conference": "کنفرانس خبری بانک مرکزی اروپا",
    "Main Refinancing Rate": "تصمیم نرخ بهره بانک مرکزی اروپا",
    "Advance GDP q/q": "رشد اقتصادی آمریکا",
    "Retail Sales m/m": "خرده‌فروشی ماهانه",
    "ISM Manufacturing PMI": "شاخص مدیران خرید تولید آمریکا",
    "ISM Services PMI": "شاخص مدیران خرید خدمات آمریکا",
}
_HIGH_VALUE_TERMS = (
    "non-farm",
    "nonfarm",
    "payroll",
    "unemployment",
    "cpi",
    "pce",
    "fomc",
    "federal funds",
    "fed chair",
    "ecb",
    "refinancing rate",
    "gdp",
    "retail sales",
    "ism manufacturing",
    "ism services",
    "jolts",
    "adp",
    "employment change",
    "rate statement",
    "press conference",
)


def _clean(value: Any, limit: int = 300) -> str:
    return re.sub(r"\s+", " ", str(value or "")).strip()[:limit]


def _float(value: Any) -> float | None:
    text = _clean(value, 80).replace(",", "").replace("%", "")
    if not text or text in {"-", "—", "n/a", "N/A"}:
        return None
    match = re.search(r"[-+]?\d+(?:\.\d+)?", text)
    if not match:
        return None
    try:
        number = float(match.group(0))
    except ValueError:
        return None
    return number if math.isfinite(number) else None


def _parse_event_datetime(value: Any) -> datetime | None:
    raw = _clean(value, 80)
    if not raw:
        return None
    parsed = parse_dt(raw)
    if parsed is not None:
        return parsed
    # Some calendar exports may omit a colon in the UTC offset.
    fixed = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", raw)
    try:
        parsed = datetime.fromisoformat(fixed.replace("Z", "+00:00"))
    except ValueError:
        return None
    if parsed.tzinfo is None:
        parsed = parsed.replace(tzinfo=UTC)
    return parsed.astimezone(UTC)


def _normalize_impact(value: Any) -> str:
    text = _clean(value, 30).casefold()
    if "high" in text:
        return "high"
    if "medium" in text or "med" == text:
        return "medium"
    if "low" in text:
        return "low"
    if "holiday" in text:
        return "holiday"
    return text or "unknown"


def _event_id(country: str, title: str, when: datetime | None) -> str:
    stamp = when.astimezone(UTC).strftime("%Y%m%d%H%M") if when else "unknown"
    slug = re.sub(r"[^a-z0-9]+", "-", title.casefold()).strip("-")[:42] or "event"
    return f"{country}-{stamp}-{slug}"


def normalize_event(item: dict[str, Any]) -> dict[str, Any] | None:
    title = _clean(item.get("title") or item.get("event") or item.get("name"), 220)
    currency = _clean(item.get("country") or item.get("currency"), 10).upper()
    when = _parse_event_datetime(item.get("date") or item.get("datetime") or item.get("timestamp"))
    if not title or not currency or when is None:
        return None
    impact = _normalize_impact(item.get("impact"))
    actual = _clean(item.get("actual"), 60)
    forecast = _clean(item.get("forecast"), 60)
    previous = _clean(item.get("previous"), 60)
    return {
        "id": _event_id(currency, title, when),
        "title": title,
        "title_fa": _PERSIAN_ALIASES.get(title, title),
        "currency": currency,
        "datetime": when.isoformat(),
        "impact": impact,
        "actual": actual,
        "forecast": forecast,
        "previous": previous,
        "source": "Forex Factory weekly export",
        "fetched_at": utc_iso(),
    }


async def _fetch_url(url: str) -> list[dict[str, Any]]:
    headers = {
        "Accept": "application/json,text/plain,*/*",
        "User-Agent": "SENTINELBot/5.2 (+economic-calendar)",
    }
    payload = await get_json(
        url,
        headers=headers,
        timeout_seconds=max(8, SETTINGS.request_timeout_seconds),
        retries=2,
    )
    if not isinstance(payload, list):
        raise RuntimeError("پاسخ تقویم اقتصادی معتبر نیست")
    rows: list[dict[str, Any]] = []
    for item in payload:
        if not isinstance(item, dict):
            continue
        normalized = normalize_event(item)
        if normalized:
            rows.append(normalized)
    rows.sort(key=lambda row: str(row.get("datetime") or ""))
    if not rows:
        raise RuntimeError("تقویم اقتصادی خالی دریافت شد")
    return rows


async def fetch_economic_calendar(*, force: bool = False) -> list[dict[str, Any]]:
    global _CACHE
    now = time.monotonic()
    if not force and _CACHE and now - _CACHE[0] < _CACHE_SECONDS:
        return [dict(row) for row in _CACHE[1]]
    async with _FETCH_LOCK():
        now = time.monotonic()
        if not force and _CACHE and now - _CACHE[0] < _CACHE_SECONDS:
            return [dict(row) for row in _CACHE[1]]
        errors: list[str] = []
        for url in (PRIMARY_URL, FALLBACK_URL):
            try:
                rows = await _fetch_url(url)
                _CACHE = (time.monotonic(), rows)
                return [dict(row) for row in rows]
            except Exception as exc:
                errors.append(exc.__class__.__name__)
                logger.warning("Economic calendar provider failed (%s): %s", url.split("/")[2], exc.__class__.__name__)
        if _CACHE:
            return [dict(row) for row in _CACHE[1]]
        raise RuntimeError(f"دریافت تقویم اقتصادی ناموفق بود ({'/'.join(errors) or 'network'})")


def local_datetime(event: dict[str, Any], timezone: str | None = None) -> datetime | None:
    parsed = parse_dt(event.get("datetime"))
    if parsed is None:
        return None
    try:
        zone: tzinfo = ZoneInfo(timezone or SETTINGS.timezone)
    except Exception:
        zone = UTC
    return parsed.astimezone(zone)


def filter_events(
    events: list[dict[str, Any]],
    *,
    period: str = "today",
    local_now: datetime | None = None,
    min_impact: str = "high",
    currencies: set[str] | None = None,
) -> list[dict[str, Any]]:
    try:
        zone: tzinfo = ZoneInfo(SETTINGS.timezone)
    except Exception:
        zone = UTC
    now = local_now.astimezone(zone) if local_now else datetime.now(zone)
    start_day: date
    end_day: date
    if period == "tomorrow":
        start_day = end_day = now.date() + timedelta(days=1)
    elif period == "week":
        start_day = now.date()
        end_day = start_day + timedelta(days=6)
    else:
        start_day = end_day = now.date()
    threshold = _IMPACT_ORDER.get(min_impact, 3)
    output: list[dict[str, Any]] = []
    for event in events:
        when = local_datetime(event, SETTINGS.timezone)
        if when is None or not (start_day <= when.date() <= end_day):
            continue
        currency = str(event.get("currency") or "").upper()
        if currencies and currency not in currencies:
            continue
        impact = str(event.get("impact") or "").casefold()
        importance = _IMPACT_ORDER.get(impact, 0)
        title = str(event.get("title") or "").casefold()
        # Keep explicitly high-value events even if the provider temporarily labels them Medium.
        if importance < threshold and not (threshold >= 3 and any(term in title for term in _HIGH_VALUE_TERMS)):
            continue
        output.append(dict(event))
    output.sort(key=lambda row: str(row.get("datetime") or ""))
    return output


def impact_label(impact: str, language: str = "fa") -> tuple[str, str]:
    value = str(impact or "").casefold()
    english = str(language or "").lower().startswith("en")
    if value == "high":
        return "🔴", "High impact" if english else "خیلی مهم"
    if value == "medium":
        return "🟠", "Medium" if english else "متوسط"
    if value == "low":
        return "🟡", "Low" if english else "کم"
    return "⚪️", "Informational" if english else "اطلاع‌رسانی"


def _event_title(event: dict[str, Any]) -> str:
    return _clean(event.get("title_fa") or event.get("title"), 220)


def render_public_calendar(
    events: list[dict[str, Any]],
    *,
    period: str = "today",
    limit: int = 18,
    local_now: datetime | None = None,
    language: str = "fa",
) -> str:
    english = str(language or "").lower().startswith("en")
    labels = ({"today": "today", "tomorrow": "tomorrow", "week": "for the next seven days"} if english else {"today": "امروز", "tomorrow": "فردا", "week": "هفت روز آینده"})
    rows = filter_events(events, period=period, min_impact="high", local_now=local_now)
    lines = [f"🗓 <b>Key economic events {labels.get(period, 'today')}</b>" if english else f"🗓 <b>خبرهای مهم اقتصادی {labels.get(period, 'امروز')}</b>", ""]
    if not rows:
        lines.append("No high-impact event matches this period." if english else "امروز خبر اقتصادی خیلی مهمی در تقویم ثبت نشده است.")
    for event in rows[:limit]:
        when = local_datetime(event)
        if when is None:
            continue
        icon, _label = impact_label(str(event.get("impact") or ""), language)
        currency = _clean(event.get("currency"), 10)
        flag = _CURRENCY_FLAGS.get(currency, "🌐")
        lines.append(
            f"{icon} {flag} <b>{html.escape(currency)}</b>  •  <code>{when.strftime('%H:%M')}</code>\n{html.escape(_event_title(event))}"
        )
        lines.append("")
    lines.extend(
        [
            f"🕒 Times are shown in {html.escape(SETTINGS.timezone)}." if english else f"🕒 زمان‌ها بر اساس {html.escape(SETTINGS.timezone)} هستند.",
            "🔒 Forecast, previous/actual values and impact analysis are available only to administrators." if english else "🔒 پیش‌بینی، مقدار قبلی، نتیجه واقعی و تحلیل اثر خبر فقط در پنل ادمین نمایش داده می‌شود.",
        ]
    )
    return "\n".join(lines)


def analyze_event(event: dict[str, Any]) -> dict[str, Any]:
    title = str(event.get("title") or "").casefold()
    currency = str(event.get("currency") or "").upper()
    actual = _float(event.get("actual"))
    forecast = _float(event.get("forecast"))
    previous = _float(event.get("previous"))
    comparator = actual if actual is not None else forecast
    baseline = forecast if actual is not None and forecast is not None else previous
    surprise = None if comparator is None or baseline is None else comparator - baseline

    inverse = any(term in title for term in ("unemployment", "jobless claims", "unemployment claims"))
    inflation = any(term in title for term in ("cpi", "pce", "inflation", "price index"))
    rate = any(term in title for term in ("rate", "fomc", "ecb", "refinancing"))
    growth = any(term in title for term in ("gdp", "payroll", "employment", "retail sales", "pmi", "jolts", "adp"))

    strength = 0
    reason = "برای نتیجه جهت‌دار، مقایسه مقدار واقعی با پیش‌بینی لازم است."
    if surprise is not None and (inflation or rate or growth or inverse):
        strength = (
            -1 if (inverse and surprise > 0) else 1 if (inverse and surprise < 0) else 1 if surprise > 0 else -1 if surprise < 0 else 0
        )
        basis = "واقعی نسبت به پیش‌بینی" if actual is not None else "پیش‌بینی نسبت به مقدار قبلی"
        reason = f"{basis}: {surprise:+.2f}"

    gold = "خنثی/نوسانی"
    eurusd = "خنثی/نوسانی"
    if currency == "USD" and strength:
        gold = "فشار نزولی محتمل" if strength > 0 else "حمایت صعودی محتمل"
        eurusd = "فشار نزولی محتمل" if strength > 0 else "حمایت صعودی محتمل"
    elif currency == "EUR" and strength:
        eurusd = "حمایت صعودی محتمل" if strength > 0 else "فشار نزولی محتمل"
        gold = "اثر غیرمستقیم و دوطرفه"
    elif currency in {"GBP", "JPY", "CHF", "CAD", "AUD", "NZD", "CNY"}:
        gold = "اثر غیرمستقیم از مسیر دلار و ریسک بازار"
        eurusd = "اثر غیرمستقیم و محدود"

    if actual is None:
        confidence = "پایین؛ خبر هنوز منتشر نشده"
    elif surprise is None:
        confidence = "پایین؛ داده قابل مقایسه نیست"
    else:
        confidence = "متوسط؛ واکنش بازار به جزئیات گزارش وابسته است"
    return {"gold": gold, "eurusd": eurusd, "reason": reason, "confidence": confidence}


def render_admin_event(event: dict[str, Any]) -> str:
    when = local_datetime(event)
    icon, label = impact_label(str(event.get("impact") or ""))
    analysis = analyze_event(event)
    lines = [
        f"{icon} <b>{html.escape(_event_title(event))}</b>",
        "",
        f"ارز: <b>{html.escape(str(event.get('currency') or '—'))}</b>",
        f"زمان: <b>{when.strftime('%Y-%m-%d %H:%M') if when else '—'}</b> ({html.escape(SETTINGS.timezone)})",
        f"اهمیت: <b>{label}</b>",
        f"واقعی: <code>{html.escape(str(event.get('actual') or '—'))}</code>",
        f"پیش‌بینی: <code>{html.escape(str(event.get('forecast') or '—'))}</code>",
        f"قبلی: <code>{html.escape(str(event.get('previous') or '—'))}</code>",
        "",
        "<b>تحلیل سناریویی داخلی:</b>",
        f"🥇 طلا: {html.escape(analysis['gold'])}",
        f"💶 EUR/USD: {html.escape(analysis['eurusd'])}",
        f"دلیل: {html.escape(analysis['reason'])}",
        f"اطمینان: {html.escape(analysis['confidence'])}",
        "",
        "⚠️ این تحلیل قطعی نیست و فقط برای تصمیم ادمین تهیه شده است.",
    ]
    return "\n".join(lines)


def render_selected_events(events: list[dict[str, Any]], indexes: list[int], *, include_analysis: bool = False) -> str:
    selected = [events[index] for index in indexes if 0 <= index < len(events)]
    lines = ["🗓 <b>تقویم خبرهای مهم بازار</b>", ""]
    if not selected:
        return "\n".join(lines + ["خبری انتخاب نشده است."])
    for number, event in enumerate(selected, start=1):
        when = local_datetime(event)
        icon, label = impact_label(str(event.get("impact") or ""))
        currency = _clean(event.get("currency"), 10)
        lines.extend(
            [
                f"{number}. {icon} <b>{html.escape(_event_title(event))}</b>",
                f"{_CURRENCY_FLAGS.get(currency, '🌐')} {html.escape(currency)}  •  <code>{when.strftime('%H:%M') if when else '—'}</code>  •  {label}",
                f"پیش‌بینی: <code>{html.escape(str(event.get('forecast') or '—'))}</code> | قبلی: <code>{html.escape(str(event.get('previous') or '—'))}</code>",
            ]
        )
        if event.get("actual"):
            lines.append(f"واقعی: <code>{html.escape(str(event.get('actual')))}</code>")
        if include_analysis:
            analysis = analyze_event(event)
            lines.extend(
                [
                    f"🥇 طلا: {html.escape(analysis['gold'])}",
                    f"💶 EUR/USD: {html.escape(analysis['eurusd'])}",
                ]
            )
        lines.append("")
    lines.extend(
        [
            "⚠️ واکنش بازار می‌تواند با سناریوی اولیه متفاوت باشد؛ مدیریت ریسک الزامی است.",
            "منبع تقویم: Forex Factory weekly export | انتشار با تأیید ادمین",
        ]
    )
    return "\n".join(lines)

# ───────────────────── Persistent preferences and automation ─────────────────────

CALENDAR_CURRENCIES = ("USD", "EUR", "GBP", "JPY", "CAD", "AUD", "NZD", "CHF", "CNY")
CALENDAR_IMPACTS = ("high", "medium", "low")
CALENDAR_REMINDER_OPTIONS = (5, 15, 30, 60, 120)
CALENDAR_TIMEZONES = ("Asia/Tehran", "Asia/Baku", "UTC")
CALENDAR_DEFAULTS: dict[str, Any] = {
    "enabled": True,
    "alerts_enabled": True,
    "actual_alerts_enabled": True,
    "auto_publish_enabled": False,
    "auto_publish_time": "07:30",
    "auto_publish_destination": "public",
    "auto_publish_min_impact": "high",
    "auto_publish_currencies": ["USD", "EUR", "GBP"],
    "default_min_impact": "high",
    "default_reminder_minutes": 30,
    "history_limit": 5000,
}


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value if value is not None else default).replace(",", ""))
    except (TypeError, ValueError):
        return default


def calendar_settings(db: dict[str, Any]) -> dict[str, Any]:
    root = db.setdefault("economic_calendar", {})
    settings = root.setdefault("settings", {})
    for key, value in CALENDAR_DEFAULTS.items():
        settings.setdefault(key, list(value) if isinstance(value, list) else value)
    return settings


def update_calendar_setting(db: dict[str, Any], key: str, value: Any) -> dict[str, Any]:
    settings = calendar_settings(db)
    if key not in CALENDAR_DEFAULTS:
        raise ValueError("تنظیم تقویم نامعتبر است")
    if key.endswith("_enabled") or key == "enabled":
        settings[key] = bool(value)
    elif key in {"default_reminder_minutes"}:
        number = int(value)
        if not 1 <= number <= 1440:
            raise ValueError("دقیقه یادآوری باید بین ۱ تا ۱۴۴۰ باشد")
        settings[key] = number
    elif key in {"default_min_impact", "auto_publish_min_impact"}:
        impact = str(value).lower()
        if impact not in CALENDAR_IMPACTS:
            raise ValueError("اهمیت خبر نامعتبر است")
        settings[key] = impact
    elif key == "auto_publish_destination":
        destination = str(value).lower()
        if destination not in {"public", "private", "both"}:
            raise ValueError("مقصد انتشار نامعتبر است")
        settings[key] = destination
    elif key == "auto_publish_time":
        text = str(value).strip()
        if not re.fullmatch(r"(?:[01]\d|2[0-3]):[0-5]\d", text):
            raise ValueError("ساعت باید به شکل HH:MM باشد")
        settings[key] = text
    elif key == "auto_publish_currencies":
        values = [str(item).upper() for item in value if str(item).upper() in CALENDAR_CURRENCIES]
        settings[key] = sorted(set(values))
    else:
        settings[key] = value
    settings["updated_at"] = utc_iso()
    return settings


def user_calendar_preferences(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    settings = calendar_settings(db)
    prefs = db.setdefault("economic_calendar_preferences", {}).setdefault(
        str(user_id),
        {
            "enabled": True,
            "actual_alerts": True,
            "currencies": ["USD", "EUR", "GBP"],
            "min_impact": str(settings.get("default_min_impact") or "high"),
            "reminder_minutes": int(settings.get("default_reminder_minutes", 30) or 30),
            "timezone": SETTINGS.timezone if SETTINGS.timezone in CALENDAR_TIMEZONES else "UTC",
            "updated_at": utc_iso(),
        },
    )
    prefs.setdefault("enabled", True)
    prefs.setdefault("actual_alerts", True)
    prefs.setdefault("currencies", ["USD", "EUR", "GBP"])
    prefs.setdefault("min_impact", str(settings.get("default_min_impact") or "high"))
    prefs.setdefault("reminder_minutes", int(settings.get("default_reminder_minutes", 30) or 30))
    prefs.setdefault("timezone", SETTINGS.timezone if SETTINGS.timezone in CALENDAR_TIMEZONES else "UTC")
    return prefs


def toggle_user_calendar_alerts(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    prefs = user_calendar_preferences(db, user_id)
    prefs["enabled"] = not bool(prefs.get("enabled", True))
    prefs["updated_at"] = utc_iso()
    return prefs


def toggle_user_actual_alerts(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    prefs = user_calendar_preferences(db, user_id)
    prefs["actual_alerts"] = not bool(prefs.get("actual_alerts", True))
    prefs["updated_at"] = utc_iso()
    return prefs


def toggle_user_calendar_currency(db: dict[str, Any], user_id: int | str, currency: str) -> dict[str, Any]:
    code = str(currency or "").upper()
    if code not in CALENDAR_CURRENCIES:
        raise ValueError("ارز تقویم نامعتبر است")
    prefs = user_calendar_preferences(db, user_id)
    values = {str(item).upper() for item in prefs.get("currencies", []) if str(item).upper() in CALENDAR_CURRENCIES}
    if code in values:
        if len(values) <= 1:
            raise ValueError("حداقل یک ارز باید فعال باشد")
        values.remove(code)
    else:
        values.add(code)
    prefs["currencies"] = sorted(values)
    prefs["updated_at"] = utc_iso()
    return prefs


def cycle_user_calendar_impact(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    prefs = user_calendar_preferences(db, user_id)
    current = str(prefs.get("min_impact") or "high")
    try:
        index = CALENDAR_IMPACTS.index(current)
    except ValueError:
        index = 0
    prefs["min_impact"] = CALENDAR_IMPACTS[(index + 1) % len(CALENDAR_IMPACTS)]
    prefs["updated_at"] = utc_iso()
    return prefs


def cycle_user_calendar_reminder(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    prefs = user_calendar_preferences(db, user_id)
    current = int(prefs.get("reminder_minutes", 30) or 30)
    try:
        index = CALENDAR_REMINDER_OPTIONS.index(current)
    except ValueError:
        index = 2
    prefs["reminder_minutes"] = CALENDAR_REMINDER_OPTIONS[(index + 1) % len(CALENDAR_REMINDER_OPTIONS)]
    prefs["updated_at"] = utc_iso()
    return prefs


def cycle_user_calendar_timezone(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    prefs = user_calendar_preferences(db, user_id)
    current = str(prefs.get("timezone") or SETTINGS.timezone)
    try:
        index = CALENDAR_TIMEZONES.index(current)
    except ValueError:
        index = -1
    prefs["timezone"] = CALENDAR_TIMEZONES[(index + 1) % len(CALENDAR_TIMEZONES)]
    prefs["updated_at"] = utc_iso()
    return prefs


def user_filtered_events(
    db: dict[str, Any],
    user_id: int | str,
    events: list[dict[str, Any]],
    *,
    period: str,
    local_now: datetime | None = None,
) -> list[dict[str, Any]]:
    prefs = user_calendar_preferences(db, user_id)
    currencies = {str(item).upper() for item in prefs.get("currencies", [])}
    return filter_events(
        events,
        period=period,
        min_impact=str(prefs.get("min_impact") or "high"),
        currencies=currencies or None,
        local_now=local_now,
    )


def _claim_calendar_log(db: dict[str, Any], key: str, payload: dict[str, Any]) -> bool:
    now = datetime.now(UTC)
    logs = db.setdefault("economic_calendar_notifications", {})
    old = logs.get(key)
    if isinstance(old, dict):
        if old.get("status") == "sent":
            return False
        claimed = parse_dt(old.get("claimed_at"))
        if old.get("status") == "pending" and claimed and now - claimed < timedelta(minutes=20):
            return False
        if _safe_int(old.get("attempts")) >= 5:
            return False
    logs[key] = {
        **dict(old or {}),
        **payload,
        "key": key,
        "status": "pending",
        "claimed_at": utc_iso(now),
        "attempts": _safe_int((old or {}).get("attempts")) + 1,
    }
    return True


def claim_due_calendar_notifications(
    db: dict[str, Any],
    events: list[dict[str, Any]],
    *,
    now: datetime | None = None,
    limit: int = 500,
) -> list[dict[str, Any]]:
    settings = calendar_settings(db)
    if not settings.get("enabled") or not settings.get("alerts_enabled"):
        return []
    current = (now or datetime.now(UTC)).astimezone(UTC)
    output: list[dict[str, Any]] = []
    users = db.get("users", {}) if isinstance(db.get("users", {}), dict) else {}
    for uid in users:
        if len(output) >= limit:
            break
        prefs = user_calendar_preferences(db, uid)
        if not prefs.get("enabled", True):
            continue
        currencies = {str(item).upper() for item in prefs.get("currencies", [])}
        threshold = _IMPACT_ORDER.get(str(prefs.get("min_impact") or "high"), 3)
        reminder = max(1, min(int(prefs.get("reminder_minutes", 30) or 30), 1440))
        for event in events:
            when = parse_dt(event.get("datetime"))
            if not when:
                continue
            currency = str(event.get("currency") or "").upper()
            impact = str(event.get("impact") or "").lower()
            if currencies and currency not in currencies:
                continue
            if _IMPACT_ORDER.get(impact, 0) < threshold:
                continue
            seconds = (when - current).total_seconds()
            if 0 <= seconds <= reminder * 60:
                key = f"reminder:{uid}:{event.get('id')}:{reminder}"
                payload = {
                    "kind": "reminder",
                    "user_id": str(uid),
                    "event_id": str(event.get("id") or ""),
                    "event": dict(event),
                    "reminder_minutes": max(1, math.ceil(seconds / 60)),
                    "timezone": str(prefs.get("timezone") or SETTINGS.timezone),
                }
                if _claim_calendar_log(db, key, payload):
                    output.append({"key": key, **payload})
                    if len(output) >= limit:
                        break
            actual = str(event.get("actual") or "").strip()
            if (
                actual
                and settings.get("actual_alerts_enabled", True)
                and prefs.get("actual_alerts", True)
                and -6 * 3600 <= seconds <= 0
            ):
                key = f"actual:{uid}:{event.get('id')}:{actual}"
                payload = {
                    "kind": "actual",
                    "user_id": str(uid),
                    "event_id": str(event.get("id") or ""),
                    "event": dict(event),
                    "timezone": str(prefs.get("timezone") or SETTINGS.timezone),
                }
                if _claim_calendar_log(db, key, payload):
                    output.append({"key": key, **payload})
                    if len(output) >= limit:
                        break
    return output


def mark_calendar_notification(db: dict[str, Any], key: str, *, success: bool, detail: str = "") -> dict[str, Any]:
    logs = db.setdefault("economic_calendar_notifications", {})
    row = logs.setdefault(str(key), {})
    row.update({"status": "sent" if success else "failed", "updated_at": utc_iso(), "detail": str(detail)[:500]})
    limit = int(calendar_settings(db).get("history_limit", 5000) or 5000)
    if len(logs) > limit:
        active = {
            log_key: item
            for log_key, item in logs.items()
            if isinstance(item, dict) and str(item.get("status") or "") == "pending"
        }
        terminal = sorted(
            (
                (log_key, item)
                for log_key, item in logs.items()
                if isinstance(item, dict) and str(item.get("status") or "") != "pending"
            ),
            key=lambda pair: str(pair[1].get("updated_at") or pair[1].get("claimed_at") or ""),
            reverse=True,
        )
        remaining = max(0, limit - len(active))
        db["economic_calendar_notifications"] = {**active, **dict(terminal[:remaining])}
    return row


def claim_auto_publication(
    db: dict[str, Any],
    events: list[dict[str, Any]],
    *,
    local_now: datetime | None = None,
) -> dict[str, Any] | None:
    settings = calendar_settings(db)
    if not settings.get("enabled") or not settings.get("auto_publish_enabled"):
        return None
    try:
        zone: tzinfo = ZoneInfo(SETTINGS.timezone)
    except Exception:
        zone = UTC
    now = (local_now or datetime.now(zone)).astimezone(zone)
    configured = str(settings.get("auto_publish_time") or "07:30")
    hour, minute = [int(part) for part in configured.split(":", 1)]
    scheduled = now.replace(hour=hour, minute=minute, second=0, microsecond=0)
    if not scheduled <= now < scheduled + timedelta(minutes=10):
        return None
    root = db.setdefault("economic_calendar", {})
    key = now.date().isoformat()
    last = root.get("last_auto_publication")
    attempts = 0
    if isinstance(last, dict) and str(last.get("date")) == key:
        status = str(last.get("status") or "")
        attempts = _safe_int(last.get("attempts"))
        if status == "sent" or attempts >= 3:
            return None
        claimed_at = parse_dt(last.get("claimed_at"))
        updated_at = parse_dt(last.get("updated_at"))
        if status == "pending" and claimed_at and datetime.now(UTC) - claimed_at < timedelta(minutes=20):
            return None
        if status == "failed" and updated_at and datetime.now(UTC) - updated_at < timedelta(minutes=2):
            return None
    currencies = {str(item).upper() for item in settings.get("auto_publish_currencies", [])}
    selected = filter_events(
        events,
        period="today",
        local_now=now,
        min_impact=str(settings.get("auto_publish_min_impact") or "high"),
        currencies=currencies or None,
    )
    root["last_auto_publication"] = {
        "date": key,
        "status": "pending",
        "claimed_at": utc_iso(),
        "destination": str(settings.get("auto_publish_destination") or "public"),
        "event_ids": [str(row.get("id") or "") for row in selected],
        "attempts": attempts + 1,
    }
    return {
        "date": key,
        "events": selected,
        "destination": str(settings.get("auto_publish_destination") or "public"),
    }


def mark_auto_publication(db: dict[str, Any], *, success: bool, detail: str = "", message_ids: list[int] | None = None) -> None:
    root = db.setdefault("economic_calendar", {})
    row = root.setdefault("last_auto_publication", {})
    row.update(
        {
            "status": "sent" if success else "failed",
            "updated_at": utc_iso(),
            "detail": str(detail)[:500],
            "message_ids": list(message_ids or []),
        }
    )


def calendar_automation_snapshot(db: dict[str, Any]) -> dict[str, Any]:
    settings = calendar_settings(db)
    logs = db.get("economic_calendar_notifications", {})
    counts = {"sent": 0, "failed": 0, "pending": 0}
    if isinstance(logs, dict):
        for row in logs.values():
            if isinstance(row, dict) and str(row.get("status")) in counts:
                counts[str(row.get("status"))] += 1
    return {
        "settings": dict(settings),
        "subscribers": sum(
            1
            for row in db.get("economic_calendar_preferences", {}).values()
            if isinstance(row, dict) and row.get("enabled", True)
        ),
        "notifications": counts,
        "last_auto_publication": dict(db.get("economic_calendar", {}).get("last_auto_publication") or {}),
    }


def actual_result_label(event: dict[str, Any]) -> str:
    actual = _float(event.get("actual"))
    forecast = _float(event.get("forecast"))
    if actual is None or forecast is None:
        return "قابل مقایسه نیست"
    if math.isclose(actual, forecast, rel_tol=1e-9, abs_tol=1e-12):
        return "مطابق انتظار"
    title = str(event.get("title") or "").casefold()
    inverse = any(term in title for term in ("unemployment", "jobless claims", "unemployment claims"))
    positive = actual < forecast if inverse else actual > forecast
    return "بهتر از انتظار" if positive else "ضعیف‌تر از انتظار"


def render_calendar_alert(
    event: dict[str, Any],
    *,
    kind: str,
    reminder_minutes: int = 0,
    timezone: str | None = None,
) -> str:
    when = local_datetime(event, timezone)
    icon, label = impact_label(str(event.get("impact") or ""))
    currency = str(event.get("currency") or "")
    title = html.escape(_event_title(event))
    if kind == "actual":
        analysis = analyze_event(event)
        return (
            f"📣 <b>نتیجه خبر اقتصادی منتشر شد</b>\n\n"
            f"{icon} <b>{title}</b>\n"
            f"{_CURRENCY_FLAGS.get(currency, '🌐')} {html.escape(currency)} • {label}\n"
            f"واقعی: <code>{html.escape(str(event.get('actual') or '—'))}</code>\n"
            f"پیش‌بینی: <code>{html.escape(str(event.get('forecast') or '—'))}</code> | قبلی: <code>{html.escape(str(event.get('previous') or '—'))}</code>\n"
            f"نتیجه: <b>{html.escape(actual_result_label(event))}</b>\n\n"
            f"🥇 طلا: {html.escape(analysis['gold'])}\n"
            f"💶 EUR/USD: {html.escape(analysis['eurusd'])}\n\n"
            "⚠️ این توضیح صرفاً سناریوی کمکی است و توصیه مالی نیست."
        )
    minutes = max(1, int(reminder_minutes or 1))
    return (
        f"⏰ <b>یادآوری خبر اقتصادی</b>\n\n"
        f"{icon} <b>{title}</b>\n"
        f"{_CURRENCY_FLAGS.get(currency, '🌐')} {html.escape(currency)} • {label}\n"
        f"زمان: <code>{when.strftime('%Y-%m-%d %H:%M') if when else '—'}</code>\n"
        f"تا انتشار: حدود <b>{minutes} دقیقه</b>\n"
        f"پیش‌بینی: <code>{html.escape(str(event.get('forecast') or '—'))}</code> | قبلی: <code>{html.escape(str(event.get('previous') or '—'))}</code>\n\n"
        "⚠️ نزدیک خبرهای مهم، Spread و نوسان می‌تواند افزایش پیدا کند."
    )


def render_user_calendar(
    events: list[dict[str, Any]],
    *,
    period: str,
    min_impact: str,
    currencies: set[str] | None,
    timezone: str | None = None,
    limit: int = 24,
    language: str = "fa",
) -> str:
    english = str(language or "").lower().startswith("en")
    labels = ({"today": "today", "tomorrow": "tomorrow", "week": "next seven days"} if english else {"today": "امروز", "tomorrow": "فردا", "week": "هفت روز آینده"})
    rows = filter_events(events, period=period, min_impact=min_impact, currencies=currencies)
    lines = [f"🗓 <b>Economic calendar — {labels.get(period, 'today')}</b>" if english else f"🗓 <b>تقویم اقتصادی {labels.get(period, 'امروز')}</b>", ""]
    if not rows:
        lines.append("No event matches your filters." if english else "رویدادی مطابق فیلترهای شما پیدا نشد.")
    for event in rows[:limit]:
        when = local_datetime(event, timezone)
        icon, label = impact_label(str(event.get("impact") or ""), language)
        currency = str(event.get("currency") or "")
        lines.extend(
            [
                f"{icon} {_CURRENCY_FLAGS.get(currency, '🌐')} <b>{html.escape(currency)}</b> • <code>{when.strftime('%m-%d %H:%M') if when else '—'}</code> • {label}",
                html.escape(_event_title(event)),
                "",
            ]
        )
    if len(rows) > limit:
        lines.append(f"… and {len(rows) - limit} more events" if english else f"… و {len(rows) - limit} رویداد دیگر")
    lines.extend(
        [
            f"🕒 Times are shown in {html.escape(timezone or SETTINGS.timezone)}." if english else f"🕒 زمان‌ها بر اساس {html.escape(timezone or SETTINGS.timezone)} هستند.",
            "Use the controls below to set currencies, impact and reminders." if english else "برای تنظیم ارزها، اهمیت و یادآوری از دکمه‌های پایین استفاده کنید.",
        ]
    )
    return "\n".join(lines)


def cache_calendar_events(db: dict[str, Any], events: list[dict[str, Any]]) -> dict[str, Any]:
    """Persist a bounded normalized calendar snapshot for the Mini App."""
    root = db.setdefault("economic_calendar", {})
    normalized = [dict(item) for item in events if isinstance(item, dict)][:500]
    root["cached_events"] = normalized
    root["cached_events_updated_at"] = utc_iso()
    return {"count": len(normalized), "updated_at": root["cached_events_updated_at"]}


def cached_calendar_events(
    db: dict[str, Any],
    user_id: int | str,
    *,
    period: str = "week",
    local_now: datetime | None = None,
) -> list[dict[str, Any]]:
    root = db.setdefault("economic_calendar", {})
    rows = [dict(item) for item in root.get("cached_events", []) if isinstance(item, dict)]
    return user_filtered_events(db, user_id, rows, period=period, local_now=local_now)


def update_user_calendar_preferences(
    db: dict[str, Any],
    user_id: int | str,
    values: dict[str, Any],
) -> dict[str, Any]:
    prefs = user_calendar_preferences(db, user_id)
    if "enabled" in values:
        prefs["enabled"] = bool(values["enabled"])
    if "actual_alerts" in values:
        prefs["actual_alerts"] = bool(values["actual_alerts"])
    if "currencies" in values:
        raw = values.get("currencies")
        candidates = raw if isinstance(raw, list) else str(raw or "").split(",")
        currencies = sorted({str(item).strip().upper() for item in candidates if str(item).strip().upper() in CALENDAR_CURRENCIES})
        if not currencies:
            raise ValueError("حداقل یک ارز تقویم باید انتخاب شود")
        prefs["currencies"] = currencies
    if "min_impact" in values:
        impact = str(values.get("min_impact") or "high").lower()
        if impact not in CALENDAR_IMPACTS:
            raise ValueError("اهمیت خبر نامعتبر است")
        prefs["min_impact"] = impact
    if "reminder_minutes" in values:
        minutes = int(values.get("reminder_minutes") or 30)
        if minutes not in CALENDAR_REMINDER_OPTIONS:
            raise ValueError("زمان یادآوری نامعتبر است")
        prefs["reminder_minutes"] = minutes
    if "timezone" in values:
        timezone = str(values.get("timezone") or SETTINGS.timezone)
        if timezone not in CALENDAR_TIMEZONES:
            raise ValueError("منطقه زمانی تقویم نامعتبر است")
        prefs["timezone"] = timezone
    prefs["updated_at"] = utc_iso()
    return dict(prefs)
