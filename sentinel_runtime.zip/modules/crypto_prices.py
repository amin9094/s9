from __future__ import annotations

import asyncio
import logging
import os
import re
import time
import unicodedata
from dataclasses import dataclass, replace
from datetime import UTC, datetime
from typing import Any

from core.http_client import get_json
from core.shared_cache import cache_get, cache_set

logger = logging.getLogger(__name__)

_COINGECKO_BASE = "https://api.coingecko.com/api/v3"
_BINANCE_BASE = "https://data-api.binance.vision/api/v3"
_COINBASE_BASE = "https://api.exchange.coinbase.com"
_SEARCH_CACHE_SECONDS = 300
_QUOTE_CACHE_SECONDS = 20
_BINANCE_SYMBOL_CACHE_SECONDS = 1800
_CATALOG_CACHE_SECONDS = 6 * 60 * 60
_CATALOG_SHARED_CACHE_SECONDS = 12 * 60 * 60
_SAFE_COIN_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,99}$")
_SAFE_BINANCE_SYMBOL = re.compile(r"^[A-Z0-9]{2,20}$")

_SEARCH_CACHE: dict[str, tuple[float, list[CryptoSearchResult]]] = {}
_QUOTE_CACHE: dict[str, tuple[float, CryptoQuote]] = {}
_TOP_CACHE: tuple[float, list[CryptoQuote]] | None = None
_BINANCE_SYMBOLS_CACHE: tuple[float, list[str]] | None = None
_COINGECKO_CATALOG_CACHE: tuple[float, list[CryptoSearchResult]] | None = None
_COIN_HINTS: dict[str, CryptoSearchResult] = {}


@dataclass(frozen=True, slots=True)
class CryptoSearchResult:
    coin_id: str
    name: str
    symbol: str
    market_cap_rank: int | None = None
    source: str = "CoinGecko"


@dataclass(frozen=True, slots=True)
class CryptoQuote:
    coin_id: str
    name: str
    symbol: str
    price_usd: float
    change_24h: float | None
    high_24h: float | None
    low_24h: float | None
    volume_24h: float | None
    market_cap: float | None
    market_cap_rank: int | None
    updated_at: datetime
    source: str
    quote_currency: str = "USD"
    identity_verified: bool = True
    provider_asset_id: str = ""


_PERSIAN_ALIASES = {
    "بیت کوین": "bitcoin",
    "بیت‌کوین": "bitcoin",
    "بیتکوین": "bitcoin",
    "اتریوم": "ethereum",
    "اتر": "ethereum",
    "تتر": "tether",
    "بایننس": "binancecoin",
    "بی ان بی": "binancecoin",
    "سولانا": "solana",
    "ریپل": "ripple",
    "دوج": "dogecoin",
    "دوج کوین": "dogecoin",
    "کاردانو": "cardano",
    "ترون": "tron",
    "تون": "the-open-network",
    "تون کوین": "the-open-network",
    "شیبا": "shiba-inu",
    "لایت کوین": "litecoin",
    "آوالانچ": "avalanche-2",
    "پولکادات": "polkadot",
    "چین لینک": "chainlink",
}

_POPULAR_NAMES = {
    "bitcoin": "Bitcoin",
    "ethereum": "Ethereum",
    "tether": "Tether",
    "binancecoin": "BNB",
    "solana": "Solana",
    "ripple": "XRP",
    "dogecoin": "Dogecoin",
    "the-open-network": "Toncoin",
    "cardano": "Cardano",
    "tron": "TRON",
}

_POPULAR_IDS = {
    "bitcoin": "BTC",
    "ethereum": "ETH",
    "tether": "USDT",
    "binancecoin": "BNB",
    "solana": "SOL",
    "ripple": "XRP",
    "dogecoin": "DOGE",
    "the-open-network": "TON",
    "cardano": "ADA",
    "tron": "TRX",
}

# A cross-provider quote must never be inferred from a ticker alone. Tickers
# are not globally unique (unrelated assets can all be named ONE, PAY or GAS).
# This deliberately small registry is reviewed and fails closed for every
# CoinGecko asset that is not explicitly mapped.
_TRUSTED_PROVIDER_SYMBOLS = {
    **_POPULAR_IDS,
    "avalanche-2": "AVAX",
    "bitcoin-cash": "BCH",
    "chainlink": "LINK",
    "dai": "DAI",
    "litecoin": "LTC",
    "polkadot": "DOT",
    "shiba-inu": "SHIB",
    "usd-coin": "USDC",
}

def popular_crypto_assets() -> list[CryptoSearchResult]:
    return [CryptoSearchResult(coin_id=coin_id, name=_POPULAR_NAMES[coin_id], symbol=symbol) for coin_id, symbol in _POPULAR_IDS.items()]


def _local_search(query: str) -> list[CryptoSearchResult]:
    lowered = query.casefold()
    alias_id = _PERSIAN_ALIASES.get(lowered)
    results: list[CryptoSearchResult] = []
    for coin_id, symbol in _POPULAR_IDS.items():
        if alias_id == coin_id or lowered in {coin_id.casefold(), symbol.casefold(), _POPULAR_NAMES[coin_id].casefold()}:
            results.append(CryptoSearchResult(coin_id=coin_id, name=_POPULAR_NAMES[coin_id], symbol=symbol))
    return results


def _normalize_query(value: str) -> str:
    text = unicodedata.normalize("NFKC", str(value or "")).strip()
    text = re.sub(r"\s+", " ", text)
    if len(text) < 2:
        raise ValueError("نام یا نماد ارز باید حداقل ۲ کاراکتر باشد")
    if len(text) > 64:
        raise ValueError("عبارت جستجو بیش از حد طولانی است")
    return text


def _headers() -> dict[str, str]:
    headers = {"User-Agent": "SENTINELBot/4.0", "Accept": "application/json"}
    demo_key = os.getenv("COINGECKO_DEMO_API_KEY", "").strip()
    if demo_key:
        headers["x-cg-demo-api-key"] = demo_key
    return headers


async def _get_json(url: str, *, params: dict[str, Any] | None = None, headers: dict[str, str] | None = None) -> Any:
    request_headers = _headers()
    if headers:
        request_headers.update(headers)
    try:
        return await get_json(url, params=params, headers=request_headers, retries=2)
    except Exception as exc:
        raise RuntimeError("سرویس قیمت ارز دیجیتال در دسترس نیست") from exc


def _safe_float(value: Any) -> float | None:
    try:
        result = float(value)
    except (TypeError, ValueError):
        return None
    return result if result == result else None


def _safe_int(value: Any) -> int | None:
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _search_sort_key(item: CryptoSearchResult, query: str) -> tuple[int, int, int, int, str]:
    lowered = query.casefold()
    exact_symbol = item.symbol.casefold() == lowered
    exact_name = item.name.casefold() == lowered
    exact_id = item.coin_id.casefold() == lowered
    starts = (
        item.symbol.casefold().startswith(lowered)
        or item.name.casefold().startswith(lowered)
        or item.coin_id.casefold().startswith(lowered)
    )
    rank = item.market_cap_rank if item.market_cap_rank and item.market_cap_rank > 0 else 10_000_000
    return (
        0 if exact_symbol else 1,
        0 if exact_name or exact_id else 1,
        0 if starts else 1,
        rank,
        item.name.casefold(),
    )


def _remember_results(rows: list[CryptoSearchResult]) -> None:
    for item in rows:
        if item.coin_id and not item.coin_id.startswith("bn-"):
            _COIN_HINTS[item.coin_id] = item
    if len(_COIN_HINTS) > 50_000:
        for key in list(_COIN_HINTS)[:10_000]:
            _COIN_HINTS.pop(key, None)


async def _search_coingecko(query: str, limit: int) -> list[CryptoSearchResult]:
    alias_id = _PERSIAN_ALIASES.get(query.casefold())
    search_term = alias_id or query
    payload = await _get_json(f"{_COINGECKO_BASE}/search", params={"query": search_term})
    coins = payload.get("coins", []) if isinstance(payload, dict) else []
    results: list[CryptoSearchResult] = []
    for row in coins:
        if not isinstance(row, dict):
            continue
        coin_id = str(row.get("id") or "").strip().lower()
        symbol = str(row.get("symbol") or "").strip().upper()
        name = str(row.get("name") or "").strip()
        if not _SAFE_COIN_ID.fullmatch(coin_id) or not symbol or not name:
            continue
        results.append(
            CryptoSearchResult(
                coin_id=coin_id,
                name=name[:80],
                symbol=symbol[:16],
                market_cap_rank=_safe_int(row.get("market_cap_rank")),
            )
        )
    if alias_id:
        results.sort(key=lambda item: (0 if item.coin_id == alias_id else 1, *_search_sort_key(item, query)))
    else:
        results.sort(key=lambda item: _search_sort_key(item, query))
    _remember_results(results)
    return results[:limit]


def _catalog_rows(payload: Any) -> list[CryptoSearchResult]:
    if not isinstance(payload, list):
        return []
    rows: list[CryptoSearchResult] = []
    for item in payload[:50_000]:
        if not isinstance(item, dict):
            continue
        coin_id = str(item.get("id") or item.get("coin_id") or "").strip().lower()
        symbol = str(item.get("symbol") or "").strip().upper()
        name = str(item.get("name") or "").strip()
        if not _SAFE_COIN_ID.fullmatch(coin_id) or not symbol or not name:
            continue
        rows.append(
            CryptoSearchResult(
                coin_id=coin_id,
                name=name[:80],
                symbol=symbol[:20],
                market_cap_rank=_safe_int(item.get("market_cap_rank")),
                source="CoinGecko Catalog",
            )
        )
    return rows


async def _coingecko_catalog() -> list[CryptoSearchResult]:
    """Return the complete active CoinGecko coin catalog with stale-cache fallback."""
    global _COINGECKO_CATALOG_CACHE
    now = time.monotonic()
    if (
        _COINGECKO_CATALOG_CACHE
        and now - _COINGECKO_CATALOG_CACHE[0] < _CATALOG_CACHE_SECONDS
    ):
        return list(_COINGECKO_CATALOG_CACHE[1])

    shared = await cache_get("crypto", "coingecko-active-catalog-v1")
    shared_rows = _catalog_rows(shared)
    if shared_rows:
        _COINGECKO_CATALOG_CACHE = (now, shared_rows)
        _remember_results(shared_rows)
        return list(shared_rows)

    stale = list(_COINGECKO_CATALOG_CACHE[1]) if _COINGECKO_CATALOG_CACHE else []
    try:
        payload = await _get_json(
            f"{_COINGECKO_BASE}/coins/list",
            params={"include_platform": "false", "status": "active"},
        )
        rows = _catalog_rows(payload)
        if not rows:
            raise RuntimeError("فهرست ارزهای دیجیتال خالی بود")
        _COINGECKO_CATALOG_CACHE = (now, rows)
        _remember_results(rows)
        await cache_set(
            "crypto",
            "coingecko-active-catalog-v1",
            [
                {"id": item.coin_id, "name": item.name, "symbol": item.symbol}
                for item in rows
            ],
            ttl_seconds=_CATALOG_SHARED_CACHE_SECONDS,
        )
        return list(rows)
    except Exception:
        if stale:
            logger.warning("CoinGecko catalog refresh failed; using stale catalog", exc_info=True)
            return stale
        raise


async def _search_catalog(query: str, limit: int) -> list[CryptoSearchResult]:
    alias_id = _PERSIAN_ALIASES.get(query.casefold())
    needle = (alias_id or query).casefold()
    compact = re.sub(r"[\s_\-]+", "", needle)
    matches: list[CryptoSearchResult] = []
    for item in await _coingecko_catalog():
        fields = (item.coin_id.casefold(), item.name.casefold(), item.symbol.casefold())
        compact_fields = tuple(re.sub(r"[\s_\-]+", "", field) for field in fields)
        if needle in fields or any(field.startswith(needle) for field in fields):
            matches.append(item)
        elif any(needle in field for field in fields) or (
            compact and any(compact in field for field in compact_fields)
        ):
            matches.append(item)
    matches.sort(key=lambda item: _search_sort_key(item, alias_id or query))
    return matches[:limit]


async def _binance_symbols() -> list[str]:
    global _BINANCE_SYMBOLS_CACHE
    now = time.monotonic()
    if _BINANCE_SYMBOLS_CACHE and now - _BINANCE_SYMBOLS_CACHE[0] < _BINANCE_SYMBOL_CACHE_SECONDS:
        return list(_BINANCE_SYMBOLS_CACHE[1])
    payload = await _get_json(f"{_BINANCE_BASE}/exchangeInfo")
    rows = payload.get("symbols", []) if isinstance(payload, dict) else []
    symbols = sorted(
        {
            str(row.get("symbol") or "").upper()
            for row in rows
            if isinstance(row, dict)
            and row.get("status") == "TRADING"
            and row.get("quoteAsset") == "USDT"
            and _SAFE_BINANCE_SYMBOL.fullmatch(str(row.get("symbol") or "").upper())
        }
    )
    _BINANCE_SYMBOLS_CACHE = (now, symbols)
    return symbols


async def _search_binance(query: str, limit: int) -> list[CryptoSearchResult]:
    normalized = re.sub(r"[^A-Za-z0-9]", "", query).upper()
    if not normalized:
        return []
    if normalized.endswith("USDT"):
        normalized = normalized[:-4]
    symbols = await _binance_symbols()
    exact = f"{normalized}USDT"
    matched = [symbol for symbol in symbols if symbol == exact]
    matched.extend(symbol for symbol in symbols if symbol != exact and symbol.startswith(normalized) and symbol.endswith("USDT"))
    results: list[CryptoSearchResult] = []
    for pair in matched[:limit]:
        base = pair[:-4]
        results.append(CryptoSearchResult(coin_id=f"bn-{pair.lower()}", name=base, symbol=base, source="Binance"))
    return results


async def search_crypto(query: str, *, limit: int = 8) -> list[CryptoSearchResult]:
    normalized = _normalize_query(query)
    limit = max(1, min(int(limit), 50))
    cache_key = normalized.casefold()
    cached = _SEARCH_CACHE.get(cache_key)
    if cached and time.monotonic() - cached[0] < _SEARCH_CACHE_SECONDS:
        return list(cached[1][:limit])

    results = _local_search(normalized)
    tasks = (
        _search_coingecko(normalized, limit),
        _search_catalog(normalized, limit),
        _search_binance(normalized, limit),
    )
    remote_batches = await asyncio.gather(*tasks, return_exceptions=True)
    for provider, batch in zip(("CoinGecko search", "CoinGecko catalog", "Binance"), remote_batches):
        if isinstance(batch, BaseException):
            logger.warning("%s failed: %s", provider, batch.__class__.__name__)
            continue
        results.extend(batch)

    deduplicated: dict[str, CryptoSearchResult] = {}
    for item in results:
        current = deduplicated.get(item.coin_id)
        if current is None or (
            current.market_cap_rank is None and item.market_cap_rank is not None
        ):
            deduplicated[item.coin_id] = item
    results = sorted(
        deduplicated.values(),
        key=lambda item: _search_sort_key(item, _PERSIAN_ALIASES.get(normalized.casefold()) or normalized),
    )[:limit]
    _remember_results(results)
    _SEARCH_CACHE[cache_key] = (time.monotonic(), list(results))
    return results


async def _fetch_coingecko_quote(coin_id: str) -> CryptoQuote:
    payload = await _get_json(
        f"{_COINGECKO_BASE}/coins/markets",
        params={
            "vs_currency": "usd",
            "ids": coin_id,
            "price_change_percentage": "24h",
            "precision": "full",
        },
    )
    if not isinstance(payload, list) or not payload or not isinstance(payload[0], dict):
        raise ValueError("ارز دیجیتال پیدا نشد")
    row = payload[0]
    price = _safe_float(row.get("current_price"))
    if price is None or price <= 0:
        raise RuntimeError("قیمت دریافتی نامعتبر بود")
    updated_raw = str(row.get("last_updated") or "")
    try:
        updated_at = datetime.fromisoformat(updated_raw.replace("Z", "+00:00")).astimezone(UTC)
    except ValueError:
        updated_at = datetime.now(UTC)
    return CryptoQuote(
        coin_id=coin_id,
        name=str(row.get("name") or coin_id)[:80],
        symbol=str(row.get("symbol") or "").upper()[:16],
        price_usd=price,
        change_24h=_safe_float(row.get("price_change_percentage_24h")),
        high_24h=_safe_float(row.get("high_24h")),
        low_24h=_safe_float(row.get("low_24h")),
        volume_24h=_safe_float(row.get("total_volume")),
        market_cap=_safe_float(row.get("market_cap")),
        market_cap_rank=_safe_int(row.get("market_cap_rank")),
        updated_at=updated_at,
        source="CoinGecko",
        quote_currency="USD",
        identity_verified=True,
        provider_asset_id=coin_id,
    )


def _quote_from_market_row(row: dict[str, Any]) -> CryptoQuote | None:
    coin_id = str(row.get("id") or "").strip().lower()
    price = _safe_float(row.get("current_price"))
    if not _SAFE_COIN_ID.fullmatch(coin_id) or price is None or price <= 0:
        return None
    updated_raw = str(row.get("last_updated") or "")
    try:
        updated_at = datetime.fromisoformat(updated_raw.replace("Z", "+00:00")).astimezone(UTC)
    except ValueError:
        updated_at = datetime.now(UTC)
    return CryptoQuote(
        coin_id=coin_id,
        name=str(row.get("name") or coin_id)[:80],
        symbol=str(row.get("symbol") or "").upper()[:20],
        price_usd=price,
        change_24h=_safe_float(row.get("price_change_percentage_24h")),
        high_24h=_safe_float(row.get("high_24h")),
        low_24h=_safe_float(row.get("low_24h")),
        volume_24h=_safe_float(row.get("total_volume")),
        market_cap=_safe_float(row.get("market_cap")),
        market_cap_rank=_safe_int(row.get("market_cap_rank")),
        updated_at=updated_at,
        source="CoinGecko",
        quote_currency="USD",
        identity_verified=True,
        provider_asset_id=coin_id,
    )


async def fetch_crypto_market_leaders(*, limit: int = 12, force: bool = False) -> list[CryptoQuote]:
    """Return market leaders without making one request per asset."""
    global _TOP_CACHE
    size = max(1, min(int(limit), 25))
    if (
        not force
        and _TOP_CACHE
        and time.monotonic() - _TOP_CACHE[0] < _SEARCH_CACHE_SECONDS
    ):
        return list(_TOP_CACHE[1][:size])
    payload = await _get_json(
        f"{_COINGECKO_BASE}/coins/markets",
        params={
            "vs_currency": "usd",
            "order": "market_cap_desc",
            "per_page": size,
            "page": 1,
            "sparkline": "false",
            "price_change_percentage": "24h",
            "precision": "full",
        },
    )
    rows = payload if isinstance(payload, list) else []
    quotes = [
        quote
        for row in rows
        if isinstance(row, dict)
        for quote in [_quote_from_market_row(row)]
        if quote is not None
    ]
    if not quotes:
        raise RuntimeError("فهرست برترین ارزها در دسترس نیست")
    _TOP_CACHE = (time.monotonic(), quotes)
    _remember_results(
        [
            CryptoSearchResult(
                coin_id=quote.coin_id,
                name=quote.name,
                symbol=quote.symbol,
                market_cap_rank=quote.market_cap_rank,
            )
            for quote in quotes
        ]
    )
    return list(quotes)


async def _fetch_binance_quote(
    pair: str,
    *,
    coin_id: str | None = None,
    name: str | None = None,
    identity_verified: bool = True,
) -> CryptoQuote:
    pair = pair.upper()
    if not _SAFE_BINANCE_SYMBOL.fullmatch(pair):
        raise ValueError("نماد ارز دیجیتال نامعتبر است")
    payload = await _get_json(f"{_BINANCE_BASE}/ticker/24hr", params={"symbol": pair})
    if not isinstance(payload, dict):
        raise RuntimeError("پاسخ سرویس قیمت نامعتبر بود")
    price = _safe_float(payload.get("lastPrice"))
    if price is None or price <= 0:
        raise ValueError("نماد ارز دیجیتال پیدا نشد")
    base = pair[:-4] if pair.endswith("USDT") else pair
    close_time = _safe_int(payload.get("closeTime"))
    updated_at = datetime.fromtimestamp(close_time / 1000, tz=UTC) if close_time else datetime.now(UTC)
    return CryptoQuote(
        coin_id=coin_id or f"bn-{pair.lower()}",
        name=name or base,
        symbol=base,
        price_usd=price,
        change_24h=_safe_float(payload.get("priceChangePercent")),
        high_24h=_safe_float(payload.get("highPrice")),
        low_24h=_safe_float(payload.get("lowPrice")),
        volume_24h=_safe_float(payload.get("quoteVolume")),
        market_cap=None,
        market_cap_rank=None,
        updated_at=updated_at,
        source="Binance Spot (USDT)",
        quote_currency="USDT",
        identity_verified=bool(identity_verified),
        provider_asset_id=pair,
    )


async def _fetch_coinbase_quote(
    symbol: str,
    *,
    coin_id: str,
    name: str,
) -> CryptoQuote:
    base = re.sub(r"[^A-Z0-9]", "", str(symbol or "").upper())
    if not _SAFE_BINANCE_SYMBOL.fullmatch(base):
        raise ValueError("نماد ارز دیجیتال نامعتبر است")
    payload = await _get_json(f"{_COINBASE_BASE}/products/{base}-USD/ticker")
    if not isinstance(payload, dict):
        raise RuntimeError("پاسخ سرویس قیمت نامعتبر بود")
    price = _safe_float(payload.get("price"))
    if price is None or price <= 0:
        raise ValueError("ارز دیجیتال در بازار دلاری پیدا نشد")
    updated_raw = str(payload.get("time") or "")
    try:
        updated_at = datetime.fromisoformat(updated_raw.replace("Z", "+00:00")).astimezone(UTC)
    except ValueError:
        updated_at = datetime.now(UTC)
    return CryptoQuote(
        coin_id=coin_id,
        name=name or base,
        symbol=base,
        price_usd=price,
        change_24h=None,
        high_24h=None,
        low_24h=None,
        volume_24h=_safe_float(payload.get("volume")),
        market_cap=None,
        market_cap_rank=None,
        updated_at=updated_at,
        source="Coinbase Exchange",
        quote_currency="USD",
        identity_verified=True,
        provider_asset_id=f"{base}-USD",
    )


async def _coin_hint(coin_id: str) -> CryptoSearchResult | None:
    hint = _COIN_HINTS.get(coin_id)
    if hint is not None:
        return hint
    try:
        for item in await _coingecko_catalog():
            if item.coin_id == coin_id:
                _COIN_HINTS[coin_id] = item
                return item
    except Exception:
        logger.warning("Could not resolve catalog hint for %s", coin_id)
    return None


async def fetch_crypto_quote(coin_id: str, *, force: bool = False) -> CryptoQuote:
    normalized = str(coin_id or "").strip().lower()
    if normalized.startswith("bn-"):
        pair = normalized[3:].upper()
        if not _SAFE_BINANCE_SYMBOL.fullmatch(pair):
            raise ValueError("نماد ارز دیجیتال نامعتبر است")
    elif not _SAFE_COIN_ID.fullmatch(normalized):
        raise ValueError("شناسه ارز دیجیتال نامعتبر است")

    cached = _QUOTE_CACHE.get(normalized)
    if not force and cached and time.monotonic() - cached[0] < _QUOTE_CACHE_SECONDS:
        return cached[1]

    if normalized.startswith("bn-"):
        quote = await _fetch_binance_quote(pair)
    else:
        errors: list[Exception] = []
        try:
            quote = await _fetch_coingecko_quote(normalized)
        except Exception as exc:
            errors.append(exc)
            hint = (
                None
                if normalized in _POPULAR_NAMES
                else await _coin_hint(normalized)
            )
            # Tickers are not globally unique. Only cross providers for assets
            # whose identity mapping is explicitly reviewed.
            symbol = _TRUSTED_PROVIDER_SYMBOLS.get(normalized, "")
            name = (
                _POPULAR_NAMES.get(normalized)
                or (hint.name if hint is not None else normalized)
            )
            fallback_quote: CryptoQuote | None = None
            if symbol:
                try:
                    fallback_quote = await _fetch_binance_quote(
                        f"{symbol}USDT",
                        coin_id=normalized,
                        name=name,
                        identity_verified=True,
                    )
                except Exception as binance_exc:
                    errors.append(binance_exc)
                    try:
                        fallback_quote = await _fetch_coinbase_quote(
                            symbol,
                            coin_id=normalized,
                            name=name,
                        )
                    except Exception as coinbase_exc:
                        errors.append(coinbase_exc)
            if fallback_quote is None:
                if errors and isinstance(errors[0], ValueError):
                    raise errors[0]
                if not symbol:
                    raise RuntimeError(
                        "Primary quote unavailable; no identity-verified exchange fallback exists for this asset"
                    ) from errors[-1]
                raise RuntimeError("قیمت این ارز فعلاً در منابع فعال پیدا نشد") from errors[-1]
            quote = fallback_quote
        if quote.coin_id != normalized:
            quote = replace(quote, coin_id=normalized)
    _QUOTE_CACHE[normalized] = (time.monotonic(), quote)
    return quote


async def compare_crypto_providers(coin_id: str) -> dict[str, Any]:
    """Compare identity-verified provider quotes for a selected asset."""
    normalized = str(coin_id or "").strip().lower()
    if normalized.startswith("bn-"):
        pair = normalized[3:].upper()
        quote = await _fetch_binance_quote(pair)
        return {
            "coin_id": normalized,
            "symbol": quote.symbol,
            "quotes": [quote],
            "spread_percent": 0.0,
            "reference_price": quote.price_usd,
            "provider_count": 1,
        }
    if not _SAFE_COIN_ID.fullmatch(normalized):
        raise ValueError("شناسه ارز دیجیتال نامعتبر است")

    hint = None if normalized in _POPULAR_NAMES else await _coin_hint(normalized)
    name = _POPULAR_NAMES.get(normalized) or (hint.name if hint else normalized)
    symbol = _TRUSTED_PROVIDER_SYMBOLS.get(normalized, "")
    tasks: list[Any] = [_fetch_coingecko_quote(normalized)]
    if symbol:
        tasks.extend(
            [
                _fetch_binance_quote(
                    f"{symbol}USDT",
                    coin_id=normalized,
                    name=name,
                    identity_verified=True,
                ),
                _fetch_coinbase_quote(
                    symbol,
                    coin_id=normalized,
                    name=name,
                ),
            ]
        )
    results = await asyncio.gather(*tasks, return_exceptions=True)
    quotes = [
        result
        for result in results
        if isinstance(result, CryptoQuote) and result.identity_verified
    ]
    if not quotes:
        raise RuntimeError("هیچ قیمت معتبر و دارای هویت تأییدشده‌ای دریافت نشد")
    prices = sorted(float(quote.price_usd) for quote in quotes)
    midpoint = prices[len(prices) // 2]
    spread = ((max(prices) - min(prices)) / midpoint * 100) if midpoint > 0 else 0.0
    return {
        "coin_id": normalized,
        "symbol": quotes[0].symbol,
        "quotes": quotes,
        "spread_percent": round(spread, 6),
        "reference_price": midpoint,
        "provider_count": len(quotes),
    }


def clear_crypto_cache_for_tests() -> None:
    global _BINANCE_SYMBOLS_CACHE, _COINGECKO_CATALOG_CACHE, _TOP_CACHE
    _SEARCH_CACHE.clear()
    _QUOTE_CACHE.clear()
    _COIN_HINTS.clear()
    _BINANCE_SYMBOLS_CACHE = None
    _COINGECKO_CATALOG_CACHE = None
    _TOP_CACHE = None
