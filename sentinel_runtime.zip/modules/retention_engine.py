from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.db import next_id
from core.utils import parse_dt, utc_iso

DEFAULT_RETENTION_SETTINGS: dict[str, Any] = {
    "enabled": True,
    "auto_send": False,
    "quiet_start": "22:30",
    "quiet_end": "08:00",
    "max_messages_per_day": 1,
    "max_messages_per_week": 3,
    "retry_minutes": 60,
    "max_attempts": 3,
    "inactive_days": 14,
    "abandoned_checkout_hours": 2,
    "vip_expiry_days": [7, 3, 1, 0],
}

MESSAGE_TEMPLATES = {
    "vip_expiring": (
        "⏳ اشتراک VIP شما رو به پایان است.\n"
        "برای حفظ دسترسی به سیگنال‌ها و کانال خصوصی، از بخش «مدیریت VIP» اشتراک را تمدید کنید."
    ),
    "inactive_vip": (
        "🛡 مدتی است از امکانات SENTINEL استفاده نکرده‌اید.\n"
        "سیگنال‌ها، ژورنال و ابزارهای مدیریت ریسک در حساب شما آماده‌اند."
    ),
    "abandoned_checkout": (
        "💳 سفارش VIP شما هنوز تکمیل نشده است.\n"
        "می‌توانید از بخش «سفارش‌های من» پرداخت را ادامه دهید یا با پشتیبانی در تماس باشید."
    ),
}


def retention_settings(db: dict[str, Any]) -> dict[str, Any]:
    settings = db.setdefault("retention_settings", {})
    if not isinstance(settings, dict):
        settings = {}
        db["retention_settings"] = settings
    for key, value in DEFAULT_RETENTION_SETTINGS.items():
        settings.setdefault(key, value)
    return settings


def _activity_map(db: dict[str, Any]) -> dict[str, datetime]:
    result: dict[str, datetime] = {}
    for row in db.get("user_activity", []):
        if not isinstance(row, dict):
            continue
        uid = str(row.get("user_id") or "")
        at = parse_dt(row.get("created_at"))
        if uid and at and (uid not in result or at > result[uid]):
            result[uid] = at
    for uid, user in (db.get("users", {}) or {}).items():
        if not isinstance(user, dict):
            continue
        at = parse_dt(user.get("last_seen_at") or user.get("updated_at"))
        if at and (str(uid) not in result or at > result[str(uid)]):
            result[str(uid)] = at
    return result


def retention_candidates(
    db: dict[str, Any],
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    settings = retention_settings(db)
    output: list[dict[str, Any]] = []
    users = db.get("users", {}) if isinstance(db.get("users"), dict) else {}
    vip = db.get("vip_users", {}) if isinstance(db.get("vip_users"), dict) else {}
    last_activity = _activity_map(db)
    expiry_buckets = sorted(
        {max(0, int(value)) for value in settings.get("vip_expiry_days", [7, 3, 1, 0])},
        reverse=True,
    )

    for uid, membership in vip.items():
        if not isinstance(membership, dict):
            continue
        uid_text = str(uid)
        expiry = parse_dt(membership.get("expires_at"))
        if expiry:
            days = max(0.0, (expiry - current).total_seconds() / 86400)
            matching = next((bucket for bucket in expiry_buckets if days <= bucket + 0.999), None)
            if expiry >= current and matching is not None:
                output.append(
                    {
                        "user_id": uid_text,
                        "reason": "vip_expiring",
                        "priority": "high",
                        "days": round(days, 1),
                        "expires_at": utc_iso(expiry),
                        "instance_key": f"vip_expiring:{uid_text}:{expiry.date().isoformat()}:{matching}",
                    }
                )

        if membership.get("active") or membership.get("status") == "active":
            reference = last_activity.get(uid_text) or parse_dt(
                membership.get("starts_at") or membership.get("created_at")
            )
            inactive_days = max(1, int(settings.get("inactive_days", 14) or 14))
            if reference and current - reference >= timedelta(days=inactive_days):
                period = current.date().isocalendar()
                output.append(
                    {
                        "user_id": uid_text,
                        "reason": "inactive_vip",
                        "priority": "medium",
                        "days": (current - reference).days,
                        "instance_key": f"inactive_vip:{uid_text}:{period.year}-W{period.week:02d}",
                    }
                )

    abandoned_after = timedelta(
        hours=max(1, int(settings.get("abandoned_checkout_hours", 2) or 2))
    )
    for order in db.get("vip_orders", []):
        if not isinstance(order, dict) or order.get("status") not in {
            "pending",
            "draft",
            "awaiting_payment",
        }:
            continue
        created = parse_dt(order.get("created_at"))
        uid = str(order.get("user_id") or "")
        order_id = str(order.get("order_id") or order.get("id") or "")
        if created and uid and order_id and current - created >= abandoned_after:
            output.append(
                {
                    "user_id": uid,
                    "reason": "abandoned_checkout",
                    "priority": "high",
                    "order_id": order_id,
                    "instance_key": f"abandoned_checkout:{order_id}",
                }
            )

    deduped: dict[str, dict[str, Any]] = {}
    for row in output:
        if row.get("user_id") in users:
            deduped[str(row["instance_key"])] = row
    return list(deduped.values())


def queue_retention_events(
    db: dict[str, Any],
    *,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    rows = db.setdefault("retention_events", [])
    existing = {
        str(row.get("instance_key") or "")
        for row in rows
        if isinstance(row, dict)
    }
    created: list[dict[str, Any]] = []
    for candidate in retention_candidates(db, now=current):
        instance_key = str(candidate["instance_key"])
        if instance_key in existing:
            continue
        event = {
            "id": next_id(db, "retention_event"),
            **candidate,
            "campaign_id": instance_key,
            "status": "pending",
            "attempts": 0,
            "created_at": utc_iso(current),
            "next_attempt_at": utc_iso(current),
            "sent_at": None,
            "error": None,
            "converted_at": None,
            "conversion_value": 0,
        }
        rows.append(event)
        created.append(event)
        existing.add(instance_key)
    db["retention_events"] = rows[-25_000:]
    return created


def _clock_minutes(value: Any, fallback: int) -> int:
    try:
        hour, minute = str(value).split(":", 1)
        return max(0, min(1439, int(hour) * 60 + int(minute)))
    except (TypeError, ValueError):
        return fallback


def _user_local_now(db: dict[str, Any], user_id: str, now: datetime) -> datetime:
    preferences = (db.get("user_notification_preferences", {}) or {}).get(user_id, {})
    timezone_name = str(preferences.get("timezone") or "Asia/Tehran")
    try:
        return now.astimezone(ZoneInfo(timezone_name))
    except ZoneInfoNotFoundError:
        return now


def _quiet_now(db: dict[str, Any], user_id: str, now: datetime) -> bool:
    settings = retention_settings(db)
    preferences = (db.get("user_notification_preferences", {}) or {}).get(user_id, {})
    start = _clock_minutes(
        preferences.get("quiet_start") or settings.get("quiet_start"),
        22 * 60 + 30,
    )
    end = _clock_minutes(
        preferences.get("quiet_end") or settings.get("quiet_end"),
        8 * 60,
    )
    local = _user_local_now(db, user_id, now)
    minute = local.hour * 60 + local.minute
    return start <= minute < end if start < end else minute >= start or minute < end


def claim_due_retention_events(
    db: dict[str, Any],
    *,
    now: datetime | None = None,
    limit: int = 50,
) -> list[dict[str, Any]]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    settings = retention_settings(db)
    if not settings.get("enabled", True) or not settings.get("auto_send", False):
        return []
    sent_rows = [
        row
        for row in db.get("retention_events", [])
        if isinstance(row, dict) and row.get("status") in {"sent", "converted"}
    ]
    claimed: list[dict[str, Any]] = []
    for row in db.get("retention_events", []):
        if len(claimed) >= max(1, int(limit)):
            break
        if not isinstance(row, dict) or row.get("status") not in {"pending", "retry"}:
            continue
        due_at = parse_dt(row.get("next_attempt_at") or row.get("created_at"))
        if due_at and due_at > current:
            continue
        uid = str(row.get("user_id") or "")
        if not uid or _quiet_now(db, uid, current):
            continue
        day_cutoff = current - timedelta(days=1)
        week_cutoff = current - timedelta(days=7)
        user_sent = [
            item
            for item in sent_rows
            if str(item.get("user_id") or "") == uid and parse_dt(item.get("sent_at"))
        ]
        daily = sum(1 for item in user_sent if parse_dt(item.get("sent_at")) >= day_cutoff)
        weekly = sum(1 for item in user_sent if parse_dt(item.get("sent_at")) >= week_cutoff)
        if daily >= int(settings.get("max_messages_per_day", 1) or 1):
            continue
        if weekly >= int(settings.get("max_messages_per_week", 3) or 3):
            continue
        row["status"] = "sending"
        row["claimed_at"] = utc_iso(current)
        row["attempts"] = int(row.get("attempts", 0) or 0) + 1
        claimed.append(dict(row))
    return claimed


def retention_message(event: dict[str, Any]) -> str:
    return MESSAGE_TEMPLATES.get(
        str(event.get("reason") or ""),
        "🔔 یک بروزرسانی جدید در حساب SENTINEL شما وجود دارد.",
    )


def mark_retention_delivery(
    db: dict[str, Any],
    event_id: int | str,
    *,
    success: bool,
    error: str = "",
    message_id: int | None = None,
    now: datetime | None = None,
) -> dict[str, Any]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    settings = retention_settings(db)
    target = str(event_id)
    for row in db.get("retention_events", []):
        if not isinstance(row, dict) or str(row.get("id")) != target:
            continue
        if success:
            row.update(
                {
                    "status": "sent",
                    "sent_at": utc_iso(current),
                    "message_id": message_id,
                    "error": None,
                }
            )
        else:
            attempts = int(row.get("attempts", 0) or 0)
            max_attempts = int(settings.get("max_attempts", 3) or 3)
            row["status"] = "failed" if attempts >= max_attempts else "retry"
            row["error"] = str(error or "delivery_failed")[:500]
            row["next_attempt_at"] = utc_iso(
                current
                + timedelta(minutes=max(5, int(settings.get("retry_minutes", 60) or 60)))
            )
        return row
    raise ValueError("رویداد نگهداشت پیدا نشد")


def record_retention_conversion(
    db: dict[str, Any],
    *,
    user_id: int | str,
    order_id: str,
    value: int = 0,
    now: datetime | None = None,
) -> list[dict[str, Any]]:
    current = (now or datetime.now(UTC)).astimezone(UTC)
    converted: list[dict[str, Any]] = []
    for row in db.get("retention_events", []):
        if not isinstance(row, dict) or str(row.get("user_id")) != str(user_id):
            continue
        if row.get("status") != "sent" or row.get("converted_at"):
            continue
        sent_at = parse_dt(row.get("sent_at"))
        if not sent_at or current - sent_at > timedelta(days=14):
            continue
        row["status"] = "converted"
        row["converted_at"] = utc_iso(current)
        row["conversion_order_id"] = str(order_id)
        row["conversion_value"] = max(0, int(value or 0))
        converted.append(row)
    return converted


def retention_summary(db: dict[str, Any]) -> dict[str, Any]:
    rows = [row for row in db.get("retention_events", []) if isinstance(row, dict)]
    statuses = Counter(str(row.get("status") or "unknown") for row in rows)
    reasons = Counter(str(row.get("reason") or "unknown") for row in rows)
    sent = statuses.get("sent", 0) + statuses.get("converted", 0)
    converted = statuses.get("converted", 0)
    return {
        "total": len(rows),
        "pending": statuses.get("pending", 0) + statuses.get("retry", 0),
        "sending": statuses.get("sending", 0),
        "sent": sent,
        "failed": statuses.get("failed", 0),
        "converted": converted,
        "conversion_rate": round(converted / max(1, sent) * 100, 4),
        "conversion_value": sum(int(row.get("conversion_value", 0) or 0) for row in rows),
        "by_reason": dict(reasons),
        "auto_send": bool(retention_settings(db).get("auto_send", False)),
    }

