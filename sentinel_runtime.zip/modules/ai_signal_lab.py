from __future__ import annotations

import copy
import math
from typing import Any, Awaitable, Callable

from core.db import with_db
from core.async_runtime import run_blocking
from core.utils import utc_iso
from modules.market_data import MarketRange, fetch_market_range
from modules.security_audit import append_security_audit

FetchRange = Callable[..., Awaitable[MarketRange]]
DEFAULT_TIMEFRAMES = ("15m", "1h")


def _finite(value: Any) -> float:
    number = float(value)
    if not math.isfinite(number) or number <= 0:
        raise ValueError("SIGNAL_LAB_PRICE_INVALID")
    return number


def create_strategy_version(
    db: dict[str, Any],
    *,
    name: str,
    rules: dict[str, Any],
    actor_id: int | str,
    status: str = "shadow",
) -> dict[str, Any]:
    root = db.setdefault("ai_signal_lab", {})
    versions = root.setdefault("strategies", [])
    clean_status = str(status or "shadow").lower()
    if clean_status not in {"draft", "shadow", "active", "archived"}:
        raise ValueError("SIGNAL_LAB_STRATEGY_STATUS_INVALID")
    clean_name = str(name or "").strip()[:120]
    if not clean_name:
        raise ValueError("SIGNAL_LAB_STRATEGY_NAME_REQUIRED")
    previous = [row for row in versions if isinstance(row, dict) and str(row.get("name")) == clean_name]
    version_number = max([int(row.get("version", 0) or 0) for row in previous] or [0]) + 1
    row = {
        "id": int(root.get("next_strategy_id", 1) or 1),
        "name": clean_name,
        "version": version_number,
        "status": clean_status,
        "rules": copy.deepcopy(rules or {}),
        "created_by": str(actor_id),
        "created_at": utc_iso(),
    }
    versions.append(row)
    root["next_strategy_id"] = row["id"] + 1
    append_security_audit(
        db, action="ai_signal_lab_strategy_created", actor_id=actor_id,
        details={"strategy_id": row["id"], "name": clean_name, "version": version_number, "status": clean_status},
        source="signal_lab",
    )
    return copy.deepcopy(row)


def queue_shadow_scan(
    db: dict[str, Any],
    *,
    strategy_id: int,
    symbols: list[str],
    actor_id: int | str,
    timeframes: list[str] | None = None,
) -> dict[str, Any]:
    root = db.setdefault("ai_signal_lab", {})
    strategy = next((row for row in root.setdefault("strategies", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == int(strategy_id)), None)
    if not strategy or str(strategy.get("status")) not in {"shadow", "active"}:
        raise ValueError("SIGNAL_LAB_STRATEGY_NOT_AVAILABLE")
    clean_symbols = list(dict.fromkeys(str(item or "").strip().upper() for item in symbols if str(item or "").strip()))[:25]
    if not clean_symbols:
        raise ValueError("SIGNAL_LAB_SYMBOLS_REQUIRED")
    clean_timeframes = list(dict.fromkeys(str(item or "").strip() for item in (timeframes or DEFAULT_TIMEFRAMES) if str(item or "").strip()))[:5]
    if not clean_timeframes:
        raise ValueError("SIGNAL_LAB_TIMEFRAMES_REQUIRED")
    row = {
        "id": int(root.get("next_run_id", 1) or 1),
        "strategy_id": int(strategy_id),
        "strategy_version": int(strategy.get("version", 1) or 1),
        "symbols": clean_symbols,
        "timeframes": clean_timeframes,
        "status": "pending",
        "mode": "shadow_only",
        "requested_by": str(actor_id),
        "created_at": utc_iso(),
    }
    root.setdefault("runs", []).append(row)
    root["next_run_id"] = row["id"] + 1
    append_security_audit(db, action="ai_signal_lab_scan_queued", actor_id=actor_id, details={"run_id": row["id"], "strategy_id": strategy_id, "symbols": clean_symbols}, source="signal_lab")
    return copy.deepcopy(row)


def _position_in_range(item: MarketRange) -> float:
    spread = max(item.high - item.low, item.close * 0.000001)
    return max(0.0, min(1.0, (item.close - item.low) / spread))


def _draft_candidate(symbol: str, ranges: dict[str, MarketRange], strategy: dict[str, Any]) -> dict[str, Any] | None:
    if not ranges or any(item.fallback or item.stale or item.confidence < 0.7 for item in ranges.values()):
        return None
    ordered = [ranges[key] for key in sorted(ranges)]
    positions = [_position_in_range(item) for item in ordered]
    rules = strategy.get("rules") if isinstance(strategy.get("rules"), dict) else {}
    buy_threshold = float(rules.get("buy_close_position", 0.65) or 0.65)
    sell_threshold = float(rules.get("sell_close_position", 0.35) or 0.35)
    if all(value >= buy_threshold for value in positions):
        side = "BUY"
    elif all(value <= sell_threshold for value in positions):
        side = "SELL"
    else:
        return None
    base = ordered[0]
    entry = _finite(base.close)
    range_size = max(_finite(base.high) - _finite(base.low), entry * 0.001)
    stop_multiplier = max(0.2, min(float(rules.get("stop_range_multiplier", 0.35) or 0.35), 2.0))
    minimum_rr = max(1.0, min(float(rules.get("minimum_rr", 2.0) or 2.0), 10.0))
    distance = range_size * stop_multiplier
    if side == "BUY":
        stop = entry - distance
        targets = [entry + distance * minimum_rr, entry + distance * (minimum_rr + 1.0)]
    else:
        stop = entry + distance
        targets = [entry - distance * minimum_rr, entry - distance * (minimum_rr + 1.0)]
    confidence = min(0.95, 0.55 + sum(abs(value - 0.5) for value in positions) / max(1, len(positions)))
    return {
        "symbol": symbol,
        "side": side,
        "entry": round(entry, 8),
        "stop": round(stop, 8),
        "targets": [round(item, 8) for item in targets],
        "risk_reward": minimum_rr,
        "confidence": round(confidence, 4),
        "timeframes": {key: value.as_dict() for key, value in ranges.items()},
        "status": "shadow_draft",
        "publication_allowed": False,
        "requires_admin_entry_stop_targets_confirmation": True,
        "disclaimer": "SHADOW_ONLY_NOT_A_TRADING_SIGNAL",
    }


def promote_candidate_to_review(
    db: dict[str, Any],
    *,
    candidate_id: int,
    actor_id: int | str,
    target: str = "public",
) -> dict[str, Any]:
    """Move one shadow-only candidate into the human signal approval queue.

    This function never publishes. Entry, stop and every target remain pending
    until the primary admin explicitly approves the generated approval record.
    """
    from modules.signal_safety import create_signal_approval

    root = db.setdefault("ai_signal_lab", {})
    candidate = next(
        (row for row in root.setdefault("candidates", [])
         if isinstance(row, dict) and int(row.get("id", 0) or 0) == int(candidate_id)),
        None,
    )
    if not candidate:
        raise ValueError("SIGNAL_LAB_CANDIDATE_NOT_FOUND")
    if candidate.get("status") != "shadow_draft":
        raise ValueError("SIGNAL_LAB_CANDIDATE_ALREADY_RESOLVED")
    if target not in {"public", "private", "both"}:
        raise ValueError("SIGNAL_LAB_TARGET_INVALID")

    payload = {
        "symbol": candidate["symbol"],
        "side": candidate["side"],
        "entry": candidate["entry"],
        "stop": candidate["stop"],
        "targets": list(candidate["targets"]),
        "risk_reward": candidate.get("risk_reward"),
        "note": "AI Signal Lab shadow candidate",
    }
    approval = create_signal_approval(
        db,
        payload=payload,
        target=target,
        requested_by=actor_id,
        source="gemini_signal_lab",
        review_requirements=["entry", "stop", "targets"],
    )
    candidate.update({
        "status": "admin_review",
        "approval_id": approval["id"],
        "promoted_by": str(actor_id),
        "promoted_at": utc_iso(),
    })
    append_security_audit(
        db,
        action="ai_signal_lab_candidate_promoted",
        actor_id=actor_id,
        details={"candidate_id": int(candidate_id), "approval_id": approval["id"], "target": target},
        source="signal_lab_human_review",
    )
    return {"candidate": copy.deepcopy(candidate), "approval": copy.deepcopy(approval)}


async def process_shadow_scan(run_id: int, *, fetcher: FetchRange = fetch_market_range) -> dict[str, Any]:
    snapshot: dict[str, Any] = {}
    def claim(db: dict[str, Any]) -> dict[str, Any]:
        root = db.setdefault("ai_signal_lab", {})
        run = next((row for row in root.setdefault("runs", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == int(run_id)), None)
        if not run:
            raise ValueError("SIGNAL_LAB_RUN_NOT_FOUND")
        if run.get("status") != "pending":
            raise ValueError("SIGNAL_LAB_RUN_NOT_PENDING")
        strategy = next((row for row in root.setdefault("strategies", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == int(run.get("strategy_id", 0) or 0)), None)
        if not strategy:
            raise ValueError("SIGNAL_LAB_STRATEGY_NOT_FOUND")
        run.update({"status": "running", "started_at": utc_iso()})
        return {"run": copy.deepcopy(run), "strategy": copy.deepcopy(strategy)}
    snapshot = await run_blocking(with_db, claim, timeout=20)
    run = snapshot["run"]
    candidates: list[dict[str, Any]] = []
    failures: list[dict[str, str]] = []
    for symbol in run.get("symbols", []):
        ranges: dict[str, MarketRange] = {}
        try:
            for timeframe in run.get("timeframes", []):
                ranges[str(timeframe)] = await fetcher(str(symbol), interval=str(timeframe), limit=20, snapshot_fallback=False)
            draft = _draft_candidate(str(symbol), ranges, snapshot["strategy"])
            if draft:
                candidates.append(draft)
        except Exception as exc:
            failures.append({"symbol": str(symbol), "error": exc.__class__.__name__, "detail": str(exc)[:300]})
    def finish(db: dict[str, Any]) -> dict[str, Any]:
        root = db.setdefault("ai_signal_lab", {})
        stored_run = next(row for row in root.setdefault("runs", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == int(run_id))
        stored: list[dict[str, Any]] = []
        for candidate in candidates:
            row = {
                "id": int(root.get("next_candidate_id", 1) or 1),
                "run_id": int(run_id),
                "strategy_id": int(stored_run.get("strategy_id", 0) or 0),
                "strategy_version": int(stored_run.get("strategy_version", 0) or 0),
                **copy.deepcopy(candidate),
                "created_at": utc_iso(),
            }
            root.setdefault("candidates", []).append(row)
            root["next_candidate_id"] = row["id"] + 1
            stored.append(copy.deepcopy(row))
        stored_run.update({"status": "completed", "completed_at": utc_iso(), "candidate_count": len(stored), "failures": failures})
        append_security_audit(db, action="ai_signal_lab_scan_completed", actor_id=stored_run.get("requested_by", "system"), details={"run_id": run_id, "candidate_count": len(stored), "failure_count": len(failures)}, source="signal_lab")
        return {"run": copy.deepcopy(stored_run), "candidates": stored, "failures": failures}
    return await run_blocking(with_db, finish, timeout=20)


async def process_pending_shadow_scans(*, limit: int = 3, fetcher: FetchRange = fetch_market_range) -> list[dict[str, Any]]:
    from core.db import read_db_sections
    db = await run_blocking(read_db_sections, ("ai_signal_lab",), timeout=10)
    root = db.get("ai_signal_lab") if isinstance(db.get("ai_signal_lab"), dict) else {}
    pending = [int(row.get("id", 0) or 0) for row in root.get("runs", []) if isinstance(row, dict) and row.get("status") == "pending"][: max(1, min(limit, 10))]
    results = []
    for run_id in pending:
        try:
            results.append(await process_shadow_scan(run_id, fetcher=fetcher))
        except Exception as exc:
            error_name = exc.__class__.__name__
            error_detail = str(exc)[:500]

            def fail(
                db2: dict[str, Any],
                *,
                captured_name: str = error_name,
                captured_detail: str = error_detail,
            ) -> None:
                root2 = db2.setdefault("ai_signal_lab", {})
                row = next((item for item in root2.setdefault("runs", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == run_id), None)
                if row:
                    row.update(
                        {
                            "status": "failed",
                            "completed_at": utc_iso(),
                            "error": captured_name,
                            "detail": captured_detail,
                        }
                    )
            await run_blocking(with_db, fail, timeout=20)
    return results
