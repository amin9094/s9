"""Deterministic native-price entry choices approved in the October session."""

from __future__ import annotations

from decimal import Decimal as D, ROUND_CEILING, ROUND_FLOOR

from modules.canonical_market import price


def inside_tick(desired, low, high, tick_size, direction):
    desired, low, high, tick = map(price, (desired, low, high, tick_size))
    if direction not in {"BUY", "SELL"} or low > high or not low <= desired <= high:
        raise ValueError("ENTRY_ORIGINAL_ZONE_INVALID")
    lower = (low / tick).to_integral_value(rounding=ROUND_CEILING) * tick
    upper = (high / tick).to_integral_value(rounding=ROUND_FLOOR) * tick
    if lower > upper:
        raise ValueError("ORIGINAL_ZONE_HAS_NO_EXECUTABLE_TICK")
    down = (desired / tick).to_integral_value(rounding=ROUND_FLOOR) * tick
    up = (desired / tick).to_integral_value(rounding=ROUND_CEILING) * tick
    choices = {min(upper, max(lower, down)), min(upper, max(lower, up))}
    # On an exact tie choose the approach-side price: BUY higher, SELL lower.
    return min(choices, key=lambda p: (abs(p - desired), -p if direction == "BUY" else p))


def fvg_entry(low, high, *, direction, tick_size, pip_size=None):
    low, high, tick = map(price, (low, high, tick_size))
    midpoint = (low + high) / 2
    offset = D(".01")  # Absolute price units, never a percentage of price.
    if pip_size is not None:
        offset = min(offset, price(pip_size) * 2)
    # Research convention: more than 5% of full gap is no longer "very little".
    # In that case the approved fallback is the original midpoint.
    if offset > (high - low) * D(".05"):
        offset = D(0)
    desired = midpoint + (offset if direction == "BUY" else -offset)
    entry = inside_tick(desired, low, high, tick, direction)
    if pip_size is not None and abs(entry - midpoint) > price(pip_size) * 2:
        entry = inside_tick(midpoint, low, high, tick, direction)
        if abs(entry - midpoint) > price(pip_size) * 2:
            raise ValueError("FOREX_ENTRY_GRID_EXCEEDS_TWO_PIP_LIMIT")
        offset = D(0)
    return entry, {
        "selector": "FVG_MIDPOINT_SMALL_OFFSET", "original_midpoint": str(midpoint),
        "requested_offset": str(offset), "requested_price": str(desired), "entry": str(entry),
        "tick_size": str(tick), "pip_size": str(pip_size) if pip_size is not None else None,
        "offset_basis": "ABSOLUTE_PRICE_UNITS", "large_offset_fallback": "ORIGINAL_MIDPOINT",
        "large_offset_gap_fraction": ".05", "is_spread_protection_guarantee": False,
    }
