"""Source-bound market evidence. Display bars and verified quotes are distinct."""

from __future__ import annotations

from dataclasses import asdict, dataclass
from decimal import Decimal, InvalidOperation

TIMEFRAMES = {
    "1m": 60_000,
    "5m": 300_000,
    "15m": 900_000,
    "30m": 1_800_000,
    "1h": 3_600_000,
    "4h": 14_400_000,
    "1d": 86_400_000,
}
ANALYSIS_TIMEFRAMES = frozenset({"5m", "1h"})


def price(value) -> Decimal:
    try:
        result = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError):
        raise ValueError("INVALID_MARKET_PRICE") from None
    if not result.is_finite() or result <= 0:
        raise ValueError("INVALID_MARKET_PRICE")
    return result


@dataclass(frozen=True, slots=True)
class Candle:
    symbol: str
    provider: str
    venue: str
    product: str
    timeframe: str
    start_ms: int
    end_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal | None
    volume_kind: str
    is_closed: bool
    available_ms: int
    source_id: str
    quality_flags: tuple[str, ...] = ()
    alignment_offset_ms: int = 0

    def __post_init__(self):
        duration = TIMEFRAMES.get(self.timeframe)
        if (
            not duration
            or not 0 <= self.alignment_offset_ms < duration
            or self.end_ms - self.start_ms != duration
            or (self.start_ms - self.alignment_offset_ms) % duration
        ):
            raise ValueError("CANDLE_BOUNDARY_INVALID")
        for field in ("open", "high", "low", "close"):
            object.__setattr__(self, field, price(getattr(self, field)))
        if not self.low <= min(self.open, self.close) <= max(self.open, self.close) <= self.high:
            raise ValueError("CANDLE_OHLC_INVALID")
        if self.volume is not None:
            volume = Decimal(str(self.volume))
            if not volume.is_finite() or volume < 0 or self.volume_kind not in {"traded", "tick_proxy"}:
                raise ValueError("CANDLE_VOLUME_INVALID")
            object.__setattr__(self, "volume", volume)
        elif self.volume_kind != "unavailable":
            raise ValueError("CANDLE_VOLUME_PROVENANCE_MISSING")
        if self.is_closed and self.available_ms < self.end_ms:
            raise ValueError("CANDLE_CLOSE_NOT_AVAILABLE")
        if not all((self.provider, self.venue, self.product, self.source_id)):
            raise ValueError("CANDLE_SOURCE_MISSING")

    def as_dict(self):
        result = asdict(self)
        for field in ("open", "high", "low", "close", "volume"):
            result[field] = str(result[field]) if result[field] is not None else None
        return result

    @classmethod
    def from_dict(cls, data):
        row = dict(data)
        row["quality_flags"] = tuple(row.get("quality_flags") or ())
        return cls(**row)

    def chart_bar(self):
        row = {
            "timestamp": self.start_ms,
            "open": float(self.open),
            "high": float(self.high),
            "low": float(self.low),
            "close": float(self.close),
        }
        if self.volume is not None:
            row["volume"] = float(self.volume)
        return row


@dataclass(frozen=True, slots=True)
class Quote:
    symbol: str
    provider: str
    venue: str
    product: str
    event_ms: int
    received_ms: int
    bid: Decimal
    ask: Decimal
    tick_size: Decimal
    source_id: str
    quality_flags: tuple[str, ...] = ()

    def __post_init__(self):
        for field in ("bid", "ask", "tick_size"):
            object.__setattr__(self, field, price(getattr(self, field)))
        if self.ask < self.bid:
            raise ValueError("QUOTE_SPREAD_REVERSED")
        if self.event_ms <= 0 or self.event_ms > self.received_ms + 1000:
            raise ValueError("QUOTE_TIMESTAMP_INVALID")
        if not all((self.provider, self.venue, self.product, self.source_id)):
            raise ValueError("QUOTE_SOURCE_MISSING")

    def fresh(self, now_ms, max_age_ms=5000):
        return not self.quality_flags and 0 <= now_ms - self.event_ms <= max_age_ms

    def as_dict(self):
        return {**asdict(self), "bid": str(self.bid), "ask": str(self.ask), "tick_size": str(self.tick_size)}


def validate_series(candles: list[Candle], *, now_ms: int, allow_open=True):
    previous = None
    for bar in candles:
        if bar.start_ms > now_ms + 1000 or bar.available_ms > now_ms + 1000:
            raise ValueError("CANDLE_FUTURE_TIMESTAMP")
        if not allow_open and not bar.is_closed:
            raise ValueError("CANDLE_NOT_CLOSED")
        if previous:
            if (bar.symbol, bar.provider, bar.venue, bar.product, bar.timeframe) != (
                previous.symbol,
                previous.provider,
                previous.venue,
                previous.product,
                previous.timeframe,
            ):
                raise ValueError("CANDLE_MIXED_MARKETS")
            if bar.start_ms <= previous.start_ms:
                raise ValueError("CANDLE_DUPLICATE_OR_OUT_OF_ORDER")
        previous = bar
    return candles
