from __future__ import annotations

from collections import Counter
from datetime import timedelta
from typing import Any

from core.utils import parse_dt, utc_iso, utc_now
from modules.growth_link_lab import growth_link_lab
from modules.user_intelligence import build_user_profile


def _rows(value: Any) -> list[dict[str, Any]]:
    return [row for row in value if isinstance(row, dict)] if isinstance(value, list) else []


def _amount(value: Any) -> int:
    try:
        return max(0, int(float(str(value or 0).replace(",", ""))))
    except (TypeError, ValueError):
        return 0


def _approved_at(row: dict[str, Any]):
    return parse_dt(row.get("approved_at") or row.get("reviewed_at") or row.get("created_at"))


def commercial_dashboard(db: dict[str, Any]) -> dict[str, Any]:
    """Board-level commercial KPIs built only from recorded transactions."""
    now = utc_now()
    current_start = now - timedelta(days=30)
    previous_start = now - timedelta(days=60)
    users = db.get("users", {}) if isinstance(db.get("users"), dict) else {}
    vip_orders = [row for row in _rows(db.get("vip_orders")) if str(row.get("status")) == "approved"]
    edu_orders = [row for row in _rows(db.get("education_orders")) if str(row.get("status")) == "approved"]
    all_orders = [*vip_orders, *edu_orders]

    def window(rows: list[dict[str, Any]], start, end) -> list[dict[str, Any]]:
        return [row for row in rows if (stamp := _approved_at(row)) is not None and start <= stamp <= end]

    current_orders = window(all_orders, current_start, now)
    previous_orders = window(all_orders, previous_start, current_start)
    current_revenue = sum(_amount(row.get("price")) for row in current_orders)
    previous_revenue = sum(_amount(row.get("price")) for row in previous_orders)
    revenue_change = (
        (current_revenue - previous_revenue) / previous_revenue * 100
        if previous_revenue
        else (100.0 if current_revenue else 0.0)
    )

    profiles = [build_user_profile(db, uid, now=now) for uid in users]
    personas = Counter(str(row.get("behavior_persona") or "explorer") for row in profiles)
    active_vip = sum(1 for row in profiles if row.get("vip_active"))
    expiring_vip = sum(
        1
        for row in profiles
        if row.get("vip_active")
        and (expiry := parse_dt(row.get("vip_expires_at"))) is not None
        and expiry <= now + timedelta(days=7)
    )
    current_vip_orders = window(vip_orders, current_start, now)
    current_buyers = {str(row.get("user_id")) for row in current_vip_orders}
    returning_buyers = {
        uid
        for uid, count in Counter(str(row.get("user_id")) for row in vip_orders).items()
        if count >= 2
    }
    new_users_30d = sum(
        1
        for row in users.values()
        if isinstance(row, dict)
        and (stamp := parse_dt(row.get("created_at"))) is not None
        and stamp >= current_start
    )

    link_lab = growth_link_lab(db, attribution_model="last_touch")
    link_totals = link_lab.get("totals", {})
    campaign_map = db.get("marketing_campaigns", {})
    campaigns = [row for row in campaign_map.values() if isinstance(row, dict)] if isinstance(campaign_map, dict) else []
    active_campaigns = sum(1 for row in campaigns if str(row.get("status")) in {"active", "scheduled"})
    discount_map = db.get("discount_codes", {})
    if not isinstance(discount_map, dict):
        discount_map = {}
    coupon_redemptions = sum(
        int(row.get("used_count", 0) or 0)
        for row in discount_map.values()
        if isinstance(row, dict) and row.get("campaign_id")
    )

    return {
        "generated_at": utc_iso(now),
        "period_days": 30,
        "revenue": {
            "current": current_revenue,
            "previous": previous_revenue,
            "change_percent": round(revenue_change, 2),
            "orders": len(current_orders),
            "average_order_value": round(current_revenue / max(1, len(current_orders))),
            "arpu": round(current_revenue / max(1, len(users))),
        },
        "vip": {
            "active": active_vip,
            "expiring_7d": expiring_vip,
            "buyers_30d": len(current_buyers),
            "repeat_buyers_all": len(returning_buyers),
            "conversion_30d": round(len(current_buyers) / max(1, new_users_30d) * 100, 2),
        },
        "growth": {
            "new_users_30d": new_users_30d,
            "links": int(link_totals.get("links", 0) or 0),
            "joins": int(link_totals.get("unique_joins", 0) or 0),
            "attributed_orders": int(link_totals.get("approved_orders", 0) or 0),
            "attributed_revenue": int(link_totals.get("revenue", 0) or 0),
            "cost": int(link_totals.get("cost", 0) or 0),
            "cac": float(link_totals.get("cac", 0) or 0),
            "roas": float(link_totals.get("roas", 0) or 0),
            "roi": float(link_totals.get("roi", 0) or 0),
        },
        "campaigns": {
            "total": len(campaigns),
            "active": active_campaigns,
            "coupon_redemptions": coupon_redemptions,
            "top_links": link_lab.get("links", [])[:5],
        },
        "crm": {
            "personas": dict(personas),
            "high_intent": sum(1 for row in profiles if int(row.get("purchase_intent_score", 0) or 0) >= 60),
            "at_risk": sum(1 for row in profiles if int(row.get("churn_risk_score", 0) or 0) >= 60),
            "engaged": sum(1 for row in profiles if int(row.get("engagement_score", 0) or 0) >= 50),
        },
    }
