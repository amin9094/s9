from __future__ import annotations

import csv
import io
import math
from decimal import Decimal
from typing import Any

from core.db import next_id
from core.utils import parse_finite_float, utc_iso
from modules.admin_control_center import module_state as control_module_state
from modules.prices import normalize_market_symbol

VISIBLE_JOURNAL_STATUSES = {"open", "partial", "closed", "cancelled"}
JOURNAL_REASON_TYPES = {"channel_signal", "personal_analysis", "other", "imported"}

CHANNEL_JOURNAL_SOURCES = {"channel_signal", "signal_taken", "telegram_bot", "miniapp"}


def _journal_signal_key(row: dict[str, Any]) -> str:
    signal_id = row.get("signal_id")
    source = str(row.get("source") or "").strip().lower()
    reason_type = str(row.get("entry_reason_type") or "").strip().lower()
    if signal_id in (None, "") or (source not in CHANNEL_JOURNAL_SOURCES and reason_type != "channel_signal"):
        return ""
    return f"signal:{signal_id}"


def _journal_row_priority(row: dict[str, Any]) -> tuple[int, int, int, str, int]:
    status = str(row.get("status") or "open").lower()
    return (
        1 if str(row.get("external_id") or "").strip() else 0,
        1 if row.get("position_id") not in (None, "") else 0,
        2 if status == "closed" else 1 if status == "partial" else 0,
        str(row.get("updated_at") or row.get("closed_at") or row.get("created_at") or ""),
        int(row.get("id", 0) or 0),
    )


def _dedupe_visible_journal_rows(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Return one visible row per channel signal without changing manual trades."""
    selected: dict[str, dict[str, Any]] = {}
    independent: list[dict[str, Any]] = []
    for row in rows:
        key = _journal_signal_key(row)
        if not key:
            independent.append(row)
            continue
        current = selected.get(key)
        if current is None or _journal_row_priority(row) > _journal_row_priority(current):
            selected[key] = row
    return independent + list(selected.values())


def reconcile_signal_journal_duplicates(db: dict[str, Any], user_id: int | str) -> int:
    """Archive historical duplicate channel-signal rows and preserve final outcome."""
    ensure_portfolio(db)
    rows = [row for row in db["trade_journal"].setdefault(str(user_id), []) if isinstance(row, dict)]
    groups: dict[str, list[dict[str, Any]]] = {}
    for row in rows:
        if str(row.get("status") or "") in {"archived", "voided"}:
            continue
        key = _journal_signal_key(row)
        if key:
            groups.setdefault(key, []).append(row)
    repaired = 0
    now = utc_iso()
    outcome_fields = (
        "status", "exit_price", "remaining_volume", "pnl_percent", "pnl_amount",
        "result_r", "fees", "commission", "swap", "closed_at", "note",
    )
    for duplicates in groups.values():
        if len(duplicates) < 2:
            continue
        canonical = max(duplicates, key=_journal_row_priority)
        outcome = max(duplicates, key=lambda row: (
            1 if str(row.get("status") or "") == "closed" else 0,
            str(row.get("updated_at") or row.get("closed_at") or row.get("created_at") or ""),
        ))
        for field in outcome_fields:
            if outcome.get(field) not in (None, ""):
                canonical[field] = outcome.get(field)
        for row in duplicates:
            if row is canonical:
                continue
            row["status"] = "archived"
            row["archived_at"] = now
            row["void_reason"] = "duplicate_channel_signal"
            row["updated_at"] = now
            _entry_audit(row, "archived_duplicate", {"canonical_id": canonical.get("id")})
            repaired += 1
        canonical["updated_at"] = now
        _entry_audit(canonical, "duplicates_reconciled", {"archived": repaired})
    return repaired


def calculate_r_multiple(
    side: str,
    entry_price: float | None,
    stop_price: float | None,
    exit_price: float | None,
) -> float | None:
    """Return the realised R multiple from entry, initial stop and exit."""
    if entry_price is None or stop_price is None or exit_price is None:
        return None
    try:
        entry = parse_finite_float(str(entry_price))
        stop = parse_finite_float(str(stop_price))
        exit_value = parse_finite_float(str(exit_price))
    except (TypeError, ValueError, OverflowError):
        return None
    risk_unit = abs(entry - stop)
    if not math.isfinite(risk_unit) or risk_unit <= 1e-12:
        return None
    normalized = str(side or "").upper()
    if normalized not in {"BUY", "LONG", "SELL", "SHORT"}:
        return None
    reward = exit_value - entry if normalized in {"BUY", "LONG"} else entry - exit_value
    result = reward / risk_unit
    return round(result, 6) if math.isfinite(result) else None


def normalize_journal_reason(reason_type: str, reason: str, *, signal_id: int | str | None = None) -> tuple[str, str]:
    kind = str(reason_type or "").strip().lower() or ("channel_signal" if signal_id not in {None, ""} else "personal_analysis")
    if kind not in JOURNAL_REASON_TYPES:
        kind = "other"
    text = str(reason or "").strip()
    if not text:
        if kind == "channel_signal":
            text = f"سیگنال کانال #{signal_id}" if signal_id not in {None, ""} else "سیگنال کانال"
        elif kind == "personal_analysis":
            text = "تحلیل شخصی"
        elif kind == "imported":
            text = "ورودی از فایل یا بروکر"
        else:
            text = "سایر"
    return kind, text[:500]


def ensure_portfolio(db: dict[str, Any]) -> None:
    db.setdefault("user_watchlists", {})
    db.setdefault("trade_journal", {})
    db.setdefault("journal_admin_notes", {})


def watchlist_for_user(db: dict[str, Any], user_id: int | str) -> list[dict[str, Any]]:
    ensure_portfolio(db)
    rows = db["user_watchlists"].setdefault(str(user_id), [])
    normalized: list[dict[str, Any]] = []
    for value in rows:
        if isinstance(value, dict):
            symbol = normalize_market_symbol(str(value.get("symbol") or ""))
            if not symbol:
                continue
            value.setdefault("created_at", utc_iso())
            value["symbol"] = symbol
            value.setdefault("alerts_enabled", True)
            normalized.append(value)
        else:
            symbol = normalize_market_symbol(str(value or ""))
            if symbol:
                normalized.append({"symbol": symbol, "created_at": utc_iso(), "alerts_enabled": True})
    deduped = {item["symbol"]: item for item in normalized}
    rows[:] = list(deduped.values())
    return rows


def toggle_watchlist_symbol(db: dict[str, Any], user_id: int | str, symbol: str) -> tuple[bool, dict[str, Any] | None]:
    settings = control_module_state(db, "watchlists")
    if not bool(settings.get("enabled", True)):
        raise ValueError("WATCHLIST_DISABLED")
    try:
        clean = normalize_market_symbol(symbol)
    except ValueError as exc:
        raise ValueError("INVALID_SYMBOL") from exc
    if not clean or len(clean) > 20:
        raise ValueError("INVALID_SYMBOL")
    rows = watchlist_for_user(db, user_id)
    existing = next((item for item in rows if item.get("symbol") == clean), None)
    if existing:
        rows.remove(existing)
        return False, existing
    maximum = max(1, int(settings.get("max_assets", 30) or 30))
    if len(rows) >= maximum:
        raise ValueError("WATCHLIST_LIMIT_REACHED")
    item = {"symbol": clean, "created_at": utc_iso(), "alerts_enabled": True}
    rows.append(item)
    return True, item


def remove_watchlist_symbol(db: dict[str, Any], user_id: int | str, symbol: str) -> bool:
    try:
        clean = normalize_market_symbol(symbol)
    except ValueError as exc:
        raise ValueError("INVALID_SYMBOL") from exc
    rows = watchlist_for_user(db, user_id)
    before = len(rows)
    rows[:] = [item for item in rows if str(item.get("symbol") or "") != clean]
    return len(rows) != before


def set_watchlist_alerts(db: dict[str, Any], user_id: int | str, symbol: str, enabled: bool) -> dict[str, Any]:
    try:
        clean = normalize_market_symbol(symbol)
    except ValueError as exc:
        raise ValueError("INVALID_SYMBOL") from exc
    item = next((row for row in watchlist_for_user(db, user_id) if row.get("symbol") == clean), None)
    if not item:
        raise ValueError("WATCHLIST_ITEM_NOT_FOUND")
    item["alerts_enabled"] = bool(enabled)
    item["updated_at"] = utc_iso()
    return item


def clear_watchlist(db: dict[str, Any], user_id: int | str) -> int:
    rows = watchlist_for_user(db, user_id)
    count = len(rows)
    rows.clear()
    return count


def journal_entries(
    db: dict[str, Any], user_id: int | str, *, limit: int = 100, include_archived: bool = False
) -> list[dict[str, Any]]:
    ensure_portfolio(db)
    rows = db["trade_journal"].setdefault(str(user_id), [])
    valid = [
        item for item in rows if isinstance(item, dict)
        and (include_archived or str(item.get("status") or "open") not in {"archived", "voided"})
    ]
    if not include_archived:
        valid = _dedupe_visible_journal_rows(valid)
    valid.sort(key=lambda item: (str(item.get("created_at") or ""), int(item.get("id", 0) or 0)), reverse=True)
    return valid[: max(1, min(int(limit), 5000))]


def find_journal_entry(
    db: dict[str, Any], user_id: int | str, entry_id: int | str, *, include_archived: bool = True
) -> dict[str, Any] | None:
    try:
        target = int(entry_id)
    except (TypeError, ValueError):
        return None
    return next(
        (row for row in journal_entries(db, user_id, limit=5000, include_archived=include_archived)
         if int(row.get("id", 0) or 0) == target),
        None,
    )


def _entry_audit(row: dict[str, Any], event: str, payload: dict[str, Any] | None = None) -> None:
    audit = row.setdefault("audit", [])
    if not isinstance(audit, list):
        audit = []
        row["audit"] = audit
    audit.append({"event": event, "payload": dict(payload or {}), "created_at": utc_iso()})
    row["audit"] = audit[-200:]


def add_journal_entry(
    db: dict[str, Any],
    user_id: int | str,
    *,
    symbol: str,
    side: str = "",
    signal_id: int | str | None = None,
    entry_price: float | None = None,
    volume: float | None = None,
    note: str = "",
    status: str = "open",
    account_id: int | str | None = None,
    position_id: int | str | None = None,
    planned_entry: float | None = None,
    actual_stop: float | None = None,
    setup: str = "",
    emotion: str = "",
    tags: list[str] | None = None,
    screenshot_id: str = "",
    source: str = "manual",
    external_id: str = "",
    broker: str = "",
    opened_at: str | None = None,
    entry_reason_type: str = "",
    entry_reason: str = "",
    result_r: float | None = None,
) -> dict[str, Any]:
    # Validate before settings initialization, ID allocation or journal writes.
    entry_price = None if entry_price is None else parse_finite_float(str(entry_price))
    planned_entry = None if planned_entry is None else parse_finite_float(str(planned_entry))
    actual_stop = None if actual_stop is None else parse_finite_float(str(actual_stop))
    volume = None if volume is None else parse_finite_float(str(volume))
    result_r = None if result_r is None else parse_finite_float(str(result_r))
    settings = control_module_state(db, "journal")
    if not bool(settings.get("enabled", True)):
        raise ValueError("JOURNAL_DISABLED")
    rows = journal_entries(db, user_id, limit=5000, include_archived=True)
    maximum = max(1, int(settings.get("max_entries", 1000) or 1000))
    if len(rows) >= maximum:
        raise ValueError("JOURNAL_LIMIT_REACHED")
    clean_symbol = normalize_market_symbol(symbol)
    if not clean_symbol or len(clean_symbol) > 20:
        raise ValueError("INVALID_SYMBOL")
    clean_side = str(side or "").upper()
    if clean_side not in {"", "BUY", "SELL", "LONG", "SHORT"}:
        raise ValueError("INVALID_TRADE_SIDE")
    if status not in {"open", "partial", "closed", "cancelled", "archived", "voided"}:
        raise ValueError("INVALID_JOURNAL_STATUS")
    now = utc_iso()
    reason_type, reason_text = normalize_journal_reason(entry_reason_type, entry_reason, signal_id=signal_id)
    initial_risk_unit = None
    reference_entry = entry_price if entry_price is not None else planned_entry
    if reference_entry is not None and actual_stop is not None:
        initial_risk_unit = abs(float(reference_entry) - float(actual_stop)) or None
        if initial_risk_unit is not None and not math.isfinite(initial_risk_unit):
            raise ValueError("INVALID_JOURNAL_RISK")
    entry = {
        "id": next_id(db, "journal_entry"),
        "user_id": str(user_id),
        "account_id": int(account_id) if account_id not in {None, ""} else None,
        "position_id": int(position_id) if position_id not in {None, ""} else None,
        "signal_id": int(signal_id) if signal_id not in {None, ""} else None,
        "symbol": clean_symbol,
        "side": clean_side,
        "planned_entry": None if planned_entry is None else float(planned_entry),
        "entry_price": None if entry_price is None else float(entry_price),
        "actual_entry": None if entry_price is None else float(entry_price),
        "actual_stop": None if actual_stop is None else float(actual_stop),
        "exit_price": None,
        "volume": None if volume is None else float(volume),
        "remaining_volume": None if volume is None else float(volume),
        "pnl_percent": None,
        "pnl_amount": None,
        "fees": 0.0,
        "commission": 0.0,
        "swap": 0.0,
        "mae": None,
        "mfe": None,
        "status": status,
        "setup": str(setup or "")[:100],
        "emotion": str(emotion or "")[:100],
        "tags": [str(value)[:40] for value in (tags or []) if str(value).strip()][:20],
        "screenshot_id": str(screenshot_id or "")[:200],
        "note": str(note or "")[:2000],
        "source": str(source or "manual")[:50],
        "entry_reason_type": reason_type,
        "entry_reason": reason_text,
        "initial_risk_unit": initial_risk_unit,
        "result_r": None if result_r is None else round(float(result_r), 6),
        "external_id": str(external_id or "")[:200],
        "broker": str(broker or "")[:100],
        "created_at": str(opened_at or now),
        "updated_at": now,
        "closed_at": None,
        "archived_at": None,
        "void_reason": "",
        "partial_closes": [],
        "audit": [],
    }
    _entry_audit(entry, "created", {"source": "miniapp"})
    db["trade_journal"].setdefault(str(user_id), []).append(entry)
    return entry


def ensure_signal_journal_entry(
    db: dict[str, Any], user_id: int | str, signal: dict[str, Any], *, position: dict[str, Any] | None = None
) -> dict[str, Any]:
    signal_id = int(signal.get("id", 0) or 0)
    position_id = int(position.get("id", 0) or 0) if isinstance(position, dict) else 0
    existing = next(
        (
            row for row in journal_entries(db, user_id, limit=5000, include_archived=True)
            if (position_id and int(row.get("position_id", 0) or 0) == position_id)
            or (not position_id and int(row.get("signal_id", 0) or 0) == signal_id and row.get("status") not in {"voided", "archived"})
        ),
        None,
    )
    if existing:
        return existing
    if position:
        return add_journal_entry(
            db,
            user_id,
            symbol=str(position.get("symbol") or signal.get("symbol") or ""),
            side=str(position.get("side") or signal.get("side") or ""),
            signal_id=signal_id,
            account_id=position.get("account_id"),
            position_id=position.get("id"),
            planned_entry=position.get("planned_entry"),
            entry_price=position.get("actual_entry"),
            actual_stop=position.get("actual_stop"),
            volume=position.get("actual_volume"),
            note=f"ثبت خودکار از سیگنال #{signal.get('display_number') or signal_id}",
            source="channel_signal",
            entry_reason_type="channel_signal",
            entry_reason=f"سیگنال کانال #{signal.get('display_number') or signal_id}",
        )
    from modules.trading_os import parse_signal_entries

    parsed = parse_signal_entries(signal)
    return add_journal_entry(
        db,
        user_id,
        symbol=str(signal.get("symbol") or ""),
        side=str(signal.get("side") or ""),
        signal_id=signal_id,
        planned_entry=parsed.get("planned_entry"),
        entry_price=parsed.get("planned_entry"),
        actual_stop=signal.get("stop") or signal.get("stop_loss") or signal.get("sl"),
        note=f"ثبت خودکار از سیگنال #{signal.get('display_number') or signal_id}",
        source="channel_signal",
        entry_reason_type="channel_signal",
        entry_reason=f"سیگنال کانال #{signal.get('display_number') or signal_id}",
    )


def void_signal_journal_entry(
    db: dict[str, Any], user_id: int | str, signal_id: int | str, *, reason: str = "signal_choice_changed"
) -> int:
    count = 0
    for row in journal_entries(db, user_id, limit=5000, include_archived=True):
        if int(row.get("signal_id", 0) or 0) != int(signal_id):
            continue
        if str(row.get("status")) in {"closed", "archived", "voided"}:
            continue
        row["status"] = "voided"
        row["void_reason"] = str(reason)[:200]
        row["updated_at"] = utc_iso()
        _entry_audit(row, "voided", {"reason": reason})
        count += 1
    return count


def link_position_journal(
    db: dict[str, Any], user_id: int | str, position_id: int | str, journal_entry_id: int | str
) -> dict[str, Any] | None:
    from modules.trading_os import find_position

    position = find_position(db, user_id, position_id)
    if not position:
        return None
    position["journal_entry_id"] = int(journal_entry_id)
    position["updated_at"] = utc_iso()
    return position


def sync_journal_from_position(
    db: dict[str, Any], user_id: int | str, position: dict[str, Any]
) -> dict[str, Any] | None:
    entry = None
    journal_id = position.get("journal_entry_id")
    if journal_id not in {None, ""}:
        entry = find_journal_entry(db, user_id, journal_id)
    if not entry:
        entry = next(
            (row for row in journal_entries(db, user_id, limit=5000, include_archived=True)
             if int(row.get("position_id", 0) or 0) == int(position.get("id", 0) or 0)),
            None,
        )
    if not entry:
        return None
    entry["actual_entry"] = position.get("actual_entry")
    entry["entry_price"] = position.get("actual_entry")
    entry["actual_stop"] = position.get("actual_stop")
    entry["volume"] = position.get("actual_volume")
    fraction_remaining = (
        float(position.get("remaining_risk_percent") or 0) / max(float(position.get("actual_risk_percent") or 0), 1e-12)
    )
    entry["remaining_volume"] = round(float(position.get("actual_volume") or 0) * max(0.0, min(1.0, fraction_remaining)), 8)
    entry["pnl_amount"] = position.get("realized_pnl_amount")
    entry["pnl_percent"] = position.get("realized_pnl_percent")
    entry["fees"] = position.get("fees", 0.0)
    entry["commission"] = position.get("commission", 0.0)
    entry["swap"] = position.get("swap", 0.0)
    entry["partial_closes"] = list(position.get("partial_closes") or [])
    if str(position.get("status")) == "closed":
        entry["status"] = "closed"
        entry["closed_at"] = position.get("closed_at") or utc_iso()
        entry["exit_price"] = position.get("exit_price")
        entry["result_r"] = calculate_r_multiple(
            str(entry.get("side") or ""), entry.get("actual_entry") or entry.get("entry_price"),
            entry.get("actual_stop"), entry.get("exit_price"),
        )
    elif str(position.get("status")) == "partial":
        entry["status"] = "partial"
    elif str(position.get("status")) == "voided":
        entry["status"] = "voided"
        entry["void_reason"] = position.get("void_reason") or "position_voided"
    else:
        entry["status"] = "open"
    entry["updated_at"] = utc_iso()
    _entry_audit(entry, "synced_from_position", {"position_status": position.get("status")})
    return entry


def sync_position_from_journal(
    db: dict[str, Any], user_id: int | str, journal: dict[str, Any]
) -> dict[str, Any] | None:
    position_id = journal.get("position_id")
    if position_id in {None, ""}:
        return None
    from modules.trading_os import find_position

    position = find_position(db, user_id, position_id)
    if not position:
        return None
    position["realized_pnl_amount"] = float(journal.get("pnl_amount") or 0)
    position["realized_pnl_percent"] = float(journal.get("pnl_percent") or 0)
    position["fees"] = float(journal.get("fees") or 0)
    position["commission"] = float(journal.get("commission") or 0)
    position["swap"] = float(journal.get("swap") or 0)
    position["exit_price"] = journal.get("exit_price")
    position["remaining_risk_percent"] = 0.0
    position["remaining_risk_money"] = 0.0
    position["status"] = "closed"
    position["closed_at"] = journal.get("closed_at") or utc_iso()
    position["updated_at"] = utc_iso()
    return position


def update_journal_result(
    db: dict[str, Any],
    user_id: int | str,
    entry_id: int | str,
    *,
    pnl_percent: float = 0.0,
    result_r: float | None = None,
    exit_price: float | None = None,
    pnl_amount: float | None = None,
    note: str | None = None,
    fees: float = 0.0,
    commission: float = 0.0,
    swap: float = 0.0,
    mae: float | None = None,
    mfe: float | None = None,
    closed_at: str | None = None,
) -> dict[str, Any]:
    row = find_journal_entry(db, user_id, entry_id)
    if not row:
        raise ValueError("JOURNAL_ENTRY_NOT_FOUND")
    value = parse_finite_float(str(pnl_percent))
    if not -1000 <= value <= 100000:
        raise ValueError("INVALID_PNL_PERCENT")
    exit_price = None if exit_price is None else parse_finite_float(str(exit_price))
    pnl_amount = None if pnl_amount is None else parse_finite_float(str(pnl_amount))
    computed_r = None if result_r is None else parse_finite_float(str(result_r))
    fees, commission, swap = (parse_finite_float(str(v or 0)) for v in (fees, commission, swap))
    mae = None if mae is None else parse_finite_float(str(mae))
    mfe = None if mfe is None else parse_finite_float(str(mfe))
    if computed_r is None:
        computed_r = calculate_r_multiple(
            str(row.get("side") or ""),
            row.get("actual_entry") if row.get("actual_entry") is not None else row.get("entry_price"),
            row.get("actual_stop"),
            exit_price,
        )
    row["pnl_percent"] = round(value, 6)
    row["exit_price"] = exit_price
    row["pnl_amount"] = None if pnl_amount is None else round(pnl_amount, 6)
    row["result_r"] = None if computed_r is None else round(float(computed_r), 6)
    row["fees"] = round(float(fees or 0), 6)
    row["commission"] = round(float(commission or 0), 6)
    row["swap"] = round(float(swap or 0), 6)
    row["mae"] = None if mae is None else float(mae)
    row["mfe"] = None if mfe is None else float(mfe)
    row["remaining_volume"] = 0.0
    row["status"] = "closed"
    row["closed_at"] = str(closed_at or utc_iso())
    row["updated_at"] = utc_iso()
    if note is not None:
        row["note"] = str(note)[:2000]
    _entry_audit(row, "closed", {"pnl_percent": value, "pnl_amount": pnl_amount, "result_r": row.get("result_r")})
    return row


def add_partial_close(
    db: dict[str, Any], user_id: int | str, entry_id: int | str, *, volume: float, exit_price: float, pnl_amount: float
) -> dict[str, Any]:
    row = find_journal_entry(db, user_id, entry_id)
    if not row or row.get("status") not in {"open", "partial"}:
        raise ValueError("JOURNAL_ENTRY_NOT_OPEN")
    remaining = parse_finite_float(str(row.get("remaining_volume") if row.get("remaining_volume") is not None else row.get("volume") or 0))
    close_volume = parse_finite_float(str(volume))
    exit_price = parse_finite_float(str(exit_price))
    pnl_amount = parse_finite_float(str(pnl_amount))
    total_pnl = parse_finite_float(str(row.get("pnl_amount") or 0)) + pnl_amount
    if not math.isfinite(total_pnl):
        raise ValueError("INVALID_PARTIAL_PNL")
    if close_volume <= 0 or close_volume > remaining:
        raise ValueError("INVALID_PARTIAL_VOLUME")
    partial = {
        "volume": close_volume,
        "exit_price": float(exit_price),
        "pnl_amount": float(pnl_amount),
        "created_at": utc_iso(),
    }
    row.setdefault("partial_closes", []).append(partial)
    row["remaining_volume"] = round(remaining - close_volume, 8)
    row["pnl_amount"] = round(total_pnl, 6)
    row["status"] = "partial" if row["remaining_volume"] > 0 else "closed"
    row["updated_at"] = utc_iso()
    if row["status"] == "closed":
        row["closed_at"] = row["updated_at"]
    _entry_audit(row, "partial_close", partial)
    return row


def delete_journal_entry(db: dict[str, Any], user_id: int | str, entry_id: int | str) -> bool:
    """Backward-compatible name: immutable journal rows are archived, never deleted."""
    row = find_journal_entry(db, user_id, entry_id)
    if not row:
        return False
    if row.get("status") == "archived":
        return False
    row["status"] = "archived"
    row["archived_at"] = utc_iso()
    row["updated_at"] = row["archived_at"]
    _entry_audit(row, "archived")
    return True


def add_journal_admin_note(db: dict[str, Any], user_id: int | str, admin_id: int | str, text: str) -> dict[str, Any]:
    ensure_portfolio(db)
    clean = str(text or "").strip()
    if not clean:
        raise ValueError("EMPTY_NOTE")
    row = {"id": next_id(db, "journal_admin_note"), "admin_id": str(admin_id), "text": clean[:2000], "created_at": utc_iso()}
    db["journal_admin_notes"].setdefault(str(user_id), []).append(row)
    return row


def _stats_for_rows(rows: list[dict[str, Any]]) -> dict[str, Any]:
    visible = [row for row in rows if str(row.get("status")) in VISIBLE_JOURNAL_STATUSES]
    closed = []
    invalid_numeric_rows = 0
    numeric_fields = ("pnl_percent", "pnl_amount", "result_r", "fees", "commission", "swap")
    for row in visible:
        if row.get("status") != "closed" or (row.get("pnl_percent") is None and row.get("result_r") is None):
            continue
        try:
            values = {key: None if row.get(key) in (None, "") else parse_finite_float(str(row[key])) for key in numeric_fields}
            if values["pnl_percent"] is not None and not -1000 <= values["pnl_percent"] <= 100000:
                raise ValueError("INVALID_PNL_PERCENT")
        except (TypeError, ValueError, OverflowError):
            invalid_numeric_rows += 1
            continue
        closed.append({**row, **values})

    def decimal_value(row: dict[str, Any], key: str) -> Decimal:
        return Decimal(str(row.get(key) or 0))

    def json_number(value: Decimal) -> float | None:
        number = float(value)
        return number if math.isfinite(number) else None

    r_rows = [row for row in closed if row.get("result_r") is not None]
    wins = [row for row in closed if float(row.get("result_r") if row.get("result_r") is not None else row.get("pnl_percent", 0) or 0) > 0]
    losses = [row for row in closed if float(row.get("result_r") if row.get("result_r") is not None else row.get("pnl_percent", 0) or 0) < 0]
    pnl_sum = sum((decimal_value(row, "pnl_percent") for row in closed), Decimal(0))
    pnl_amount = sum((decimal_value(row, "pnl_amount") for row in closed), Decimal(0))
    costs = sum((decimal_value(row, key) for row in closed for key in ("fees", "commission", "swap")), Decimal(0))
    r_net = sum((decimal_value(row, "result_r") for row in r_rows), Decimal(0))
    r_won = sum((max(Decimal(0), decimal_value(row, "result_r")) for row in r_rows), Decimal(0))
    r_lost = abs(sum((min(Decimal(0), decimal_value(row, "result_r")) for row in r_rows), Decimal(0)))
    equity = Decimal(100)
    peak = equity
    max_drawdown = Decimal(0)
    for row in sorted(closed, key=lambda item: str(item.get("closed_at") or item.get("updated_at") or "")):
        equity *= 1 + decimal_value(row, "pnl_percent") / 100
        peak = max(peak, equity)
        if peak > 0:
            max_drawdown = max(max_drawdown, (peak - equity) / peak * 100)
    return {
        "total": len(visible), "open": sum(1 for row in visible if row.get("status") in {"open", "partial"}),
        "closed": len(closed), "wins": len(wins), "losses": len(losses),
        "win_rate": len(wins) / max(1, len(closed)) * 100,
        "pnl_sum": json_number(pnl_sum), "pnl_amount": json_number(pnl_amount), "costs": json_number(costs),
        "equity_index": json_number(equity), "max_drawdown": json_number(max_drawdown),
        "r_count": len(r_rows), "r_net": json_number(r_net), "r_won": json_number(r_won), "r_lost": json_number(r_lost),
        "avg_r": json_number(r_net / max(1, len(r_rows))),
        "profit_factor_r": json_number((r_won / r_lost) if r_lost > Decimal("1e-12") else r_won),
        "invalid_numeric_rows": invalid_numeric_rows,
        "channel_signal_entries": sum(1 for row in visible if row.get("entry_reason_type") == "channel_signal" or row.get("source") == "channel_signal"),
        "personal_entries": sum(1 for row in visible if row.get("entry_reason_type") != "channel_signal" and row.get("source") != "channel_signal"),
    }


def journal_stats(db: dict[str, Any], user_id: int | str) -> dict[str, Any]:
    return _stats_for_rows(journal_entries(db, user_id, limit=5000))


def journal_csv(db: dict[str, Any], user_id: int | str) -> bytes:
    output = io.StringIO()
    fields = [
        "id", "account_id", "position_id", "signal_id", "source", "entry_reason_type", "entry_reason", "external_id", "broker", "symbol", "side", "planned_entry", "entry_price",
        "actual_stop", "initial_risk_unit", "exit_price", "volume", "remaining_volume", "result_r", "pnl_percent", "pnl_amount", "fees",
        "commission", "swap", "mae", "mfe", "setup", "emotion", "tags", "status", "note", "created_at", "closed_at",
    ]
    writer = csv.writer(output)
    writer.writerow(fields)
    for row in journal_entries(db, user_id, limit=5000, include_archived=True):
        writer.writerow(["|".join(row.get(key, [])) if key == "tags" else row.get(key) for key in fields])
    return output.getvalue().encode("utf-8-sig")


def import_journal_csv(db: dict[str, Any], user_id: int | str, content: str) -> dict[str, Any]:
    reader = csv.DictReader(io.StringIO(str(content or "")))
    imported = 0
    errors: list[dict[str, Any]] = []
    for index, row in enumerate(reader, start=2):
        try:
            add_journal_entry(
                db, user_id,
                symbol=str(row.get("symbol") or ""),
                side=str(row.get("side") or ""),
                entry_price=float(row["entry_price"]) if row.get("entry_price") else None,
                volume=float(row["volume"]) if row.get("volume") else None,
                note=str(row.get("note") or ""),
                setup=str(row.get("setup") or ""),
                emotion=str(row.get("emotion") or ""),
                tags=str(row.get("tags") or "").split("|") if row.get("tags") else [],
                entry_reason_type=str(row.get("entry_reason_type") or row.get("source") or "imported"),
                entry_reason=str(row.get("entry_reason") or ""),
                result_r=float(row["result_r"]) if row.get("result_r") else None,
            )
            imported += 1
        except (ValueError, TypeError) as exc:
            errors.append({"row": index, "error": str(exc)})
    return {"imported": imported, "errors": errors[:100]}


def portfolio_admin_summary(db: dict[str, Any]) -> dict[str, Any]:
    ensure_portfolio(db)
    watchlists = db.get("user_watchlists", {})
    journals = db.get("trade_journal", {})
    return {
        "watchlist_users": sum(1 for rows in watchlists.values() if isinstance(rows, list) and rows),
        "watchlist_assets": sum(len(rows) for rows in watchlists.values() if isinstance(rows, list)),
        "journal_users": sum(1 for rows in journals.values() if isinstance(rows, list) and rows),
        "journal_entries": sum(len(rows) for rows in journals.values() if isinstance(rows, list)),
        "open_journal_entries": sum(
            1 for rows in journals.values() if isinstance(rows, list) for row in rows
            if isinstance(row, dict) and row.get("status") in {"open", "partial"}
        ),
    }


def watchlist_by_market(db: dict[str, Any], user_id: int | str, market_category: str) -> list[dict[str, Any]]:
    from modules.market_scope import classify_market_symbol, normalize_market_category
    category = normalize_market_category(market_category)
    return [row for row in watchlist_for_user(db, user_id) if classify_market_symbol(row.get("symbol")) == category]


def clear_watchlist_market(db: dict[str, Any], user_id: int | str, market_category: str) -> int:
    from modules.market_scope import classify_market_symbol, normalize_market_category
    category = normalize_market_category(market_category)
    rows = watchlist_for_user(db, user_id)
    before = len(rows)
    rows[:] = [row for row in rows if classify_market_symbol(row.get("symbol")) != category]
    return before - len(rows)


def journal_entries_by_market(db: dict[str, Any], user_id: int | str, market_category: str, *, limit: int = 100) -> list[dict[str, Any]]:
    from modules.market_scope import classify_market_symbol, normalize_market_category
    category = normalize_market_category(market_category)
    return [row for row in journal_entries(db, user_id, limit=5000) if classify_market_symbol(row.get("symbol")) == category][: max(1, min(int(limit), 5000))]


def journal_stats_by_market(db: dict[str, Any], user_id: int | str, market_category: str) -> dict[str, Any]:
    return _stats_for_rows(journal_entries_by_market(db, user_id, market_category, limit=5000))


def journal_csv_by_market(db: dict[str, Any], user_id: int | str, market_category: str) -> bytes:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(["id", "signal_id", "market", "source", "entry_reason_type", "entry_reason", "symbol", "side", "entry_price", "actual_stop", "exit_price", "volume", "result_r", "pnl_percent", "pnl_amount", "status", "note", "created_at", "closed_at"])
    for row in journal_entries_by_market(db, user_id, market_category, limit=5000):
        writer.writerow([row.get("id"), row.get("signal_id"), market_category, row.get("source"), row.get("entry_reason_type"), row.get("entry_reason"), row.get("symbol"), row.get("side"), row.get("entry_price"), row.get("actual_stop"), row.get("exit_price"), row.get("volume"), row.get("result_r"), row.get("pnl_percent"), row.get("pnl_amount"), row.get("status"), row.get("note"), row.get("created_at"), row.get("closed_at")])
    return output.getvalue().encode("utf-8-sig")
