from __future__ import annotations

import abc
import hashlib
import hmac
import json
import os
import re
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any
from urllib.parse import quote

import httpx

from modules.data_confidence import DataConfidenceService


def authorized_account_reference(user_id: int | str, account_id: str) -> str:
    """Only operator-owned configuration may bind a private broker account."""
    try:
        bindings = json.loads(os.getenv("BROKER_READONLY_ACCOUNT_BINDINGS", "{}"))
        if not isinstance(bindings, dict):
            raise ValueError("BROKER_BINDINGS_INVALID")
        owners = {}
        for uid, accounts in bindings.items():
            if not str(uid).isdigit() or not isinstance(accounts, dict):
                raise ValueError("BROKER_BINDINGS_INVALID")
            for aid, reference in accounts.items():
                if not isinstance(reference, str) or not reference.strip():
                    raise ValueError("BROKER_BINDINGS_INVALID")
                ref = reference.strip()
                owner = (str(uid), str(aid))
                if ref in owners and owners[ref] != owner:
                    raise ValueError("BROKER_BINDING_NOT_UNIQUE")
                owners[ref] = owner
        row = bindings.get(str(user_id), {})
        reference = str(row.get(str(account_id)) or "").strip()
        if not reference:
            raise ValueError("BROKER_ACCOUNT_NOT_AUTHORIZED")
        return reference
    except (TypeError, json.JSONDecodeError) as exc:
        raise ValueError("BROKER_BINDINGS_INVALID") from exc


@dataclass(frozen=True)
class BrokerSnapshot:
    provider: str
    account_reference: str
    balance: float
    equity: float
    floating_pnl: float
    positions: tuple[dict[str, Any], ...]
    observed_at: str
    confidence: float


class ReadOnlyBrokerAdapter(abc.ABC):
    """Contract deliberately excludes order placement and account mutation."""

    @abc.abstractmethod
    def fetch_snapshot(self, account_reference: str, *, user_id: int | str | None = None) -> BrokerSnapshot:
        raise NotImplementedError


class HttpBrokerSnapshotAdapter(ReadOnlyBrokerAdapter):
    """Read-only adapter for a private MT5/broker bridge.

    The bridge must expose only GET snapshot endpoints. Requests are signed with
    HMAC and the response timestamp is checked to avoid replaying stale account
    state into the risk engine.
    """

    def __init__(self, *, base_url: str | None = None, api_key: str | None = None, secret: str | None = None):
        self.base_url = str(base_url or os.getenv("BROKER_READONLY_BASE_URL") or "").rstrip("/")
        self.api_key = str(api_key or os.getenv("BROKER_READONLY_API_KEY") or "")
        self.secret = str(secret or os.getenv("BROKER_READONLY_SECRET") or "")
        if not self.base_url or not self.api_key or not self.secret:
            raise RuntimeError("read-only broker connector is not configured")

    def fetch_snapshot(self, account_reference: str, *, user_id: int | str | None = None) -> BrokerSnapshot:
        clean_reference = str(account_reference or "").strip()
        if (
            not 1 <= len(clean_reference) <= 96
            or not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9._:@-]*", clean_reference)
            or ".." in clean_reference
        ):
            raise ValueError("BROKER_ACCOUNT_REFERENCE_INVALID")
        encoded_reference = quote(clean_reference, safe="")
        timestamp = str(int(datetime.now(UTC).timestamp()))
        path = f"/v1/accounts/{encoded_reference}/snapshot"
        signature = hmac.new(self.secret.encode(), f"GET\n{path}\n{timestamp}".encode(), hashlib.sha256).hexdigest()
        owner_headers = {}
        if user_id is not None:
            if not str(user_id).isdigit():
                raise ValueError("BROKER_OWNER_INVALID")
            owner_headers = {"X-Telegram-User-ID": str(user_id), "X-Owner-Signature": hmac.new(
                self.secret.encode(), f"GET\n{path}\n{timestamp}\n{user_id}".encode(), hashlib.sha256).hexdigest()}
        with httpx.Client(timeout=10, follow_redirects=False) as client:
            response = client.get(
                self.base_url + path,
                headers={"X-API-Key": self.api_key, "X-Timestamp": timestamp, "X-Signature": signature, "Accept": "application/json", **owner_headers},
            )
            response.raise_for_status()
            payload = response.json()
        if not isinstance(payload, dict):
            raise ValueError("BROKER_RESPONSE_INVALID")
        if payload.get("account_reference") not in (None, clean_reference):
            raise ValueError("BROKER_ACCOUNT_REFERENCE_MISMATCH")
        if user_id is not None and payload.get("user_id") not in (None, str(user_id), int(user_id)):
            raise ValueError("BROKER_OWNER_MISMATCH")
        observed = str(payload.get("observed_at") or "")
        try:
            parsed = datetime.fromisoformat(observed.replace("Z", "+00:00"))
            if parsed.tzinfo is None:
                parsed = parsed.replace(tzinfo=UTC)
        except Exception as exc:
            raise ValueError("BROKER_TIMESTAMP_INVALID") from exc
        age = (datetime.now(UTC) - parsed.astimezone(UTC)).total_seconds()
        if age < -60 or age > 120:
            raise ValueError("BROKER_DATA_STALE")
        positions = payload.get("positions") if isinstance(payload.get("positions"), list) else []
        # Reject any accidental trading capability in a provider response.
        forbidden = {"order_endpoint", "trade_token", "place_order", "modify_order"}
        if forbidden & payload.keys():
            raise ValueError("BROKER_READONLY_CONTRACT_VIOLATION")
        return BrokerSnapshot(
            provider=str(payload.get("provider") or "broker"),
            account_reference=clean_reference,
            balance=float(payload.get("balance") or 0),
            equity=float(payload.get("equity") or 0),
            floating_pnl=float(payload.get("floating_pnl") or 0),
            positions=tuple(dict(row) for row in positions if isinstance(row, dict)),
            observed_at=parsed.astimezone(UTC).isoformat(),
            confidence=min(1.0, max(0.0, float(payload.get("confidence") or 0.98))),
        )


def record_broker_snapshot(account_id: str, snapshot: BrokerSnapshot, confidence: DataConfidenceService | None = None) -> None:
    service = confidence or DataConfidenceService()
    for field, value in (("balance", snapshot.balance), ("equity", snapshot.equity), ("floating_pnl", snapshot.floating_pnl)):
        service.record(
            entity_type="trading_account", entity_id=str(account_id), field_name=field, value=value,
            source="broker", provider=snapshot.provider, observed_at=snapshot.observed_at,
            ttl_seconds=180, confidence=snapshot.confidence,
        )
