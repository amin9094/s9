from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime, timedelta
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso

MAX_LINK_EVENTS = 250_000


def _safe_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value if value is not None else default).replace(",", "").strip())
    except (TypeError, ValueError):
        return default


def _normalize_link(value: Any) -> str:
    return str(value or "").strip().rstrip("/")


def channel_link_by_id(db: dict[str, Any], link_id: int | str) -> dict[str, Any] | None:
    target = str(link_id or "")
    return next(
        (
            row
            for row in db.setdefault("public_channel_links", [])
            if isinstance(row, dict) and str(row.get("id")) == target
        ),
        None,
    )


def channel_link_by_url(db: dict[str, Any], invite_link: str) -> dict[str, Any] | None:
    target = _normalize_link(invite_link)
    return next(
        (
            row
            for row in db.setdefault("public_channel_links", [])
            if isinstance(row, dict) and _normalize_link(row.get("invite_link")) == target
        ),
        None,
    )


def register_public_channel_link(
    db: dict[str, Any],
    *,
    name: str,
    invite_link: str,
    created_by: int | str,
    channel_id: int | str,
    campaign_id: str = "",
    expires_at: str | datetime | None = None,
    member_limit: int = 0,
    attribution_window_days: int = 30,
    advertiser: str = "",
    source: str = "",
    medium: str = "",
    creative: str = "",
    cost: int = 0,
) -> dict[str, Any]:
    clean_name = " ".join(str(name or "").strip().split())
    if not 3 <= len(clean_name) <= 80:
        raise ValueError("نام لینک باید بین ۳ تا ۸۰ نویسه باشد.")
    clean_url = _normalize_link(invite_link)
    if not clean_url.startswith(("https://t.me/", "https://telegram.me/", "tg://")):
        raise ValueError("لینک دعوت تلگرام معتبر نیست.")
    if channel_link_by_url(db, clean_url):
        raise ValueError("این لینک قبلاً ثبت شده است.")
    expiry = expires_at.astimezone(UTC) if isinstance(expires_at, datetime) else parse_dt(expires_at)
    now = utc_iso()
    row = {
        "id": next_id(db, "public_channel_link"),
        "name": clean_name,
        "invite_link": clean_url,
        "channel_id": str(channel_id),
        "campaign_id": str(campaign_id or ""),
        "advertiser": " ".join(str(advertiser or "").strip().split())[:100],
        "source": " ".join(str(source or "").strip().split())[:100],
        "medium": " ".join(str(medium or "").strip().split())[:80],
        "creative": " ".join(str(creative or "").strip().split())[:120],
        "cost": max(0, _safe_int(cost)),
        "status": "active",
        "member_limit": max(0, min(99_999, int(member_limit or 0))),
        "attribution_window_days": max(1, min(365, int(attribution_window_days or 30))),
        "expires_at": utc_iso(expiry) if expiry else None,
        "join_count": 0,
        "unique_join_count": 0,
        "rejoin_count": 0,
        "leave_count": 0,
        "active_members": 0,
        "created_at": now,
        "created_by": str(created_by),
        "updated_at": now,
        "revoked_at": None,
        "revoked_by": None,
    }
    db.setdefault("public_channel_links", []).append(row)
    return row


def mark_public_channel_link_revoked(
    db: dict[str, Any],
    link_id: int | str,
    *,
    actor_id: int | str,
) -> dict[str, Any]:
    row = channel_link_by_id(db, link_id)
    if row is None:
        raise ValueError("لینک پیدا نشد.")
    row["status"] = "revoked"
    row["revoked_at"] = utc_iso()
    row["revoked_by"] = str(actor_id)
    row["updated_at"] = utc_iso()
    return row


def _append_event(
    db: dict[str, Any],
    *,
    link_id: int | str | None,
    user_id: int | str,
    event_type: str,
    invite_link: str = "",
    campaign_id: str = "",
) -> dict[str, Any]:
    row = {
        "id": next_id(db, "public_channel_link_event"),
        "link_id": int(link_id) if str(link_id or "").isdigit() else None,
        "user_id": str(user_id),
        "type": str(event_type),
        "invite_link": _normalize_link(invite_link),
        "campaign_id": str(campaign_id or ""),
        "created_at": utc_iso(),
    }
    events = db.setdefault("public_channel_link_events", [])
    events.append(row)
    db["public_channel_link_events"] = events[-MAX_LINK_EVENTS:]
    return row


def record_public_channel_membership(
    db: dict[str, Any],
    *,
    user_id: int | str,
    joined: bool,
    invite_link: str = "",
) -> dict[str, Any]:
    uid = str(user_id)
    users = db.setdefault("public_channel_attribution_users", {})
    current = users.get(uid) if isinstance(users.get(uid), dict) else {}
    link = channel_link_by_url(db, invite_link) if invite_link else None
    if joined:
        previous_link_id = current.get("link_id")
        link_id = link.get("id") if link else None
        was_ever_joined = bool(current.get("first_joined_at"))
        was_active = bool(current.get("active", False))
        if was_active and previous_link_id == link_id:
            return {"recorded": False, "reason": "duplicate", "link": link}
        if was_active and previous_link_id and previous_link_id != link_id:
            previous = channel_link_by_id(db, previous_link_id)
            if previous:
                previous["active_members"] = max(0, int(previous.get("active_members", 0) or 0) - 1)
        if link:
            link["join_count"] = int(link.get("join_count", 0) or 0) + 1
            historical_link_ids = {str(item) for item in current.get("link_ids", []) if str(item).isdigit()}
            if "link_ids" not in current:
                historical_link_ids.update(
                    str(event.get("link_id"))
                    for event in db.get("public_channel_link_events", [])
                    if isinstance(event, dict)
                    and str(event.get("user_id")) == uid
                    and event.get("type") in {"join", "rejoin"}
                    and str(event.get("link_id") or "").isdigit()
                )
            if str(link["id"]) not in historical_link_ids:
                link["unique_join_count"] = int(link.get("unique_join_count", 0) or 0) + 1
            if was_ever_joined:
                link["rejoin_count"] = int(link.get("rejoin_count", 0) or 0) + 1
            link["active_members"] = int(link.get("active_members", 0) or 0) + 1
            link["last_joined_at"] = utc_iso()
            link["updated_at"] = utc_iso()
        users[uid] = {
            "user_id": uid,
            "link_id": link_id,
            "campaign_id": str(link.get("campaign_id") or "") if link else "",
            "active": True,
            "first_joined_at": current.get("first_joined_at") or utc_iso(),
            "last_joined_at": utc_iso(),
            "last_left_at": current.get("last_left_at"),
            "link_ids": list(
                dict.fromkeys(
                    [
                        *[str(item) for item in current.get("link_ids", []) if str(item).isdigit()],
                        *([str(link_id)] if link_id is not None else []),
                    ]
                )
            )[-100:],
        }
        event = _append_event(
            db,
            link_id=link_id,
            user_id=uid,
            event_type="rejoin" if was_ever_joined else "join",
            invite_link=invite_link,
            campaign_id=str(link.get("campaign_id") or "") if link else "",
        )
        return {"recorded": True, "event": event, "link": link}

    link_id = current.get("link_id")
    linked = channel_link_by_id(db, link_id) if link_id else None
    if not current or not bool(current.get("active", False)):
        return {"recorded": False, "reason": "duplicate_leave", "link": linked}
    current["active"] = False
    current["last_left_at"] = utc_iso()
    if linked:
        linked["leave_count"] = int(linked.get("leave_count", 0) or 0) + 1
        linked["active_members"] = max(0, int(linked.get("active_members", 0) or 0) - 1)
        linked["updated_at"] = utc_iso()
    event = _append_event(
        db,
        link_id=link_id,
        user_id=uid,
        event_type="leave",
        campaign_id=str(current.get("campaign_id") or ""),
    )
    return {"recorded": True, "event": event, "link": linked}


def public_channel_link_report(db: dict[str, Any], link_id: int | str) -> dict[str, Any]:
    row = channel_link_by_id(db, link_id)
    if row is None:
        raise ValueError("لینک پیدا نشد.")
    events = [
        event
        for event in db.get("public_channel_link_events", [])
        if isinstance(event, dict) and str(event.get("link_id")) == str(row["id"])
    ]
    users = {
        str(event.get("user_id"))
        for event in events
        if event.get("type") in {"join", "rejoin"} and str(event.get("user_id") or "").isdigit()
    }
    registered = users & {str(uid) for uid in db.get("users", {})}
    first_joins: dict[str, datetime] = {}
    for event in events:
        uid = str(event.get("user_id") or "")
        joined_at = parse_dt(event.get("created_at"))
        if event.get("type") not in {"join", "rejoin"} or not uid.isdigit() or joined_at is None:
            continue
        if uid not in first_joins or joined_at < first_joins[uid]:
            first_joins[uid] = joined_at
    attribution_window_days = max(1, min(365, _safe_int(row.get("attribution_window_days"), 30)))
    approved_orders = [
        order
        for order in db.get("vip_orders", [])
        if isinstance(order, dict)
        and str(order.get("user_id")) in users
        and str(order.get("status")) == "approved"
        and (order_time := parse_dt(order.get("approved_at") or order.get("created_at"))) is not None
        and (join_time := first_joins.get(str(order.get("user_id")))) is not None
        and join_time <= order_time <= join_time + timedelta(days=attribution_window_days)
    ]
    revenue = sum(_safe_int(order.get("price")) for order in approved_orders)
    return {
        "link": dict(row),
        "events": dict(Counter(str(event.get("type") or "") for event in events)),
        "unique_users": len(users),
        "registered_users": len(registered),
        "approved_orders": len(approved_orders),
        "revenue": revenue,
        "registration_rate": round(len(registered) / max(1, len(users)) * 100, 2),
        "purchase_rate": round(len(approved_orders) / max(1, len(users)) * 100, 2),
        "attribution_window_days": attribution_window_days,
    }


def public_channel_attribution_summary(db: dict[str, Any]) -> dict[str, Any]:
    rows = [row for row in db.setdefault("public_channel_links", []) if isinstance(row, dict)]
    return {
        "total_links": len(rows),
        "active_links": sum(1 for row in rows if row.get("status") == "active"),
        "total_joins": sum(int(row.get("join_count", 0) or 0) for row in rows),
        "unique_joins": sum(int(row.get("unique_join_count", 0) or 0) for row in rows),
        "active_members": sum(int(row.get("active_members", 0) or 0) for row in rows),
        "leaves": sum(int(row.get("leave_count", 0) or 0) for row in rows),
        "latest": sorted(rows, key=lambda row: str(row.get("created_at") or ""), reverse=True)[:25],
    }
