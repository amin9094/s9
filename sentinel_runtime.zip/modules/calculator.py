from __future__ import annotations

import math
from dataclasses import dataclass
from decimal import ROUND_FLOOR, Decimal, InvalidOperation, localcontext
from typing import Final


@dataclass(frozen=True, slots=True)
class InstrumentSpec:
    symbol: str
    contract_size: Decimal
    min_lot: Decimal = Decimal("0.01")
    lot_step: Decimal = Decimal("0.01")
    max_lot: Decimal = Decimal("100")
    quote_mode: str = "forex"  # forex | usd
    pip_size: Decimal = Decimal("0.0001")
    note: str = ""


_FOREX_STANDARD = Decimal("100000")
SPECS: Final[dict[str, InstrumentSpec]] = {
    "EURUSD": InstrumentSpec("EURUSD", _FOREX_STANDARD),
    "GBPUSD": InstrumentSpec("GBPUSD", _FOREX_STANDARD),
    "AUDUSD": InstrumentSpec("AUDUSD", _FOREX_STANDARD),
    "NZDUSD": InstrumentSpec("NZDUSD", _FOREX_STANDARD),
    "USDJPY": InstrumentSpec("USDJPY", _FOREX_STANDARD, pip_size=Decimal("0.01")),
    "USDCHF": InstrumentSpec("USDCHF", _FOREX_STANDARD),
    "USDCAD": InstrumentSpec("USDCAD", _FOREX_STANDARD),
    "EURGBP": InstrumentSpec("EURGBP", _FOREX_STANDARD),
    "EURJPY": InstrumentSpec("EURJPY", _FOREX_STANDARD, pip_size=Decimal("0.01")),
    "GBPJPY": InstrumentSpec("GBPJPY", _FOREX_STANDARD, pip_size=Decimal("0.01")),
    "XAUUSD": InstrumentSpec(
        "XAUUSD", Decimal("100"), pip_size=Decimal("0.01"),
        note="هر لات استاندارد طلا ۱۰۰ اونس فرض شده است؛ مشخصات نماد بروکر را بررسی کنید.",
    ),
    "GOLD": InstrumentSpec(
        "XAUUSD", Decimal("100"), pip_size=Decimal("0.01"),
        note="هر لات استاندارد طلا ۱۰۰ اونس فرض شده است؛ مشخصات نماد بروکر را بررسی کنید.",
    ),
    "XAGUSD": InstrumentSpec(
        "XAGUSD", Decimal("5000"), pip_size=Decimal("0.001"),
        note="هر لات استاندارد نقره ۵۰۰۰ اونس فرض شده است؛ مشخصات نماد بروکر را بررسی کنید.",
    ),
    "SILVER": InstrumentSpec(
        "XAGUSD", Decimal("5000"), pip_size=Decimal("0.001"),
        note="هر لات استاندارد نقره ۵۰۰۰ اونس فرض شده است؛ مشخصات نماد بروکر را بررسی کنید.",
    ),
    "US100": InstrumentSpec(
        "US100", Decimal("1"), min_lot=Decimal("0.01"), max_lot=Decimal("1000"),
        quote_mode="usd", pip_size=Decimal("1"),
        note="ارزش هر پوینت برای یک لات ۱ دلار فرض شده است؛ مقدار واقعی به بروکر بستگی دارد.",
    ),
    "NAS100": InstrumentSpec(
        "US100", Decimal("1"), min_lot=Decimal("0.01"), max_lot=Decimal("1000"),
        quote_mode="usd", pip_size=Decimal("1"),
        note="ارزش هر پوینت برای یک لات ۱ دلار فرض شده است؛ مقدار واقعی به بروکر بستگی دارد.",
    ),
    "US500": InstrumentSpec(
        "US500", Decimal("1"), min_lot=Decimal("0.01"), max_lot=Decimal("1000"),
        quote_mode="usd", pip_size=Decimal("1"),
        note="ارزش هر پوینت برای یک لات ۱ دلار فرض شده است؛ مشخصات بروکر را بررسی کنید.",
    ),
    "US30": InstrumentSpec(
        "US30", Decimal("1"), min_lot=Decimal("0.01"), max_lot=Decimal("1000"),
        quote_mode="usd", pip_size=Decimal("1"),
        note="ارزش هر پوینت برای یک لات ۱ دلار فرض شده است؛ مشخصات بروکر را بررسی کنید.",
    ),
    "BTCUSD": InstrumentSpec(
        "BTCUSD", Decimal("1"), min_lot=Decimal("0.001"), lot_step=Decimal("0.001"),
        max_lot=Decimal("100"), quote_mode="usd", pip_size=Decimal("1"),
        note="در حالت CFD هر لات برابر ۱ بیت‌کوین فرض شده است؛ برای اسپات/فیوچرز از حالت کریپتو استفاده کنید.",
    ),
}

MAX_BALANCE = Decimal("1000000000000")
MAX_PRICE = Decimal("1000000000000000")
MAX_CONTRACT_SIZE = Decimal("1000000000000")
MAX_LEVERAGE = Decimal("1000")


def _decimal(value: object, field: str) -> Decimal:
    try:
        number = Decimal(str(value).replace(",", "").strip())
    except (InvalidOperation, ValueError, AttributeError) as exc:
        raise ValueError(f"{field} عدد معتبر نیست.") from exc
    if not number.is_finite():
        raise ValueError(f"{field} باید محدود و معتبر باشد.")
    return number


def _safe_float(value: Decimal, field: str) -> float:
    try:
        result = float(value)
    except (OverflowError, ValueError) as exc:
        raise ValueError(f"{field} خارج از محدوده قابل نمایش است.") from exc
    if not math.isfinite(result):
        raise ValueError(f"{field} خارج از محدوده قابل نمایش است.")
    return result


def normalize_symbol(symbol: str) -> str:
    return "".join(ch for ch in str(symbol).upper().strip() if ch.isalnum())


def infer_spec(symbol: str) -> InstrumentSpec:
    normalized = normalize_symbol(symbol)
    if normalized in SPECS:
        return SPECS[normalized]
    if len(normalized) == 6 and normalized.isalpha():
        pip_size = Decimal("0.01") if normalized.endswith("JPY") else Decimal("0.0001")
        return InstrumentSpec(normalized, _FOREX_STANDARD, pip_size=pip_size)
    raise ValueError("نماد پشتیبانی نمی‌شود؛ یکی از نمادهای پشتیبانی‌شده را انتخاب کنید. تنظیم دستی قرارداد فقط برای همین نمادها در دسترس است.")


def quote_to_usd_rate(spec: InstrumentSpec, current_price: object, cross_rate: object | None = None) -> Decimal:
    current = _decimal(current_price, "قیمت فعلی")
    if spec.quote_mode == "usd" or spec.symbol.endswith("USD"):
        return Decimal("1")
    if len(spec.symbol) != 6:
        raise ValueError("ساختار نماد برای تبدیل ارز معتبر نیست.")
    base, quote = spec.symbol[:3], spec.symbol[3:]
    if quote == "USD":
        return Decimal("1")
    if base == "USD":
        if current <= 0:
            raise ValueError("قیمت فعلی باید مثبت باشد.")
        return Decimal("1") / current
    if cross_rate is None:
        raise ValueError(f"برای {spec.symbol} نرخ تبدیل {quote} به دلار لازم است.")
    cross = _decimal(cross_rate, "نرخ تبدیل ارز مظنه به دلار")
    if cross <= 0:
        raise ValueError("نرخ تبدیل ارز مظنه به دلار باید مثبت باشد.")
    return cross


def _floor_to_step(value: Decimal, step: Decimal) -> Decimal:
    if step <= 0:
        raise ValueError("گام حجم باید مثبت باشد.")
    return (value / step).to_integral_value(rounding=ROUND_FLOOR) * step


def _validate_common(balance: Decimal, risk_pct: Decimal, entry: Decimal, stop: Decimal) -> Decimal:
    if balance <= 0:
        raise ValueError("موجودی باید بیشتر از صفر باشد.")
    if balance > MAX_BALANCE:
        raise ValueError("موجودی از محدوده پشتیبانی‌شده بیشتر است.")
    if not Decimal("0") < risk_pct <= Decimal("20"):
        raise ValueError("درصد ریسک باید بیشتر از صفر و حداکثر ۲۰ باشد.")
    if entry <= 0 or stop <= 0:
        raise ValueError("قیمت ورود و حد ضرر باید مثبت باشند.")
    if entry > MAX_PRICE or stop > MAX_PRICE:
        raise ValueError("قیمت از محدوده پشتیبانی‌شده بیشتر است.")
    distance = abs(entry - stop)
    if distance <= 0:
        raise ValueError("قیمت ورود و حد ضرر نباید یکسان باشند.")
    return distance


def calculate_position_size(
    symbol: str,
    balance_usd: float,
    risk_percent: float,
    entry_price: float,
    stop_price: float,
    current_price: float | None = None,
    cross_rate: float | None = None,
    contract_size: float | None = None,
    min_lot: float | None = None,
    lot_step: float | None = None,
    max_lot: float | None = None,
    leverage: float | None = None,
    available_margin_usd: float | None = None,
) -> dict:
    """Calculate Forex/CFD position size for a USD-denominated account.

    The calculation floors volume to the broker lot step so the resulting risk
    never exceeds the selected budget because of rounding.
    """
    balance = _decimal(balance_usd, "موجودی")
    risk_pct = _decimal(risk_percent, "درصد ریسک")
    entry = _decimal(entry_price, "قیمت ورود")
    stop = _decimal(stop_price, "حد ضرر")
    distance = _validate_common(balance, risk_pct, entry, stop)

    spec = infer_spec(symbol)
    size = _decimal(contract_size, "اندازه قرارداد") if contract_size is not None else spec.contract_size
    min_size = _decimal(min_lot, "حداقل لات") if min_lot is not None else spec.min_lot
    step = _decimal(lot_step, "گام لات") if lot_step is not None else spec.lot_step
    maximum = _decimal(max_lot, "حداکثر لات") if max_lot is not None else spec.max_lot
    if size <= 0 or min_size <= 0 or step <= 0 or maximum <= 0:
        raise ValueError("مشخصات قرارداد نامعتبر است.")
    if size > MAX_CONTRACT_SIZE or maximum > MAX_CONTRACT_SIZE:
        raise ValueError("مشخصات قرارداد از محدوده پشتیبانی‌شده بیشتر است.")

    leverage_value = _decimal(leverage or 1, "اهرم")
    if not Decimal("1") <= leverage_value <= MAX_LEVERAGE:
        raise ValueError("اهرم باید بین ۱ تا ۱۰۰۰ باشد.")

    with localcontext() as ctx:
        ctx.prec = 34
        q2usd = quote_to_usd_rate(spec, current_price if current_price is not None else entry, cross_rate)
        risk_amount = balance * risk_pct / Decimal("100")
        loss_per_lot = distance * size * q2usd
        if loss_per_lot <= 0 or not loss_per_lot.is_finite():
            raise ValueError("زیان هر لات قابل محاسبه نیست.")
        raw_lot = risk_amount / loss_per_lot
        maximum = _floor_to_step(maximum, step)
        risk_limited_lot = min(_floor_to_step(raw_lot, step), maximum)
        available_margin = _decimal(available_margin_usd, "مارجین آزاد") if available_margin_usd is not None else balance
        if available_margin <= 0 or available_margin > MAX_BALANCE:
            raise ValueError("مارجین آزاد باید بیشتر از صفر و در محدوده معتبر باشد.")
        notional_usd_per_lot = size * entry * q2usd
        if notional_usd_per_lot <= 0:
            raise ValueError("ارزش اسمی هر لات قابل محاسبه نیست.")
        margin_limited_raw = available_margin * leverage_value / notional_usd_per_lot
        margin_limited_lot = min(_floor_to_step(margin_limited_raw, step), maximum)
        rounded_lot = min(risk_limited_lot, margin_limited_lot, maximum)
        capped_by_margin = margin_limited_lot < risk_limited_lot
        below_minimum = rounded_lot < min_size
        effective_lot = Decimal("0") if below_minimum else rounded_lot
        units = effective_lot * size
        effective_risk = effective_lot * loss_per_lot
        notional_quote = units * entry
        notional_usd = notional_quote * q2usd
        margin_usd = notional_usd / leverage_value
        pip_distance = distance / spec.pip_size
        pip_value_per_lot = spec.pip_size * size * q2usd
        stop_percent = distance / entry * Decimal("100")
        effective_risk_percent = effective_risk / balance * Decimal("100") if balance else Decimal("0")
        risk_budget_usage_percent = effective_risk / risk_amount * Decimal("100") if risk_amount else Decimal("0")
        margin_usage_percent = margin_usd / available_margin * Decimal("100") if available_margin else Decimal("0")

    return {
        "mode": "forex",
        "symbol": spec.symbol,
        "risk_amount": _safe_float(risk_amount, "مبلغ ریسک"),
        "effective_risk": _safe_float(effective_risk, "ریسک واقعی"),
        "distance": _safe_float(distance, "فاصله قیمت"),
        "pip_size": _safe_float(spec.pip_size, "اندازه پیپ"),
        "pip_distance": _safe_float(pip_distance, "فاصله پیپ"),
        "pip_value_per_lot": _safe_float(pip_value_per_lot, "ارزش پیپ"),
        "contract_size": _safe_float(size, "اندازه قرارداد"),
        "quote_to_usd": _safe_float(q2usd, "نرخ تبدیل"),
        "loss_per_lot": _safe_float(loss_per_lot, "زیان هر لات"),
        "raw_lot": _safe_float(raw_lot, "حجم خام"),
        "risk_limited_lot": _safe_float(risk_limited_lot, "حجم محدودشده با ریسک"),
        "margin_limited_lot": _safe_float(margin_limited_lot, "حجم محدودشده با مارجین"),
        "lot": _safe_float(effective_lot, "حجم نهایی"),
        "units": _safe_float(units, "تعداد واحد"),
        "notional": _safe_float(notional_usd, "ارزش اسمی دلاری"),
        "notional_quote": _safe_float(notional_quote, "ارزش اسمی ارز مظنه"),
        "estimated_margin": _safe_float(margin_usd, "مارجین تقریبی"),
        "available_margin": _safe_float(available_margin, "مارجین آزاد"),
        "leverage": _safe_float(leverage_value, "اهرم"),
        "stop_percent": _safe_float(stop_percent, "درصد فاصله استاپ"),
        "effective_risk_percent": _safe_float(effective_risk_percent, "درصد ریسک واقعی"),
        "risk_budget_usage_percent": _safe_float(risk_budget_usage_percent, "درصد مصرف بودجه ریسک"),
        "margin_usage_percent": _safe_float(margin_usage_percent, "درصد مصرف مارجین"),
        "capped_by_margin": capped_by_margin,
        "below_minimum": below_minimum,
        "min_lot": _safe_float(min_size, "حداقل لات"),
        "lot_step": _safe_float(step, "گام لات"),
        "note": spec.note,
    }


def calculate_crypto_position_size(
    balance_usd: float,
    risk_percent: float,
    entry_price: float,
    stop_price: float,
    *,
    leverage: float = 1,
    fee_percent_round_trip: float = 0,
    quantity_step: float | None = None,
    min_quantity: float | None = None,
    min_notional: float | None = None,
    available_margin_usd: float | None = None,
) -> dict:
    """Calculate quantity for crypto spot or linear USDT/USD perpetuals.

    ``fee_percent_round_trip`` is optional and is treated as the total estimated
    entry+exit fee percentage of entry notional. Exchange-specific quantity
    filters can be supplied without hard-coding stale rules.
    """
    balance = _decimal(balance_usd, "موجودی")
    risk_pct = _decimal(risk_percent, "درصد ریسک")
    entry = _decimal(entry_price, "قیمت ورود")
    stop = _decimal(stop_price, "حد ضرر")
    distance = _validate_common(balance, risk_pct, entry, stop)
    leverage_value = _decimal(leverage, "اهرم")
    if not Decimal("1") <= leverage_value <= Decimal("125"):
        raise ValueError("اهرم کریپتو باید بین ۱ تا ۱۲۵ باشد.")
    fee_pct = _decimal(fee_percent_round_trip, "کارمزد رفت‌وبرگشت")
    if not Decimal("0") <= fee_pct <= Decimal("10"):
        raise ValueError("کارمزد رفت‌وبرگشت باید بین صفر تا ۱۰ درصد باشد.")
    step = _decimal(quantity_step, "گام مقدار") if quantity_step is not None else Decimal("0.00000001")
    minimum = _decimal(min_quantity, "حداقل مقدار") if min_quantity is not None else step
    minimum_notional = _decimal(min_notional, "حداقل ارزش سفارش") if min_notional is not None else Decimal("0")
    if step <= 0 or minimum <= 0 or minimum_notional < 0:
        raise ValueError("فیلترهای مقدار سفارش نامعتبر هستند.")

    with localcontext() as ctx:
        ctx.prec = 34
        risk_amount = balance * risk_pct / Decimal("100")
        fee_per_unit = entry * fee_pct / Decimal("100")
        loss_per_unit = distance + fee_per_unit
        if loss_per_unit <= 0:
            raise ValueError("ریسک هر واحد قابل محاسبه نیست.")
        raw_quantity = risk_amount / loss_per_unit
        risk_limited_quantity = _floor_to_step(raw_quantity, step)
        available_margin = _decimal(available_margin_usd, "مارجین آزاد") if available_margin_usd is not None else balance
        if available_margin <= 0 or available_margin > MAX_BALANCE:
            raise ValueError("مارجین آزاد باید بیشتر از صفر و در محدوده معتبر باشد.")
        max_affordable_quantity = _floor_to_step((available_margin * leverage_value) / entry, step)
        quantity = min(risk_limited_quantity, max_affordable_quantity)
        capped_by_margin = max_affordable_quantity < risk_limited_quantity
        below_minimum = quantity < minimum
        if below_minimum:
            quantity = Decimal("0")
        notional = quantity * entry
        below_min_notional = bool(quantity and notional < minimum_notional)
        if below_min_notional:
            quantity = Decimal("0")
            notional = Decimal("0")
        effective_risk = quantity * loss_per_unit
        margin = notional / leverage_value
        stop_percent = distance / entry * Decimal("100")
        max_spot_quantity = available_margin / entry
        exceeds_spot_balance = leverage_value == 1 and risk_limited_quantity > max_spot_quantity
        effective_risk_percent = effective_risk / balance * Decimal("100") if balance else Decimal("0")
        risk_budget_usage_percent = effective_risk / risk_amount * Decimal("100") if risk_amount else Decimal("0")
        margin_usage_percent = margin / available_margin * Decimal("100") if available_margin else Decimal("0")

    return {
        "mode": "crypto_spot" if leverage_value == 1 else "crypto_futures",
        "risk_amount": _safe_float(risk_amount, "مبلغ ریسک"),
        "effective_risk": _safe_float(effective_risk, "ریسک واقعی"),
        "distance": _safe_float(distance, "فاصله قیمت"),
        "stop_percent": _safe_float(stop_percent, "درصد فاصله استاپ"),
        "fee_percent_round_trip": _safe_float(fee_pct, "کارمزد"),
        "loss_per_unit": _safe_float(loss_per_unit, "ریسک هر واحد"),
        "raw_quantity": _safe_float(raw_quantity, "مقدار خام"),
        "risk_limited_quantity": _safe_float(risk_limited_quantity, "مقدار محدودشده با ریسک"),
        "max_affordable_quantity": _safe_float(max_affordable_quantity, "حداکثر مقدار قابل خرید"),
        "quantity": _safe_float(quantity, "مقدار نهایی"),
        "notional": _safe_float(notional, "ارزش پوزیشن"),
        "estimated_margin": _safe_float(margin, "مارجین تقریبی"),
        "available_margin": _safe_float(available_margin, "مارجین آزاد"),
        "leverage": _safe_float(leverage_value, "اهرم"),
        "effective_risk_percent": _safe_float(effective_risk_percent, "درصد ریسک واقعی"),
        "risk_budget_usage_percent": _safe_float(risk_budget_usage_percent, "درصد مصرف بودجه ریسک"),
        "margin_usage_percent": _safe_float(margin_usage_percent, "درصد مصرف مارجین"),
        "capped_by_margin": capped_by_margin,
        "quantity_step": _safe_float(step, "گام مقدار"),
        "min_quantity": _safe_float(minimum, "حداقل مقدار"),
        "min_notional": _safe_float(minimum_notional, "حداقل ارزش سفارش"),
        "below_minimum": below_minimum,
        "below_min_notional": below_min_notional,
        "exceeds_spot_balance": exceeds_spot_balance,
        "max_spot_quantity": _safe_float(max_spot_quantity, "حداکثر مقدار اسپات"),
    }
