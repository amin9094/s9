"""Exact session-defined Fibonacci prices; geometry does not certify an entry."""

from __future__ import annotations

from decimal import Decimal

from modules.canonical_market import price

OB_RETRACEMENT = Decimal("0.61")
FVG_RETRACEMENT = Decimal("0.71")
GOLDEN_EXTENSION_LOW = Decimal("1.61")
GOLDEN_EXTENSION_HIGH = Decimal("1.68")


def wave_level(start, end, ratio):
    """Session orientation: 0 at wave start and 1 at confirmed wave end."""
    start, end = price(start), price(end)
    if start == end:
        raise ValueError("FIBONACCI_ZERO_WAVE")
    return price(start + (end - start) * Decimal(str(ratio)))


def retracement_price(start, end, *, context):
    """Measure against the entire preconfirmed causal impulse, both directions.

    Callers own the prelocked wave/source/timing evidence. This helper must not
    replace the full-candle OB or FVG-midpoint entry without a resolved selector.
    """
    start, end = price(start), price(end)
    if start == end:
        raise ValueError("FIBONACCI_ZERO_WAVE")
    ratios = {"order_block": OB_RETRACEMENT, "fvg": FVG_RETRACEMENT}
    if context not in ratios:
        raise ValueError("FIBONACCI_CONTEXT_UNSUPPORTED")
    return price(end - (end - start) * ratios[context])


def golden_extension_band(a, b, *, convention, c=None):
    """Do not silently choose a two- vs three-anchor projection convention."""
    a, b = price(a), price(b)
    if a == b:
        raise ValueError("FIBONACCI_ZERO_WAVE")
    if convention == "two_anchor":
        if c is not None:
            raise ValueError("FIBONACCI_EXTRA_ANCHOR")
        origin = a
    elif convention == "three_anchor":
        if c is None:
            raise ValueError("FIBONACCI_THIRD_ANCHOR_REQUIRED")
        origin = price(c)
    else:
        raise ValueError("FIBONACCI_PROJECTION_CONVENTION_REQUIRED")
    bounds = [price(origin + (b - a) * ratio) for ratio in (GOLDEN_EXTENSION_LOW, GOLDEN_EXTENSION_HIGH)]
    return min(bounds), max(bounds)


def golden_support(reference_price, bands):
    """Optional exact geometrical corroboration; never a probability or fill."""
    reference = price(reference_price)
    matching = []
    for low, high in bands:
        low, high = price(low), price(high)
        if low > high:
            raise ValueError("FIBONACCI_BAND_REVERSED")
        if low <= reference <= high:
            matching.append((str(low), str(high)))
    return {"matched": bool(matching), "matching_bands": matching, "mandatory_for_base": False}
