from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime, timedelta, tzinfo
from typing import Any
from zoneinfo import ZoneInfo, ZoneInfoNotFoundError

from core.utils import parse_dt, utc_now
from modules.user_intelligence import build_user_profile

_FINAL_SIGNAL_STATUSES = {"target_complete", "manual_close", "no_entry", "stop", "cancelled", "expired"}


def _safe_int(value: Any) -> int:
    try:
        return int(str(value or 0).replace(",", ""))
    except (TypeError, ValueError):
        return 0


def _safe_float(value: Any) -> float:
    try:
        return float(value or 0)
    except (TypeError, ValueError):
        return 0.0


def _rows(value: Any) -> list[dict[str, Any]]:
    if not isinstance(value, list):
        return []
    return [row for row in value if isinstance(row, dict)]


def _mapping(value: Any) -> dict[str, Any]:
    return value if isinstance(value, dict) else {}


def _status_count(rows: list[dict[str, Any]], status: str) -> int:
    return sum(1 for row in rows if str(row.get("status") or "").lower() == status)


def _date_for(row: dict[str, Any], *keys: str) -> datetime | None:
    for key in keys:
        parsed = parse_dt(row.get(key))
        if parsed is not None:
            return parsed
    return None


def _window_start(now: datetime, days: int) -> datetime:
    return now - timedelta(days=max(0, days))


def _in_window(value: Any, start: datetime, end: datetime) -> bool:
    parsed = parse_dt(value)
    return bool(parsed and start <= parsed <= end)


def _local_day_start(now: datetime, timezone: str) -> datetime:
    try:
        zone: tzinfo = ZoneInfo(timezone)
    except ZoneInfoNotFoundError:
        zone = UTC
    local_now = now.astimezone(zone)
    return local_now.replace(hour=0, minute=0, second=0, microsecond=0).astimezone(UTC)


def _rank_for_user(points_map: dict[str, Any], uid: str) -> int | None:
    normalized = {str(user_id): _safe_int(points) for user_id, points in points_map.items()}
    normalized.setdefault(uid, 0)
    ordered = sorted(
        normalized.items(),
        key=lambda item: (-item[1], item[0]),
    )
    return next((index for index, (user_id, _) in enumerate(ordered, start=1) if user_id == uid), None)


def user_account_snapshot(db: dict[str, Any], user_id: int | str, *, now: datetime | None = None) -> dict[str, Any]:
    """Build a read-only, UI-ready summary for the user account center."""

    current = (now or utc_now()).astimezone(UTC)
    uid = str(user_id)
    users = _mapping(db.get("users"))
    user = _mapping(users.get(uid))
    points_map = _mapping(db.get("user_points"))
    points = _safe_int(points_map.get(uid))

    vip_users = _mapping(db.get("vip_users"))
    vip = _mapping(vip_users.get(uid))
    expiry = parse_dt(vip.get("expires_at"))
    vip_active = bool(expiry and expiry > current and str(vip.get("status") or "active") != "expired")
    days_left = max(0, (expiry.date() - current.date()).days) if vip_active and expiry else 0

    vip_orders = [row for row in _rows(db.get("vip_orders")) if str(row.get("user_id")) == uid]
    vip_orders.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    approved_vip = [row for row in vip_orders if str(row.get("status")) == "approved"]

    education_orders = [row for row in _rows(db.get("education_orders")) if str(row.get("user_id")) == uid]
    education_orders.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    approved_education = [row for row in education_orders if str(row.get("status")) == "approved"]
    access_map = _mapping(_mapping(db.get("education_access")).get(uid))
    lessons = _rows(db.get("lessons"))
    lesson_by_id = {str(row.get("id")): row for row in lessons}
    accessible_lessons = [lesson_by_id[key] for key in access_map if key in lesson_by_id]

    tickets = [row for row in _rows(db.get("tickets")) if str(row.get("user_id")) == uid]
    tickets.sort(key=lambda row: str(row.get("updated_at") or row.get("created_at") or ""), reverse=True)
    rewards = [row for row in _rows(db.get("user_rewards")) if str(row.get("user_id")) == uid]
    reward_requests = [row for row in _rows(db.get("reward_requests")) if str(row.get("user_id")) == uid]
    alerts = [row for row in _rows(db.get("price_alerts")) if str(row.get("user_id")) == uid]
    missions = _rows(db.get("missions"))
    completed_missions = _mapping(_mapping(db.get("user_missions")).get(uid))
    referral = _mapping(_mapping(db.get("user_referrals")).get(uid))
    profile = build_user_profile(db, uid, now=current)

    return {
        "user_id": uid,
        "user": user,
        "created_at": user.get("created_at"),
        "last_seen_at": user.get("last_seen_at"),
        "points": points,
        "rank": _rank_for_user(points_map, uid),
        "vip": vip,
        "vip_active": vip_active,
        "vip_expires_at": vip.get("expires_at"),
        "vip_days_left": days_left,
        "vip_orders": vip_orders,
        "vip_order_count": len(vip_orders),
        "vip_approved_count": len(approved_vip),
        "vip_pending_count": sum(1 for row in vip_orders if str(row.get("status")) in {"pending", "approving"}),
        "vip_spend": sum(_safe_int(row.get("price")) for row in approved_vip),
        "education_orders": education_orders,
        "education_order_count": len(education_orders),
        "education_approved_count": len(approved_education),
        "education_pending_count": _status_count(education_orders, "pending"),
        "education_spend": sum(_safe_int(row.get("price")) for row in approved_education),
        "accessible_lessons": accessible_lessons,
        "accessible_lesson_count": len(accessible_lessons),
        "tickets": tickets,
        "ticket_count": len(tickets),
        "open_ticket_count": _status_count(tickets, "open"),
        "rewards": rewards,
        "reward_count": len(rewards),
        "delivered_reward_count": _status_count(rewards, "delivered"),
        "pending_reward_count": _status_count(reward_requests, "pending"),
        "alerts": alerts,
        "active_alert_count": _status_count(alerts, "active"),
        "mission_count": len(missions),
        "completed_mission_count": len(completed_missions),
        "referral_count": len(referral.get("invited", [])) if isinstance(referral.get("invited", []), list) else 0,
        "referral_points": _safe_int(referral.get("points_awarded")),
        "profile": profile,
        "primary_category": profile.get("primary_category"),
        "primary_category_label": profile.get("primary_category_label"),
        "segments": profile.get("segments", []),
        "segment_labels": profile.get("segment_labels", []),
        "behavior_persona": profile.get("behavior_persona", "explorer"),
        "engagement_score": profile.get("engagement_score", 0),
        "purchase_intent_score": profile.get("purchase_intent_score", 0),
        "churn_risk_score": profile.get("churn_risk_score", 0),
        "points_received": profile.get("points_received", points),
        "points_spent": profile.get("points_spent", 0),
        "point_transaction_count": profile.get("point_transaction_count", 0),
        "vip_renewal_count": profile.get("vip_renewal_count", max(0, len(approved_vip) - 1)),
        "activity_total": _safe_int(_mapping(profile.get("activity_summary")).get("total")),
        "last_activity_action": _mapping(profile.get("activity_summary")).get("last_action"),
        "last_activity_at": _mapping(profile.get("activity_summary")).get("last_at"),
    }


def _revenue_metrics(rows: list[dict[str, Any]], now: datetime, today_start: datetime) -> dict[str, int]:
    approved = [row for row in rows if str(row.get("status") or "").lower() == "approved"]

    def amount_since(start: datetime) -> int:
        return sum(
            _safe_int(row.get("price"))
            for row in approved
            if (stamp := _date_for(row, "approved_at", "reviewed_at", "created_at")) is not None and stamp >= start
        )

    def count_since(start: datetime) -> int:
        return sum(
            1
            for row in approved
            if (stamp := _date_for(row, "approved_at", "reviewed_at", "created_at")) is not None and stamp >= start
        )

    return {
        "today": amount_since(today_start),
        "today_count": count_since(today_start),
        "days_7": amount_since(_window_start(now, 7)),
        "days_7_count": count_since(_window_start(now, 7)),
        "days_30": amount_since(_window_start(now, 30)),
        "days_30_count": count_since(_window_start(now, 30)),
        "all": sum(_safe_int(row.get("price")) for row in approved),
        "all_count": len(approved),
    }


def admin_dashboard_snapshot(
    db: dict[str, Any],
    *,
    now: datetime | None = None,
    timezone: str = "UTC",
) -> dict[str, Any]:
    """Return consolidated business, support, signal, and system analytics."""

    current = (now or utc_now()).astimezone(UTC)
    today_start = _local_day_start(current, timezone)
    users = _mapping(db.get("users"))
    vip_users = _mapping(db.get("vip_users"))
    vip_orders = _rows(db.get("vip_orders"))
    education_orders = _rows(db.get("education_orders"))
    tickets = _rows(db.get("tickets"))
    signals = _rows(db.get("signals"))
    broadcasts = _rows(db.get("broadcasts"))
    rewards = _rows(db.get("reward_requests"))
    approvals = _rows(db.get("pending_admin_actions"))
    admin_logs = _rows(db.get("admin_logs"))

    user_created = [parse_dt(row.get("created_at")) for row in users.values() if isinstance(row, dict)]
    user_seen = [parse_dt(row.get("last_seen_at") or row.get("created_at")) for row in users.values() if isinstance(row, dict)]

    active_vip = 0
    expiring_7d = 0
    expired_vip = 0
    for row in vip_users.values():
        if not isinstance(row, dict):
            continue
        expiry = parse_dt(row.get("expires_at"))
        if expiry and expiry > current and str(row.get("status") or "active") != "expired":
            active_vip += 1
            if expiry <= current + timedelta(days=7):
                expiring_7d += 1
        else:
            expired_vip += 1

    vip_revenue = _revenue_metrics(vip_orders, current, today_start)
    education_revenue = _revenue_metrics(education_orders, current, today_start)
    total_revenue = {
        key: vip_revenue[key] + education_revenue[key]
        for key in ("today", "today_count", "days_7", "days_7_count", "days_30", "days_30_count", "all", "all_count")
    }

    approved_vip_orders = [row for row in vip_orders if str(row.get("status")) == "approved"]
    buyer_order_counts = Counter(str(row.get("user_id")) for row in approved_vip_orders)
    unique_buyers = len(buyer_order_counts)
    repeat_buyers = sum(1 for count in buyer_order_counts.values() if count >= 2)
    conversion_rate = (unique_buyers / len(users) * 100) if users else 0.0
    renewal_rate = (repeat_buyers / unique_buyers * 100) if unique_buyers else 0.0

    open_tickets = [row for row in tickets if str(row.get("status")) == "open"]
    stale_tickets = [
        row
        for row in open_tickets
        if (stamp := _date_for(row, "updated_at", "created_at")) is not None and stamp < current - timedelta(hours=24)
    ]
    closed_7d = sum(
        1
        for row in tickets
        if str(row.get("status")) == "closed"
        and (stamp := _date_for(row, "closed_at", "updated_at")) is not None
        and stamp >= current - timedelta(days=7)
    )

    active_signals = [row for row in signals if str(row.get("status") or "open") not in _FINAL_SIGNAL_STATUSES]
    final_signals = [row for row in signals if str(row.get("status") or "open") in _FINAL_SIGNAL_STATUSES]
    signal_wins = sum(
        1
        for row in final_signals
        if _safe_int(row.get("highest_target_hit")) > 0
        or _safe_float(row.get("profit_percent")) > 0
        or str(row.get("status")) == "target_complete"
    )
    signal_losses = sum(
        1
        for row in final_signals
        if str(row.get("status")) == "stop" or _safe_float(row.get("profit_percent")) < 0
    )
    settled_for_rate = signal_wins + signal_losses
    win_rate = (signal_wins / settled_for_rate * 100) if settled_for_rate else 0.0
    signal_profit = sum(_safe_float(row.get("profit_percent")) for row in final_signals)

    broadcasts_7d = [
        row
        for row in broadcasts
        if (stamp := _date_for(row, "created_at")) is not None and stamp >= current - timedelta(days=7)
    ]
    broadcast_dates = [stamp for row in broadcasts if (stamp := _date_for(row, "created_at")) is not None]
    admin_log_dates = [stamp for row in admin_logs if (stamp := _date_for(row, "created_at")) is not None]
    latest_broadcast = max(broadcast_dates, default=None)
    latest_admin_log = max(admin_log_dates, default=None)
    user_profiles = [build_user_profile(db, uid, now=current) for uid in users]
    primary_category_counts = Counter(str(row.get("primary_category") or "inactive_user") for row in user_profiles)
    segment_counts: Counter[str] = Counter()
    for row in user_profiles:
        segment_counts.update(str(segment) for segment in row.get("segments", []))

    return {
        "generated_at": current.isoformat(),
        "users": {
            "total": len(users),
            "new_today": sum(1 for stamp in user_created if stamp and stamp >= today_start),
            "new_7d": sum(1 for stamp in user_created if stamp and stamp >= current - timedelta(days=7)),
            "new_30d": sum(1 for stamp in user_created if stamp and stamp >= current - timedelta(days=30)),
            "active_24h": sum(1 for stamp in user_seen if stamp and stamp >= current - timedelta(hours=24)),
            "active_7d": sum(1 for stamp in user_seen if stamp and stamp >= current - timedelta(days=7)),
            "active_30d": sum(1 for stamp in user_seen if stamp and stamp >= current - timedelta(days=30)),
            "banned": sum(
                1
                for row in _mapping(db.get("user_bans")).values()
                if isinstance(row, dict)
                and str(row.get("status") or "active") == "active"
                and ((expiry := parse_dt(row.get("expires_at"))) is None or expiry > current)
            ),
            "unique_vip_buyers": unique_buyers,
            "repeat_vip_buyers": repeat_buyers,
            "conversion_rate": conversion_rate,
            "renewal_rate": renewal_rate,
            "primary_categories": dict(primary_category_counts),
            "segments": dict(segment_counts),
        },
        "vip": {
            "active": active_vip,
            "expiring_7d": expiring_7d,
            "expired": expired_vip,
            "pending_orders": sum(1 for row in vip_orders if str(row.get("status")) in {"pending", "approving"}),
            "rejected_orders": _status_count(vip_orders, "rejected"),
        },
        "sales": {
            "vip": vip_revenue,
            "education": education_revenue,
            "total": total_revenue,
            "pending_education": _status_count(education_orders, "pending"),
            "lessons_total": len(_rows(db.get("lessons"))),
            "paid_lessons": sum(1 for row in _rows(db.get("lessons")) if str(row.get("access_type")) == "paid"),
        },
        "support": {
            "open": len(open_tickets),
            "stale_24h": len(stale_tickets),
            "closed_7d": closed_7d,
            "total": len(tickets),
            "pending_rewards": _status_count(rewards, "pending"),
        },
        "signals": {
            "total": len(signals),
            "active": len(active_signals),
            "final": len(final_signals),
            "wins": signal_wins,
            "losses": signal_losses,
            "win_rate": win_rate,
            "profit_percent_sum": signal_profit,
        },
        "engagement": {
            "active_price_alerts": _status_count(_rows(db.get("price_alerts")), "active"),
            "completed_missions": sum(len(_mapping(row)) for row in _mapping(db.get("user_missions")).values()),
            "delivered_rewards": _status_count(_rows(db.get("user_rewards")), "delivered"),
            "broadcasts_7d": len(broadcasts_7d),
            "broadcast_sent_7d": sum(_safe_int(row.get("sent")) for row in broadcasts_7d),
            "broadcast_failed_7d": sum(_safe_int(row.get("failed")) for row in broadcasts_7d),
            "latest_broadcast_at": latest_broadcast.isoformat() if latest_broadcast else None,
        },
        "system": {
            "pending_approvals": _status_count(approvals, "pending"),
            "admin_logs_24h": sum(
                1
                for row in admin_logs
                if (stamp := _date_for(row, "created_at")) is not None and stamp >= current - timedelta(hours=24)
            ),
            "latest_admin_activity_at": latest_admin_log.isoformat() if latest_admin_log else None,
            "delegated_admins": sum(
                1
                for row in _mapping(db.get("delegated_admins")).values()
                if isinstance(row, dict) and row.get("active", True)
            ),
            "database_schema": _safe_int(db.get("schema_version")),
        },
    }
