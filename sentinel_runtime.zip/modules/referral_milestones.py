"""Configurable referral rewards in the canonical transaction store."""
from __future__ import annotations

from typing import Any

from core.db import next_id
from core.domain import activate_vip, add_points, assign_discount_from_pool, audit
from core.utils import parse_dt, utc_iso, utc_now
from modules.admin_access import PERMISSION_REWARD_POINTS, has_permission
from modules.advanced_features import record_user_reward

TRIGGERS = {"referrals_joined", "referrals_purchased", "referral_revenue"}
REWARDS = {"points", "vip_days", "discount_coupon", "reward_item"}


def save_milestone(db: dict[str, Any], actor: int | str, values: dict[str, Any], milestone_id=None) -> dict:
    if not has_permission(db, actor, PERMISSION_REWARD_POINTS):
        raise PermissionError("مجوز مدیریت پاداش لازم است.")
    rows = db.setdefault("referral_milestones", {})
    previous = rows.get(str(milestone_id), {}) if milestone_id is not None else {}
    if milestone_id is not None and not previous:
        raise ValueError("مرحله پیدا نشد.")
    if previous.get('deleted_at'):
        raise ValueError("مرحله حذف شده است.")
    from modules.referral_ui import LOCKED_FIELDS, has_claims
    if previous and has_claims(db,previous['id']) and any(key in values and values[key]!=previous.get(key) for key in LOCKED_FIELDS):
        raise ValueError("این مرحله جایزه صادر کرده است؛ برای تغییر هدف یا جایزه، مرحلهٔ تازه بسازید.")
    data = {**previous, **values}
    if data.get("trigger_type") not in TRIGGERS or data.get("reward_type") not in REWARDS:
        raise ValueError("نوع مرحله یا پاداش نامعتبر است.")
    for field in ("required_count", "reward_value"):
        data[field] = int(data.get(field, 0))
        if not 1 <= data[field] <= 1_000_000_000:
            raise ValueError("مقدار باید مثبت و معتبر باشد.")
    if data['reward_type'] == 'vip_days' and data['reward_value'] > 3650:
        raise ValueError("حداکثر اعتبار ۳۶۵۰ روز است.")
    if data['reward_type'] == 'discount_coupon':
        from core.domain import normalize_discount_tier
        normalize_discount_tier(data['reward_value'])
    if data['reward_type'] == 'reward_item' and not any(str(r.get('id')) == str(data['reward_value']) for r in db.get('settings', {}).get('rewardItems', [])):
        raise ValueError("جایزه انتخابی وجود ندارد.")
    for field in ("start_at", "expire_at"):
        if data.get(field) and not parse_dt(data[field]):
            raise ValueError("تاریخ نامعتبر است.")
    if data.get('start_at') and data.get('expire_at') and parse_dt(data['start_at']) >= parse_dt(data['expire_at']):
        raise ValueError("پایان باید بعد از شروع باشد.")
    data['max_claims'] = max(0, int(data.get('max_claims', 0)))
    data['sort_order'] = int(data.get('sort_order', 0))
    data['title'] = str(data.get('title') or '').strip()[:100]
    data['description'] = str(data.get('description') or '')[:500]
    if not data['title']:
        raise ValueError("عنوان لازم است.")
    data.setdefault('enabled', True); data.setdefault('repeatable', False)
    data['id'] = previous.get('id') or next_id(db, 'referral_milestone')
    data['updated_at'] = utc_iso()
    if (not previous and data.get('retroactive') is False) or (previous and data.get('trigger_type') != previous.get('trigger_type')):
        # Capture the verified totals before enabling this milestone. Existing
        # activity must not silently create a new economic entitlement.
        data['baseline'] = {}
        probe={**data,'baseline':{},'enabled':True,'start_at':None,'expire_at':None}
        rows[str(data['id'])] = probe
        for uid in db.get('users',{}):
            progress=next((r for r in milestone_progress(db,uid) if r['id']==data['id']),None)
            data['baseline'][str(uid)]=int(progress['progress']) if progress else 0
    rows[str(data['id'])] = data
    audit(db, actor, 'referral_milestone_saved', str(data['id']))
    return dict(data)


def milestone_progress(db: dict, user_id: int | str) -> list[dict]:
    from core.economy_integrity import verified_referral_activity
    qualified, purchases = verified_referral_activity(db, user_id)
    totals = {'referrals_joined':len(qualified), 'referrals_purchased':len({p[0] for p in purchases.values()}),
              'referral_revenue':sum(p[1] for p in purchases.values())}
    claims = db.get('referral_milestone_claims', {})
    now = utc_now(); result = []
    for row in sorted(db.get('referral_milestones', {}).values(), key=lambda r: (r.get('sort_order', 0), r['id'])):
        if not row.get('enabled', True) or row.get('deleted_at'): continue
        start, end = parse_dt(row.get('start_at')), parse_dt(row.get('expire_at'))
        if (start and now < start) or (end and now >= end): continue
        count = max(0, totals[row['trigger_type']] - int(row.get('baseline',{}).get(str(user_id),0))); required = max(1, int(row['required_count']))
        done = sum(1 for c in claims.values() if str(c['user_id']) == str(user_id) and c['milestone_id'] == row['id'])
        allowed = count // required if row.get('repeatable') else min(1, count // required)
        if row.get('max_claims'): allowed = min(allowed, int(row['max_claims']))
        result.append({**row, 'progress': count, 'claimed': done, 'claimable': allowed > done})
    return result


def claim_milestone(db: dict, user_id: int | str, milestone_id: int | str, *, expected_cycle: int | None = None) -> dict:
    if expected_cycle is not None:
        previous = db.get('referral_milestone_claims', {}).get(f'{user_id}:{milestone_id}:{expected_cycle}')
        if previous: return dict(previous)
    row = next((r for r in milestone_progress(db, user_id) if str(r['id']) == str(milestone_id)), None)
    if not row or not row['claimable']:
        raise ValueError("این پاداش قبلاً دریافت شده یا هنوز قابل دریافت نیست.")
    if expected_cycle is not None and expected_cycle != row['claimed'] + 1:
        raise ValueError('صفحه پاداش را تازه کنید.')
    key = f"{user_id}:{row['id']}:{row['claimed'] + 1}"
    claims = db.setdefault('referral_milestone_claims', {})
    if key in claims: return claims[key]
    kind, value = row['reward_type'], row['reward_value']; reference = key; detail = str(value); status = 'delivered'
    if kind == 'points': add_points(db, user_id, value, f"referral_milestone:{row['id']}",source_event=f"points:referral_milestone:{key}")
    elif kind == 'vip_days':
        vip = activate_vip(db, user_id, value,source_order_id=f"referral_milestone:{key}"); detail = f"{value} روز VIP | {vip['expires_at']}"
    elif kind == 'discount_coupon':
        coupon, _ = assign_discount_from_pool(db, value, user_id, issued_via='referral_milestone')
        reference = coupon['code']; detail = f"{value}% | {reference}"
    else:
        from core.domain import create_reward_request
        item = next(r for r in db['settings']['rewardItems'] if str(r['id']) == str(value))
        request = create_reward_request(db, user_id, item); reference = request['id']; detail = item['name']; status = 'pending'
    reward = record_user_reward(db, user_id, row['title'], reward_type=kind, detail=detail,
                                source='referral_milestone', status=status, reference_id=reference)
    claim = {'user_id': str(user_id), 'milestone_id': row['id'], 'cycle': row['claimed'] + 1,
             'reward_id': reward['id'], 'created_at': utc_iso()}
    from core.economy_integrity import economic_event
    economic_event(db, f'referral_milestone:{key}', user_id, kind=kind, value=value, actor=user_id, reason=row['title'], metadata={'milestone':row['id'],'reward_id':reward['id'],'cycle':row['claimed']+1,'payment_ids':sorted(__import__('core.economy_integrity',fromlist=['verified_referral_activity']).verified_referral_activity(db,user_id)[1])})
    claims[key] = claim
    audit(db, user_id, 'referral_milestone_claimed', key)
    return dict(claim)


def remove_milestone(db,actor,milestone_id):
    if not has_permission(db,actor,PERMISSION_REWARD_POINTS):
        raise PermissionError("مجوز مدیریت پاداش لازم است.")
    row=db.get('referral_milestones',{}).get(str(milestone_id))
    if not row or row.get('deleted_at'):
        raise ValueError("مرحله پیدا نشد یا قبلاً حذف شده است.")
    row.update(enabled=False,deleted_at=utc_iso(),deleted_by=str(actor))
    audit(db,actor,'referral_milestone_deleted',str(milestone_id))
