"""Full original candle OB geometry; absent native volume never becomes POC."""
from decimal import Decimal as D
from modules.strategies.common import indicators
from modules.strategies.fibonacci.engine import causal_wave
from modules.strategies.observations import contiguous,observation,safe_swings


def observe(context):
    bars,p = context.closed,context.parameters
    swings,atr = safe_swings(bars,p),indicators(bars)['atr']
    rows = []
    for i in range(20,len(bars)-2):
        ob,departure = bars[i:i+2]
        direction = 'BUY' if departure.close>departure.open else 'SELL'
        sign = D(1) if direction=='BUY' else D(-1)
        if sign*(ob.close-ob.open)>0 or sign*(bars[i-1].close-bars[i-1].open)<0:
            continue
        if sign*(departure.close-departure.open)<atr*p.displacement_atr or sign*(departure.close-(ob.high if direction=='BUY' else ob.low))<=0:
            continue
        if not contiguous(bars,i-1):
            continue
        pair = causal_wave(bars,swings,direction,i,confirmation_right=p.swing_right)
        wave = {'start_index':pair[0].index,'end_index':pair[1].index} if pair and contiguous(bars,pair[0].index,pair[1].index+1) else None
        row = observation(context,'order_block','causal_wave_poc_pending',direction,(ob.low,ob.high),
                          [ob.source_id,departure.source_id],after_ms=departure.end_ms,wave=wave,
                          facts=[{'kind':'ob_full_candle','source_id':ob.source_id,
                                  'departure_source_id':departure.source_id,'poc':'UNAVAILABLE'}],
                          missing=['CAUSAL_WAVE_NATIVE_VOLUME_PROFILE','NATIVE_DEPARTURE_VOLUME','ORDERED_OB_DEPARTURE'])
        if row:
            row['ob_source_id'] = ob.source_id
            rows.append(row)
    return rows

