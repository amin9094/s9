"""Independent M5/H1 sweep, closed reclaim and CHoCH, untouched FVG."""

from __future__ import annotations

from decimal import Decimal as D

from modules.entry_selection import fvg_entry
from modules.strategies.common import _candidate, confirmed_swings, indicators, structure_direction
from modules.strategies.fibonacci.engine import causal_wave


class SweepCHoCHFVG:
    name = "sweep_fvg"

    def evaluate(self, context):
        bars, p = context.closed, context.parameters
        swings = confirmed_swings(bars, p)
        atr = indicators(bars)["atr"]
        if atr <= 0:
            return []
        output, used = [], set()
        for sweep_index in range(p.swing_left + p.swing_right, len(bars) - 3):
            sweep = bars[sweep_index]
            # Ingested historical bars can share one receipt timestamp. Relative
            # confirmation still must precede the sweep; receipt is not bar time.
            known = [s for s in swings if s.index + p.swing_right < sweep_index]
            for direction, sign, poolkind in [("BUY", D(1), "low"), ("SELL", D(-1), "high")]:
                if structure_direction(known) != ('DOWN' if direction == 'BUY' else 'UP'):
                    continue  # A continuation BOS is not a reversal CHoCH.
                pools = [s for s in known if s.kind == poolkind]
                protected = [s for s in known if s.kind != poolkind]
                if not pools or not protected:
                    continue
                pool, structure = pools[-1], protected[-1]
                extreme = sweep.low if direction == "BUY" else sweep.high
                if sign * (pool.value - extreme) < max(atr * p.sweep_atr, context.spread * 2):
                    continue
                # No arbitrary candle limit: structural reclaim can be later.
                reclaim = next((j for j in range(sweep_index, len(bars)) if sign * (bars[j].close - pool.value) > 0), None)
                if reclaim is None:
                    continue
                choch = next((j for j in range(reclaim, len(bars)) if sign * (bars[j].close - structure.value) > 0), None)
                if choch is None:
                    continue
                identity = (direction, pool.index, structure.index, choch)
                if identity in used:
                    continue
                used.add(identity)
                ends = [s for s in swings if s.kind == ('high' if direction == 'BUY' else 'low') and s.index >= choch]
                impulse_end = ends[0].index if ends else len(bars) - 1
                rejected_gaps = []
                for third in range(sweep_index + 2, impulse_end + 1):
                    one, middle, three = bars[third - 2:third + 1]
                    zone = (one.high, three.low) if direction == "BUY" else (three.high, one.low)
                    if zone[1] <= zone[0]:
                        continue
                    if sign * (middle.close - middle.open) < atr * p.displacement_atr:
                        rejected_gaps.append({'third_index':third,'reason':'RELATED_DIRECTIONAL_DISPLACEMENT_INSUFFICIENT'})
                        continue
                    if zone[1] - zone[0] < max(atr * p.min_fvg_atr, context.spread * p.spread_gap_multiple):
                        rejected_gaps.append({'third_index':third,'reason':'FVG_WIDTH_BELOW_ATR_OR_SPREAD_THRESHOLD'})
                        continue
                    try:
                        entry, selection = fvg_entry(*zone, direction=direction, tick_size=context.tick_size, pip_size=context.pip_size)
                    except ValueError as exc:
                        rejected_gaps.append({'third_index':third,'reason':str(exc)})
                        continue
                    extremes = [getattr(b, "low" if direction == "BUY" else "high") for b in bars[sweep_index:choch + 1]]
                    invalidation = min(extremes + [pool.value]) if direction == "BUY" else max(extremes + [pool.value])
                    stop = invalidation - sign * max(context.spread * 2, atr * p.stop_buffer_atr)
                    facts = [("sweep_reclaim", bars[reclaim].available_ms, {"pool_index": pool.index, "pool_price":str(pool.value), "sweep_index": sweep_index, "reclaim_index": reclaim,
                                                                         "sweep_extreme":str(min(extremes) if direction == 'BUY' else max(extremes))}),
                             ("closed_choch", bars[choch].available_ms, {"index": choch, "protected_index": structure.index, "protected_price":str(structure.value),
                                                                        "prior_structure":structure_direction(known),"break_kind":"CHoCH"}),
                             ("fvg_third_close", three.available_ms, {"index": third}),
                             ("entry_selection", context.cutoff_ms, selection)]
                    wave = causal_wave(bars, swings, direction, third - 1, confirmation_right=p.swing_right)
                    if wave:
                        start, end = wave
                        facts.append(("causal_wave", end.available_ms, {"start_index": start.index, "end_index": end.index}))
                    row = _candidate(context, self.name, "liquidity_reversal", direction, zone, entry, stop,
                                     swings, [direction,bars[pool.index].source_id,bars[structure.index].source_id,
                                              bars[choch].source_id], facts, fresh_after=three.end_ms)
                    if row.get("plan"):
                        row['selection_basis'] = 'FIRST_CHRONOLOGICAL_VALID_FRESH_FVG'
                        row['earlier_disqualified_fvg'] = rejected_gaps
                        output.append(row)
                        break
                    rejected_gaps.append({'third_index':third,'reason':row.get('reason')})
        return output
