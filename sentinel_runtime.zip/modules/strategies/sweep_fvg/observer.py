"""Closed sweep/reclaim/CHoCH plus first fresh directional FVG geometry."""
from decimal import Decimal as D
from modules.strategies.common import indicators,structure_direction
from modules.strategies.fibonacci.engine import causal_wave
from modules.strategies.observations import contiguous,observation,safe_swings


def observe(context):
    bars,p = context.closed,context.parameters
    swings,atr = safe_swings(bars,p),indicators(bars)['atr']
    rows,used = [],set()
    if atr<=0:
        return rows
    for i in range(p.swing_left+p.swing_right,len(bars)-3):
        known = [s for s in swings if s.index+p.swing_right<i]
        for direction,sign,kind in [('BUY',D(1),'low'),('SELL',D(-1),'high')]:
            if structure_direction(known)!=('DOWN' if direction=='BUY' else 'UP'):
                continue
            pools,protected = [s for s in known if s.kind==kind],[s for s in known if s.kind!=kind]
            if not pools or not protected:
                continue
            pool,structure = pools[-1],protected[-1]
            if not contiguous(bars,min(pool.index,structure.index)):
                continue
            extreme = bars[i].low if direction=='BUY' else bars[i].high
            if sign*(pool.value-extreme)<atr*p.sweep_atr:
                continue
            reclaim = next((j for j in range(i,len(bars)) if sign*(bars[j].close-pool.value)>0),None)
            choch = next((j for j in range(reclaim,len(bars)) if sign*(bars[j].close-structure.value)>0),None) if reclaim is not None else None
            if choch is None or (direction,pool.index,structure.index,choch) in used:
                continue
            used.add((direction,pool.index,structure.index,choch))
            ends = [s.index for s in swings if s.kind==('high' if direction=='BUY' else 'low') and s.index>=choch]
            for third in range(i+2,(ends[0] if ends else len(bars)-1)+1):
                one,middle,three = bars[third-2:third+1]
                zone = (one.high,three.low) if direction=='BUY' else (three.high,one.low)
                if zone[1]-zone[0]<=0 or zone[1]-zone[0]<atr*p.min_fvg_atr or sign*(middle.close-middle.open)<atr*p.displacement_atr:
                    continue
                pair = causal_wave(bars,swings,direction,third-1,confirmation_right=p.swing_right)
                wave = {'start_index':pair[0].index,'end_index':pair[1].index} if pair else None
                row = observation(context,'sweep_fvg','liquidity_reversal',direction,zone,
                                  [bars[i].source_id,bars[choch].source_id,three.source_id],
                                  after_ms=three.end_ms,wave=wave,
                                  facts=[{'kind':'sweep_reclaim','pool_price':str(pool.value),'sweep_index':i,'reclaim_index':reclaim},
                                         {'kind':'closed_choch','index':choch,'protected_price':str(structure.value),'prior_structure':structure_direction(known)},
                                         {'kind':'fvg','third_index':third,'midpoint_reference':str(sum(zone)/2),
                                          'spread_gate_pending':True,'midpoint_is_entry':False}],
                                  missing=['NATIVE_SPREAD_FVG_WIDTH_CHECK','NATIVE_PIP_SIZE_FOR_OFFSET'])
                if row:
                    rows.append(row)
                    break
    return rows

