"""Isolated fibonacci strategy family."""
