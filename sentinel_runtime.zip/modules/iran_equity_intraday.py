"""Trade-derived Tehran-clock H4 bars; daily OHLC is never split into hours.

Only a complete trade list reconciled to official daily count, shares, value
and OHLC is accepted. Missing contracts or ambiguous ordering fail closed.
"""

from dataclasses import dataclass
from datetime import datetime, timedelta
from decimal import Decimal

from modules.iran_equities import TEHRAN, instrument_code, number


@dataclass(frozen=True)
class H4Bar:
    date: str
    start_ms: int
    end_ms: int
    open: Decimal
    high: Decimal
    low: Decimal
    close: Decimal
    volume: Decimal
    is_closed: bool

    def chart_bar(self):
        return {"timestamp": self.start_ms, **{k: float(getattr(self, k)) for k in ("open", "high", "low", "close", "volume")}}


def _integer(value, *, positive=False):
    result = number(value, positive=positive)
    if result != result.to_integral_value():
        raise ValueError("IR_EQUITY_TRADE_CONTRACT_INVALID")
    return int(result)


def h4_bars(payload, daily_row, day, code, observed_ms):
    code = instrument_code(code)
    rows = payload.get("tradeHistory") if isinstance(payload, dict) else None
    if not isinstance(rows, list) or not rows or len(rows) > 200000:
        raise ValueError("IR_EQUITY_INTRADAY_INCOMPLETE")
    official_count = _integer(daily_row.get("zTotTran"), positive=True)
    official_value = number(daily_row.get("qTotCap"), positive=True)
    local_day = datetime.fromisoformat(day.date).replace(tzinfo=TEHRAN)
    dated = int(local_day.strftime("%Y%m%d"))
    seen, trades = set(), []
    for row in rows:
        if not isinstance(row, dict):
            raise ValueError("IR_EQUITY_TRADE_CONTRACT_INVALID")
        if row.get("insCode") is not None and instrument_code(row["insCode"]) != code:
            raise ValueError("IR_EQUITY_IDENTITY_MISMATCH")
        if row.get("dEven") not in (None, 0) and str(row["dEven"]) != str(dated):
            raise ValueError("IR_EQUITY_IDENTITY_MISMATCH")
        # Do not guess whether a cancellation marker denotes an active trade.
        if row.get("canceled") not in (None, False, 0) or row.get('iAnuTran') not in (None, 0):
            raise ValueError("IR_EQUITY_TRADE_CONTRACT_INVALID")
        sequence = _integer(row.get("nTran"), positive=True)
        if sequence in seen:
            raise ValueError("IR_EQUITY_TRADE_DUPLICATE")
        seen.add(sequence)
        clock = _integer(row.get("hEven"))
        hour, minute, second = clock // 10000, clock // 100 % 100, clock % 100
        if hour > 23 or minute > 59 or second > 59:
            raise ValueError("IR_EQUITY_TRADE_TIME_INVALID")
        stamp = local_day.replace(hour=hour, minute=minute, second=second)
        if int(stamp.timestamp() * 1000) > observed_ms:
            raise ValueError("IR_EQUITY_TRADE_TIME_INVALID")
        price, volume = number(row.get("pTran"), positive=True), number(row.get("qTitTran"), positive=True)
        if volume != volume.to_integral_value():
            raise ValueError("IR_EQUITY_TRADE_CONTRACT_INVALID")
        trades.append((sequence, stamp, price, volume))
    trades.sort(key=lambda t: t[0])
    if any(a[1] > b[1] for a, b in zip(trades, trades[1:])):
        raise ValueError("IR_EQUITY_TRADE_ORDER_INVALID")
    prices = [t[2] for t in trades]
    if (len(trades) != official_count or sum(t[3] for t in trades) != day.volume
        or sum(t[2] * t[3] for t in trades) != official_value
        or (prices[0], max(prices), min(prices), prices[-1]) != (day.open, day.high, day.low, day.close)):
        raise ValueError("IR_EQUITY_INTRADAY_INCOMPLETE")
    buckets = {}
    for _, stamp, price, volume in trades:
        # 00–04, 04–08, 08–12, 12–16, ... Tehran civil clock.
        start = stamp.replace(hour=stamp.hour // 4 * 4, minute=0, second=0)
        buckets.setdefault(start, []).append((price, volume))
    result = []
    for start, items in sorted(buckets.items()):
        end_ms = int((start + timedelta(hours=4)).timestamp() * 1000)
        result.append(H4Bar(day.date, int(start.timestamp() * 1000), end_ms,
                            items[0][0], max(x[0] for x in items), min(x[0] for x in items),
                            items[-1][0], sum(x[1] for x in items), end_ms <= observed_ms))
    return result


def analyze_h4(bars, daily, observed_ms):
    from modules.iran_equities import _technical_values

    closed = [b for b in bars if b.is_closed]
    breaks = [b.date for a, b in zip(daily, daily[1:])
              if b.previous_weighted_close is None or b.previous_weighted_close != a.weighted_close]
    segment = [b for b in closed if not breaks or b.date >= breaks[-1]]
    latest = closed[-1] if closed else None
    stale = latest is None or observed_ms - latest.end_ms > 7 * 86400000
    result = {"mode": "H4_TECHNICAL_REVIEW", "timeframe": "4h", "is_signal": False,
              "execution_eligible": False, "currency": "IRR", "adjustment": "UNADJUSTED",
              "closed_bars": len(closed), "continuous_price_base_bars": len(segment),
              "required_closed_bars": 105, "latest_closed_date": latest.date if latest else None,
              "current_period_excluded": any(not b.is_closed for b in bars),
              "price_base_breaks": [{"date": d} for d in breaks[-20:]],
              "bucket_alignment": "TEHRAN_MIDNIGHT_4H", "session_calendar_verified": False,
              "state": "HISTORICAL_OR_HALTED" if stale else "INDICATOR_WARMUP_INCOMPLETE"
              if len(segment) < 105 else "H4_REVIEW_AVAILABLE"}
    if len(segment) >= 105 and not stale:
        result.update(_technical_values(segment))
    return result
