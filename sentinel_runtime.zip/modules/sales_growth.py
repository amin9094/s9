from __future__ import annotations

import secrets
from collections import Counter
from datetime import timedelta
from typing import Any

from core.db import next_id
from core.utils import parse_dt, utc_iso, utc_now
from modules.discount_campaigns import normalize_campaign_fields

PLAN_AUDIENCES = {"all", "new", "renewal"}


def _as_int(value: Any, default: int = 0) -> int:
    try:
        return int(str(value or default).replace(",", ""))
    except (TypeError, ValueError):
        return default


def ensure_vip_plans(db: dict[str, Any]) -> list[dict[str, Any]]:
    plans = db.setdefault("vip_plans", [])
    if not isinstance(plans, list):
        plans = []
        db["vip_plans"] = plans
    valid = [row for row in plans if isinstance(row, dict)]
    if not valid:
        settings = db.setdefault("vip_settings", {})
        default = {
            "id": next_id(db, "vip_plan"),
            "name": "اشتراک VIP استاندارد",
            "description": "دسترسی کامل به سیگنال‌ها و کانال VIP",
            "price": max(0, _as_int(settings.get("price"))),
            "original_price": 0,
            "duration_days": max(1, _as_int(settings.get("duration_days"), 30)),
            "features": ["دسترسی به کانال VIP", "سیگنال‌های ویژه", "پشتیبانی کاربران VIP"],
            "audience": "all",
            "highlight": True,
            "active": True,
            "starts_at": None,
            "ends_at": None,
            "sales_limit": 0,
            "sales_count": 0,
            "sort_order": 10,
            "created_at": utc_iso(),
            "updated_at": utc_iso(),
        }
        plans.append(default)
        valid = [default]
    for row in valid:
        row.setdefault("description", "")
        row.setdefault("original_price", 0)
        row.setdefault("features", [])
        row.setdefault("audience", "all")
        row.setdefault("highlight", False)
        row.setdefault("active", True)
        row.setdefault("starts_at", None)
        row.setdefault("ends_at", None)
        row.setdefault("sales_limit", 0)
        row.setdefault("sales_count", 0)
        row.setdefault("sort_order", 100)
        row.setdefault("updated_at", row.get("created_at") or utc_iso())
    return valid


def get_vip_plan(db: dict[str, Any], plan_id: int | str | None) -> dict[str, Any] | None:
    if plan_id in {None, ""}:
        plans = active_vip_plans(db, user_is_vip=False)
        return plans[0] if plans else None
    try:
        target = int(plan_id)
    except (TypeError, ValueError):
        return None
    return next((row for row in ensure_vip_plans(db) if int(row.get("id", 0) or 0) == target), None)


def _plan_available(row: dict[str, Any], *, user_is_vip: bool, user_has_purchased: bool | None = None, now=None) -> bool:
    current = now or utc_now()
    if not bool(row.get("active", True)):
        return False
    starts = parse_dt(row.get("starts_at"))
    ends = parse_dt(row.get("ends_at"))
    if starts and starts > current:
        return False
    if ends and ends <= current:
        return False
    audience = str(row.get("audience") or "all")
    has_purchase = user_is_vip if user_has_purchased is None else bool(user_has_purchased)
    if audience == "new" and (user_is_vip or has_purchase):
        return False
    if audience == "renewal" and not (user_is_vip or has_purchase):
        return False
    limit = max(0, _as_int(row.get("sales_limit")))
    if limit and _as_int(row.get("sales_count")) >= limit:
        return False
    return True


def active_vip_plans(db: dict[str, Any], *, user_is_vip: bool, user_has_purchased: bool | None = None) -> list[dict[str, Any]]:
    rows = [
        row for row in ensure_vip_plans(db)
        if _plan_available(row, user_is_vip=user_is_vip, user_has_purchased=user_has_purchased)
    ]
    rows.sort(key=lambda row: (not bool(row.get("highlight")), _as_int(row.get("sort_order"), 100), _as_int(row.get("price"))))
    return rows


def create_vip_plan(
    db: dict[str, Any],
    *,
    name: str,
    price: int,
    duration_days: int,
    description: str = "",
    original_price: int = 0,
    features: list[str] | None = None,
    audience: str = "all",
    highlight: bool = False,
    sales_limit: int = 0,
    starts_at: str | None = None,
    ends_at: str | None = None,
    created_by: int | str = "",
) -> dict[str, Any]:
    title = str(name or "").strip()[:80]
    if len(title) < 2:
        raise ValueError("نام پلن باید حداقل ۲ کاراکتر باشد")
    amount = int(price)
    days = int(duration_days)
    if amount < 0 or amount > 10_000_000_000:
        raise ValueError("قیمت پلن نامعتبر است")
    if not 1 <= days <= 3650:
        raise ValueError("مدت پلن باید بین ۱ تا ۳۶۵۰ روز باشد")
    audience = str(audience or "all").lower()
    if audience not in PLAN_AUDIENCES:
        raise ValueError("مخاطب پلن باید all، new یا renewal باشد")
    start_dt = parse_dt(starts_at) if starts_at else None
    end_dt = parse_dt(ends_at) if ends_at else None
    if starts_at and start_dt is None:
        raise ValueError("زمان شروع نامعتبر است")
    if ends_at and end_dt is None:
        raise ValueError("زمان پایان نامعتبر است")
    if start_dt and end_dt and end_dt <= start_dt:
        raise ValueError("زمان پایان باید بعد از شروع باشد")
    row = {
        "id": next_id(db, "vip_plan"),
        "name": title,
        "description": str(description or "")[:500],
        "price": amount,
        "original_price": max(0, int(original_price)),
        "duration_days": days,
        "features": [str(item).strip()[:100] for item in (features or []) if str(item).strip()][:10],
        "audience": audience,
        "highlight": bool(highlight),
        "active": True,
        "starts_at": utc_iso(start_dt) if start_dt else None,
        "ends_at": utc_iso(end_dt) if end_dt else None,
        "sales_limit": max(0, int(sales_limit)),
        "sales_count": 0,
        "sort_order": len(ensure_vip_plans(db)) * 10 + 10,
        "created_by": str(created_by),
        "created_at": utc_iso(),
        "updated_at": utc_iso(),
    }
    db.setdefault("vip_plans", []).append(row)
    return row


def update_vip_plan(db: dict[str, Any], plan_id: int | str, field: str, value: Any) -> dict[str, Any]:
    row = get_vip_plan(db, plan_id)
    if not row:
        raise ValueError("پلن پیدا نشد")
    key = str(field or "")
    if key == "name":
        clean = str(value or "").strip()[:80]
        if len(clean) < 2:
            raise ValueError("نام پلن باید حداقل ۲ کاراکتر باشد")
        row["name"] = clean
    elif key == "price":
        amount = int(value)
        if not 0 <= amount <= 10_000_000_000:
            raise ValueError("قیمت پلن نامعتبر است")
        row["price"] = amount
    elif key == "original_price":
        amount = int(value)
        if not 0 <= amount <= 10_000_000_000:
            raise ValueError("قیمت قبلی نامعتبر است")
        row["original_price"] = amount
    elif key == "duration_days":
        days = int(value)
        if not 1 <= days <= 3650:
            raise ValueError("مدت پلن باید بین ۱ تا ۳۶۵۰ روز باشد")
        row["duration_days"] = days
    elif key == "sales_limit":
        limit = int(value)
        if limit < 0:
            raise ValueError("سقف فروش نامعتبر است")
        if limit and limit < _as_int(row.get("sales_count")):
            raise ValueError("سقف فروش نمی‌تواند کمتر از فروش ثبت‌شده باشد")
        row["sales_limit"] = limit
    elif key == "description":
        row["description"] = str(value or "").strip()[:500]
    elif key == "audience":
        audience = str(value or "all").lower()
        if audience not in PLAN_AUDIENCES:
            raise ValueError("مخاطب پلن باید all، new یا renewal باشد")
        row["audience"] = audience
    elif key == "highlight":
        row["highlight"] = bool(value)
    elif key == "features":
        if not isinstance(value, list):
            raise ValueError("امکانات پلن نامعتبر است")
        row["features"] = [str(item).strip()[:100] for item in value if str(item).strip()][:10]
    elif key == "window":
        if not isinstance(value, dict):
            raise ValueError("بازه زمانی نامعتبر است")
        starts_at = value.get("starts_at")
        ends_at = value.get("ends_at")
        start_dt = parse_dt(starts_at) if starts_at else None
        end_dt = parse_dt(ends_at) if ends_at else None
        if starts_at and start_dt is None:
            raise ValueError("زمان شروع نامعتبر است")
        if ends_at and end_dt is None:
            raise ValueError("زمان پایان نامعتبر است")
        if start_dt and end_dt and end_dt <= start_dt:
            raise ValueError("زمان پایان باید بعد از شروع باشد")
        row["starts_at"] = utc_iso(start_dt) if start_dt else None
        row["ends_at"] = utc_iso(end_dt) if end_dt else None
    else:
        raise ValueError("فیلد ویرایش پلن نامعتبر است")
    row["updated_at"] = utc_iso()
    return row


def cycle_vip_plan_audience(db: dict[str, Any], plan_id: int | str) -> dict[str, Any]:
    row = get_vip_plan(db, plan_id)
    if not row:
        raise ValueError("پلن پیدا نشد")
    values = ("all", "new", "renewal")
    current = str(row.get("audience") or "all")
    try:
        index = values.index(current)
    except ValueError:
        index = 0
    row["audience"] = values[(index + 1) % len(values)]
    row["updated_at"] = utc_iso()
    return row


def toggle_vip_plan(db: dict[str, Any], plan_id: int | str) -> dict[str, Any]:
    row = get_vip_plan(db, plan_id)
    if not row:
        raise ValueError("پلن پیدا نشد")
    row["active"] = not bool(row.get("active", True))
    row["updated_at"] = utc_iso()
    return row


def toggle_vip_plan_highlight(db: dict[str, Any], plan_id: int | str) -> dict[str, Any]:
    row = get_vip_plan(db, plan_id)
    if not row:
        raise ValueError("پلن پیدا نشد")
    row["highlight"] = not bool(row.get("highlight", False))
    row["updated_at"] = utc_iso()
    return row


def delete_vip_plan(db: dict[str, Any], plan_id: int | str) -> bool:
    plans = ensure_vip_plans(db)
    target = int(plan_id)
    if len(plans) <= 1:
        raise ValueError("حداقل یک پلن باید باقی بماند")
    before = len(plans)
    db["vip_plans"] = [row for row in plans if int(row.get("id", 0) or 0) != target]
    return len(db["vip_plans"]) != before


def register_plan_sale(db: dict[str, Any], plan_id: int | str | None) -> None:
    row = get_vip_plan(db, plan_id)
    if row:
        row["sales_count"] = _as_int(row.get("sales_count")) + 1
        row["updated_at"] = utc_iso()


def reconcile_plan_sales(db: dict[str, Any]) -> dict[str, Any]:
    """Rebuild plan counters exclusively from approved VIP orders."""
    counts: dict[int, int] = {}
    for order in db.get("vip_orders", []):
        if not isinstance(order, dict) or str(order.get("status")) != "approved":
            continue
        plan_id = _as_int(order.get("plan_id"))
        if plan_id > 0:
            counts[plan_id] = counts.get(plan_id, 0) + 1
    changed = 0
    for plan in ensure_vip_plans(db):
        expected = counts.get(_as_int(plan.get("id")), 0)
        if _as_int(plan.get("sales_count")) != expected:
            plan["sales_count"] = expected
            plan["updated_at"] = utc_iso()
            changed += 1
    return {"plans_changed": changed, "approved_sales": sum(counts.values()), "counts": counts}


def create_public_discount(
    db: dict[str, Any],
    *,
    code: str,
    percent: int,
    starts_at: str | None,
    ends_at: str,
    max_uses: int = 0,
    one_per_user: bool = True,
    created_by: int | str = "",
) -> dict[str, Any]:
    clean = "".join(ch for ch in str(code or "").strip().upper() if ch.isalnum() or ch in {"-", "_"})
    if not 4 <= len(clean) <= 24:
        raise ValueError("کد عمومی باید بین ۴ تا ۲۴ کاراکتر باشد")
    if clean in db.setdefault("discount_codes", {}):
        raise ValueError("این کد قبلاً وجود دارد")
    pct = int(percent)
    if not 1 <= pct <= 100:
        raise ValueError("درصد باید بین ۱ تا ۱۰۰ باشد")
    start = parse_dt(starts_at) if starts_at else utc_now()
    end = parse_dt(ends_at)
    if start is None or end is None:
        raise ValueError("زمان شروع یا پایان نامعتبر است")
    if end <= start:
        raise ValueError("زمان پایان باید بعد از شروع باشد")
    row = {
        "code": clean,
        "percent": pct,
        "status": "active",
        "scope": "public",
        "assigned_to": "",
        "starts_at": utc_iso(start),
        "expires_at": utc_iso(end),
        "max_uses": max(0, int(max_uses)),
        "used_count": 0,
        "used_by": [],
        "one_per_user": bool(one_per_user),
        "reservations": {},
        "reserved_order_id": None,
        "created_at": utc_iso(),
        "created_by": str(created_by),
        "source": "admin_public_campaign",
        "pool": False,
        "admin_distribution_only": True,
    }
    normalize_campaign_fields(row)
    db["discount_codes"][clean] = row
    return row




def create_weekly_public_discount(
    db: dict[str, Any],
    *,
    code: str,
    percent: int,
    created_by: int | str = "",
    max_uses: int = 0,
    one_per_user: bool = True,
) -> dict[str, Any]:
    """Create a public campaign that starts now and expires after seven days."""
    now = utc_now()
    row = create_public_discount(
        db,
        code=code,
        percent=percent,
        starts_at=None,
        ends_at=utc_iso(now + timedelta(days=7)),
        max_uses=max_uses,
        one_per_user=one_per_user,
        created_by=created_by,
    )
    row["duration_days"] = 7
    row["auto_expire"] = True
    row["updated_at"] = utc_iso()
    return row


def _sync_public_discount_expiry(row: dict[str, Any]) -> dict[str, Any]:
    expiry = parse_dt(row.get("expires_at"))
    if expiry is not None and expiry <= utc_now() and row.get("status") != "expired":
        row["status"] = "expired"
        row["expired_at"] = row.get("expires_at") or utc_iso()
        row["updated_at"] = utc_iso()
    return row


def expire_public_discount(
    db: dict[str, Any],
    code: str,
    *,
    expired_by: int | str = "",
) -> dict[str, Any]:
    row = db.setdefault("discount_codes", {}).get(str(code).strip().upper())
    if not isinstance(row, dict) or row.get("scope") != "public":
        raise ValueError("کد عمومی پیدا نشد")
    now = utc_iso()
    row.update(
        {
            "status": "expired",
            "expires_at": now,
            "expired_at": now,
            "expired_by": str(expired_by),
            "manual_expiry": True,
            "updated_at": now,
        }
    )
    return row


def public_discount_codes(db: dict[str, Any], *, include_inactive: bool = True) -> list[dict[str, Any]]:
    rows = [
        _sync_public_discount_expiry(row)
        for row in db.setdefault("discount_codes", {}).values()
        if isinstance(row, dict) and str(row.get("scope") or "") == "public"
    ]
    if not include_inactive:
        rows = [row for row in rows if row.get("status") == "active"]
    rows.sort(key=lambda row: str(row.get("created_at") or ""), reverse=True)
    return rows


def toggle_public_discount(db: dict[str, Any], code: str) -> dict[str, Any]:
    row = db.setdefault("discount_codes", {}).get(str(code).upper())
    if not isinstance(row, dict) or row.get("scope") != "public":
        raise ValueError("کد عمومی پیدا نشد")
    _sync_public_discount_expiry(row)
    if row.get("status") == "expired":
        raise ValueError("این کد منقضی شده و قابل فعال‌سازی دوباره نیست")
    row["status"] = "disabled" if row.get("status") == "active" else "active"
    row["updated_at"] = utc_iso()
    return row


def sales_funnel_snapshot(db: dict[str, Any], *, days: int = 30) -> dict[str, Any]:
    cutoff = utc_now() - timedelta(days=max(1, int(days)))
    stage_actions = {
        "entered": {"bot_started", "start", "menu_opened"},
        "vip_viewed": {"vip_page_viewed"},
        "plan_selected": {"vip_plan_selected"},
        "checkout_started": {"vip_checkout_started", "vip_coupon_step", "vip_receipt_requested"},
        "order_created": {"vip_order_created"},
        "approved": {"vip_order_approved"},
    }
    users: dict[str, set[str]] = {key: set() for key in stage_actions}
    for row in db.get("user_activity", []):
        if not isinstance(row, dict):
            continue
        created = parse_dt(row.get("created_at"))
        if created and created < cutoff:
            continue
        action = str(row.get("action") or "")
        uid = str(row.get("user_id") or "")
        if not uid:
            continue
        for stage, actions in stage_actions.items():
            if action in actions:
                users[stage].add(uid)
    # Reliable order data supplements activity logs.
    for order in db.get("vip_orders", []):
        if not isinstance(order, dict):
            continue
        created = parse_dt(order.get("created_at"))
        if created and created < cutoff:
            continue
        uid = str(order.get("user_id") or "")
        if uid:
            users["order_created"].add(uid)
            users["checkout_started"].add(uid)
            users["plan_selected"].add(uid)
            users["vip_viewed"].add(uid)
            if order.get("status") == "approved":
                users["approved"].add(uid)
    all_registered = {
        str(uid) for uid, user in db.get("users", {}).items()
        if not parse_dt(user.get("created_at")) or parse_dt(user.get("created_at")) >= cutoff
    }
    users["entered"].update(all_registered)
    order_counts = Counter(str(row.get("status") or "unknown") for row in db.get("vip_orders", []) if isinstance(row, dict))
    stages = ["entered", "vip_viewed", "plan_selected", "checkout_started", "order_created", "approved"]
    counts = {stage: len(users[stage]) for stage in stages}
    conversions: dict[str, float] = {}
    for prev, current in zip(stages, stages[1:], strict=False):
        conversions[f"{prev}_to_{current}"] = counts[current] / max(1, counts[prev]) * 100
    return {
        "days": max(1, int(days)),
        "counts": counts,
        "conversions": conversions,
        "pending_orders": order_counts.get("pending", 0) + order_counts.get("approving", 0),
        "rejected_orders": order_counts.get("rejected", 0),
        "approved_orders": order_counts.get("approved", 0),
        "abandoned_users": sorted(users["checkout_started"] - users["order_created"]),
        "viewer_dropoff_users": sorted(users["vip_viewed"] - users["plan_selected"]),
    }


def crm_segment_snapshot(db: dict[str, Any]) -> dict[str, list[str]]:
    from modules.user_intelligence import rebuild_all_user_profiles

    profiles = rebuild_all_user_profiles(db)
    result: dict[str, list[str]] = {}
    for uid, profile in profiles.items():
        for segment in profile.get("segments", []):
            result.setdefault(str(segment), []).append(str(uid))
    for users in result.values():
        users.sort(key=lambda uid: int(uid) if uid.isdigit() else 0)
    return result


def random_public_code(prefix: str = "VRXPUB") -> str:
    return f"{prefix}{secrets.token_hex(3).upper()}"
