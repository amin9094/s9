from __future__ import annotations

import asyncio
import json
import logging
import os
import tempfile
import time
from dataclasses import asdict, dataclass, field
from datetime import UTC, datetime
from statistics import median
from typing import Any

from config import SETTINGS
from core.async_runtime import run_blocking
from core.async_primitives import LoopLocalLock
from core.http_client import get_json

logger = logging.getLogger(__name__)

_TROY_OUNCE_GRAMS = 31.1034768
_GOLD_18_PURITY = 0.75
_CACHE_TTL_SECONDS = 60
_STALE_MAX_AGE_SECONDS = 6 * 60 * 60
_CACHE_FILE = SETTINGS.db_file.parent / "iran_market_cache.json"
_CACHE: tuple[float, IranMarketSnapshot] | None = None
_CACHE_LOCK = LoopLocalLock()


@dataclass(frozen=True, slots=True)
class IranMarketQuote:
    symbol: str
    title: str
    price: float
    unit: str
    change_percent: float | None
    source: str
    estimated: bool
    updated_at: str


@dataclass(frozen=True, slots=True)
class IranMarketSnapshot:
    dollar: IranMarketQuote
    tether: IranMarketQuote
    gold18: IranMarketQuote
    fetched_at: str
    stale: bool = False
    extras: tuple[IranMarketQuote, ...] = field(default_factory=tuple)

    @property
    def sources(self) -> tuple[str, ...]:
        return tuple(dict.fromkeys(item.source for item in self.all_quotes))

    @property
    def all_quotes(self) -> tuple[IranMarketQuote, ...]:
        return (self.dollar, self.tether, self.gold18, *self.extras)

    def quote(self, symbol: str) -> IranMarketQuote | None:
        wanted = str(symbol or "").strip().lower()
        aliases = {
            "dollar": "USD",
            "tether": "USDT_IRT",
            "gold18": "IR_GOLD_18K",
            "gold24": "IR_GOLD_24K",
            "mesghal": "IR_GOLD_MESGHAL",
            "coin_emami": "IR_COIN_EMAMI",
            "coin_bahar": "IR_COIN_BAHAR",
            "half_coin": "IR_COIN_HALF",
            "quarter_coin": "IR_COIN_QUARTER",
            "gerami_coin": "IR_COIN_GRAMI",
            "euro_iran": "EUR",
            "aed_iran": "AED",
            "gbp_iran": "GBP",
            "try_iran": "TRY",
        }
        target = aliases.get(wanted, wanted.upper())
        return next((item for item in self.all_quotes if item.symbol.upper() == target), None)


async def _get_json(url: str) -> Any:
    try:
        return await get_json(url, headers={"User-Agent": "SENTINELBot/5.2", "Accept": "application/json"}, retries=2)
    except Exception as exc:
        raise RuntimeError("سرویس قیمت پاسخ معتبر نداد") from exc


def _to_float(value: Any) -> float:
    try:
        number = float(str(value).replace(",", "").strip())
    except (TypeError, ValueError) as exc:
        raise ValueError("invalid numeric value") from exc
    if number <= 0:
        raise ValueError("non-positive numeric value")
    return number


def _normalize_toman(price: Any, unit: Any) -> float:
    value = _to_float(price)
    normalized_unit = str(unit or "").strip().lower()
    if "ریال" in normalized_unit or normalized_unit in {"rial", "irr", "rls"}:
        value /= 10
    return value


def _now_iso() -> str:
    return datetime.now(UTC).isoformat()


def _quote_from_brs(item: dict[str, Any], *, title: str) -> IranMarketQuote:
    change_raw = item.get("change_percent")
    try:
        change = float(change_raw) if change_raw is not None else None
    except (TypeError, ValueError):
        change = None
    return IranMarketQuote(
        symbol=str(item.get("symbol") or ""),
        title=title,
        price=_normalize_toman(item.get("price"), item.get("unit")),
        unit="تومان",
        change_percent=change,
        source="BrsApi",
        estimated=False,
        updated_at=_now_iso(),
    )


def _find_symbol(payload: Any, symbol: str) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    for section in ("gold", "currency", "cryptocurrency", "data"):
        rows = payload.get(section)
        if isinstance(rows, list):
            for row in rows:
                if isinstance(row, dict) and str(row.get("symbol", "")).upper() == symbol:
                    return row
    return None


_BRS_EXTRA_SYMBOLS: dict[str, tuple[str, str]] = {
    "IR_GOLD_24K": ("IR_GOLD_24K", "طلای ۲۴ عیار (هر گرم)"),
    "IR_GOLD_MESGHAL": ("IR_GOLD_MESGHAL", "مثقال طلا"),
    "IR_COIN_EMAMI": ("IR_COIN_EMAMI", "سکه امامی"),
    "IR_COIN_BAHAR": ("IR_COIN_BAHAR", "سکه بهار آزادی"),
    "IR_COIN_HALF": ("IR_COIN_HALF", "نیم‌سکه"),
    "IR_COIN_QUARTER": ("IR_COIN_QUARTER", "ربع‌سکه"),
    "IR_COIN_GRAMI": ("IR_COIN_GRAMI", "سکه گرمی"),
    "EUR": ("EUR", "یورو آزاد"),
    "GBP": ("GBP", "پوند آزاد"),
    "AED": ("AED", "درهم امارات"),
    "TRY": ("TRY", "لیر ترکیه"),
}


async def _fetch_brs_snapshot() -> IranMarketSnapshot | None:
    api_key = os.getenv("BRS_API_KEY", "").strip()
    if not api_key:
        return None
    payload = await _get_json(f"https://Api.BrsApi.ir/Market/Gold_Currency.php?key={api_key}")
    usd = _find_symbol(payload, "USD")
    usdt = _find_symbol(payload, "USDT_IRT")
    gold18 = _find_symbol(payload, "IR_GOLD_18K")
    if not (usd and usdt and gold18):
        raise RuntimeError("پاسخ BrsApi شامل هر سه نماد موردنیاز نبود")
    now = _now_iso()
    extras: list[IranMarketQuote] = []
    for lookup_symbol, (canonical, title) in _BRS_EXTRA_SYMBOLS.items():
        item = _find_symbol(payload, lookup_symbol)
        if item:
            quote = _quote_from_brs(item, title=title)
            extras.append(
                IranMarketQuote(
                    canonical, quote.title, quote.price, quote.unit, quote.change_percent, quote.source, quote.estimated, quote.updated_at
                )
            )
    return IranMarketSnapshot(
        dollar=_quote_from_brs(usd, title="دلار آزاد"),
        tether=_quote_from_brs(usdt, title="تتر"),
        gold18=_quote_from_brs(gold18, title="طلای ۱۸ عیار (هر گرم)"),
        fetched_at=now,
        extras=tuple(extras),
    )


async def _fetch_nobitex_usdt() -> tuple[float, float | None, str]:
    payload = await _get_json("https://apiv2.nobitex.ir/market/stats?srcCurrency=usdt&dstCurrency=rls")
    if not isinstance(payload, dict) or payload.get("status") != "ok":
        raise RuntimeError("پاسخ نوبیتکس نامعتبر است")
    stats = payload.get("stats")
    if not isinstance(stats, dict):
        raise RuntimeError("آمار نوبیتکس موجود نیست")
    row = stats.get("usdt-rls") or stats.get("USDT-RLS")
    if not isinstance(row, dict):
        for key, value in stats.items():
            if str(key).lower().replace("_", "-") == "usdt-rls" and isinstance(value, dict):
                row = value
                break
    if not isinstance(row, dict):
        raise RuntimeError("بازار تتر ریالی نوبیتکس یافت نشد")
    price_toman = _to_float(row.get("latest")) / 10
    change_raw = row.get("dayChange")
    try:
        change = float(change_raw) if change_raw is not None else None
    except (TypeError, ValueError):
        change = None
    return price_toman, change, "Nobitex"


async def _fetch_wallex_usdt() -> tuple[float, float | None, str]:
    payload = await _get_json("https://api.wallex.ir/v1/markets")
    if not isinstance(payload, dict) or not payload.get("success"):
        raise RuntimeError("پاسخ والکس نامعتبر است")
    result = payload.get("result")
    symbols = result.get("symbols") if isinstance(result, dict) else None
    if not isinstance(symbols, dict):
        raise RuntimeError("لیست بازارهای والکس موجود نیست")

    row: dict[str, Any] | None = None
    preferred_keys = ("USDTTMN", "USDTIRT", "USDTTOMAN")
    for key in preferred_keys:
        candidate = symbols.get(key)
        if isinstance(candidate, dict):
            row = candidate
            break
    if row is None:
        for candidate in symbols.values():
            if not isinstance(candidate, dict):
                continue
            base = str(candidate.get("baseAsset", "")).upper()
            quote = str(candidate.get("quoteAsset", "")).upper()
            if base == "USDT" and quote in {"TMN", "IRT", "TOMAN"}:
                row = candidate
                break
    if row is None:
        raise RuntimeError("بازار تتر تومانی والکس یافت نشد")

    stats = row.get("stats")
    if not isinstance(stats, dict):
        raise RuntimeError("آمار بازار تتر والکس موجود نیست")
    price = _to_float(stats.get("lastPrice"))
    change_raw = stats.get("24h_ch")
    try:
        change = float(change_raw) if change_raw is not None else None
    except (TypeError, ValueError):
        change = None
    return price, change, "Wallex"


async def _fetch_global_gold_ounce() -> tuple[float, str]:
    payload = await _get_json("https://api.gold-api.com/price/XAU")
    if not isinstance(payload, dict):
        raise RuntimeError("پاسخ قیمت جهانی طلا نامعتبر است")
    return _to_float(payload.get("price")), "Gold-API"


def _successful_tether_rows(results: list[Any]) -> list[tuple[float, float | None, str]]:
    rows: list[tuple[float, float | None, str]] = []
    for result in results:
        if isinstance(result, Exception):
            logger.info("Iran market fallback source failed: %s", result)
            continue
        if isinstance(result, tuple) and len(result) == 3:
            try:
                price = _to_float(result[0])
            except ValueError:
                continue
            rows.append((price, result[1], str(result[2])))
    return rows


async def _fetch_fallback_snapshot() -> IranMarketSnapshot:
    nobitex_result, wallex_result, gold_result = await asyncio.gather(
        _fetch_nobitex_usdt(),
        _fetch_wallex_usdt(),
        _fetch_global_gold_ounce(),
        return_exceptions=True,
    )
    tether_rows = _successful_tether_rows([nobitex_result, wallex_result])
    if not tether_rows:
        raise RuntimeError("هیچ منبع تتر ایرانی در دسترس نیست")

    tether_price = float(median(row[0] for row in tether_rows))
    changes = [row[1] for row in tether_rows if isinstance(row[1], (int, float))]
    tether_change = float(sum(changes) / len(changes)) if changes else None
    tether_sources = " + ".join(row[2] for row in tether_rows)
    now = _now_iso()

    if isinstance(gold_result, BaseException):
        raise RuntimeError("قیمت جهانی طلا در دسترس نیست") from gold_result
    ounce_usd, gold_source = gold_result
    gold18_toman = ounce_usd * tether_price * _GOLD_18_PURITY / _TROY_OUNCE_GRAMS

    tether = IranMarketQuote(
        symbol="USDT_IRT",
        title="تتر",
        price=tether_price,
        unit="تومان",
        change_percent=tether_change,
        source=tether_sources,
        estimated=False,
        updated_at=now,
    )
    dollar = IranMarketQuote(
        symbol="USD_EST",
        title="دلار آزاد",
        price=tether_price,
        unit="تومان",
        change_percent=tether_change,
        source=f"برآورد از {tether_sources}",
        estimated=True,
        updated_at=now,
    )
    gold18 = IranMarketQuote(
        symbol="IR_GOLD_18K_EST",
        title="طلای ۱۸ عیار (هر گرم)",
        price=gold18_toman,
        unit="تومان",
        change_percent=None,
        source=f"{gold_source} + بازار تتر ایران",
        estimated=True,
        updated_at=now,
    )
    gold24 = IranMarketQuote(
        symbol="IR_GOLD_24K",
        title="طلای ۲۴ عیار (هر گرم)",
        price=ounce_usd * tether_price / _TROY_OUNCE_GRAMS,
        unit="تومان",
        change_percent=None,
        source=f"{gold_source} + بازار تتر ایران",
        estimated=True,
        updated_at=now,
    )
    mesghal = IranMarketQuote(
        symbol="IR_GOLD_MESGHAL",
        title="مثقال طلا",
        price=gold18_toman * 4.6083,
        unit="تومان",
        change_percent=None,
        source=f"{gold_source} + بازار تتر ایران",
        estimated=True,
        updated_at=now,
    )
    return IranMarketSnapshot(dollar=dollar, tether=tether, gold18=gold18, fetched_at=now, extras=(gold24, mesghal))


def _snapshot_to_dict(snapshot: IranMarketSnapshot) -> dict[str, Any]:
    return asdict(snapshot)


def _quote_from_dict(data: Any) -> IranMarketQuote:
    if not isinstance(data, dict):
        raise ValueError("invalid quote cache")
    return IranMarketQuote(
        symbol=str(data["symbol"]),
        title=str(data["title"]),
        price=_to_float(data["price"]),
        unit=str(data.get("unit") or "تومان"),
        change_percent=float(data["change_percent"]) if data.get("change_percent") is not None else None,
        source=str(data.get("source") or "نامشخص"),
        estimated=bool(data.get("estimated")),
        updated_at=str(data.get("updated_at") or _now_iso()),
    )


def _snapshot_from_dict(data: Any, *, stale: bool) -> IranMarketSnapshot:
    if not isinstance(data, dict):
        raise ValueError("invalid snapshot cache")
    return IranMarketSnapshot(
        dollar=_quote_from_dict(data["dollar"]),
        tether=_quote_from_dict(data["tether"]),
        gold18=_quote_from_dict(data["gold18"]),
        fetched_at=str(data.get("fetched_at") or _now_iso()),
        stale=stale,
        extras=tuple(_quote_from_dict(item) for item in data.get("extras", []) if isinstance(item, dict)),
    )


def _write_persistent_cache(snapshot: IranMarketSnapshot) -> None:
    try:
        _CACHE_FILE.parent.mkdir(parents=True, exist_ok=True)
        payload = {
            "saved_at": time.time(),
            "snapshot": _snapshot_to_dict(snapshot),
        }
        fd, tmp_name = tempfile.mkstemp(prefix="iran-prices-", suffix=".json", dir=str(_CACHE_FILE.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, ensure_ascii=False, allow_nan=False)
                handle.flush()
                os.fsync(handle.fileno())
            os.replace(tmp_name, _CACHE_FILE)
        finally:
            if os.path.exists(tmp_name):
                os.unlink(tmp_name)
    except (OSError, TypeError, ValueError):
        logger.exception("Could not persist Iran market price cache")


def _read_persistent_cache() -> IranMarketSnapshot | None:
    try:
        data = json.loads(_CACHE_FILE.read_text(encoding="utf-8"))
        saved_at = float(data.get("saved_at", 0))
        if time.time() - saved_at > _STALE_MAX_AGE_SECONDS:
            return None
        return _snapshot_from_dict(data.get("snapshot"), stale=True)
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None


async def fetch_iran_market_snapshot(*, force: bool = False) -> IranMarketSnapshot:
    global _CACHE
    now_mono = time.monotonic()
    if not force and _CACHE and now_mono - _CACHE[0] < _CACHE_TTL_SECONDS:
        return _CACHE[1]

    async with _CACHE_LOCK():
        now_mono = time.monotonic()
        if not force and _CACHE and now_mono - _CACHE[0] < _CACHE_TTL_SECONDS:
            return _CACHE[1]
        try:
            try:
                snapshot = await _fetch_brs_snapshot()
            except Exception as exc:
                logger.warning("BrsApi unavailable; using public fallback sources: %s", exc)
                snapshot = None
            if snapshot is None:
                snapshot = await _fetch_fallback_snapshot()
            _CACHE = (time.monotonic(), snapshot)
            await run_blocking(_write_persistent_cache, snapshot)
            return snapshot
        except Exception:
            logger.exception("Iran market price fetch failed")
            if _CACHE:
                cached = _CACHE[1]
                return IranMarketSnapshot(
                    dollar=cached.dollar,
                    tether=cached.tether,
                    gold18=cached.gold18,
                    fetched_at=cached.fetched_at,
                    stale=True,
                    extras=cached.extras,
                )
            stale = await run_blocking(_read_persistent_cache)
            if stale:
                _CACHE = (time.monotonic(), stale)
                return stale
            raise RuntimeError("قیمت‌های بازار ایران فعلاً در دسترس نیستند") from None


def clear_iran_price_cache_for_tests() -> None:
    global _CACHE
    _CACHE = None
