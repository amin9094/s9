"""Admin presentation and edits for the existing automation settings/V2 engine."""

from __future__ import annotations

from core.domain import audit
from core.utils import utc_iso
from modules.admin_access import PERMISSION_AUTOMATIONS, PERMISSION_RENEWALS, has_permission
from modules.automation_v2 import create_automation_rule, update_automation_rule
from modules.management_suite import AUTOMATION_DEFAULTS, automation_settings, update_automation_setting

BUILTINS = {
    "welcome": (
        "👋 خوش‌آمدگویی",
        "پس از عضویت کاربر، پیام خوش‌آمدگویی ارسال می‌کند.",
        "crm_welcome_enabled",
        ("crm_welcome_delay_minutes",),
    ),
    "checkout": (
        "🛒 خرید نیمه‌کاره",
        "خرید نیمه‌کاره را برای پیگیری مشخص می‌کند.",
        "crm_abandoned_checkout_enabled",
        ("crm_abandoned_checkout_hours",),
    ),
    "renewal": (
        "💎 یادآوری تمدید VIP",
        "پیش از پایان اشتراک، یادآوری و پیشنهاد تمدید می‌دهد.",
        "vip_reminders_enabled",
        ("vip_reminder_days", "renewal_discount_percent", "renewal_code_expiry_days", "early_renewal_bonus_days"),
    ),
    "inactive": (
        "👤 بازگشت کاربر غیرفعال",
        "پس از مدت تعیین‌شده برای بازگشت کاربر پیگیری می‌کند.",
        "inactive_enabled",
        ("inactive_days", "inactive_discount_percent"),
    ),
    "pending": (
        "💳 هشدار پرداخت معلق",
        "پرداخت معلق را به ادمین یادآوری می‌کند.",
        "pending_payment_enabled",
        ("pending_payment_hours",),
    ),
    "points": (
        "⭐ پاداش امتیاز بالا",
        "برای رسیدن به آستانهٔ امتیاز، پیشنهاد هدیه می‌دهد.",
        "high_points_enabled",
        ("high_points_threshold", "high_points_discount_percent"),
    ),
    "churn": (
        "📉 جلوگیری از ریزش",
        "کاربران در معرض ریزش را برای پیگیری مشخص می‌کند.",
        "crm_churn_risk_enabled",
        ("crm_churn_risk_days",),
    ),
    "lead": (
        "🔥 هشدار مشتری علاقه‌مند",
        "با رسیدن امتیاز علاقه به حد تعیین‌شده، هشدار می‌دهد.",
        "crm_lead_alert_enabled",
        ("crm_lead_alert_threshold",),
    ),
    "value": (
        "💰 مشتری باارزش",
        "مشتریان با خرید بالا را مشخص می‌کند.",
        "crm_high_value_enabled",
        ("crm_high_value_threshold",),
    ),
    "stage": (
        "🪜 مرحله‌بندی خودکار فروش",
        "وضعیت فروش مشتری را براساس رفتار ثبت‌شده تغییر می‌دهد.",
        "crm_auto_stage_enabled",
        (),
    ),
    "campaign": (
        "📣 اجرای کمپین زمان‌بندی‌شده",
        "کمپین‌های زمان‌بندی‌شده را در زمان مقرر پردازش می‌کند.",
        "campaign_scheduler_enabled",
        ("campaign_scheduler_batch",),
    ),
    "quiet": (
        "🌙 ساعات سکوت",
        "ارسال پیام در ساعت‌های تعیین‌شده محدود می‌شود.",
        "crm_quiet_hours_enabled",
        ("crm_quiet_start_hour", "crm_quiet_end_hour", "crm_timezone"),
    ),
    "general": (
        "⚙️ تنظیمات عمومی",
        "کل اتوماسیون و CRM، سقف پیام و بازیابی ارسال را کنترل می‌کند.",
        "enabled",
        ("crm_enabled", "crm_daily_contact_cap", "crm_max_batch", "crm_max_attempts", "crm_retry_base_minutes"),
    ),
}
FIELDS = {
    "vip_reminder_days": ("روزهای مانده تا پایان اشتراک", "مثال: 7,3,1,0"),
    "renewal_discount_percent": ("درصد پیشنهاد تمدید", "عدد از صفر تا صد؛ صفر یعنی بدون تخفیف"),
    "renewal_code_expiry_days": ("اعتبار کد تمدید (روز)", "تعداد روز معتبر بودن کد"),
    "early_renewal_bonus_days": ("روز هدیهٔ تمدید زودهنگام", "صفر یعنی بدون هدیه"),
    "inactive_days": ("مدت غیرفعالی (روز)", "پس از چند روز پیگیری شود؟"),
    "inactive_discount_percent": ("درصد پیشنهاد بازگشت", "صفر یعنی بدون تخفیف"),
    "pending_payment_hours": ("تأخیر هشدار پرداخت (ساعت)", "چند ساعت پس از ایجاد پرداخت؟"),
    "high_points_threshold": ("امتیاز لازم", "حداقل امتیاز کاربر"),
    "high_points_discount_percent": ("درصد هدیهٔ امتیاز", "صفر یعنی بدون تخفیف"),
    "crm_welcome_delay_minutes": ("تأخیر خوش‌آمدگویی (دقیقه)", "چند دقیقه پس از عضویت؟"),
    "crm_abandoned_checkout_hours": ("تأخیر پیگیری خرید (ساعت)", "چند ساعت پس از خرید نیمه‌کاره؟"),
    "crm_churn_risk_days": ("مدت بی‌فعالیتی (روز)", "چند روز بی‌فعالیتی هشدار ایجاد کند؟"),
    "crm_lead_alert_threshold": ("حد علاقهٔ مشتری", "عددی از صفر تا صد"),
    "crm_high_value_threshold": ("حد خرید مشتری (تومان)", "مجموع خرید تأییدشده؛ عدد به تومان"),
    "crm_quiet_start_hour": ("شروع سکوت", "ساعت از صفر تا ۲۳"),
    "crm_quiet_end_hour": ("پایان سکوت", "ساعت از صفر تا ۲۳"),
    "crm_timezone": ("منطقهٔ زمانی", "تهران یا UTC"),
    "crm_enabled": ("اجرای CRM خودکار", "فعال / غیرفعال"),
    "crm_daily_contact_cap": ("سقف پیام روزانه به هر کاربر", "عدد از ۱ تا ۲۰"),
    "crm_max_batch": ("تعداد بررسی در هر نوبت", "عدد از ۱ تا ۱۰۰۰"),
    "crm_max_attempts": ("تعداد تلاش ارسال", "عدد از ۱ تا ۱۰"),
    "crm_retry_base_minutes": ("فاصلهٔ تلاش دوباره (دقیقه)", "عدد از ۱ تا ۲۴۰"),
    "campaign_scheduler_batch": ("تعداد کمپین در هر نوبت", "عدد از ۱ تا ۵۰"),
}
RENEWAL_KEYS = frozenset(
    {
        "vip_reminders_enabled",
        "vip_reminder_days",
        "renewal_discount_percent",
        "renewal_code_expiry_days",
        "early_renewal_bonus_days",
    }
)
TRIGGER_LABELS = {
    "user_registered": "عضویت کاربر",
    "user_inactive": "غیرفعال شدن کاربر",
    "vip_expiring": "نزدیک پایان VIP",
    "vip_expired": "پایان VIP",
    "payment_created": "ثبت پرداخت",
    "payment_approved": "تأیید پرداخت",
    "payment_rejected": "رد پرداخت",
    "ticket_created": "ثبت تیکت",
    "ticket_closed": "بسته‌شدن تیکت",
    "ticket_waiting": "تیکت در انتظار",
    "signal_created": "ساخت سیگنال",
    "signal_published": "انتشار سیگنال",
    "signal_tp": "رسیدن به هدف سیگنال",
    "signal_sl": "رسیدن به استاپ",
    "signal_closed": "بسته‌شدن سیگنال",
    "campaign_created": "ساخت کمپین",
    "campaign_published": "انتشار کمپین",
    "link_clicked": "کلیک لینک ثبت‌شده",
    "contest_started": "شروع مسابقه",
    "contest_ended": "پایان مسابقه",
    "mission_completed": "تکمیل مأموریت",
    "system_error": "خطای سیستم",
    "provider_down": "قطع منبع قیمت",
    "scheduled": "رویداد زمان‌بندی‌شده",
    "gemini_command": "فرمان Gemini",
    "mt5_risk": "هشدار ریسک MT5",
    "custom": "رویداد اختصاصی ثبت‌شده",
}
ACTION_LABELS = {
    "send_message": "💬 پیام به همان کاربر",
    "notify_admin": "🔔 اطلاع به ادمین اصلی",
    "add_tag": "🏷 افزودن برچسب مشتری",
    "remove_tag": "🏷 حذف برچسب مشتری",
    "create_task": "📌 ایجاد کار برای پیگیری",
    "write_log": "📜 ثبت یادداشت در گزارش",
}
ALL_ACTION_LABELS = {
    **ACTION_LABELS,
    "create_ticket": "ایجاد تیکت",
    "queue_campaign": "صف‌بندی کمپین",
    "ai_draft": "پیش‌نویس هوشمند",
    "stop_feature": "توقف قابلیت",
    "webhook": "ارسال وبهوک",
    "create_coupon": "ساخت کوپن",
    "assign_admin": "واگذاری به ادمین",
}


def can_edit_key(db, actor, key):
    return key in AUTOMATION_DEFAULTS and (
        has_permission(db, actor, PERMISSION_AUTOMATIONS)
        or key in RENEWAL_KEYS
        and has_permission(db, actor, PERMISSION_RENEWALS)
    )


def set_setting(db, actor, key, value):
    if not can_edit_key(db, actor, key):
        raise PermissionError("مجوز تغییر این تنظیم را ندارید.")
    if key == "vip_reminder_days" and (
        not isinstance(value, list) or not value or any(not 0 <= int(day) <= 90 for day in value)
    ):
        raise ValueError("روزها را از صفر تا ۹۰ وارد کنید.")
    if key == "crm_lead_alert_threshold" and not 0 <= int(value) <= 100:
        raise ValueError("امتیاز علاقه از صفر تا صد است.")
    settings = automation_settings(db)
    if value is True and any(
        spec[2] == key and builtin in set(settings.get("admin_hidden_builtins") or [])
        for builtin, spec in BUILTINS.items()
    ):
        raise ValueError("این مورد حذف شده؛ ابتدا دوباره اضافه کنید.")
    result = update_automation_setting(db, key, value)
    audit(db, actor, "automation_setting", f"{key}:{value}")
    return result


def builtin_state(db, actor, key, *, enabled=None, remove=False, restore=False):
    if key not in BUILTINS or not has_permission(db, actor, PERMISSION_AUTOMATIONS):
        raise PermissionError("مجوز مدیریت اتوماسیون لازم است.")
    if key == "general" and (remove or restore):
        raise ValueError("تنظیمات عمومی حذف نمی‌شود.")
    settings = automation_settings(db)
    archived = set(settings.get("admin_hidden_builtins") or [])
    if remove:
        archived.add(key)
        enabled = False
    if restore:
        archived.discard(key)
        enabled = False
    if enabled is not None:
        if enabled and key in archived and not restore:
            raise ValueError("این مورد حذف شده است؛ ابتدا دوباره اضافه کنید.")
        update_automation_setting(db, BUILTINS[key][2], bool(enabled))
    settings["admin_hidden_builtins"] = sorted(archived)
    audit(db, actor, "automation_builtin", f"{key}:{enabled}:{remove}:{restore}")
    return settings


def remove_rule(db, actor, rule_id):
    if not has_permission(db, actor, PERMISSION_AUTOMATIONS):
        raise PermissionError("مجوز مدیریت اتوماسیون لازم است.")
    row = db.get("automation_rules_v2", {}).get(rule_id)
    if not row or row.get("deleted_at"):
        raise ValueError("قانون پیدا نشد یا قبلاً حذف شده است.")
    update_automation_rule(db, rule_id, {"enabled": False}, actor_id=actor)
    row.update(status="deleted", deleted_at=utc_iso(), deleted_by=str(actor))
    # Preserve history, but cancel deliveries that have not begun yet.
    for job in db.get("automation_v2_jobs", {}).values():
        if job.get("rule_id") == rule_id and job.get("status") in {"pending", "retry"}:
            job.update(status="cancelled", updated_at=utc_iso())
    for job in db.get("automation_outbox", {}).values():
        if str(job.get("dedupe_key", "")).startswith(f"av2:{rule_id}:") and job.get("status") in {"pending", "retry"}:
            job.update(status="cancelled", updated_at=utc_iso())
    audit(db, actor, "automation_rule_deleted", rule_id)


def save_rule_draft(db, actor, token, values):
    if not has_permission(db, actor, PERMISSION_AUTOMATIONS):
        raise PermissionError("مجوز مدیریت اتوماسیون لازم است.")
    for row in db.get("automation_rules_v2", {}).values():
        if row.get("ui_creation_token") == token and row.get("created_by") == str(actor):
            return dict(row)
    row = create_automation_rule(db, actor_id=actor, enabled=False, **values)
    db["automation_rules_v2"][row["id"]]["ui_creation_token"] = token
    audit(db, actor, "automation_rule_draft", row["id"])
    return dict(db["automation_rules_v2"][row["id"]])
