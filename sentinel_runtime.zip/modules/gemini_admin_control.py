from __future__ import annotations

import json
import re
from typing import Any

from config import SETTINGS, is_primary_admin
from core.db import read_db_sections, with_db
from core.utils import utc_iso
from modules.admin_access import has_permission, PERMISSION_AI_CONFIRM_STANDARD_ACTIONS, PERMISSION_AI_CONFIRM_SENSITIVE_ACTIONS
from modules.ai_action_firewall import (
    HUMAN_ONLY_ACTIONS, backend_risk, bind_to_admin_intent, json_schema_for,
    validate_payload, gemini_function_schema_for,
)
from modules.security_audit import append_security_audit
from modules.gemini_command_router import select_operational_tools

# Recursive AI endpoints are intentionally not exposed as tools.  Every other
# registered administrator action may be exposed to the numeric primary owner;
# authorization and payload validation still happen in the shared action
# registry before execution.
_BLOCKED_ACTION_PREFIXES: tuple[str, ...] = ()
_BLOCKED_ACTIONS = {
    "admin_ai_query", "admin_ai_proposal_approve", "admin_ai_proposal_reject",
    "user_ai_query", "user_ai_review", "copilot_query",
}
_FORBIDDEN_KEY_RE = re.compile(
    r"(?:api[_-]?key|secret|password|token|bot[_-]?token|private[_-]?key|seed|mnemonic|"
    r"shell|sql|deploy|webhook[_-]?secret)",
    re.IGNORECASE,
)

# Complete operational command surface exposed to Gemini. This includes bot,
# Mini App, channel, CRM, users, signals, tickets, content, education, contests,
# risk, MT5 supervision, runtime, commerce and admin management. The numeric
# primary owner may use every registered application action; raw infrastructure
# and secrets are intentionally not modeled as bot tools.
AI_OPERATIONAL_TOOLS: dict[str, dict[str, Any]] = {
    "control_change": {"description": "Change one supported bot/Mini App module setting", "keys": ["module", "field", "value"]},
    "control_reset": {"description": "Reset one module to its defaults", "keys": ["module"]},
    "control_preset": {"description": "Apply an existing control preset", "keys": ["preset"]},
    "runtime_mode_update": {"description": "Set runtime mode normal/safe/maintenance/read_only/production/staging", "keys": ["mode", "reason"]},
    "miniapp_runtime_toggle": {"description": "Enable or disable Mini App runtime", "keys": ["enabled", "reason"]},
    "integration_reconcile": {"description": "Reconcile bot and Mini App integration projections", "keys": []},
    "incident_status_update": {"description": "Update an incident status", "keys": ["incident_id", "status", "note"]},
    "automation_retry": {"description": "Retry a failed automation", "keys": ["message_id"]},
    "campaign_create": {"description": "Create a CRM/content campaign", "keys": ["name", "category", "audience", "message", "delivery", "objective", "tracking"]},
    "public_discount_create": {"description": "Create a public discount code", "keys": ["code", "percent", "days", "max_uses", "one_per_user"]},
    "ai_idea_create": {"description": "Create and save a new Sentinel product, content or marketing idea in the admin backlog", "keys": ["title", "category", "description", "implementation_steps", "priority", "related_feature", "status"]},
    "campaign_status_update": {"description": "Change campaign status", "keys": ["campaign_id", "status"]},
    "campaign_delivery_update": {"description": "Change campaign delivery mode", "keys": ["campaign_id", "delivery"]},
    "campaign_schedule": {"description": "Schedule an existing campaign", "keys": ["campaign_id", "scheduled_for", "priority"]},
    "experiment_create": {"description": "Create a content/CRM experiment", "keys": ["name", "hypothesis", "primary_metric", "variants", "starts_at", "ends_at", "holdout_percent", "conversion_window_hours", "min_sample_per_variant", "stop_loss_percent"]},
    "experiment_status_update": {"description": "Change experiment status", "keys": ["experiment_id", "status"]},
    "miniapp_announcement_publish": {"description": "Publish or queue an announcement", "keys": ["title", "message", "delivery", "scheduled_for"]},
    "publisher_channel_upsert": {"description": "Register or update a managed channel", "keys": ["chat_id", "title", "language", "channel_type", "template_key", "approval_required"]},
    "publication_enqueue": {"description": "Queue content for one or more registered channels", "keys": ["channel_ids", "content", "content_type", "scheduled_at", "reference_type", "reference_id"]},
    "publication_status_update": {"description": "Update a publisher queue item", "keys": ["job_id", "status"]},
    "content_render": {"description": "Render approved text/card content", "keys": ["template_key", "values"]},
    "public_performance_snapshot": {"description": "Generate a public performance snapshot", "keys": []},
    "business_inbox_admin_classify": {"description": "Classify a business inbox item", "keys": ["user_id", "text", "source"]},
        "workspace_create": {"description": "Create an internal workspace", "keys": ["name", "slug", "brand_name"]},
    "payment_approve": {"description": "Approve a specific payment order and activate its VIP entitlement", "keys": ["order_id"]},
    "payment_reject": {"description": "Reject a specific payment order with an administrator reason", "keys": ["order_id", "reason"]},
    "admin_vip_plan_create": {"description": "Create a VIP subscription plan", "keys": ["name", "price", "duration_days", "description", "original_price", "features", "audience", "highlight", "sales_limit", "starts_at", "ends_at"]},
    "admin_vip_plan_update": {"description": "Update one field of a VIP plan", "keys": ["plan_id", "field", "value"]},
    "admin_vip_plan_toggle": {"description": "Activate, deactivate, toggle or archive a VIP plan", "keys": ["plan_id", "mode"]},
    "admin_vip_plan_delete": {"description": "Delete an unused VIP plan", "keys": ["plan_id"]},
    "admin_user_ban": {"description": "Ban a user", "keys": ["user_id", "days", "reason"]},
    "admin_user_unban": {"description": "Unban a user", "keys": ["user_id"]},
    "delegated_admin_upsert": {"description": "Add a delegated admin. Non-primary requests require primary approval", "keys": ["user_id", "permissions"]},
    "delegated_admin_permissions_set": {"description": "Replace a delegated admin permission set", "keys": ["user_id", "permissions"]},
    "delegated_admin_remove": {"description": "Remove a delegated admin", "keys": ["user_id"]},
            "signal_edit": {"description": "Edit one field of a signal", "keys": ["signal_id", "field", "value"]},
    "signal_result_set": {"description": "Set TP/SL/BE/closed result for a signal", "keys": ["signal_id", "result"]},
    "signal_result_reset": {"description": "Clear a signal result and reopen it", "keys": ["signal_id"]},
    "signal_delete": {"description": "Permanently delete a signal", "keys": ["signal_id"]},
    "miniapp_signal_publish": {"description": "Publish a validated signal to Telegram and Mini App", "keys": ["symbol", "side", "entry", "entries", "targets", "stop", "stop_loss", "risk", "risk_percent", "target", "market_category", "timeframe", "note", "analysis"]},
    "ai_signal_draft_create": {"description": "Create an AI signal draft that always requires human Entry/SL/TP approval", "keys": ["symbol", "side", "entry", "entries", "targets", "stop", "stop_loss", "risk", "risk_percent", "target", "scheduled_at", "market_category", "timeframe", "note", "analysis"]},
    "signal_job_retry": {"description": "Retry a queued signal job", "keys": ["job_id"]},
    "signal_job_cancel": {"description": "Cancel a queued signal job", "keys": ["job_id", "reason"]},
    "signal_job_update": {"description": "Update a queued signal job", "keys": ["job_id", "target", "run_at", "payload"]},
    "signal_cycle_rollover": {"description": "Rollover the active signal cycle", "keys": ["name", "new_name"]},
    "signal_cycle_close": {"description": "Close a signal cycle", "keys": ["cycle_id"]},
    "signal_cycle_start": {"description": "Start a signal cycle", "keys": ["name"]},
    "signal_cycle_rename": {"description": "Rename a signal cycle", "keys": ["cycle_id", "name"]},
    "ai_signal_template_apply_asset": {"description": "Use a stored admin image asset as BUY or SELL signal template", "keys": ["side", "asset_id", "autodetect"]},
    "ai_signal_template_layout_update": {"description": "Move or style a field on BUY/SELL signal template", "keys": ["side", "field", "x", "y", "dx", "dy", "size", "font_delta"]},
    "ai_signal_template_reset": {"description": "Reset signal template background/layout", "keys": ["side", "background", "layout"]},
    "ai_signal_refresh_channel": {"description": "Rebuild and refresh one signal media/caption in its channels", "keys": ["signal_id"]},
    "ai_channel_message_operation": {"description": "Edit/delete/pin/unpin a channel message; may use latest signal or stored asset", "keys": ["operation", "chat_id", "message_id", "text", "asset_id", "signal_id"]},
    "ticket_admin_reply": {"description": "Reply to a support ticket", "keys": ["ticket_id", "text", "attachment"]},
    "ticket_admin_status_update": {"description": "Update ticket status", "keys": ["ticket_id", "status"]},
    "ticket_admin_assign": {"description": "Assign a ticket to an admin", "keys": ["ticket_id", "admin_id", "assigned_admin_id"]},
    "ticket_admin_priority_update": {"description": "Update ticket priority", "keys": ["ticket_id", "priority"]},
    "ticket_admin_internal_note": {"description": "Add an internal ticket note", "keys": ["ticket_id", "text"]},
    "shift_handoff_create": {"description": "Create admin shift handoff", "keys": ["to_admin_id", "summary", "pending_items", "risks", "decisions", "next_actions", "due_at"]},
    "shift_handoff_status_update": {"description": "Update shift handoff status", "keys": ["handoff_id", "status", "note"]},
    "prop_template_create": {"description": "Create a prop-account rules template", "keys": ["name", "rules", "provider", "template_id", "version"]},
    "ai_lesson_create": {"description": "Create a free or paid education lesson", "keys": ["category", "course", "chapter", "title", "text", "duration_minutes", "status", "access_type", "price"]},
    "ai_lesson_update": {"description": "Update an education lesson", "keys": ["lesson_id", "category", "course", "chapter", "title", "text", "duration_minutes", "access_type", "price", "status", "active", "position", "quiz"]},
    "ai_lesson_status": {"description": "Publish, archive or return a lesson to draft", "keys": ["lesson_id", "status"]},
    "ai_lesson_delete": {"description": "Delete an education lesson", "keys": ["lesson_id"]},
    "ai_mission_create": {"description": "Create a points-based user mission", "keys": ["title", "description", "reward", "event", "target", "period", "active", "starts_at", "ends_at", "badge", "random_bonus_max"]},
    "ai_mission_update": {"description": "Update a user mission", "keys": ["mission_id", "title", "description", "reward", "event", "target", "period", "active", "starts_at", "ends_at", "badge", "random_bonus_max"]},
    "ai_mission_toggle": {"description": "Enable or disable a mission", "keys": ["mission_id"]},
    "ai_mission_delete": {"description": "Delete a mission", "keys": ["mission_id"]},
    "ai_contest_start": {"description": "Start a points-based price/chart/candle contest", "keys": ["kind", "symbol", "question", "duration_minutes", "reward_points"]},
    "ai_contest_end": {"description": "Settle an active points-based contest", "keys": ["kind", "final_price", "correct_choice"]},
                "governance_request_retry": {"description": "Retry a governance request", "keys": ["request_id"]},
    "signal_team_rules_update": {"description": "Update deterministic daily signal, loss-streak and cooldown rules", "keys": ["enabled", "timezone", "max_daily_signals", "max_weekly_signals", "max_daily_forex", "max_daily_crypto", "max_consecutive_stops", "cooldown_minutes", "max_daily_loss_r", "override_requires_primary_admin"]},
    "ai_signal_lab_strategy_create": {"description": "Create a versioned strategy used only by the shadow signal lab", "keys": ["name", "rules", "status"]},
    "ai_signal_lab_scan_queue": {"description": "Queue a shadow-only market scan; it can never publish a signal", "keys": ["strategy_id", "symbols", "timeframes"]},
    "admin_ai_user_access_toggle": {"description": "Toggle user AI access between VIP-only and all users", "keys": ["mode"]},
    "admin_ai_health_test": {"description": "Run a live Gemini health/auth/model test", "keys": ["generation_test"]},
    "admin_ai_daily_report": {"description": "Create the daily manager report", "keys": ["force", "language"]},
    "admin_ai_execution_toggle": {"description": "Emergency enable/disable Gemini execution while retaining analysis", "keys": ["enabled"]},
    "admin_command_center_snapshot": {"description": "Read the live administrator command-center snapshot", "keys": []},
    "admin_global_search": {"description": "Permission-aware global search across Sentinel modules", "keys": ["query", "domain", "limit"]},
    "automation_v2_rule_list": {"description": "List Automation V2 rules", "keys": ["enabled"]},
    "automation_v2_rule_create": {"description": "Create a Trigger/Condition/Action Automation V2 rule", "keys": ["name", "trigger", "conditions", "actions", "guards", "enabled"]},
    "automation_v2_rule_update": {"description": "Update an Automation V2 rule", "keys": ["rule_id", "changes"]},
    "automation_v2_rule_test": {"description": "Dry-run one Automation V2 rule with a sample event", "keys": ["rule_id", "trigger", "event"]},
    "ai_ad_campaign_create": {"description": "Create Gemini advertisement copy and a campaign draft", "keys": ["name", "product", "objective", "audience", "delivery", "tone", "call_to_action", "language", "brand_notes"]},
    "ai_ad_image_generate": {"description": "Generate and QA a Gemini advertisement image", "keys": ["campaign_id", "prompt", "aspect_ratio"]},
    "ai_ad_summary": {"description": "Read an AI advertisement summary and QA state", "keys": ["campaign_id"]},
    "ai_ad_approve": {"description": "Approve a QA-passed AI advertisement after human confirmation", "keys": ["campaign_id"]},
    "ai_ad_schedule": {"description": "Schedule an approved AI advertisement after human confirmation", "keys": ["campaign_id", "scheduled_for", "priority"]},
}


def _tool_spec(action_name: Any) -> dict[str, Any] | None:
    """Return a reviewed tool contract for a registered admin action."""
    name = str(action_name or "").strip()
    if not name or name in _BLOCKED_ACTIONS or name in HUMAN_ONLY_ACTIONS:
        return None
    if any(name.startswith(prefix) for prefix in _BLOCKED_ACTION_PREFIXES):
        return None
    direct = AI_OPERATIONAL_TOOLS.get(name)
    if direct:
        return direct
    try:
        from services.actions_v2 import action_specs
        from services.admin_action_catalog import catalog_entry

        registered = action_specs().get(name)
        if registered is None or not registered.admin_only:
            return None
        entry = catalog_entry(name)
        if entry.get("ui_state") != "ready":
            return None
        keys = [
            str(field.get("name") or "").strip()
            for field in (entry.get("fields") or [])
            if isinstance(field, dict) and str(field.get("name") or "").strip()
        ]
        # Generic JSON fallbacks do not provide a closed schema and therefore
        # are not sent to the model until a reviewed static contract is added.
        if entry.get("ui_mode") == "json" and not keys:
            return None
        description = str(entry.get("description_en") or entry.get("description_fa") or name)
        return {"description": description[:500], "keys": keys}
    except (ImportError, RuntimeError):
        return None


def is_ai_operational_action_allowed(action_name: Any) -> bool:
    return _tool_spec(action_name) is not None


def _clean_value(value: Any, *, depth: int = 0) -> Any:
    if depth > 5:
        raise ValueError("AI_TOOL_PAYLOAD_TOO_DEEP")
    if isinstance(value, dict):
        result: dict[str, Any] = {}
        for raw_key, raw_value in list(value.items())[:60]:
            key = str(raw_key).strip()[:100]
            if not key or _FORBIDDEN_KEY_RE.search(key):
                raise PermissionError("AI_TOOL_PAYLOAD_FIELD_BLOCKED")
            result[key] = _clean_value(raw_value, depth=depth + 1)
        return result
    if isinstance(value, list):
        return [_clean_value(item, depth=depth + 1) for item in value[:100]]
    if isinstance(value, str):
        text = value.strip()
        if len(text) > 8000:
            text = text[:8000]
        return text
    if value is None or isinstance(value, (bool, int, float)):
        return value
    return str(value)[:1000]


def sanitize_tool_calls(
    raw: Any,
    *,
    admin_command: str = "",
) -> list[dict[str, Any]]:
    """Validate model tool calls with action-specific schemas and intent binding."""
    rows = raw if isinstance(raw, list) else []
    result: list[dict[str, Any]] = []
    for index, row in enumerate(rows[: SETTINGS.gemini_max_tool_calls_per_request]):
        if not isinstance(row, dict):
            continue
        action_name = str(row.get("action") or row.get("name") or "").strip()
        if not is_ai_operational_action_allowed(action_name):
            continue
        payload_raw = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        payload = _clean_value(payload_raw)
        tool_spec = _tool_spec(action_name)
        if tool_spec is None:
            continue
        keys = list(tool_spec.get("keys") or [])
        payload = validate_payload(action_name, payload, keys)
        if admin_command:
            bind_to_admin_intent(action_name, payload, admin_command)
        result.append({
            "action": action_name,
            "payload": payload,
            "reason": str(row.get("reason") or "")[:1000],
            "risk": backend_risk(action_name),
            "tool_call_index": index,
        })
    return result


def selected_operational_tool_catalog(command: str, *, scope: str = "management", limit: int = 18) -> list[dict[str, Any]]:
    """Return a small, intent-ranked tool surface for one administrator command.

    Sending all registered actions in every Gemini request made schemas too
    large and caused the provider to fall back to unrelated analysis. Every
    registered action remains reachable; only the relevant subset is declared
    for the current command.
    """
    return select_operational_tools(command, operational_tool_catalog(), scope=scope, limit=limit)


def gemini_function_declarations(rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
    declarations: list[dict[str, Any]] = []
    for row in rows:
        action = str(row.get("action") or "").strip()
        if not action:
            continue
        keys = list(row.get("keys") or [])
        declarations.append({
            "name": action,
            "description": str(row.get("description") or action)[:700],
            "parameters": gemini_function_schema_for(action, keys),
        })
    return declarations


def operational_tool_catalog(*, compact: bool = True) -> list[dict[str, Any]]:
    names = list(AI_OPERATIONAL_TOOLS)
    try:
        from services.actions_v2 import action_specs

        names.extend(name for name, spec in action_specs().items() if spec.admin_only)
    except (ImportError, RuntimeError):
        pass
    rows = []
    for name in dict.fromkeys(names):
        row = _tool_spec(name)
        if row is None:
            continue
        keys = list(row.get("keys") or [])
        item = {
            "action": name,
            "description": row["description"],
            "keys": keys,
            "risk": backend_risk(name),
            "parameters": json_schema_for(name, keys),
        }
        rows.append(item)
    return rows


def ai_execution_settings() -> dict[str, Any]:
    db = read_db_sections(("ai_runtime_settings",))
    runtime = db.get("ai_runtime_settings") if isinstance(db.get("ai_runtime_settings"), dict) else {}
    return {
        "execution_enabled": bool(runtime.get("execution_enabled", True)),
        "autonomous_primary_admin": bool(SETTINGS.gemini_autonomous_primary_admin),
        "primary_admin_full_bot_access": bool(SETTINGS.gemini_primary_admin_full_bot_access),
        "safety_threshold": str(SETTINGS.gemini_safety_threshold),
        "delegated_admin_approval_required": bool(SETTINGS.gemini_delegated_admin_approval_required),
        "confirm_sensitive_actions": bool(SETTINGS.gemini_confirm_sensitive_actions),
        "primary_admin_id": int(SETTINGS.primary_admin_id),
        "updated_at": str(runtime.get("execution_updated_at") or ""),
        "updated_by": str(runtime.get("execution_updated_by") or ""),
    }


def set_ai_execution_enabled(actor_id: int | str, enabled: bool) -> dict[str, Any]:
    if not is_primary_admin(actor_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        runtime = db.setdefault("ai_runtime_settings", {})
        runtime.update({"execution_enabled": bool(enabled), "execution_updated_at": utc_iso(), "execution_updated_by": str(actor_id)})
        db.setdefault("ai_audit_log", []).append({
            "action": "ai_execution_toggle", "actor_id": str(actor_id), "enabled": bool(enabled), "created_at": utc_iso(),
        })
        append_security_audit(db, action="ai_execution_toggle", actor_id=actor_id, details={"enabled": bool(enabled)}, source="gemini_control")
        return dict(runtime)
    return with_db(mutate)


def requester_may_request_action(actor_id: int | str, action_name: str, permission: str = "") -> bool:
    if is_primary_admin(actor_id):
        return True
    if not permission:
        return False
    db = read_db_sections(("delegated_admins", "users", "admin_shifts"))
    if not has_permission(db, actor_id, permission):
        return False
    risk = backend_risk(action_name)
    confirmation_permission = (
        PERMISSION_AI_CONFIRM_SENSITIVE_ACTIONS
        if risk in {"financial_mutation", "destructive", "privilege_change", "external_side_effect", "sensitive_human_confirmation"}
        else PERMISSION_AI_CONFIRM_STANDARD_ACTIONS
    )
    return has_permission(db, actor_id, confirmation_permission)


def queue_ai_admin_commands(
    actor_id: int | str,
    calls: list[dict[str, Any]],
    *,
    conversation_id: int | str = "",
    question: str = "",
) -> list[dict[str, Any]]:
    if not calls:
        return []
    def mutate(db: dict[str, Any]) -> list[dict[str, Any]]:
        root = db.setdefault("ai_admin_command_queue", [])
        seq = int(db.get("next_ai_admin_command_id", 1) or 1)
        created: list[dict[str, Any]] = []
        for call in calls:
            row = {
                "id": seq,
                "status": "pending_primary_approval",
                "requested_by": str(actor_id),
                "primary_admin_id": str(SETTINGS.primary_admin_id),
                "conversation_id": str(conversation_id or ""),
                "question": str(question or "")[:2000],
                "action": str(call.get("action") or ""),
                "payload": dict(call.get("payload") or {}),
                "reason": str(call.get("reason") or "")[:1000],
                "risk": str(call.get("risk") or "standard")[:20],
                "created_at": utc_iso(),
                "updated_at": utc_iso(),
            }
            root.append(row); created.append(dict(row)); seq += 1
        db["next_ai_admin_command_id"] = seq
        db["ai_admin_command_queue"] = root
        db.setdefault("ai_audit_log", []).append({
            "action": "ai_commands_queued", "actor_id": str(actor_id), "command_ids": [row["id"] for row in created], "created_at": utc_iso(),
        })
        append_security_audit(db, action="ai_commands_queued", actor_id=actor_id, details={"command_ids": [row["id"] for row in created]}, source="gemini_control")
        return created
    return with_db(mutate)


def ai_admin_command(command_id: int | str) -> dict[str, Any] | None:
    target = int(command_id)
    db = read_db_sections(("ai_admin_command_queue",))
    return next((dict(row) for row in db.get("ai_admin_command_queue", []) if isinstance(row, dict) and int(row.get("id", 0) or 0) == target), None)


def pending_ai_admin_commands(*, limit: int = 100) -> list[dict[str, Any]]:
    db = read_db_sections(("ai_admin_command_queue",))
    rows = [dict(row) for row in db.get("ai_admin_command_queue", []) if isinstance(row, dict) and str(row.get("status") or "").startswith("pending")]
    return rows[-max(1, min(limit, 500)):][::-1]


def update_ai_admin_command(command_id: int | str, actor_id: int | str, *, status: str, result: Any = None, reason: str = "") -> dict[str, Any]:
    if not is_primary_admin(actor_id):
        raise PermissionError("PRIMARY_ADMIN_REQUIRED")
    target = int(command_id)
    allowed = {"approved", "rejected", "executed", "failed"}
    if status not in allowed:
        raise ValueError("AI_COMMAND_STATUS_INVALID")
    def mutate(db: dict[str, Any]) -> dict[str, Any]:
        row = next((item for item in db.setdefault("ai_admin_command_queue", []) if isinstance(item, dict) and int(item.get("id", 0) or 0) == target), None)
        if row is None:
            raise ValueError("AI_ADMIN_COMMAND_NOT_FOUND")
        row.update({"status": status, "resolved_by": str(actor_id), "resolved_at": utc_iso(), "updated_at": utc_iso()})
        if result is not None:
            row["result"] = result
        if reason:
            row["resolution_reason"] = str(reason)[:1000]
        db.setdefault("ai_audit_log", []).append({
            "action": f"ai_command_{status}", "actor_id": str(actor_id), "command_id": target, "created_at": utc_iso(),
        })
        append_security_audit(db, action=f"ai_command_{status}", actor_id=actor_id, details={"command_id": target}, source="human_ai_queue")
        return dict(row)
    return with_db(mutate)


def serialize_tool_catalog() -> str:
    return json.dumps(operational_tool_catalog(), ensure_ascii=False, separators=(",", ":"))
