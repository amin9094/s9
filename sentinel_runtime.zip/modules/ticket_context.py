"""Validated references on support tickets. Private ownership is checked server-side."""
from __future__ import annotations
from modules.admin_access import has_permission, PERMISSION_TICKETS

TYPES = {'payment','signal','course','reward','vip','referral','competition','price_alert'}


def reward_context_reference(item):
    import hashlib
    ident = str(item.get('id') or '')
    return ident if ident.isdigit() else 'c' + hashlib.sha256(str(item.get('code') or ident).encode()).hexdigest()[:20]


def competition_contexts(db):
    import hashlib
    rows = [(str(r.get('id')), r) for r in db.get('contests',[]) if isinstance(r,dict)]
    for kind in ('chart','candle','news'):
        row = db.get('news_direction_contest' if kind == 'news' else f'{kind}_contest')
        if isinstance(row,dict) and row:
            key = str(row.get('id') or hashlib.sha256(str(row.get('created_at') or row.get('ends_at') or row.get('question')).encode()).hexdigest()[:12])
            rows.append((f'{kind}_{key}', row))
    return rows


def resolve_context(db, user_id, kind, reference):
    uid, ref = str(user_id), str(reference)
    if kind not in TYPES or len(ref) > 100: raise ValueError('موضوع مرتبط نامعتبر است.')
    if kind in {'vip','referral'}:
        if ref != uid: raise PermissionError('مورد مرتبط در دسترس نیست.')
        section = 'vip_users' if kind == 'vip' else 'user_referrals'
        return db.get(section, {}).get(uid)
    if kind == 'signal':
        from modules.signal_portal import user_visible_signals
        from core.domain import is_vip
        return next((r for r in user_visible_signals(db, vip=is_vip(db, user_id)) if str(r.get('id')) == ref), None)
    if kind == 'competition':
        return next((row for ident,row in competition_contexts(db) if ident == ref), None)
    if kind == 'reward' and ref.startswith('c'):
        from modules.reward_wallet import wallet_items
        return next((row for row in wallet_items(db,uid) if reward_context_reference(row)==ref),None)
    section, field, private = {
        'payment': ('vip_orders','order_id', True), 'course':('lessons','id',False),
        'reward':('user_rewards','id',True), 'competition':('contests','id',False),
        'price_alert':('price_alerts','id',True),
    }[kind]
    raw = db.get(section, []); rows = raw.values() if isinstance(raw, dict) else raw
    row = next((r for r in rows if isinstance(r,dict) and str(r.get(field)) == ref), None)
    if row is None and kind == 'payment':
        from repositories.v2.commerce import CommerceRepository
        row = CommerceRepository().get(ref, user_id=uid)
    if row and private and str(row.get('user_id')) != uid: raise PermissionError('مورد مرتبط در دسترس نیست.')
    return row


def attach_context(db, ticket, kind, reference):
    row = resolve_context(db, ticket['user_id'], kind, reference)
    if row is None: raise ValueError('مورد مرتبط دیگر در دسترس نیست.')
    ticket.update(context_type=kind, context_id=str(reference))
    return ticket


def ticket_context_view(db, actor, ticket):
    if str(ticket['user_id']) != str(actor) and not has_permission(db, actor, PERMISSION_TICKETS):
        raise PermissionError('تیکت در دسترس نیست.')
    if not ticket.get('context_type'): return None
    row = resolve_context(db, ticket['user_id'], ticket['context_type'], ticket['context_id'])
    if row is None: return None
    fields = ('title','name','symbol','asset','condition','target_price','question','status','order_id','price','amount_toman','expires_at','duration_days','created_at')
    return {k: row[k] for k in fields if k in row}


def context_for_route(route, user_id):
    mapping = {'user_signal_view':'signal', 'lesson':'course', 'user_payment':'payment', 'pa_view':'price_alert'}
    prefix, _, reference = str(route).removeprefix('nb:').partition(':')
    if prefix in mapping and reference and len(reference) < 40: return mapping[prefix], reference
    if prefix == 'u_referral': return 'referral', str(user_id)
    if prefix in {'u_vip', 'account_vip'}: return 'vip', str(user_id)
    return None
