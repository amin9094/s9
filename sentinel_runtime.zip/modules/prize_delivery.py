"""Deliver server-configured prizes inside the caller's existing DB transaction."""
from __future__ import annotations

from typing import Any

from core.economy_integrity import economic_event


def validate_prize(prize: dict[str, Any]) -> dict[str, int]:
    result = {key: int(prize.get(key, 0) or 0) for key in ('points', 'vip_days', 'coupon_percent')}
    if not 0 <= result['points'] <= 1_000_000 or not 0 <= result['vip_days'] <= 3650:
        raise ValueError('مقدار جایزه خارج از محدوده است.')
    if result['coupon_percent'] not in {0, 10, 20, 30, 40, 50}:
        raise ValueError('درصد کوپن نامعتبر است.')
    if not any(result.values()):
        raise ValueError('حداقل یک پاداش انتخاب کنید.')
    return result


def prize_label(prize: dict[str, Any], language: str = 'fa') -> str:
    parts = []
    for key, fa, en in [('points', 'امتیاز', 'points'), ('vip_days', 'روز VIP', 'VIP days'), ('coupon_percent', '٪ تخفیف', '% coupon')]:
        if prize.get(key):
            parts.append(f"{int(prize[key]):,} {en if language == 'en' else fa}")
    return ' + '.join(parts) or ('No prize' if language == 'en' else 'بدون جایزه')


def deliver_prize(db, user_id, prize, *, source_event, title, actor='system', source='reward', coupon_expires_at=None, apply_expiry_policy=False):
    from core.domain import add_points, activate_vip
    from modules.advanced_features import record_user_reward
    from core.domain import assign_discount_from_pool

    values = validate_prize(prize)
    uid = str(user_id)
    delivered = []
    for kind, value in values.items():
        if not value:
            continue
        event = f'{source_event}:reward:{kind}'
        if not economic_event(db, event, uid, kind=kind, value=value, actor=actor, reason=title):
            continue
        detail, reference = str(value), event
        if kind == 'points':
            add_points(db, uid, value, title, source_event=f'points:{event}', actor=actor)
        elif kind == 'vip_days':
            activate_vip(db, uid, value, source_order_id=event)
        else:
            coupon, _ = assign_discount_from_pool(db, value, uid, issued_via=source, coupon_expires_at=coupon_expires_at, apply_expiry_policy=apply_expiry_policy)
            if not coupon:
                raise ValueError('موجودی کد تخفیف کافی نیست؛ پاداش ثبت نشد.')
            reference, detail = coupon['code'], coupon['code']
        delivered.append(record_user_reward(db, uid, title, reward_type=kind, detail=detail,
                         source=source, reference_id=reference, status='delivered'))
    return delivered
