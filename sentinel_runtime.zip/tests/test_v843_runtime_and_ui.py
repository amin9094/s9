from __future__ import annotations

import logging
import sys
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

import bot
from bot_runtime import crm_content, navigation
from core.logging_context import JsonFormatter, RedactingFilter, RedactingFormatter, redact
from core.update_processor import KeyedUpdateProcessor
from modules.admin_access import PERMISSION_SIGNAL_DELETE
from modules.admin_permission_ui import permission_page, permission_token
from services import miniapp_read_service_v2 as read, miniapp_v2_service as legacy

FIXTURE_TOKEN = "123456789:" + "a" * 35


@pytest.mark.parametrize("text", [
    f"HTTP Request: POST https://api.telegram.org/bot{FIXTURE_TOKEN}/getMe HTTP/1.1 200",
    f"Local endpoint: http://localhost:8081/bot{FIXTURE_TOKEN}/sendMessage",
    f"NetworkError for bot{FIXTURE_TOKEN.replace(':', '%3A')}/getUpdates",
    f"Request failed with token {FIXTURE_TOKEN}",
])
def test_telegram_secret_is_redacted(text):
    result = redact(text)
    assert "a" * 35 not in result
    assert "[REDACTED]" in result


def test_bearer_credentials_are_redacted_completely():
    assert "fixture-secret-value" not in redact("Authorization: Bearer fixture-secret-value")


@pytest.mark.parametrize("formatter", [RedactingFormatter(), JsonFormatter()])
def test_exception_traceback_redacts_telegram_credentials(formatter):
    try:
        raise RuntimeError(f"https://api.telegram.org/bot{FIXTURE_TOKEN}/getUpdates")
    except RuntimeError:
        record = logging.LogRecord("httpx", logging.ERROR, __file__, 1, "polling failed", (), sys.exc_info())
    RedactingFilter().filter(record)
    output = formatter.format(record)
    assert "a" * 35 not in output
    assert "RuntimeError" in output and "[REDACTED]" in output


def test_incident_store_redacts_credential_detail_and_nested_metadata():
    import json
    from modules.incident_center import record_incident
    db = {}
    row = record_incident(db, source="telegram_update", kind="NetworkError", detail=f"bot{FIXTURE_TOKEN}/getUpdates", metadata={"url": f"bot{FIXTURE_TOKEN}", "nested": [{"api_key": "private-fixture-value"}], "user_id": 99})
    output = json.dumps(row)
    assert "a" * 35 not in output and "private-fixture-value" not in output
    assert row["metadata"]["user_id"] == 99


@pytest.mark.parametrize("permission", [PERMISSION_SIGNAL_DELETE, "education.delete"])
def test_granted_destructive_permission_is_green_and_has_visible_state(permission):
    rows = crm_content._delegated_admin_rows("99", {"permissions": [permission]}, permission_page(permission))
    button = next(b for row in rows for b in row if str(b.callback_data).split(":")[2:3] == [permission_token(permission)])
    assert button.style == "success"
    assert "فعال" in button.text or "روشن" in button.text


def test_watchdog_ignores_old_diagnostic_backlog(monkeypatch):
    from core import observability
    monkeypatch.setattr(observability, "snapshot", lambda: {"gauges": {"telegram_update_backlog": 100}})
    processor = KeyedUpdateProcessor(2)
    assert processor.delivery_probe()["pending"] == 0


def test_delivery_probe_does_not_read_metrics_file_or_filesystem(monkeypatch):
    from core import observability
    def blocked():
        raise AssertionError("delivery monitor must only observe actual in-flight work")
    monkeypatch.setattr(observability, "snapshot", blocked)
    assert KeyedUpdateProcessor(2).delivery_probe()["processor_healthy"] is True


@pytest.mark.parametrize("signal,expected", [
    ({"side": "buy", "entry": "2000", "stop": "1800", "targets": ["2400"]}, 2),
    ({"side": "sell", "entry": "2000", "stop": "2200", "targets": ["1600"]}, 2),
    ({"side": "buy", "entry": "2,000", "stop": "1,800", "targets": ["2,400"]}, 2),
    ({"side": "buy", "entries": [97, 100, 109], "entry": 102, "stop": 96, "targets": [114]}, 2),
    ({"side": "sell", "entries": [97, 100, 109], "entry": 102, "stop": 108, "targets": [90]}, 2),
    ({"side": "buy", "entries": [97, 100, 109], "stop": 96, "targets": [114]}, 2),
    ({"side": "buy", "entry": "0.000010", "stop": "0.000009", "targets": ["0.000012"]}, 2),
    ({"side": "buy", "entry": "1e-5", "stop": "9e-6", "targets": ["1.2e-5"]}, 2),
])
def test_rr_uses_published_entry_and_is_independent_of_market_price(signal, expected):
    for price in (None, 1, 9999):
        metrics = read._signal_live_metrics(signal, {"price": price})
        assert metrics["risk_reward"] == pytest.approx(expected)
        assert metrics["target_rr"][0]["r"] == pytest.approx(expected)


@pytest.mark.parametrize("signal", [
    {"side": "buy", "entry_min": 100, "entry_max": 110, "stop": 90, "targets": [130]},
    {"side": "buy", "entry": 100, "stop": 100, "targets": [110]},
    {"side": "buy", "entry": 100, "stop": 105, "targets": [110]},
    {"side": "buy", "entry": 100, "stop": 95, "targets": [90]},
    {"side": "unknown", "entry": 100, "stop": 95, "targets": [110]},
    {"rr": 999},
])
def test_invalid_or_ambiguous_levels_do_not_invent_rr(signal):
    assert read._signal_live_metrics(signal, None)["risk_reward"] is None


def test_invalid_first_target_keeps_its_number_and_has_no_rr():
    result = read._signal_live_metrics({"side": "buy", "entry": 100, "stop": 95, "targets": ["bad", 110]}, None)
    assert result["risk_reward"] is None
    assert [(x["label"], x["r"]) for x in result["target_rr"]] == [("TP1", None), ("TP2", 2)]


@pytest.mark.parametrize("signal", [
    {"side": "buy", "entry": "1e9999", "stop": 1, "targets": ["2e9999"]},
    {"side": "buy", "entry": "1e-300", "stop": "5e-301", "targets": ["1e300"]},
])
def test_unrepresentable_rr_never_breaks_json(signal):
    import json
    from modules.signal_engine import signal_rr_snapshot
    metrics = signal_rr_snapshot(signal)
    assert metrics["risk_reward"] is None
    json.dumps(metrics, allow_nan=False)


def test_legacy_signal_view_uses_current_levels_instead_of_stored_rr(monkeypatch):
    monkeypatch.setattr(legacy, "_quote_for_signal", lambda *_: {})
    monkeypatch.setattr(legacy, "late_entry_snapshot", lambda *_: {})
    signal = {"id": 1, "symbol": "XAUUSD", "side": "buy", "entry": 2000, "stop": 1800, "targets": [2400], "rr": 1.44}
    assert float(legacy._signal_core({}, "99", signal)["risk_reward"]) == 2


def test_governance_is_manual_only_for_existing_settings():
    from modules.operations_governance import run_automation_checks, claim_governance_digest
    db = {"enterprise_control": {"modules": {"governance": {"enabled": True, "notify_admins": True}}}}
    assert run_automation_checks(db).get("checks") == []
    assert claim_governance_digest(db, force=True) is None


@pytest.mark.asyncio
async def test_permission_click_returns_saved_green_state(monkeypatch):
    db = {"delegated_admins": {"99": {"permissions": [], "active": True, "approval_status": "approved", "created_by": "1"}}}
    async def mutate(fn):
        return fn(db)
    monkeypatch.setattr(crm_content, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(crm_content, "async_with_db", mutate)
    monkeypatch.setattr(crm_content, "audit", lambda *_: None)
    monkeypatch.setattr(crm_content, "_delegated_admin_self_edit_error", lambda *_: None)
    saved = AsyncMock()
    monkeypatch.setattr(crm_content, "edit", saved)
    permission = PERMISSION_SIGNAL_DELETE
    page = permission_page(permission)
    query = SimpleNamespace(data=f"ap_set:99:{permission_token(permission)}:1:{page}", from_user=SimpleNamespace(id=1), answer=AsyncMock())
    await bot.admin_permission_set(SimpleNamespace(callback_query=query), SimpleNamespace(user_data={}))
    assert permission in db["delegated_admins"]["99"]["permissions"]
    rows = saved.call_args.args[2]
    button = next(b for row in rows for b in row if str(b.callback_data).split(":")[2:3] == [permission_token(permission)])
    assert button.style == "success"


def test_manual_monitoring_unregisters_old_job_and_schedules_nothing():
    from unittest.mock import Mock
    from bot_runtime.runtime_jobs import _configure_governance_monitoring
    job = Mock()
    queue = Mock()
    queue.get_jobs_by_name.return_value = (job,)
    _configure_governance_monitoring(SimpleNamespace(job_queue=queue), {})
    job.schedule_removal.assert_called_once()
    queue.run_repeating.assert_not_called()


def test_explicit_automatic_monitoring_can_be_scheduled():
    from unittest.mock import Mock
    from bot_runtime.runtime_jobs import _configure_governance_monitoring
    queue = Mock()
    queue.get_jobs_by_name.return_value = ()
    db = {"enterprise_control": {"modules": {"governance": {"monitoring_mode": "automatic", "enabled": True}}}}
    _configure_governance_monitoring(SimpleNamespace(job_queue=queue), db)
    assert queue.run_repeating.call_args.kwargs["name"] == "operations-governance-watchdog"
    assert queue.run_repeating.call_args.kwargs["interval"] >= 300


def test_manual_check_cannot_execute_automatic_retries_or_pause_modules(monkeypatch):
    from modules import operations_governance as gov
    monkeypatch.setattr(gov, "observability_snapshot", lambda: {"jobs": {}, "uptime_seconds": 0})
    monkeypatch.setattr(gov, "retry_due_requests", lambda *_: pytest.fail("manual check must not apply queued changes"))
    db = {"enterprise_control": {"modules": {"governance": {"auto_retry": True, "auto_pause_on_failure": True}}}}
    result = gov.run_automation_checks(db, manual=True)
    assert len(result["checks"]) == 15
    assert result["retry"]["retried"] == 0
    assert result["auto_paused"] == []


@pytest.mark.asyncio
async def test_manual_mode_does_not_probe_or_notify_in_background(monkeypatch):
    from bot_runtime import runtime_jobs as jobs
    monkeypatch.setattr(jobs, "async_snapshot", AsyncMock(return_value={}))
    probe = AsyncMock()
    transaction = AsyncMock()
    monkeypatch.setattr(jobs, "refresh_channel_permission_health", probe)
    monkeypatch.setattr(jobs, "async_with_db", transaction)
    await jobs.operations_governance_watchdog_job(SimpleNamespace())
    probe.assert_not_awaited()
    transaction.assert_not_awaited()


@pytest.mark.asyncio
async def test_incident_push_is_quiet_in_manual_mode(monkeypatch):
    from bot_runtime import runtime_jobs as jobs
    transaction = AsyncMock(return_value={})
    monkeypatch.setattr(jobs, "async_with_db", transaction)
    monkeypatch.setattr(jobs, "async_snapshot", AsyncMock(return_value={}))
    await jobs.incident_maintenance_job(SimpleNamespace())
    assert transaction.await_args_list[0].args[0] is jobs.maintain_incidents
    assert transaction.await_count == 1  # Internal cleanup remains, notification claims do not.


@pytest.mark.asyncio
async def test_manual_check_acknowledges_before_expensive_work(monkeypatch):
    from bot_runtime import operations_governance as handlers
    from modules import operations_governance as gov
    query = SimpleNamespace(from_user=SimpleNamespace(id=1), answer=AsyncMock())
    monkeypatch.setattr(handlers, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(handlers, "_is_owner_admin", lambda _: True)
    monkeypatch.setattr(gov, "observability_snapshot", lambda: {"jobs": {}, "uptime_seconds": 0})
    db = {}
    async def probe(_):
        query.answer.assert_awaited_once()
    async def mutate(fn):
        return fn(db)
    monkeypatch.setattr(handlers, "refresh_channel_permission_health", probe)
    monkeypatch.setattr(handlers, "async_with_db", mutate)
    monkeypatch.setattr(handlers, "async_snapshot", AsyncMock(side_effect=lambda: db))
    monkeypatch.setattr(handlers, "edit", AsyncMock())
    await handlers.operations_run_now(SimpleNamespace(callback_query=query), SimpleNamespace())
    assert len(db["operations_governance"]["automation_checks"]) == 15


@pytest.mark.asyncio
@pytest.mark.parametrize("name", ["operations_run_now", "governance_monitoring_mode", "governance_notification_snooze"])
async def test_delegates_cannot_start_manual_or_automatic_monitoring(monkeypatch, name):
    from bot_runtime import operations_governance as handlers
    monkeypatch.setattr(handlers, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(handlers, "_is_owner_admin", lambda _: False)
    transaction = AsyncMock()
    monkeypatch.setattr(handlers, "async_with_db", transaction)
    query = SimpleNamespace(data="ops_monitor:automatic", from_user=SimpleNamespace(id=99), answer=AsyncMock())
    await getattr(handlers, name)(SimpleNamespace(callback_query=query), SimpleNamespace())
    transaction.assert_not_awaited()
    assert query.answer.call_args.kwargs["show_alert"] is True


@pytest.mark.asyncio
async def test_owner_can_explicitly_enable_and_disable_monitoring(monkeypatch):
    from unittest.mock import Mock
    from bot_runtime import operations_governance as handlers
    from modules.admin_control_center import module_state
    db = {}
    monkeypatch.setattr(handlers, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(handlers, "_is_owner_admin", lambda _: True)
    monkeypatch.setattr(handlers, "async_snapshot", AsyncMock(side_effect=lambda: db))
    async def mutate(fn):
        return fn(db)
    monkeypatch.setattr(handlers, "async_with_db", mutate)
    monkeypatch.setattr(handlers, "edit", AsyncMock())
    queue = Mock()
    old_job = Mock()
    queue.get_jobs_by_name.return_value = (old_job,)
    context = SimpleNamespace(application=SimpleNamespace(job_queue=queue))
    for mode in ("automatic", "manual"):
        query = SimpleNamespace(data=f"ops_monitor:{mode}", from_user=SimpleNamespace(id=1), answer=AsyncMock())
        await handlers.governance_monitoring_mode(SimpleNamespace(callback_query=query), context)
        settings = module_state(db, "governance")
        assert settings["monitoring_mode"] == mode
        assert settings["notify_admins"] is (mode == "automatic")
    assert queue.run_repeating.call_count == 1
    assert old_job.schedule_removal.call_count == 2


def test_governance_home_has_direct_check_and_no_extra_menu_hubs():
    from bot_runtime.operations_governance import _governance_home_content
    from modules.operations_governance import governance_dashboard
    text, rows = _governance_home_content(governance_dashboard({}), owner=True)
    callbacks = [b.callback_data for row in rows for b in row]
    assert "ops_run" in callbacks
    assert "ops_monitor:automatic" in callbacks
    assert "ops_checks" not in callbacks and "ecc_mod:governance" not in callbacks
    assert "خاموش" in text


def test_menu_renders_one_catalog_per_category_and_honors_alternative_permissions(monkeypatch):
    from modules.admin_access import PERMISSION_CRM_EXPORT
    original = navigation._admin_items_by_callback
    calls = []
    def catalog():
        calls.append(1)
        return original()
    monkeypatch.setattr(navigation, "_admin_items_by_callback", catalog)
    monkeypatch.setattr(navigation, "_admin_granted_permissions", lambda _: {PERMISSION_CRM_EXPORT})
    monkeypatch.setattr(navigation, "_is_owner_admin", lambda _: False)
    rows = navigation.admin_category_menu("users", 99)
    callbacks = [b.callback_data for row in rows for b in row]
    assert "a_export_users" in callbacks and "a_export_activity" in callbacks
    assert "a_export_transactions" not in callbacks
    assert len(calls) == 1


@pytest.mark.asyncio
@pytest.mark.parametrize("name,category", [("a_crm", "users"), ("a_edu", "education"), ("a_export_csv", "users")])
async def test_legacy_hubs_preserve_content_and_return_directly_to_category(monkeypatch, name, category):
    from bot_runtime import admin_operations
    handlers = admin_operations if name == "a_edu" else crm_content
    monkeypatch.setattr(handlers, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(handlers, "_has_admin_permission", lambda *_: True)
    monkeypatch.setattr(handlers, "async_snapshot", AsyncMock(return_value={}))
    async def mutate(fn):
        return fn({})
    monkeypatch.setattr(handlers, "async_with_db", mutate)
    output = AsyncMock()
    monkeypatch.setattr(handlers, "edit", output)
    query = SimpleNamespace(from_user=SimpleNamespace(id=1), answer=AsyncMock())
    await getattr(handlers, name)(SimpleNamespace(callback_query=query), SimpleNamespace(user_data={}))
    rows = output.call_args.args[2]
    assert [str(b.callback_data).removeprefix("nb:") for row in rows for b in row] == [f"admin_cat:{category}"]


@pytest.mark.asyncio
async def test_legacy_back_refreshes_permission_screen_from_server(monkeypatch):
    snapshot = {"fingerprint": "old", "reply_markup": {"inline_keyboard": [[{"text": "old disabled", "callback_data": "ap_set:99:1234abcd:1:2"}]]}}
    monkeypatch.setattr(navigation, "_callback_screen_snapshot", lambda _: {"fingerprint": "now"})
    monkeypatch.setattr(navigation, "_navigation_stack", lambda _: [snapshot])
    monkeypatch.setattr(navigation, "_clear_current_operation", lambda *_, **__: None)
    route = AsyncMock(return_value=-1)
    monkeypatch.setattr(navigation, "_dispatch_back_target", route)
    query = SimpleNamespace(data="nav_back", answer=AsyncMock())
    update = SimpleNamespace(callback_query=query)
    context = SimpleNamespace()
    await navigation.navigation_back(update, context)
    assert route.await_args.args[2] == "admin_manage:99:2"


def test_role_preset_and_monitoring_changes_are_not_back_history():
    assert navigation._is_state_mutation_callback("admin_role:99:support")
    assert navigation._is_state_mutation_callback("ops_monitor:automatic")


def test_real_stalled_updates_still_trigger_recovery(monkeypatch):
    import time
    from core.runtime_watchdog import DeliveryProgressWatch
    processor = KeyedUpdateProcessor(2)
    processor._active[1] = time.monotonic()
    watch = DeliveryProgressWatch(30)
    assert watch.check(processor.delivery_probe(), 1) is None
    assert watch.check(processor.delivery_probe(), 32).startswith("telegram-delivery-no-progress")
    processor._active.clear()
    assert watch.check(processor.delivery_probe(), 33) is None


def test_rr_frontend_displays_only_authoritative_valid_values():
    import subprocess
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    result = subprocess.run(["node", str(root / "tests/miniapp_rr843.mjs")], cwd=root, capture_output=True, text=True, timeout=10)
    assert result.returncode == 0, result.stderr
    assert "7 scenarios passed" in result.stdout
