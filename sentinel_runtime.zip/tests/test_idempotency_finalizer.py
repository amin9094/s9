from __future__ import annotations

from pathlib import Path

from core.storage.engine import DatabaseEngine
from repositories.v2.idempotency import IdempotencyRepository


def test_async_finalizer_can_replace_intermediate_response(tmp_path: Path):
    engine = DatabaseEngine(database_url="", sqlite_path=tmp_path / "idem.sqlite3")
    engine.ensure_schema()
    repo = IdempotencyRepository(engine)
    reservation = repo.reserve("1", "req-1", action="payment_approve", fingerprint="f")
    repo.complete("1", "req-1", token=reservation.token, response={"data": {"status": "approving"}})
    repo.replace_completed_response("1", "req-1", response={"data": {"status": "approved"}})
    replay = repo.reserve("1", "req-1", action="payment_approve", fingerprint="f")
    assert replay.state == "replay"
    assert replay.response == {"data": {"status": "approved"}}


def test_failed_async_finalizer_can_reset_completed_reservation(tmp_path: Path):
    engine = DatabaseEngine(database_url="", sqlite_path=tmp_path / "idem.sqlite3")
    engine.ensure_schema()
    repo = IdempotencyRepository(engine)
    reservation = repo.reserve("1", "req-1", action="payment_approve", fingerprint="f")
    repo.complete("1", "req-1", token=reservation.token, response={"data": {"status": "approving"}})
    repo.reset_completed("1", "req-1")
    retry = repo.reserve("1", "req-1", action="payment_approve", fingerprint="f")
    assert retry.state == "new"
