from __future__ import annotations

import re

from bot_runtime.analytics_governance import (
    _automation_dashboard_health,
    _automation_panel_text,
)
from bot_runtime.navigation import _admin_navigation_categories
from core.domain import record_event
from handlers.callback_routes import callback_routes
from modules.contest import add_price_guess, end_price_contest, start_price_contest
from modules.education import create_lesson, mark_lesson_complete, visible_lessons
from modules.missions import create_mission, mission_progress_snapshot


class _RouteNamespace(dict[str, str]):
    def __missing__(self, key: str) -> str:
        return key


def _registered_patterns(callback_name: str) -> list[str]:
    return [
        pattern
        for pattern, callback in callback_routes(_RouteNamespace())
        if callback == callback_name
    ]


def test_every_new_admin_category_reaches_admin_navigation() -> None:
    patterns = _registered_patterns("admin_navigation")
    categories = _admin_navigation_categories()

    assert set(categories) == {
        "trading",
        "users",
        "sales",
        "content",
        "education",
        "engagement",
        "automation",
        "system",
    }
    for category in categories:
        callback = f"admin_cat:{category}"
        assert any(re.fullmatch(pattern, callback) for pattern in patterns), callback


def test_reactivated_module_entrypoints_have_live_callback_routes() -> None:
    routes = callback_routes(_RouteNamespace())
    expected = {
        "a_ai_command_center": "a_ai_command_center",
        "a_market_intel": "a_market_intel",
        "a_portfolio": "a_portfolio",
        "sig_exposure": "signal_exposure_board",
        "a_edu": "a_edu",
        "a_contest": "a_contest",
        "a_missions": "a_missions",
        "a_automations": "a_automations",
        "u_account": "u_account",
        "u_edu": "u_edu",
        "u_contests": "u_contests",
        "u_missions": "u_missions",
        "u_market_intel": "u_market_intel",
        "u_risk_coach": "u_risk_coach",
    }
    for callback_data, callback_name in expected.items():
        assert any(
            callback == callback_name and re.fullmatch(pattern, callback_data)
            for pattern, callback in routes
        ), callback_data


def test_automation_panel_exposes_v2_runtime_health() -> None:
    db = {
        "automation_rules_v2": {
            "AR2-1": {"id": "AR2-1", "enabled": True},
            "AR2-2": {"id": "AR2-2", "enabled": False},
        },
        "automation_v2_runs": [
            {"id": "AV2-1", "status": "completed"},
            {"id": "AV2-2", "status": "failed"},
        ],
        "automation_v2_jobs": {
            "AJ2-1": {"id": "AJ2-1", "status": "pending"},
            "AJ2-2": {"id": "AJ2-2", "status": "retry"},
            "AJ2-3": {"id": "AJ2-3", "status": "dead_letter"},
        },
    }
    health = _automation_dashboard_health(db)

    assert health["automation_v2"] == {
        "rules": 2,
        "enabled_rules": 1,
        "completed_runs": 1,
        "failed_runs": 1,
        "pending_jobs": 1,
        "retry_jobs": 1,
        "dead_letter_jobs": 1,
    }
    text = _automation_panel_text({"enabled": True}, health)
    assert "Automation V2" in text
    assert "قانون فعال: <b>1</b> از <b>2</b>" in text
    assert "Dead-letter: <b>1</b>" in text


def test_education_mission_contest_and_points_work_end_to_end() -> None:
    db: dict = {}
    lesson = create_lesson(
        db,
        category="ترید",
        title="مدیریت ریسک",
        access_type="free",
        price=0,
        text="ریسک هر معامله را قبل از ورود محاسبه کنید.",
        actor_id=1,
    )
    mission = create_mission(
        db,
        title="تکمیل اولین آموزش",
        reward=10,
        event="complete_lesson",
        target=1,
        actor_id=1,
    )

    assert visible_lessons(db) == [lesson]
    assert mark_lesson_complete(db, 1001, lesson["id"])["completed"] is True
    assert record_event(db, 1001, "complete_lesson") == []  # completion now grants atomically inside mark_lesson_complete
    assert mission_progress_snapshot(db, 1001, mission)["completed"] is True
    assert db["user_points"]["1001"] == 10

    contest = start_price_contest(db, "XAUUSD", 60, reward_points=7)
    assert add_price_guess(db, 1001, 2350) == "OK"
    assert add_price_guess(db, 1002, 2360) == "OK"
    closed, results = end_price_contest(db, 2352)

    assert closed is contest
    assert closed["status"] == "closed"
    assert results[0]["uid"] == "1001"
    assert results[0]["points"] == 7
    assert db["user_points"]["1001"] == 17
