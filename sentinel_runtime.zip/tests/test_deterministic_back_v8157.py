from pathlib import Path
import sys

sys.path.insert(0, str(Path(__file__).resolve().parent))
from telegram_test_stub import install
install()

from ui.button_factory import InlineKeyboardButton, canonical_navigation_text


def _text(button):
    # ``getattr(obj, name, fallback)`` evaluates ``fallback`` eagerly.
    # The old helper used ``button.args[0]`` as that fallback, but the real
    # python-telegram-bot InlineKeyboardButton has ``text`` and no ``args``.
    # Read the production attribute first and use the local stub only when
    # that attribute is genuinely absent.
    text = getattr(button, "text", None)
    if text is not None:
        return text
    args = getattr(button, "args", ())
    if not args:
        raise AssertionError("button exposes neither text nor positional test-stub args")
    return args[0]


def test_back_keeps_exact_parent_callback_in_navigation_envelope() -> None:
    button = InlineKeyboardButton("🔙 گروه‌های دسترسی", callback_data="admin_manage:123456")
    assert _text(button) == "⬅️ برگشت"
    assert button.callback_data == "nb:admin_manage:123456"
    assert button.style is None


def test_committed_permission_toggle_is_not_a_back_target() -> None:
    button = InlineKeyboardButton("دسترسی سیگنال", callback_data="admin_perm:123:signals")
    assert button.callback_data == "admin_perm:123:signals"
    assert canonical_navigation_text(_text(button), button.callback_data) is None


def test_cancel_remains_separate_from_back() -> None:
    button = InlineKeyboardButton("✖️ لغو", callback_data="cancel_current")
    assert button.callback_data == "cancel_current"
    assert _text(button) == "✖️ لغو"


def test_release_version_v8157() -> None:
    assert Path("VERSION").read_text(encoding="utf-8").strip() == "9.0.0-candidate.14"


def test_every_literal_back_parent_has_a_registered_callback_route() -> None:
    import ast
    import re

    route_tree = ast.parse(Path("handlers/callback_routes.py").read_text(encoding="utf-8"))
    patterns = [
        node.elts[0].value
        for node in ast.walk(route_tree)
        if isinstance(node, ast.Tuple)
        and node.elts
        and isinstance(node.elts[0], ast.Constant)
        and isinstance(node.elts[0].value, str)
        and node.elts[0].value.startswith("^")
    ]
    missing = []
    for source in Path("bot_runtime").glob("*.py"):
        tree = ast.parse(source.read_text(encoding="utf-8"), filename=source)
        for node in ast.walk(tree):
            if not (
                isinstance(node, ast.Call)
                and isinstance(node.func, ast.Name)
                and node.func.id == "back"
                and node.args
                and isinstance(node.args[0], ast.Constant)
                and isinstance(node.args[0].value, str)
            ):
                continue
            target = node.args[0].value
            if not any(re.match(pattern, target) for pattern in patterns):
                missing.append(f"{source}:{node.lineno}:{target}")
    assert missing == []


def test_representative_dynamic_back_parents_are_routable() -> None:
    import ast
    import re

    tree = ast.parse(Path("handlers/callback_routes.py").read_text(encoding="utf-8"))
    patterns = [
        node.elts[0].value
        for node in ast.walk(tree)
        if isinstance(node, ast.Tuple)
        and node.elts
        and isinstance(node.elts[0], ast.Constant)
        and isinstance(node.elts[0].value, str)
        and node.elts[0].value.startswith("^")
    ]
    samples = (
        "ticket_a:123",
        "mission_manage:1",
        "campaign_view:CMP-000001",
        "public_discount_view:ABC",
        "lesson_manage:1",
        "ecc_mod:signals",
        "faq_manage:1",
        "crm_field_menu:123",
        "sig_edit_menu:1",
        "sig_result_view:1",
    )
    assert all(any(re.match(pattern, target) for pattern in patterns) for target in samples)
