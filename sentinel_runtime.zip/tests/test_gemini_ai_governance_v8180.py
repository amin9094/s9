from __future__ import annotations

from pathlib import Path

import pytest

from modules import gemini_ai

ROOT = Path(__file__).resolve().parents[1]


def test_default_user_access_is_vip_only(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(gemini_ai, "read_db_sections", lambda _sections: {})
    settings = gemini_ai.ai_runtime_settings()
    assert settings["user_access_mode"] == "vip_only"


def test_toggle_user_access_between_vip_and_all(monkeypatch: pytest.MonkeyPatch) -> None:
    db: dict = {"ai_runtime_settings": {"user_access_mode": "vip_only"}}

    def fake_read(_sections):
        return db

    def fake_with_db(fn):
        return fn(db)

    monkeypatch.setattr(gemini_ai, "read_db_sections", fake_read)
    monkeypatch.setattr(gemini_ai, "with_db", fake_with_db)
    first = gemini_ai.toggle_user_ai_access_mode(1)
    assert first["user_access_mode"] == "all"
    second = gemini_ai.toggle_user_ai_access_mode(1)
    assert second["user_access_mode"] == "vip_only"


def test_direct_user_chat_is_blocked_before_provider_for_non_vip(monkeypatch: pytest.MonkeyPatch) -> None:
    called = False

    def provider(*_args, **_kwargs):
        nonlocal called
        called = True
        raise AssertionError("provider must not be called")

    monkeypatch.setattr(gemini_ai, "user_ai_access", lambda _uid: {"allowed": False, "mode": "vip_only"})
    monkeypatch.setattr(gemini_ai, "_gemini_request", provider)
    with pytest.raises(PermissionError, match="AI_VIP_REQUIRED"):
        gemini_ai.user_ai_query(10, "عملکرد حسابم را بگو")
    assert called is False


def test_direct_user_chat_answers_inside_bot_for_eligible_user(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(gemini_ai, "user_ai_access", lambda _uid: {"allowed": True, "mode": "vip_only", "vip_active": True})
    monkeypatch.setattr(gemini_ai, "user_ai_context", lambda _uid: {"risk": {"score": 80}})
    monkeypatch.setattr(gemini_ai, "_gemini_request", lambda *_args, **_kwargs: {
        "text": '{"answer":"پاسخ داخل ربات","findings":[],"warnings":[],"next_steps":[]}',
        "model": "gemini-test",
        "usage": {"total_tokens": 10},
    })
    monkeypatch.setattr(gemini_ai, "_record_ai_result", lambda **_kwargs: {"conversation": {"id": 77}})
    monkeypatch.setattr(gemini_ai, "gemini_status", lambda: {"enabled": True})

    result = gemini_ai.user_ai_query(10, "عملکرد حسابم را بگو")

    assert result["answer"] == "پاسخ داخل ربات"
    assert result["conversation_id"] == 77
    assert result["tool_calls"] == []


def test_recursive_financial_smuggling_is_rejected() -> None:
    rows = gemini_ai._sanitize_proposals([
        {
            "type": "channel_draft",
            "title": "unsafe",
            "payload": {"message": "normal", "metadata": {"payment": "approve"}},
        },
        {
            "type": "crm_campaign_draft",
            "title": "unsafe-plan",
            "payload": {"message": "hello", "plan": "vip"},
        },
        {
            "type": "report_note",
            "title": "safe",
            "payload": {"text": "گزارش سلامت سیستم", "category": "system"},
        },
    ])
    assert rows == [
        {
            "type": "report_note",
            "title": "safe",
            "reason": "",
            "payload": {"text": "گزارش سلامت سیستم", "category": "system"},
        }
    ]


def test_crm_journey_intelligence_has_stage_and_next_action() -> None:
    db = {
        "users": {"100": {"id": "100", "created_at": "2026-07-01T00:00:00+00:00"}},
        "user_activity": [
            {"user_id": "100", "event": "start", "created_at": "2026-07-20T00:00:00+00:00"},
            {"user_id": "100", "event": "miniapp_open", "created_at": "2026-07-20T00:01:00+00:00"},
            {"user_id": "100", "event": "mt5_pairing_started", "created_at": "2026-07-20T00:02:00+00:00"},
        ],
    }
    result = gemini_ai.crm_journey_intelligence(db, target_user_id="100")
    assert result["total_users"] == 1
    assert result["priority_users"][0]["stages"]
    assert result["priority_users"][0]["next_best_action"]


def test_knowledge_search_uses_approved_project_sources(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(gemini_ai, "read_db_sections", lambda _sections: {})
    result = gemini_ai.knowledge_search("MetaTrader MT5 اتصال")
    assert result["items"]
    assert all("text" in row and "source" in row for row in result["items"])


def test_health_status_includes_real_provider_fields(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(gemini_ai, "_health_cache", lambda: {
        "reachable": True,
        "authenticated": True,
        "model_available": True,
        "last_checked_at": "2026-07-28T00:00:00+00:00",
        "latency_ms_ema": 120,
    })
    monkeypatch.setattr(gemini_ai, "ai_runtime_settings", lambda: {"user_access_mode": "vip_only"})
    status = gemini_ai.gemini_status()
    for field in ("configured", "reachable", "authenticated", "model_available", "latency_ms", "last_checked_at"):
        assert field in status


def test_frontend_has_review_button_and_admin_access_toggle() -> None:
    js = (ROOT / "webapp" / "src" / "admin-parity.js").read_text(encoding="utf-8")
    assert "data-user-ai-review" in js
    assert "data-admin-ai-access-toggle" in js
    assert "data-admin-ai-health-test" in js
    assert "data-admin-ai-daily-report" in js
    user_block = js[js.index("function userAiCenter"):js.index("async function _adminAiCenterLegacy")]
    assert "textarea" not in user_block.lower()
    assert "با Gemini صحبت کنید یا فرمان بدهید" in js
    assert "کد WELCOME15" in js


def test_telegram_has_aistatus_daily_report_and_no_image_analysis() -> None:
    platform = (ROOT / "bot_runtime" / "platform_expansion.py").read_text(encoding="utf-8")
    routes = (ROOT / "handlers" / "registration_plan.py").read_text(encoding="utf-8")
    callbacks = (ROOT / "handlers" / "callback_routes.py").read_text(encoding="utf-8")
    assert "ai_status_command" in platform and '"aistatus"' in routes
    assert "ai_daily_command" in platform and '"aidaily"' in routes
    assert "a_ai_access_toggle" in callbacks
    assert "image_analysis" not in platform
    assert "receipt_analysis" not in platform


def test_usage_limit_settings_are_defined() -> None:
    assert gemini_ai.SETTINGS.gemini_user_daily_request_limit >= 1
    assert gemini_ai.SETTINGS.gemini_admin_daily_request_limit >= 1
    assert gemini_ai.SETTINGS.gemini_daily_token_limit >= 1
    assert gemini_ai.SETTINGS.gemini_monthly_token_limit >= 1
