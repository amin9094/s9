from datetime import UTC, datetime, timedelta

from modules.system_center import build_system_center_snapshot


def test_system_center_healthy_snapshot():
    now = datetime(2026, 9, 25, tzinfo=UTC)
    result = build_system_center_snapshot(
        {},
        observability={"uptime_seconds": 7200, "jobs": {"a": {"status": "ok"}}},
        readiness={"checks": {"telegram": True, "telegram_transport_running": True, "database": True, "job_queue": True}},
        google_sheets={"enabled": True, "configured": True, "pending_sections": []},
        latest_backup={"created_at": (now - timedelta(hours=2)).isoformat()},
        now=now,
    )
    assert result["overall"] == "healthy"
    assert result["components"]["google_sheets"]["state"] == "healthy"
    assert result["jobs"]["ok"] == 1


def test_system_center_surfaces_google_queue_and_job_failure():
    result = build_system_center_snapshot(
        {},
        observability={"jobs": {"google": {"status": "failed"}}},
        readiness={"checks": {"telegram": True, "telegram_transport_running": True, "database": True, "job_queue": True}},
        google_sheets={"enabled": True, "configured": True, "pending_sections": [str(i) for i in range(25)]},
    )
    assert result["overall"] == "degraded"
    assert result["components"]["google_sheets"]["state"] == "degraded"
    assert result["jobs"]["failed_names"] == ["google"]
