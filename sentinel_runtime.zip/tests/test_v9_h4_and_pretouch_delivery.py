"""Synthetic trade/Telegram race contracts; never live feed or send claims."""
from copy import deepcopy
from dataclasses import replace
from decimal import Decimal as D
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from modules import iran_equities as domain
from modules.iran_equity_intraday import analyze_h4, h4_bars
from services import iran_equity_service as service
from tests.test_v9_iran_equities import CODE, NOW, history, identity, client
from tests.test_v9_ordered_live_pipeline import B, frame, live_plan, owner_fixture


def intraday_history(count=130, current_day=False):
    raw = history(count, current_day=current_day)
    trades = {}
    for row in raw['closingPriceDaily']:
        close = row['pDrCotVal']
        prices = [close-5, close+10, close-10, close-3, close]
        quantities = [100]*4 + [row['qTotTran5J']-400]
        rows = [dict(nTran=i+1, hEven=clock, pTran=price, qTitTran=q, canceled=0, iAnuTran=0, dEven=0)
                for i,(clock,price,q) in enumerate(zip([90000,100000,115959,120000,123000],prices,quantities))]
        row['zTotTran'] = len(rows)
        row['qTotCap'] = sum(p*q for p,q in zip(prices,quantities))
        trades[str(row['dEven'])] = {'tradeHistory': list(reversed(rows))}
    return raw, trades


@pytest.fixture
def input_feed(monkeypatch):
    raw, trades = intraday_history()
    calls = []
    async def fetch(path, ttl):
        calls.append(path)
        if 'InstrumentInfo' in path:return {'instrumentInfo': identity()}
        if 'ClosingPriceDailyList' in path:return raw
        return trades[path.split('/')[-2]]
    monkeypatch.setattr(service, '_fetch', fetch)
    monkeypatch.setattr(service, '_H4_CACHE', {})
    monkeypatch.setattr(service.time, 'time', lambda:NOW/1000)
    return raw, trades, calls


def test_h4_uses_actual_trades_midnight_alignment_boundary_and_daily_reconciliation():
    raw, trades = intraday_history(1)
    day = domain.daily_bars(raw,CODE,NOW)[0][0]
    result = h4_bars(next(iter(trades.values())),raw['closingPriceDaily'][0],day,CODE,NOW)
    assert len(result)==2
    assert [domain.datetime.fromtimestamp(b.start_ms/1000,domain.TEHRAN).hour for b in result]==[8,12]
    assert result[0].close==day.low and result[1].open==day.close-3
    assert result[0].high==day.high and result[1].high!=day.high
    assert sum(b.volume for b in result)==day.volume
    assert all(b.end_ms-b.start_ms==4*3600000 and b.is_closed for b in result)


@pytest.mark.parametrize('mutation',[
    {'nTran':1}, {'nTran':None}, {'nTran':True}, {'hEven':246000}, {'hEven':126099},
    {'qTitTran':0}, {'qTitTran':'NaN'}, {'qTitTran':'1.5'}, {'pTran':None},
    {'insCode':'123'}, {'dEven':20261012}, {'canceled':1}, {'iAnuTran':1}, {'hEven':80000},
])
def test_missing_duplicate_cancelled_or_misordered_trade_contract_is_rejected(mutation):
    raw, trades = intraday_history(1)
    day = domain.daily_bars(raw,CODE,NOW)[0][0]
    data = next(iter(trades.values()))
    data['tradeHistory'][0].update(mutation)
    with pytest.raises(ValueError):h4_bars(data,raw['closingPriceDaily'][0],day,CODE,NOW)


@pytest.mark.parametrize('field,value',[('qTotCap',1),('zTotTran',6),('qTotCap',None),('zTotTran',True)])
def test_daily_count_value_and_volume_must_match(field,value):
    raw, trades = intraday_history(1)
    day = domain.daily_bars(raw,CODE,NOW)[0][0]
    raw['closingPriceDaily'][0][field]=value
    with pytest.raises(ValueError):h4_bars(next(iter(trades.values())),raw['closingPriceDaily'][0],day,CODE,NOW)


def test_current_h4_open_is_excluded_and_future_trade_is_rejected():
    raw, trades = intraday_history(1,current_day=True)
    day = domain.daily_bars(raw,CODE,NOW)[0][0]
    data = next(iter(trades.values()))
    bars = h4_bars(data,raw['closingPriceDaily'][0],day,CODE,NOW)
    assert bars[0].is_closed and not bars[1].is_closed
    analysis = analyze_h4(bars,[day],NOW)
    assert analysis['closed_bars']==1 and analysis['current_period_excluded']
    with pytest.raises(ValueError,match='TIME_INVALID'):
        h4_bars(data,raw['closingPriceDaily'][0],day,CODE,day.start_ms+12*3600000)


@pytest.mark.asyncio
async def test_h4_paging_accumulates_contiguous_verified_warmup_without_daily_splitting(input_feed):
    raw, trades, calls = input_feed
    first = await service.equity_chart(CODE,timeframe='4h')
    assert len(first['bars'])==24 and first['timeframe']=='4h'
    assert first['state']=='INDICATOR_WARMUP_INCOMPLETE'
    assert first['volume_kind']=='RECONCILED_TRADES' and first['has_more']
    cursor = first['bars'][0]['timestamp']
    for _ in range(5):
        page = await service.equity_chart(CODE,timeframe='4h',before_ms=cursor)
        assert page['bars'][-1]['timestamp']<cursor
        cursor = page['bars'][0]['timestamp']
    assert page['analysis']['continuous_price_base_bars']>=105
    assert page['state']=='H4_REVIEW_AVAILABLE' and not page['execution_eligible']
    assert page['analysis']['trend']=='UP'
    assert not {'entry','stop','tp1'} & page.keys()
    # A missing middle date may not be bridged by cached older days.
    cache=service._H4_CACHE[CODE];cache.pop(sorted(cache)[-20])
    latest = await service.equity_chart(CODE,timeframe='4h')
    assert latest['analysis']['continuous_price_base_bars']<105
    assert latest['state']=='INDICATOR_WARMUP_INCOMPLETE'


@pytest.mark.asyncio
async def test_h4_does_not_accept_daily_only_or_partial_trades(input_feed):
    raw,trades,_ = input_feed
    trades[str(raw['closingPriceDaily'][0]['dEven'])]['tradeHistory'].pop()
    with pytest.raises(service.IranEquityUnavailable,match='INTRADAY_INCOMPLETE'):
        await service.equity_chart(CODE,timeframe='4h')
    assert (await service.equity_chart(CODE,timeframe='1d'))['state']=='DAILY_REVIEW_AVAILABLE'
    with pytest.raises(ValueError,match='TIMEFRAME'):
        await service.equity_chart(CODE,timeframe='2h')


def test_h4_api_keeps_private_rbac_and_forwards_exact_timeframe(client,monkeypatch):
    from core import miniapp_server as server
    from services import setup_review_service
    mock=AsyncMock(return_value={'timeframe':'4h','bars':[]})
    monkeypatch.setattr(service,'equity_chart',mock)
    url='/api/v1/admin/iran-equities/chart?ins_code='+CODE+'&timeframe=4h'
    assert client.get(url).status_code==403
    mock.assert_not_awaited()
    monkeypatch.setattr(setup_review_service,'can_review_setups',lambda _:True)
    monkeypatch.setattr(server,'rate_limit_allow',lambda *args:True)
    assert client.get(url).json()['data']['timeframe']=='4h'
    mock.assert_awaited_once_with(CODE,limit=300,before_ms=None,timeframe='4h')
    monkeypatch.setattr(service,'equity_chart',AsyncMock(side_effect=service.IranEquityUnavailable('IR_EQUITY_INTRADAY_INCOMPLETE')))
    assert client.get(url).json()['error']['code']=='IR_EQUITY_INTRADAY_INCOMPLETE'


def queued(owner,p):
    owner.repository.propose(p,proposed_ms=B+3000,freshness_proof={
        'untouched':True,'complete_coverage':True,'observed_through_ms':B+3000,'epoch':'fixture-epoch'})
    return owner.live.enqueue(setup_id='s1',version=1,event_id='SIGNAL',audience='admin',target_id=123,content_hash=p.plan_hash)


def delivery_row(owner,key):
    from repositories.v2.common import json_load
    with owner.repository.engine.transaction(read_only=True) as cursor:
        row=cursor.execute('SELECT * FROM s9_deliveries WHERE id=?',(key,)).fetchone()
    row['payload']=json_load(row['payload']);return row


@pytest.mark.asyncio
@pytest.mark.parametrize('engine',['indicators','order_block','sweep_fvg','fibonacci_pullback'])
@pytest.mark.parametrize('direction',['BUY','SELL'])
async def test_every_engine_rejects_touched_zone_before_send(owner_fixture,engine,direction):
    from services.strategy_delivery_service import deliver_cycle
    owner,book,journal=owner_fixture
    from modules.entry_selection import fvg_entry
    entry=D(105)
    evidence=({'kind':'fixture','available_ms':B+1000},)
    if engine=='sweep_fvg':
        entry,detail=fvg_entry(D(100),D(110),direction=direction,tick_size=D(1),pip_size=None)
        evidence=({'kind':'entry_selection','available_ms':B+1000,'detail':detail},)
    if engine=='order_block':
        poc={'kind':'POC','price':'105','source_id':'fixture','source_ids':['fixture'],
             'volume_kind':'traded','symbol':'BTCUSDT','provider':'okx','venue':'okx_spot_USDT',
             'product':'spot','start_ms':B,'end_ms':B+1000,'available_ms':B+1000,'window_locked_ms':B+1000}
        evidence=({'kind':'entry_selection','available_ms':B+1000,'detail':{
                    'selector':'CAUSAL_WAVE_POC','poc':poc,'entry':'105'}},)
    sign=1 if direction=='BUY' else -1
    p=live_plan(engine=engine,direction=direction,entry=entry,stop=entry-sign*10,
                tp1=entry+sign*20,tp2=entry+sign*30,evidence=evidence)
    key=queued(owner,p)
    journal.append(frame(book,7,5,B+3000,bid='109',ask='110'))
    bot=SimpleNamespace(send_message=AsyncMock())
    await deliver_cycle(bot,owner)
    bot.send_message.assert_not_awaited()
    assert delivery_row(owner,key)['state']=='REVOKED'


@pytest.mark.asyncio
async def test_final_synchronous_gate_rejects_touch_after_awaited_candle_check(owner_fixture):
    from services.strategy_delivery_service import deliver_cycle
    owner,book,journal=owner_fixture
    key=queued(owner,live_plan())
    async def race(*args,**kwargs):
        journal.append(frame(book,7,5,B+3000,bid='109',ask='110'))
        return {'observed_through_ms':B+3000}
    owner.freshness=race
    bot=SimpleNamespace(send_message=AsyncMock())
    await deliver_cycle(bot,owner)
    bot.send_message.assert_not_awaited()
    assert delivery_row(owner,key)['state']=='REVOKED'


@pytest.mark.asyncio
@pytest.mark.parametrize('correction',['edit','delete','failure'])
async def test_touch_in_transit_is_corrected_and_never_qualified_or_resent(owner_fixture,correction):
    from services.strategy_delivery_service import deliver_cycle
    owner,_,_=owner_fixture
    key=queued(owner,live_plan())
    owner.freshness=AsyncMock(side_effect=[{'observed_through_ms':B+3000},ValueError('TOUCHED')])
    bot=SimpleNamespace(send_message=AsyncMock(return_value=SimpleNamespace(message_id=77)),
        edit_message_text=AsyncMock(side_effect=RuntimeError() if correction!='edit' else None),
        delete_message=AsyncMock(side_effect=RuntimeError() if correction=='failure' else None))
    await deliver_cycle(bot,owner)
    row=delivery_row(owner,key)
    assert row['state']=='SENT' and row['payload']['detail']=='DELIVERED_BUT_PRETOUCH_UNPROVEN'
    status=row['payload']['verification']['notification_correction']
    assert status=={'edit':'INVALID_NOTICE_EDITED','delete':'INVALID_NOTICE_DELETED','failure':'INVALID_NOTICE_CORRECTION_FAILED'}[correction]
    bot.edit_message_text.assert_awaited_once()
    assert 'Entry:' not in bot.edit_message_text.call_args.kwargs['text']
    assert owner.repository.get('s1')['payload']['admin_delivered_ms'] is None
    await deliver_cycle(bot,owner)
    bot.send_message.assert_awaited_once()


def test_shared_fibonacci_confirmation_cannot_emit_an_independent_entry():
    with pytest.raises(ValueError,match='FIBONACCI_CONFIRMATION_CANNOT_CREATE_ENTRY'):
        live_plan(engine='fibonacci')


@pytest.mark.asyncio
async def test_h4_analysis_resets_at_unadjusted_base_break(input_feed):
    raw,_,_=input_feed
    cursor=None
    for _ in range(6):
        result=await service.equity_chart(CODE,timeframe='4h',before_ms=cursor)
        cursor=result['bars'][0]['timestamp']
    assert result['state']=='H4_REVIEW_AVAILABLE'
    raw['closingPriceDaily'][10]['priceYesterday']=1
    result=await service.equity_chart(CODE,timeframe='4h')
    assert result['state']=='INDICATOR_WARMUP_INCOMPLETE'
    assert result['analysis']['continuous_price_base_bars']==22
    assert 'indicators' not in result['analysis']


@pytest.mark.asyncio
async def test_retry_after_must_revalidate_and_reject_if_price_touched(owner_fixture):
    from telegram.error import RetryAfter
    from services.strategy_delivery_service import deliver_cycle
    owner,book,journal=owner_fixture
    key=queued(owner,live_plan())
    bot=SimpleNamespace(send_message=AsyncMock(side_effect=RetryAfter(0)))
    await deliver_cycle(bot,owner)
    assert delivery_row(owner,key)['state']=='PENDING'
    journal.append(frame(book,7,5,B+3000,bid='104',ask='105'))
    await deliver_cycle(bot,owner)
    bot.send_message.assert_awaited_once()
    assert delivery_row(owner,key)['state']=='REVOKED'


@pytest.mark.asyncio
async def test_known_receipt_cancellation_still_finishes_postflight_correction(owner_fixture):
    import asyncio
    from services.strategy_delivery_service import deliver_cycle
    owner,_,_=owner_fixture
    key=queued(owner,live_plan())
    entered=asyncio.Event();release=asyncio.Event();count=0
    async def freshness(*args,**kwargs):
        nonlocal count
        count+=1
        if count==1:return {'observed_through_ms':B+3000}
        entered.set();await release.wait();raise ValueError('TOUCHED')
    owner.freshness=freshness
    bot=SimpleNamespace(send_message=AsyncMock(return_value=SimpleNamespace(message_id=77)),edit_message_text=AsyncMock())
    task=asyncio.create_task(deliver_cycle(bot,owner))
    await entered.wait();task.cancel();release.set()
    with pytest.raises(asyncio.CancelledError):await task
    bot.edit_message_text.assert_awaited_once()
    assert delivery_row(owner,key)['payload']['verification']['notification_correction']=='INVALID_NOTICE_EDITED'
    assert owner.repository.get('s1')['payload']['admin_delivered_ms'] is None


@pytest.mark.asyncio
async def test_delayed_default_fx_does_not_hide_fresh_free_history_or_mix_sources(monkeypatch):
    from services import canonical_market_service as market, keyless_market_data_service as keyless
    from tests.test_v9_combined_free_sources import price_bars
    yahoo=price_bars('yahoo_fx');now=yahoo[-1].end_ms+3600000+1000
    delta=now-yahoo[-1].start_ms-1000
    fresh=[replace(b,provider='biquote',venue='biquote_indicative',start_ms=b.start_ms+delta,
                   end_ms=b.end_ms+delta,available_ms=b.available_ms+delta,source_id='fresh-'+b.source_id) for b in yahoo]
    monkeypatch.setattr(market.time,'time',lambda:now/1000)
    monkeypatch.setattr(market,'_SOURCE_COOLDOWNS',{})
    monkeypatch.delenv('MARKET_FX_PROVIDER',raising=False)
    monkeypatch.setattr(market,'_yahoo_fx',AsyncMock(return_value=yahoo))
    free=AsyncMock(return_value=fresh);monkeypatch.setattr(keyless,'biquote_history',free)
    assert await market._core_route('EURUSD','5m',300,None,None)==fresh
    free.assert_awaited_once()
    # An explicit chart source is immutable, even when delayed.
    assert await market._core_route('EURUSD','5m',300,None,'yahoo_fx')==yahoo
    assert free.await_count==1
