from __future__ import annotations

import copy
import hashlib
import json
from types import SimpleNamespace
from pathlib import Path

import pytest

from modules import portfolio


@pytest.mark.parametrize("field", ["entry_price", "planned_entry", "actual_stop", "volume", "result_r"])
@pytest.mark.parametrize("bad", [float("nan"), float("inf"), float("-inf")])
def test_journal_creation_rejects_nonfinite_values_without_record_or_counter_change(field, bad):
    db = {"trade_journal": {"42": []}}
    before = copy.deepcopy(db)
    with pytest.raises(ValueError):
        portfolio.add_journal_entry(db, "42", symbol="XAUUSD", side="BUY", **{field: bad})
    assert db == before


@pytest.mark.parametrize("field", ["result_r", "exit_price", "pnl_amount", "fees", "commission", "swap", "mae", "mfe"])
@pytest.mark.parametrize("bad", [float("nan"), float("inf"), "invalid"])
def test_failed_journal_close_keeps_original_open_record(field, bad):
    db = {}
    row = portfolio.add_journal_entry(db, "42", symbol="XAUUSD", side="BUY", entry_price=100, actual_stop=95, volume=1)
    before = copy.deepcopy(row)
    with pytest.raises(ValueError):
        portfolio.update_journal_result(db, "42", row["id"], pnl_percent=2, **{field: bad})
    assert row == before


@pytest.mark.parametrize("bad", [float("nan"), float("inf"), "invalid"])
def test_invalid_partial_close_does_not_debit_volume(bad):
    db = {}
    row = portfolio.add_journal_entry(db, "42", symbol="XAUUSD", side="BUY", entry_price=100, actual_stop=95, volume=1)
    before = copy.deepcopy(row)
    with pytest.raises(ValueError):
        portfolio.add_partial_close(db, "42", row["id"], volume=bad, exit_price=110, pnl_amount=10)
    assert row == before


@pytest.mark.parametrize("levels", [(float("inf"), 95, 110), (100, float("nan"), 110), (100, 95, float("inf"))])
def test_invalid_r_levels_have_no_result(levels):
    assert portfolio.calculate_r_multiple("BUY", *levels) is None


@pytest.mark.parametrize("side", ["", "UNKNOWN", "BULL"])
def test_journal_r_does_not_assume_sell_for_an_unknown_side(side):
    assert portfolio.calculate_r_multiple(side, 100, 95, 110) is None


def test_old_invalid_journal_data_does_not_break_statistics_json():
    rows = [{"status": "closed", "result_r": float("nan"), "pnl_percent": float("inf")},
            {"status": "closed", "result_r": 2, "pnl_percent": 5}]
    stats = portfolio._stats_for_rows(rows)
    json.dumps(stats, allow_nan=False)
    assert stats["invalid_numeric_rows"] == 1
    assert stats["r_net"] == 2
    assert stats["wins"] == 1


def test_large_valid_journal_history_never_overflows_json():
    rows = [{"status": "closed", "pnl_percent": 100000, "result_r": 2} for _ in range(500)]
    stats = portfolio._stats_for_rows(rows)
    json.dumps(stats, allow_nan=False)
    assert stats["equity_index"] is None
    assert stats["r_net"] == 1000


@pytest.mark.parametrize("count", ["nan", "inf", "-1", "2.5", "not-a-number"])
def test_invalid_junit_totals_are_not_accepted(tmp_path, monkeypatch, count):
    monkeypatch.syspath_prepend(str(Path("scripts").resolve()))
    from scripts.quality_gate import _junit_totals
    path = tmp_path / "report.xml"
    path.write_text(f'<testsuite tests="{count}" failures="0" errors="0" skipped="0"/>')
    assert _junit_totals(path) is None


def test_junit_parser_rejects_entities_instead_of_counting_expanded_values(tmp_path, monkeypatch):
    monkeypatch.syspath_prepend(str(Path("scripts").resolve()))
    from scripts.quality_gate import _junit_totals
    path = tmp_path / "report.xml"
    path.write_text('<!DOCTYPE testsuite [<!ENTITY total "4">]><testsuite tests="&total;" failures="0" errors="0" skipped="0"/>')
    assert _junit_totals(path) is None


def test_junit_totals_reject_more_failures_than_tests(tmp_path, monkeypatch):
    monkeypatch.syspath_prepend(str(Path("scripts").resolve()))
    from scripts.quality_gate import _junit_totals
    path = tmp_path / "report.xml"
    path.write_text('<testsuite tests="1" failures="2" errors="0" skipped="0"/>')
    assert _junit_totals(path) is None


def test_junit_totals_accept_complete_pytest_report(tmp_path, monkeypatch):
    monkeypatch.syspath_prepend(str(Path("scripts").resolve()))
    from scripts.quality_gate import _junit_totals
    path = tmp_path / "report.xml"
    path.write_text('<testsuites><testsuite tests="3" failures="1" errors="0" skipped="1"><testcase/><testcase/><testcase/></testsuite></testsuites>')
    assert _junit_totals(path) == (3, 1, 0, 1)


@pytest.mark.parametrize("changed", ["none", "checksum", "development_version"])
def test_hash_locked_dependencies_reject_drift(tmp_path, monkeypatch, changed):
    from scripts import verify_dependency_lock as verifier
    requirement = "demo==1 --hash=sha256:" + "a" * 64 + "\n"
    (tmp_path / "requirements.txt").write_text("demo==1\n")
    (tmp_path / "requirements.lock.txt").write_text(requirement)
    (tmp_path / "requirements-dev.txt").write_text("-r requirements.lock.txt\n")
    (tmp_path / "requirements-dev.lock.txt").write_text(requirement.replace("demo==1", "demo==2") if changed == "development_version" else requirement)
    status = {"complete_transitive_lock": True, "hashes_required": True}
    for file, key in [("requirements.lock.txt", "production_lock_sha256"), ("requirements-dev.lock.txt", "development_lock_sha256")]:
        status[key] = hashlib.sha256((tmp_path / file).read_bytes()).hexdigest()
    if changed == "checksum":
        (tmp_path / "requirements.lock.txt").write_text(requirement + "# unexpected edit\n")
    (tmp_path / "DEPENDENCY_LOCK_STATUS.json").write_text(json.dumps(status))
    monkeypatch.setattr(verifier, "ROOT", tmp_path)
    monkeypatch.setattr("sys.argv", ["verify_dependency_lock.py", "--require-hashes"])
    if changed == "none":
        assert verifier.main() == 0
    else:
        with pytest.raises(RuntimeError, match="checksum mismatch|changes a production"):
            verifier.main()


def test_direct_source_dockerfile_has_all_copy_inputs_and_no_bootstrap_dependency():
    from scripts.build_lean_railway_release import _lean_dockerfile, _lean_dockerignore
    source = _lean_dockerfile().decode()
    assert "COPY requirements.lock.txt /tmp/requirements.lock.txt" in source
    assert "COPY . /app" in source
    assert "--from=quality" not in source
    assert "COPY restore_runtime.py" not in source
    assert ".quality-stage-passed" not in source
    assert "python main.py --check" in source
    ignored = _lean_dockerignore().decode().splitlines()
    assert "**" not in ignored
    assert "main.py" not in ignored and "core" not in ignored
    assert ".env*" in ignored and "**/*.sqlite3" in ignored


def test_trading_coach_configuration_error_is_logged_and_does_not_enable_analysis(monkeypatch, caplog):
    from modules import feature_flags, trading_coach
    def broken(*args, **kwargs):
        raise ValueError("invalid feature configuration")
    monkeypatch.setattr(feature_flags, "feature_enabled", broken)
    result = trading_coach.trading_coach_snapshot({}, "42")
    assert result["status"] == "unavailable"
    assert result["sample_size"] == 0
    assert "could not be read" in caplog.text


@pytest.mark.asyncio
async def test_redis_client_returns_the_current_loop_client_despite_another_loop_alias(monkeypatch):
    import redis.asyncio
    from core import connection_limits as limits
    mine, other = object(), object()
    class InterleavedRegistry(dict):
        def __setitem__(self, key, value):
            super().__setitem__(key, value)
            # Model another event-loop thread publishing its compatibility alias
            # between our registry write and our return statement.
            limits._REDIS_CLIENT = other
    monkeypatch.setattr(limits, "SETTINGS", SimpleNamespace(redis_url="redis://fixture.invalid"))
    monkeypatch.setattr(limits, "_REDIS_CLIENT", None)
    monkeypatch.setattr(limits, "_REDIS_CLIENTS", InterleavedRegistry())
    monkeypatch.setattr(limits, "_REDIS_CLIENT_LOCKS", {})
    monkeypatch.setattr(redis.asyncio.Redis, "from_url", lambda *a, **kw: mine)
    assert await limits._redis() is mine
    assert await limits._redis() is mine
