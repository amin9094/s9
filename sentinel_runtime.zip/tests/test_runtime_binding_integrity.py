from __future__ import annotations

import builtins
import dis
import inspect
import types
from importlib import import_module


def _nested_code_objects(code: types.CodeType):
    yield code
    for value in code.co_consts:
        if isinstance(value, types.CodeType):
            yield from _nested_code_objects(value)


def test_application_builds_with_all_registered_handlers() -> None:
    import bot

    application = bot.build_application()
    handlers = getattr(application, "handlers", {})
    assert isinstance(handlers, dict)
    assert sum(len(group) for group in handlers.values()) >= 500


def test_runtime_functions_have_no_unbound_global_names() -> None:
    # bot import performs the same shared/export namespace injection used by
    # Railway. Inspect every owner function, including nested lambdas and
    # comprehensions, for LOAD_GLOBAL/LOAD_NAME references that remain absent.
    import bot  # noqa: F401
    from bot_runtime import FEATURE_MODULES

    missing: set[tuple[str, str, str, str]] = set()
    for feature in FEATURE_MODULES:
        module = import_module(f"bot_runtime.{feature}")
        for function_name, function in vars(module).items():
            if not inspect.isfunction(function) or function.__module__ != module.__name__:
                continue
            for code in _nested_code_objects(function.__code__):
                for instruction in dis.get_instructions(code):
                    if instruction.opname not in {"LOAD_GLOBAL", "LOAD_NAME"}:
                        continue
                    name = str(instruction.argval)
                    if name not in function.__globals__ and not hasattr(builtins, name):
                        missing.add((module.__name__, function_name, code.co_name, name))

    assert not missing, "Unbound runtime globals: " + "; ".join(
        f"{module}.{function}/{code}:{name}" for module, function, code, name in sorted(missing)
    )
