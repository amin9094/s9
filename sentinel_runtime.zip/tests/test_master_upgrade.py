from __future__ import annotations
import asyncio
import copy
import json
from types import SimpleNamespace
from unittest.mock import AsyncMock
import pytest
from core.db import DEFAULT_DB
from core.domain import add_points, apply_referral, ensure_referral, record_referral_purchase
from modules import admin_creation as creation

OWNER=354678485


@pytest.fixture
def canonical_store(state, tmp_path, monkeypatch):
    import core.db as storage
    store = storage.SQLiteStore(tmp_path/'canonical.sqlite3', tmp_path/'backups')
    store.write(state)
    monkeypatch.setattr(storage, '_STORE', store)
    monkeypatch.setattr(storage, '_CACHE', None)
    monkeypatch.setattr(storage, '_CACHE_VERSION', None)
    monkeypatch.setattr(storage, '_mirror_primary_to_google', lambda *a, **k: None)
    return store

@pytest.fixture
def state():
    db=copy.deepcopy(DEFAULT_DB)
    db['users']={'1':{'id':1,'username':'one','first_name':'Alpha'},'2':{'id':2,'username':'two'}}
    db['vip_plans']=[{'id':1,'name':'ماهانه','price':150000,'duration_days':30,'active':True}]
    return db


def test_referral_owner_is_immutable_and_codes_secure(state):
    code=ensure_referral(state,1)['code'];assert len(code)==20
    assert not apply_referral(state,1,code)[0]
    assert apply_referral(state,2,code)[0]
    assert not apply_referral(state,2,ensure_referral(state,3)['code'])[0]
    assert state['users']['2']['referred_by']=='1'


def test_referral_requires_authoritative_payment(state,monkeypatch):
    from repositories.v2.commerce import CommerceRepository
    monkeypatch.setattr(CommerceRepository,'get',lambda *a,**k:None)
    state['users']['2']['referred_by']='1'
    with pytest.raises(ValueError):record_referral_purchase(state,2,'invented',amount=999999)
    state['vip_orders']=[{'order_id':'p','user_id':'2','price':150000,'status':'pending'}]
    with pytest.raises(ValueError):record_referral_purchase(state,2,'p',amount=999999)
    state['vip_orders'][0]['status']='approved'
    record_referral_purchase(state,2,'p',amount=999999)
    record_referral_purchase(state,2,'p',amount=999999)
    assert state['user_referrals']['1']['purchase_amounts']=={'p':150000}
    assert len(state['economic_events'])==1


def test_forged_invited_counter_cannot_unlock_milestone(state):
    from modules.referral_milestones import save_milestone,milestone_progress
    state['user_referrals']['1']={'code':'OLD','invited':['2','3','4','5','6']}
    save_milestone(state,OWNER,{'title':'test','trigger_type':'referrals_joined','required_count':1,'reward_type':'points','reward_value':10})
    assert milestone_progress(state,1)[0]['progress']==0
    state['users']['2']['referred_by']='1'
    assert milestone_progress(state,1)[0]['progress']==1


def test_economy_sql_constraint_rolls_back_mutation(state,tmp_path,monkeypatch):
    import core.db as storage
    store=storage.SQLiteStore(tmp_path/'db.sqlite3',tmp_path/'backups');store.write(state)
    monkeypatch.setattr(storage,'_STORE',store);monkeypatch.setattr(storage,'_CACHE',None);monkeypatch.setattr(storage,'_CACHE_VERSION',None)
    monkeypatch.setattr(storage,'_mirror_primary_to_google',lambda *a,**k:None)
    storage.with_db(lambda db:add_points(db,1,10,'test',source_event='unit:event'))
    assert storage.with_db(lambda db:add_points(db,1,10,'test',source_event='unit:event'))==10
    # Bypass the service's duplicate check: the SQL UNIQUE constraint still wins.
    def attack(db):
        add_points(db,1,50,'attack')
        db['point_history'][-1]['source_event']='unit:event'
    with pytest.raises(Exception):storage.with_db(attack)
    assert store._read()['user_points']['1']==10


def test_signal_delete_compacts_display_without_changing_internal_ids(state):
    from modules.management_suite import delete_signal_permanently
    from modules.signal_portal import reserve_signal_identity
    state['signals']=[{'id':100+i,'display_number':i,'cycle_id':1,'symbol':'XAUUSD','market_category':'forex','created_at':f'2026-01-0{i}'} for i in (1,2,3)]
    state['next_ids']['signal']=104
    delete_signal_permanently(state,102,OWNER)
    assert [(r['id'],r['display_number']) for r in state['signals']]==[(101,1),(103,2)]
    next_signal=reserve_signal_identity(state,'forex')
    assert next_signal['id']==104 and next_signal['display_number']==3


def test_normalized_signal_cannot_be_resurrected(sqlite_engine):
    from repositories.v2.signals import SignalRepository
    repo=SignalRepository(sqlite_engine)
    for i in (1,2,3):repo.upsert({'id':i,'display_number':i,'symbol':'XAUUSD','cycle_id':1,'market_category':'forex','created_at':f'2026-01-0{i}'})
    assert repo.delete(2,actor_id=str(OWNER))
    assert repo.get(3)['display_number']==2
    assert repo.get(2) is None
    with pytest.raises(ValueError):repo.upsert({'id':2,'symbol':'XAUUSD'})


def test_wizard_draft_preview_permission_and_idempotent_publish(state):
    row=creation.create_draft(state,OWNER,'discount',mode='quick')
    with pytest.raises(ValueError):creation.publish(state,OWNER,row['id'],1)
    creation.review(state,OWNER,row['id'])
    code=creation.publish(state,OWNER,row['id'],1)['code']
    assert creation.publish(state,OWNER,row['id'],1)['code']==code
    assert len(state['discount_codes'])==1
    with pytest.raises(PermissionError):creation.get_draft(state,2,row['id'])
    assert state['discount_codes'][code]['max_uses_per_user']==1
    assert not state['discount_codes'][code]['stackable']


def test_points_wizard_bulk_and_negative_balance_are_safe(state):
    row=creation.create_draft(state,OWNER,'points',mode='quick')
    creation.answer(state,OWNER,row['id'],'users','@one,2')
    creation.answer(state,OWNER,row['id'],'value','10')
    creation.review(state,OWNER,row['id']);revision=state['admin_creation_drafts'][row['id']]['revision']
    creation.publish(state,OWNER,row['id'],revision)
    assert state['user_points']['1']==state['user_points']['2']==10
    creation.publish(state,OWNER,row['id'],revision)
    assert state['user_points']['1']==10


def test_fixed_discount_and_server_eligibility(state):
    from modules.discount_campaigns import calculate_discount_amount
    row=creation.create_draft(state,OWNER,'discount',mode='quick')
    creation.answer(state,OWNER,row['id'],'discount_type','fixed')
    creation.answer(state,OWNER,row['id'],'value','20000')
    creation.review(state,OWNER,row['id']);revision=state['admin_creation_drafts'][row['id']]['revision']
    coupon=creation.publish(state,OWNER,row['id'],revision)
    assert calculate_discount_amount(coupon,150000)['final_amount']==130000
    assert calculate_discount_amount(coupon,10000)['final_amount']==0


def test_education_repeat_completion_cannot_multiply_progress(state):
    from modules.education import create_lesson,mark_lesson_complete
    from modules.missions import create_mission
    lesson=create_lesson(state,category='test',title='lesson',access_type='free',price=0,text='content')
    mission=create_mission(state,title='3 lessons',reward=100,event='complete_lesson',target=3)
    for _ in range(10):mark_lesson_complete(state,1,lesson['id'])
    assert state['user_missions']['1'][str(mission['id'])]['progress']==1
    assert state['user_points'].get('1',0)==0


def test_paid_lesson_completion_requires_access(state):
    from modules.education import create_lesson,mark_lesson_complete
    lesson=create_lesson(state,category='test',title='paid',access_type='paid',price=10000,text='content')
    with pytest.raises(ValueError):mark_lesson_complete(state,1,lesson['id'])


def test_privacy_pseudonymization_preserves_attribution_constraint(canonical_store):
    from core.db import with_db
    from modules.privacy import anonymize_user
    with_db(lambda db: apply_referral(db, 2, ensure_referral(db, 1)['code']))
    result = with_db(lambda db: anonymize_user(db, 1))
    assert canonical_store._read()['users']['2']['referred_by'] == result['pseudonym']
    with pytest.raises(ValueError, match='IMMUTABLE'):
        with_db(lambda db: db['users']['2'].update(referred_by='9'))


def test_fixed_discount_and_audience_survive_reload_and_batch(state):
    from core.db import migrate_db
    from modules.discount_campaigns import generate_one_time_codes, calculate_discount_amount, validate_campaign_conditions
    row = creation.create_draft(state, OWNER, 'discount', mode='quick')
    for field, value in [('discount_type','fixed'),('value','25000'),('eligible','selected'),('users','1')]:
        creation.answer(state, OWNER, row['id'], field, value)
    creation.review(state, OWNER, row['id'])
    code = creation.publish(state, OWNER, row['id'], state['admin_creation_drafts'][row['id']]['revision'])['code']
    migrate_db(state)
    parent = state['discount_codes'][code]
    assert calculate_discount_amount(parent, 100000)['final_amount'] == 75000
    child = generate_one_time_codes(state, code, count=1)[0]
    assert calculate_discount_amount(child, 100000)['final_amount'] == 75000
    assert not validate_campaign_conditions(state, child, 2)[0]
    assert validate_campaign_conditions(state, child, 1)[0]


def test_coupon_refund_duplicate_does_not_free_another_use(state):
    from core.domain import create_discount
    from modules.discount_campaigns import settle_discount_for_order
    row = create_discount(state, 10, code='REFUND10')
    row.update(scope='public', used_count=2, used_by=['1','2'], consumed_order_ids=['p1','p2'], restore_on_full_refund=True)
    order = {'order_id':'p1', 'user_id':'1', 'coupon':'REFUND10'}
    settle_discount_for_order(state, order, 'refunded')
    settle_discount_for_order(state, order, 'refunded')
    assert row['used_count'] == 1 and row['used_by'] == ['2']


def test_forged_legacy_referral_buyers_do_not_grant_vip(state):
    state['users']['2']['referred_by'] = '1'
    ref = ensure_referral(state, 1)
    ref['purchasers'] = [str(n) for n in range(100, 300)]
    state['vip_orders'] = [{'order_id':'real', 'status':'approved', 'user_id':'2','price':150000}]
    record_referral_purchase(state, 2, 'real')
    assert ref['purchase_count'] == 1
    assert '1' not in state['vip_users']


def test_refunded_purchase_cannot_unlock_milestones(state):
    from core.economy_integrity import verified_referral_activity, approved_purchase
    state['users']['2']['referred_by'] = '1'
    order = {'order_id':'p','status':'approved','price':150000,'user_id':'2'}
    state['vip_orders'] = [order]
    record_referral_purchase(state, 2, 'p')
    assert len(verified_referral_activity(state, 1)[1]) == 1
    order['refund_status'] = 'full'
    assert not verified_referral_activity(state, 1)[1]
    with pytest.raises(ValueError):approved_purchase(state, 'p')


def test_granular_education_permission_does_not_grant_other_media(state):
    from modules.admin_access import has_permission
    state['delegated_admins'] = {'9':{'user_id':9,'active':True,'permissions':['education.create','education.create_image','education.publish']}}
    assert has_permission(state, 9, 'education.create_image')
    assert not has_permission(state, 9, 'education.create_video')
    row = creation.create_draft(state, 9, 'education', mode='quick')
    stored = state['admin_creation_drafts'][row['id']]
    stored['attachments'] = [{'type':'video','file_id':'video-file'}]
    creation.review(state, 9, row['id'])
    with pytest.raises(PermissionError):creation.publish(state, 9, row['id'], stored['revision'])
    assert not state['lessons']


def test_economic_tables_in_normalized_backup(sqlite_engine):
    from core.google_sheets_backup import export_normalized_tables, NORMALIZED_TABLES
    required = {'economy_ledger','economy_referral_codes','economy_referral_attribution','signal_deletion_audit'}
    assert required <= set(NORMALIZED_TABLES)
    with sqlite_engine.transaction() as cursor:
        cursor.execute('INSERT INTO economy_ledger(source,user_id,payload) VALUES(?,?,?)', ('test','1','{}'))
    data = export_normalized_tables(sqlite_engine)
    assert data['economy_ledger'][0]['source'] == 'test'


@pytest.mark.asyncio
async def test_lesson_album_sent_once_and_captions_preserved():
    from bot_runtime.account_support import _deliver_lesson_attachments
    bot = SimpleNamespace(send_media_group=AsyncMock(), send_photo=AsyncMock(), send_message=AsyncMock())
    lesson = {'id':1,'attachments':[{'type':'photo','file_id':f'f{i}','media_group_id':'g','caption':f'caption{i}'} for i in range(3)]}
    await _deliver_lesson_attachments(SimpleNamespace(bot=bot), 1, lesson, 'fa')
    bot.send_media_group.assert_awaited_once()
    assert len(bot.send_media_group.call_args.kwargs['media']) == 3
    assert bot.send_media_group.call_args.kwargs['media'][1].caption == 'caption1'
    bot.send_photo.assert_not_awaited()


@pytest.mark.asyncio
async def test_cancelled_postgres_acquisition_closes_late_connection(monkeypatch):
    import threading
    import core.distributed_jobs as jobs
    started, resume, closed = threading.Event(), threading.Event(), threading.Event()
    def acquire(name):
        started.set()
        assert resume.wait(2)
        return 'acquired', SimpleNamespace(close=closed.set)
    monkeypatch.setattr(jobs, '_acquire_postgres_lease', acquire)
    task = asyncio.create_task(jobs._acquire_postgres_lease_async('late'))
    for _ in range(200):
        if started.is_set():break
        await asyncio.sleep(.001)
    assert started.is_set()
    task.cancel()
    with pytest.raises(asyncio.CancelledError):await task
    resume.set()
    for _ in range(200):
        if closed.is_set():break
        await asyncio.sleep(.001)
    assert closed.is_set()


@pytest.mark.asyncio
async def test_redis_failure_multi_replica_fails_closed_off_railway(monkeypatch):
    import core.connection_limits as limits
    client = SimpleNamespace(eval=AsyncMock(side_effect=ConnectionError), aclose=AsyncMock())
    monkeypatch.setattr(limits, '_redis', AsyncMock(return_value=client))
    monkeypatch.setattr(limits, 'replica_count', lambda: 2)
    monkeypatch.delenv('RAILWAY_PROJECT_ID', raising=False)
    monkeypatch.delenv('ALLOW_LOCAL_RATE_LIMIT', raising=False)
    assert await limits.acquire_connection_limits((('user','1',1),)) is None


def test_guides_removed_from_production_sources():
    from pathlib import Path
    for name in ['bot_runtime/account_support.py','handlers/callback_routes.py','modules/user_experience.py']:
        assert 'bot_guide' not in Path(name).read_text()


@pytest.mark.asyncio
async def test_cancelled_distributed_job_stops_child_before_unlock(monkeypatch):
    import core.distributed_jobs as jobs
    monkeypatch.setattr(jobs,'SETTINGS',SimpleNamespace(redis_url='',database_url=''))
    monkeypatch.setattr(jobs,'_replica_count',lambda:1)
    entered=asyncio.Event();stopped=asyncio.Event()
    async def work():
        entered.set()
        try:await asyncio.Event().wait()
        finally:stopped.set()
    wrapped=jobs.distributed_job('unit-cancellation',work)
    task=asyncio.create_task(wrapped());await entered.wait();task.cancel()
    with pytest.raises(asyncio.CancelledError):await task
    assert stopped.is_set() and 'unit-cancellation' not in jobs._LOCAL_RUNNING


@pytest.mark.asyncio
async def test_stale_connection_owner_cannot_release_new_lease(monkeypatch):
    import core.connection_limits as limits
    limits.reset_connection_limits_for_tests()
    monkeypatch.setattr(limits,'_redis',AsyncMock(return_value=None));monkeypatch.setattr(limits,'replica_count',lambda:1)
    now=[100.0];monkeypatch.setattr(limits.time,'monotonic',lambda:now[0])
    one=await limits.acquire_connection_limits((('user','1',1),),ttl_seconds=10)
    now[0]=111
    two=await limits.acquire_connection_limits((('user','1',1),),ttl_seconds=10)
    await one.release()
    assert await limits.acquire_connection_limits((('user','1',1),),ttl_seconds=10) is None
    await two.release()
    assert await limits.acquire_connection_limits((('user','1',1),),ttl_seconds=10)


def test_initdata_duplicate_fields_rejected():
    from core.webapp_auth import validate_init_data
    with pytest.raises(ValueError,match='DUPLICATE'):validate_init_data('user=a&user=b&hash=a','token')
