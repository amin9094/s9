"""Minimal test-only Telegram module used when python-telegram-bot is unavailable.

The production image installs python-telegram-bot.  Local unit tests for the
FastAPI Mini App do not need a live Telegram client, but several shared domain
modules import PTB exception/type names.  This helper avoids coupling those
pure HTTP/domain tests to the optional runtime dependency.
"""
from __future__ import annotations

import sys
import types


def install() -> None:
    try:
        __import__("telegram")
        return
    except ModuleNotFoundError:
        pass

    telegram = types.ModuleType("telegram")
    constants = types.ModuleType("telegram.constants")
    error = types.ModuleType("telegram.error")
    ext = types.ModuleType("telegram.ext")
    warning_mod = types.ModuleType("telegram.warnings")

    class TelegramError(Exception):
        pass

    class BadRequest(TelegramError):
        pass

    class Forbidden(TelegramError):
        pass

    class RetryAfter(TelegramError):
        retry_after = 1

    class PTBUserWarning(UserWarning):
        pass

    class ParseMode:
        HTML = "HTML"
        MARKDOWN = "Markdown"
        MARKDOWN_V2 = "MarkdownV2"

    class _ContextTypes:
        DEFAULT_TYPE = object

    class _BaseUpdateProcessor:
        def __init__(self, max_concurrent_updates: int = 1):
            self.max_concurrent_updates = max_concurrent_updates

    class _BasePersistence:
        def __init__(self, *args, **kwargs):
            pass

        def __class_getitem__(cls, _item):
            return cls

    class _PersistenceInput:
        def __init__(self, *args, **kwargs):
            self.__dict__.update(kwargs)

    class _Simple:
        def __init__(self, *args, **kwargs):
            self.args = args
            self.__dict__.update(kwargs)

        def __call__(self, *args, **kwargs):
            return _Simple(*args, **kwargs)

    class _Application(_Simple):
        def __init__(self, *args, **kwargs):
            super().__init__(*args, **kwargs)
            self.handlers = {}
            self.error_handlers = []
            self.bot_data = {}
            self.user_data = {}
            self.chat_data = {}

        @classmethod
        def builder(cls):
            return _ApplicationBuilder()

        def add_handler(self, handler, group=0):
            self.handlers.setdefault(group, []).append(handler)

        def add_error_handler(self, handler):
            self.error_handlers.append(handler)

    class _ApplicationBuilder:
        def __init__(self):
            self.values = {}

        def __getattr__(self, name):
            def setter(*args, **kwargs):
                self.values[name] = (args, kwargs)
                return self
            return setter

        def build(self):
            return _Application(**self.values)

    class _ConversationHandler(_Simple):
        END = -1

    class _ApplicationHandlerStop(Exception):
        pass

    class _Filters:
        def __getattr__(self, _name):
            return self

        def __and__(self, _other):
            return self

        def __or__(self, _other):
            return self

        def __invert__(self):
            return self

        def __call__(self, *args, **kwargs):
            return self

    class InlineKeyboardButton(_Simple):
        def __init__(
            self,
            text,
            url=None,
            callback_data=None,
            switch_inline_query=None,
            switch_inline_query_current_chat=None,
            callback_game=None,
            pay=None,
            login_url=None,
            web_app=None,
            switch_inline_query_chosen_chat=None,
            copy_text=None,
            style=None,
            icon_custom_emoji_id=None,
            api_kwargs=None,
            **kwargs,
        ):
            super().__init__(text)
            self.text = text
            self.url = url
            self.callback_data = callback_data
            self.switch_inline_query = switch_inline_query
            self.switch_inline_query_current_chat = switch_inline_query_current_chat
            self.callback_game = callback_game
            self.pay = pay
            self.login_url = login_url
            self.web_app = web_app
            self.switch_inline_query_chosen_chat = switch_inline_query_chosen_chat
            self.copy_text = copy_text
            self.style = style
            self.icon_custom_emoji_id = icon_custom_emoji_id
            self.api_kwargs = api_kwargs
            self.__dict__.update(kwargs)

    class ReplyKeyboardRemove(_Simple):
        def __init__(self, selective=False, api_kwargs=None, **kwargs):
            super().__init__()
            self.remove_keyboard = True
            self.selective = selective
            self.api_kwargs = api_kwargs
            self.__dict__.update(kwargs)

    class WebAppInfo(_Simple):
        def __init__(self, url, **kwargs):
            super().__init__(url)
            self.url = url
            self.__dict__.update(kwargs)

    telegram.InlineKeyboardButton = InlineKeyboardButton
    telegram.ReplyKeyboardRemove = ReplyKeyboardRemove
    telegram.WebAppInfo = WebAppInfo

    for name in (
        "Bot", "Update", "InlineKeyboardMarkup", "KeyboardButton",
        "ReplyKeyboardMarkup", "InputMediaPhoto", "InputFile",
        "MenuButtonWebApp", "MenuButtonDefault", "MenuButtonCommands",
    ):
        setattr(telegram, name, type(name, (_Simple,), {}))

    constants.ParseMode = ParseMode
    error.TelegramError = TelegramError
    error.BadRequest = BadRequest
    error.Forbidden = Forbidden
    error.RetryAfter = RetryAfter
    ext.ContextTypes = _ContextTypes
    ext.BaseUpdateProcessor = _BaseUpdateProcessor
    ext.BasePersistence = _BasePersistence
    ext.PersistenceInput = _PersistenceInput
    ext.Application = _Application
    ext.ApplicationHandlerStop = _ApplicationHandlerStop
    ext.ConversationHandler = _ConversationHandler
    for name in ("CallbackQueryHandler", "CommandHandler", "MessageHandler", "PreCheckoutQueryHandler", "TypeHandler"):
        setattr(ext, name, type(name, (_Simple,), {}))
    ext.ChatMemberHandler = type("ChatMemberHandler", (_Simple,), {"CHAT_MEMBER": 1, "MY_CHAT_MEMBER": 2})
    ext.filters = _Filters()

    telegram.constants = constants
    telegram.error = error
    warning_mod.PTBUserWarning = PTBUserWarning
    telegram.ext = ext
    telegram.warnings = warning_mod
    sys.modules["telegram"] = telegram
    sys.modules["telegram.constants"] = constants
    sys.modules["telegram.error"] = error
    sys.modules["telegram.ext"] = ext
    sys.modules["telegram.warnings"] = warning_mod
