"""Regression coverage for the twelve confirmed trading/consistency defects."""
from __future__ import annotations
import copy
from datetime import UTC,datetime
import time
import pytest
from core.storage.engine import DatabaseEngine
from core.webapp_auth import TelegramWebAppIdentity
from core.db import DEFAULT_DB
from repositories.v2.accounts import AccountRepository
from repositories.v2.positions import PositionRepository
from repositories.v2.signals import SignalRepository
from repositories.v2.journal import JournalRepository
from services.actions_v2.context import create_context
from services.actions_v2.trading import account_upsert,signal_choice_update,position_close,risk_profile_update

@pytest.fixture
def engine(tmp_path):
    e=DatabaseEngine(database_url='',sqlite_path=tmp_path/'audit.sqlite3');e.ensure_schema()
    yield e
    e.close()

def ctx(e,payload,action='account_upsert'):
    identity=TelegramWebAppIdentity(1,'','Audit','',int(time.time()),'')
    return create_context(identity,request_id='probe',action=action,payload=payload,engine=e)

def boundary(e,monkeypatch):
    import core.storage.engine as storage
    import services.miniapp_action_service_v2 as api
    monkeypatch.setattr(storage,'_ENGINE',e)
    monkeypatch.setattr(api,'read_db_sections',lambda *a,**k:copy.deepcopy(DEFAULT_DB))
    monkeypatch.setattr(api,'rate_limit_allow',lambda *a,**k:True)
    return api.handle_miniapp_action_for_identity_v2

def account(e,**extra):
    return AccountRepository(e).upsert(1,{'balance':10000,'equity':10000,'starting_balance':10000,'type':'personal',**extra})

def position(e,a):
    return PositionRepository(e).open({'user_id':1,'account_id':a['id'],'symbol':'EURUSD','side':'BUY','actual_entry':1.1,'actual_stop':1.09,'actual_volume':1,'risk_money':1000,'risk_percent':10})

def signal(e):
    return SignalRepository(e).upsert({'id':'audit-signal','symbol':'EURUSD','side':'BUY','status':'open','entry':1.1,'stop_loss':1.09,'created_at':datetime.now(UTC).isoformat()})

def execution(a,**extra):
    return {'account_id':a['id'],'confirmation':True,'actual_entry':1.1,'actual_stop':1.09,'volume':.1,'risk_percent':1,**extra}

def test_supplied_volume_cannot_bypass_server_risk(engine,monkeypatch):
    a=account(engine);s=signal(engine)
    with pytest.raises(ValueError,match="EXECUTION_VOLUME_EXCEEDS_RISK_BUDGET"):
        signal_choice_update(ctx(engine,{'signal_id':s['id'],'choice':'taken','execution':execution(a,volume=10)},'signal_choice_update'))
    assert PositionRepository(engine).active_for_signal(1,s['id'])==[]


def test_journal_insert_failure_rolls_back_position_then_retry_is_complete(engine,monkeypatch):
    a=account(engine);s=signal(engine);handle=boundary(engine,monkeypatch)
    body={'action':'signal_choice_update','request_id':'same-signal','payload':{'signal_id':s['id'],'choice':'taken','execution':execution(a)}}
    original=JournalRepository.add
    def broken(*a,**k):raise RuntimeError('journal insert failed')
    monkeypatch.setattr(JournalRepository,'add',broken)
    with pytest.raises(RuntimeError):handle(ctx(engine,{}).identity,body)
    assert PositionRepository(engine).active_for_signal(1,s['id'])==[]
    monkeypatch.setattr(JournalRepository,'add',original)
    retry=handle(ctx(engine,{}).identity,body)
    assert retry['data']['journal']['position_id']==retry['data']['position']['id']
    again=handle(ctx(engine,{}).identity,body)
    assert again['data']['position']['id']==retry['data']['position']['id']
    assert len(PositionRepository(engine).active_for_signal(1,s['id']))==1


def test_partial_close_journal_failure_rolls_back_and_retry_applies_once(engine,monkeypatch):
    a=account(engine);p=position(engine,a)
    JournalRepository(engine).add(1,{'position_id':p['id'],'account_id':a['id'],'symbol':'EURUSD','side':'BUY','status':'open'})
    handle=boundary(engine,monkeypatch)
    original=JournalRepository.update
    def broken(*a,**k):raise RuntimeError('journal update failed')
    monkeypatch.setattr(JournalRepository,'update',broken)
    body={'action':'position_close','request_id':'same-close','payload':{'position_id':p['id'],'close_volume':.2,'exit_price':1.11,'pnl_amount':20}}
    with pytest.raises(RuntimeError):handle(ctx(engine,{}).identity,body)
    updated=PositionRepository(engine).get(1,p['id'])
    assert updated['remaining_volume']==1 and updated['realized_pnl']==0
    assert PositionRepository(engine).events_for_position(p['id'])==[]
    monkeypatch.setattr(JournalRepository,'update',original)
    handle(ctx(engine,{}).identity,body);handle(ctx(engine,{}).identity,body)
    updated=PositionRepository(engine).get(1,p['id'])
    assert updated['remaining_volume']==pytest.approx(.8) and updated['realized_pnl']==20
    assert len(PositionRepository(engine).events_for_position(p['id']))==1


def test_zero_equity_survives_account_save_and_hard_blocks(engine):
    result=account_upsert(ctx(engine,{'balance':10000,'equity':0}))
    assert result['equity']==0
    decision=ctx(engine,{}).prop_rules.evaluate(user_id=1,account_id=result['id'],record=False)
    assert any(row['code']=='ACCOUNT_EQUITY_INVALID' for row in decision.hard_blocks)
    assert decision.metrics['total_drawdown_percent']==100


def test_daily_zero_equity_event_does_not_fall_back(engine):
    a=account(engine)
    AccountRepository(engine).record_equity(1,a['id'],balance=10000,equity=0)
    result=ctx(engine,{}).prop_rules.evaluate(user_id=1,account_id=a['id'],record=False)
    assert result.metrics['lowest_equity']==0 and result.metrics['opening_equity']==0


def test_manual_risk_profile_demotes_provider_and_records_event(engine):
    a=account(engine,data_source='mt5_connector',data_confidence=.99)
    risk_profile_update(ctx(engine,{'account_id':a['id'],'balance':999999,'equity':999999},'risk_profile_update'))
    updated=AccountRepository(engine).get(1,a['id'])
    assert updated['equity']==999999 and updated['data_source']=='manual' and updated['data_confidence']==.5
    with engine.transaction(read_only=True) as cur:
        assert cur.execute('SELECT COUNT(*) AS n FROM v8_equity_events').fetchone()['n']==1


@pytest.mark.parametrize('percent,amount,expected',[(5,None,500),(-5,None,-500),(5,0,0),(5,25,25)])
def test_percent_pnl_and_explicit_amount_precedence(engine,percent,amount,expected):
    a=account(engine);p=position(engine,a)
    result=position_close(ctx(engine,{'position_id':p['id'],'exit_price':1.12,'pnl_percent':percent,'pnl_amount':amount},'position_close'))
    assert result['status']=='closed' and result['realized_pnl']==expected


def test_remaining_risk_aggregates_and_position_fields_agree(engine,monkeypatch):
    from services import miniapp_read_service_v2 as read
    import core.storage.engine as storage
    a=account(engine);p=position(engine,a)
    PositionRepository(engine).close(1,p['id'],close_volume=.9,realized_pnl=0,exit_price=1.1)
    monkeypatch.setattr(storage,'_ENGINE',engine)
    result=read._account_risk(1,a['id'])
    assert result['exposure']['risk_money']==pytest.approx(100)
    assert result['portfolio_exposure']['risk_money']==pytest.approx(100)
    assert result['what_if']['all_stops_pnl']==pytest.approx(-100)
    dto=result['positions'][0]
    assert dto['remaining_risk_percent']==pytest.approx(1)
    assert dto['remaining_risk_money']==pytest.approx(100)
    assert dto['actual_risk_percent']==10


def test_empty_telegram_watchlist_overrides_stale_projection(engine,monkeypatch):
    from modules.portfolio import toggle_watchlist_symbol,remove_watchlist_symbol,watchlist_for_user
    from services import live_market_service as live
    from repositories.v2.preferences import PreferenceRepository
    import core.storage.engine as storage
    db={};toggle_watchlist_symbol(db,1,'EURUSD')
    PreferenceRepository(engine).set(1,'user_watchlists',[dict(x) for x in watchlist_for_user(db,1)])
    remove_watchlist_symbol(db,1,'EURUSD')
    monkeypatch.setattr(storage,'_ENGINE',engine)
    monkeypatch.setattr(live,'read_db_sections',lambda *a,**k:copy.deepcopy(db))
    assert watchlist_for_user(db,1)==[] and live._watchlist(1)==[]


def test_personal_open_risk_cannot_exceed_stricter_template_or_account(engine):
    a=account(engine,max_open_risk_percent=1)
    result=ctx(engine,{}).prop_rules.evaluate(user_id=1,account_id=a['id'],candidate={'signal_status':'open','symbol':'EURUSD','actual_entry':1.1,'actual_stop':1.09,'risk_percent':2},record=False)
    assert not result.allowed
    assert any(x['code']=='MAX_OPEN_RISK_EXCEEDED' and x['limit']==1 for x in result.hard_blocks)
    AccountRepository(engine).upsert(1,{'max_open_risk_percent':100},account_id=a['id'])
    result=ctx(engine,{}).prop_rules.evaluate(user_id=1,account_id=a['id'],candidate={'signal_status':'open','actual_entry':1.1,'actual_stop':1.09,'risk_percent':6},record=False)
    assert not result.allowed and result.metrics['effective_max_open_risk_percent']==5


def test_private_broker_requires_operator_binding_and_rejects_other_reference(engine,monkeypatch):
    from services.actions_v2.trading import broker_snapshot_sync
    from modules.broker_readonly import BrokerSnapshot,HttpBrokerSnapshotAdapter
    import json
    requested=[];a=account(engine,broker_account_reference='client-only')
    monkeypatch.delenv('BROKER_READONLY_ACCOUNT_BINDINGS',raising=False)
    with pytest.raises(ValueError,match='BROKER_ACCOUNT_NOT_AUTHORIZED'):
        broker_snapshot_sync(ctx(engine,{'account_id':a['id']},'broker_snapshot_sync'))
    monkeypatch.setenv('BROKER_READONLY_ACCOUNT_BINDINGS',json.dumps({'1':{a['id']:'owned-account'}}))
    def fetch(self,reference,*,user_id=None):
        requested.append((reference,user_id))
        return BrokerSnapshot('Bridge',reference,10000,9900,-100,(),datetime.now(UTC).isoformat(),.99)
    monkeypatch.setattr(HttpBrokerSnapshotAdapter,'__init__',lambda self:None)
    monkeypatch.setattr(HttpBrokerSnapshotAdapter,'fetch_snapshot',fetch)
    with pytest.raises(ValueError,match='BROKER_ACCOUNT_REFERENCE_FORBIDDEN'):
        broker_snapshot_sync(ctx(engine,{'account_id':a['id'],'account_reference':'other-account'},'broker_snapshot_sync'))
    assert requested==[]
    broker_snapshot_sync(ctx(engine,{'account_id':a['id']},'broker_snapshot_sync'))
    assert requested==[('owned-account','1')]
    assert AccountRepository(engine).get(1,a['id'])['equity']==9900


def test_manual_account_payload_cannot_bind_private_broker(engine):
    result=account_upsert(ctx(engine,{'balance':10000,'equity':10000,'broker_account_reference':'victim','data_source':'broker','data_confidence':1}))
    assert not result.get('broker_account_reference')
    assert result['data_source']=='manual' and result['data_confidence']==.5


def test_worst_case_evaluates_projected_equity_not_unrelated_blocks(engine,monkeypatch):
    from services import miniapp_read_service_v2 as read
    import core.storage.engine as storage
    a=account(engine,balance=9200,equity=9200,starting_balance=10000,rule_template_id='prop-static-5-10')
    PositionRepository(engine).open({'user_id':1,'account_id':a['id'],'symbol':'EURUSD','side':'BUY','actual_entry':1.1,'actual_stop':1.09,'actual_volume':.4,'risk_money':400,'risk_percent':4})
    monkeypatch.setattr(storage,'_ENGINE',engine)
    result=read._account_risk(1,a['id'])
    assert result['what_if']['worst_case_equity']==8800
    assert result['what_if']['would_breach_total_loss'] is True
    assert result['what_if']['worst_case_drawdown_percent']==12

@pytest.mark.parametrize('action', ['journal_partial_close', 'journal_result_update'])
def test_journal_close_routes_roll_back_position_on_journal_failure(engine,monkeypatch,action):
    a=account(engine);p=position(engine,a)
    entry=JournalRepository(engine).add(1,{'position_id':p['id'],'account_id':a['id'],'symbol':'EURUSD','side':'BUY','entry_price':1.1,'actual_stop':1.09,'volume':1,'remaining_volume':1,'status':'open'})
    handle=boundary(engine,monkeypatch)
    original=JournalRepository.update
    monkeypatch.setattr(JournalRepository,'update',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('journal unavailable')))
    body={'action':action,'request_id':'journal-close','payload':{'id':entry['id'],'volume':.2,'pnl_amount':20,'exit_price':1.11}}
    with pytest.raises(RuntimeError):handle(ctx(engine,{}).identity,body)
    assert PositionRepository(engine).get(1,p['id'])['remaining_volume']==1
    assert PositionRepository(engine).events_for_position(p['id'])==[]
    monkeypatch.setattr(JournalRepository,'update',original)
    handle(ctx(engine,{}).identity,body);handle(ctx(engine,{}).identity,body)
    assert len(PositionRepository(engine).events_for_position(p['id']))==1


def test_idempotency_completion_failure_rolls_back_trading_mutation(engine,monkeypatch):
    from repositories.v2.idempotency import IdempotencyRepository
    a=account(engine);p=position(engine,a);handle=boundary(engine,monkeypatch)
    body={'action':'position_close','request_id':'receipt-failure','payload':{'position_id':p['id'],'close_volume':.2,'pnl_amount':20,'exit_price':1.11}}
    original=IdempotencyRepository.complete
    monkeypatch.setattr(IdempotencyRepository,'complete',lambda *a,**k: (_ for _ in ()).throw(RuntimeError('receipt unavailable')))
    with pytest.raises(RuntimeError):handle(ctx(engine,{}).identity,body)
    assert PositionRepository(engine).get(1,p['id'])['remaining_volume']==1
    monkeypatch.setattr(IdempotencyRepository,'complete',original)
    handle(ctx(engine,{}).identity,body)
    assert PositionRepository(engine).get(1,p['id'])['remaining_volume']==pytest.approx(.8)


def test_old_position_without_journal_is_repaired_without_new_trade(engine):
    from repositories.v2.preferences import PreferenceRepository
    a=account(engine);s=signal(engine);p=position(engine,a)
    with engine.transaction() as cur:
        cur.execute('UPDATE v8_positions SET signal_id=? WHERE id=?',(s['id'],p['id']))
    PreferenceRepository(engine).set(1,'user_signal_choices',{s['id']:{'choice':'taken','position_id':p['id']}})
    result=signal_choice_update(ctx(engine,{'signal_id':s['id'],'choice':'taken'},'signal_choice_update'))
    assert result['journal']['position_id']==p['id']
    assert result['position']['actual_volume']==1
    assert len(PositionRepository(engine).active_for_signal(1,s['id']))==1


@pytest.mark.parametrize('fraction',[0,-1,1.1,float('nan'),float('inf')])
def test_invalid_close_fraction_never_closes_any_volume(engine,fraction):
    a=account(engine);p=position(engine,a)
    with pytest.raises(ValueError,match='INVALID_CLOSE_FRACTION'):
        position_close(ctx(engine,{'position_id':p['id'],'close_fraction':fraction,'exit_price':1.11},'position_close'))
    assert PositionRepository(engine).get(1,p['id'])['remaining_volume']==1


def test_concurrent_duplicate_close_creates_one_event(engine,monkeypatch):
    from concurrent.futures import ThreadPoolExecutor
    a=account(engine);p=position(engine,a);handle=boundary(engine,monkeypatch)
    body={'action':'position_close','request_id':'parallel-close','payload':{'position_id':p['id'],'close_volume':.2,'pnl_amount':20,'exit_price':1.11}}
    def run(_):
        try:return handle(ctx(engine,{}).identity,body)
        except ValueError as exc:
            assert str(exc)=='REQUEST_IN_PROGRESS'
            return None
    with ThreadPoolExecutor(max_workers=4) as pool:
        results=list(pool.map(run,range(4)))
    assert any(r for r in results)
    assert PositionRepository(engine).get(1,p['id'])['remaining_volume']==pytest.approx(.8)
    assert len(PositionRepository(engine).events_for_position(p['id']))==1


def test_actual_position_card_displays_remaining_and_explicit_zero(tmp_path):
    import subprocess
    from pathlib import Path
    src=(Path(__file__).resolve().parents[1]/'webapp/src/risk-journal.js').read_text()
    function=src[src.index('function positionCard('):src.index('function accountRuleTemplates(')]
    script="const esc=x=>String(x),t=x=>x,num=x=>String(x),pct=x=>'PCT='+x,money=x=>'MONEY='+x;"+function+"\nconst card=positionCard({symbol:'EURUSD',side:'BUY',remaining_risk_percent:0,actual_risk_percent:10,remaining_risk_money:0,risk_money:1000});if(!card.includes('PCT=0')||!card.includes('MONEY=0'))throw Error(card);"
    path=tmp_path/'position.js';path.write_text(script)
    subprocess.run(['node',str(path)],check=True,capture_output=True,timeout=10)


def test_operator_broker_mapping_cannot_reuse_reference_for_two_owners(monkeypatch):
    import json
    from modules.broker_readonly import authorized_account_reference
    monkeypatch.setenv('BROKER_READONLY_ACCOUNT_BINDINGS',json.dumps({'1':{'a':'same'},'2':{'b':'same'}}))
    with pytest.raises(ValueError,match='BROKER_BINDING_NOT_UNIQUE'):
        authorized_account_reference(1,'a')


def test_daily_risk_limit_counts_already_closed_positions(engine):
    a=account(engine,max_daily_risk_percent=1)
    p=PositionRepository(engine).open({'user_id':1,'account_id':a['id'],'symbol':'EURUSD','side':'BUY','actual_entry':1.1,'actual_stop':1.09,'actual_volume':.1,'risk_money':100,'risk_percent':1})
    PositionRepository(engine).close(1,p['id'],close_volume=.1,realized_pnl=0,exit_price=1.1)
    result=ctx(engine,{}).prop_rules.evaluate(user_id=1,account_id=a['id'],candidate={'signal_status':'open','actual_entry':1.1,'actual_stop':1.09,'risk_percent':.1},record=False)
    assert result.metrics['daily_risk_percent']==1
    assert any(x['code']=='MAX_DAILY_RISK_EXCEEDED' for x in result.hard_blocks)


def test_worst_case_includes_positions_beyond_the_display_page(engine,monkeypatch):
    from services import miniapp_read_service_v2 as read
    import core.storage.engine as storage
    a=account(engine)
    for _ in range(101):
        PositionRepository(engine).open({'user_id':1,'account_id':a['id'],'symbol':'EURUSD','side':'BUY','actual_entry':1.1,'actual_stop':1.09,'actual_volume':.1,'risk_money':10,'risk_percent':.1})
    monkeypatch.setattr(storage,'_ENGINE',engine)
    result=read._account_risk(1,a['id'])
    assert len(result['positions'])==100 and result['exposure']['open_count']==101
    assert result['what_if']['all_stops_pnl']==-1010
