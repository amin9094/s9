"""Synthetic adapters and budget race tests; not evidence of market returns."""
import asyncio
from concurrent.futures import ThreadPoolExecutor
from dataclasses import replace
from decimal import Decimal as D
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest

from modules.strategies.common import Parameters,Swing
from modules.strategies.observations import ObservationContext,evaluate_observations,observation,safe_swings
from repositories.v2.provider_budget import ProviderBudgetExceeded,reserve_twelve
from services import canonical_market_service as market
from tests.test_v9_strategy_engines import bars


def price_bars(provider='yahoo_fx',symbol='EURUSD'):
    data = [replace(b,symbol=symbol,provider=provider,venue=provider+'_indicative',
                    volume=None,volume_kind='unavailable',source_id=f'{provider}-{i}') for i,b in enumerate(bars())]
    data[-1] = replace(data[-1],is_closed=False,available_ms=data[-1].start_ms+1000)
    return data


@pytest.mark.parametrize('provider',['yahoo_fx','twelve_data'])
def test_candle_only_context_needs_no_spread_grid_or_native_volume(provider):
    data=price_bars(provider)
    result=evaluate_observations(ObservationContext(tuple(data),data[-1].available_ms))
    assert result['analysis_mode']=='CANDLE_ONLY' and result['execution_eligible'] is False
    assert result['engine_roles']['fibonacci']=='SHARED_OPTIONAL_CONFIRMATION'
    assert not any(row.get('plan') for row in result['results'])


@pytest.mark.parametrize('mutation,code',[
    ('short','WARMUP'),('stale','STALE'),('mixed','MIXED'),('future','FUTURE'),('delayed','DELAYED')])
def test_observations_reject_unusable_evidence(mutation,code):
    data=price_bars();cutoff=data[-1].available_ms
    if mutation=='short':data=data[-50:]
    if mutation=='stale':cutoff+=1200000
    if mutation=='mixed':data[4]=replace(data[4],provider='different')
    if mutation=='future':data[4]=replace(data[4],available_ms=cutoff+1)
    if mutation=='delayed':data[4]=replace(data[4],quality_flags=('DELAYED_FX_FEED',))
    with pytest.raises(ValueError,match=code):
        evaluate_observations(ObservationContext(tuple(data),cutoff))


def test_gaps_are_not_filled_or_used_as_pivot_neighbors():
    data=price_bars();gap=data[58].start_ms
    data=data[:58]+data[59:]
    context=ObservationContext(tuple(data),data[-1].available_ms)
    result=evaluate_observations(context)
    assert result['history_has_gaps'] and all(b.start_ms!=gap for b in context.candles)
    assert all(not (55<=s.index<=60) for s in safe_swings(data,Parameters()))


def make_observation(provider='yahoo_fx'):
    data=price_bars(provider)
    context=ObservationContext(tuple(data),data[-1].available_ms)
    return context,observation(context,'order_block','poc_pending','BUY',(D(90),D(91)),
                               ['causal-id'],after_ms=data[100].end_ms,missing=['NATIVE_VOLUME_PROFILE'])


def test_observation_has_no_entry_target_stop_poc_or_verified_first_visit():
    context,row=make_observation()
    assert row['state']=='ANALYTICAL_OBSERVATION' and row['is_signal'] is False
    assert not {'plan','entry','stop','tp1','poc'} & row.keys()
    assert row['observation']['native_first_visit_proven'] is False
    assert 'NATIVE_VOLUME_PROFILE' in row['observation']['missing_requirements']
    changed=list(context.candles);changed[110]=replace(changed[110],low=D(90))
    assert observation(replace(context,candles=tuple(changed)),'order_block','poc_pending','BUY',
                       (D(90),D(91)),['causal-id'],after_ms=changed[100].end_ms) is None


def test_observation_deduplication_is_provider_and_profile_bound(sqlite_engine,monkeypatch):
    from repositories.v2 import setup_proposals,strategy_reviews
    from services.strategy_review_queue_service import _save_analysis
    monkeypatch.setattr(setup_proposals,'normalized_engine',lambda:sqlite_engine)
    monkeypatch.setattr(strategy_reviews,'normalized_engine',lambda:sqlite_engine)
    context,a=make_observation();_,b=make_observation('twelve_data')
    result=_save_analysis({'results':[a,b]})
    assert len(result['new_review_ids'])==2 and result['stored_setups']==[] and not result['publicly_approved']
    assert _save_analysis({'results':[a,b]})['new_review_ids']==[]
    records=strategy_reviews.StrategyReviewRepository(sqlite_engine).list()
    assert {r['state'] for r in records}=={'ANALYTICAL_OBSERVATION'}
    changed=replace(context,parameters=replace(Parameters(),profile_id='different'))
    c=observation(changed,'order_block','poc_pending','BUY',(D(90),D(91)),['causal-id'],after_ms=context.closed[100].end_ms)
    assert c['thesis_key']!=a['thesis_key']
    with pytest.raises(ValueError,match='CANNOT_BECOME'):
        _save_analysis({'results':[{**a,'plan':{'invalid':'forbidden'}}]})


def test_ob_price_pattern_keeps_full_candle_and_poc_pending():
    from modules.strategies.order_block.observer import observe
    data=price_bars()
    data[107]=replace(data[107],open=D(101),close=D('100.9'),high=D(102),low=D(100))
    data[108]=replace(data[108],open=D(101),close=D(105),high=D(106),low=D('100.8'))
    for i in range(109,len(data)):
        data[i]=replace(data[i],open=D(106),close=D('106.1'),high=D(107),low=D(105))
    rows=observe(ObservationContext(tuple(data),data[-1].available_ms))
    row=next(r for r in rows if r['ob_source_id']==data[107].source_id)
    assert row['original_zone']==['100','102']
    assert 'poc' not in row and 'CAUSAL_WAVE_NATIVE_VOLUME_PROFILE' in row['observation']['missing_requirements']


def test_sweep_requires_closed_reversal_and_first_untouched_gap(monkeypatch):
    from modules.strategies.sweep_fvg import observer
    data=price_bars()
    prices={20:('94.5',97,94,96),21:(97,101,97,101),22:(100,109,100,108),
            23:(105,117,105,117),24:('118.5',120,118,119)}
    for i,values in prices.items():
        data[i]=replace(data[i],**dict(zip(('open','high','low','close'),map(D,values))))
    for i in range(25,len(data)):
        data[i]=replace(data[i],open=D(125),high=D(126),low=D(124),close=D(125))
    swings=[Swing(4,'high',D(120),1),Swing(7,'low',D(98),1),Swing(10,'high',D(118),1),Swing(13,'low',D(95),1)]
    monkeypatch.setattr(observer,'safe_swings',lambda *_:swings)
    monkeypatch.setattr(observer,'indicators',lambda *_:{'atr':D(1)})
    rows=observer.observe(ObservationContext(tuple(data),data[-1].available_ms))
    assert rows[0]['original_zone']==['97','100'] and not rows[0].get('plan')
    fact=next(f for f in rows[0]['observation']['facts'] if f['kind']=='closed_choch')
    assert fact['prior_structure']=='DOWN' and fact['index']==24
    # A continuation cannot be silently relabeled CHoCH.
    monkeypatch.setattr(observer,'structure_direction',lambda *_:'UP')
    assert not any(r['direction']=='BUY' for r in observer.observe(ObservationContext(tuple(data),data[-1].available_ms)))


def test_fibonacci_golden_confluence_comes_from_another_smaller_wave(monkeypatch):
    from modules.strategies.fibonacci import observer
    context,row=make_observation()
    swings=[Swing(10,'low',D(10),1),Swing(20,'high',D(20),1),
            Swing(30,'low',D(10),1),Swing(40,'high',D(14),1)]
    monkeypatch.setattr(observer,'safe_swings',lambda *_:swings)
    row['original_zone']=['16.1','16.8'];row['observation']['causal_wave']={'start_index':10,'end_index':20}
    result=observer.confirm(context,row)
    golden=[r for r in result['confirmations'] if r['kind']=='OTHER_MINOR_WAVE_GOLDEN_OVERLAP']
    assert golden and all(r['anchors']!=[10,20] for r in golden)
    assert result['main_levels']['0.61']=='16.10' and '0.71' not in result['main_levels']
    assert result['entry_changed'] is False


def test_rolling_minute_budget_survives_new_repository_and_uses_no_raw_secret(sqlite_engine,monkeypatch):
    monkeypatch.setenv('TWELVE_DATA_MINUTE_BUDGET','2')
    params={'apikey':'fixture-secret','symbol':'XAU/USD'}
    reserve_twelve(params,engine=sqlite_engine,now_ms=100000)
    reserve_twelve(params,engine=sqlite_engine,now_ms=100001)
    from core.storage.engine import DatabaseEngine
    restarted = DatabaseEngine(database_url='',sqlite_path=sqlite_engine.sqlite_path)
    restarted.ensure_schema()
    with pytest.raises(ProviderBudgetExceeded,match='MINUTE'):
        reserve_twelve(params,engine=restarted,now_ms=159999)
    restarted.close()
    reserve_twelve(params,engine=sqlite_engine,now_ms=160001)
    with sqlite_engine.transaction(read_only=True) as cursor:
        raw=str(cursor.execute('SELECT * FROM s9_provider_budget').fetchall())
    assert 'fixture-secret' not in raw


def test_daily_budget_and_gold_reservation_reset_at_utc_day(sqlite_engine,monkeypatch):
    monkeypatch.setenv('TWELVE_DATA_DAILY_BUDGET','3');monkeypatch.setenv('TWELVE_DATA_NON_GOLD_DAILY_BUDGET','1')
    params={'apikey':'fixture','symbol':'EUR/USD'}
    reserve_twelve(params,engine=sqlite_engine,now_ms=100000)
    with pytest.raises(ProviderBudgetExceeded,match='NON_GOLD'):
        reserve_twelve(params,engine=sqlite_engine,now_ms=200000)
    gold={**params,'symbol':'XAU/USD'}
    reserve_twelve(gold,engine=sqlite_engine,now_ms=200000)
    reserve_twelve(gold,engine=sqlite_engine,now_ms=300000)
    with pytest.raises(ProviderBudgetExceeded,match='DAILY'):
        reserve_twelve(gold,engine=sqlite_engine,now_ms=400000)
    reserve_twelve(params,engine=sqlite_engine,now_ms=86400001)


def test_concurrent_requests_cannot_overdraw_one_credit(sqlite_engine,monkeypatch):
    monkeypatch.setenv('TWELVE_DATA_MINUTE_BUDGET','1')
    def attempt(_):
        try:
            reserve_twelve({'apikey':'fixture','symbol':'XAU/USD'},engine=sqlite_engine,now_ms=100000)
            return True
        except ProviderBudgetExceeded:
            return False
    with ThreadPoolExecutor(max_workers=8) as pool:
        assert sum(pool.map(attempt,range(8)))==1


@pytest.mark.asyncio
async def test_http_budget_exhaustion_sends_no_network_request(monkeypatch):
    from core import http_client
    from repositories.v2 import provider_budget
    client=SimpleNamespace(request=AsyncMock())
    monkeypatch.setattr(http_client,'get_client',AsyncMock(return_value=client))
    def blocked(*_):raise ProviderBudgetExceeded('TWELVE_DATA_DAILY_BUDGET_EXHAUSTED')
    monkeypatch.setattr(provider_budget,'reserve_twelve',blocked)
    with pytest.raises(ProviderBudgetExceeded):
        await http_client.get_json('https://api.twelvedata.com/price',params={'apikey':'fixture'},retries=2)
    client.request.assert_not_awaited()


@pytest.mark.asyncio
async def test_fx_fails_over_whole_history_and_obeys_cooldown(monkeypatch):
    market._SOURCE_COOLDOWNS.clear()
    monkeypatch.setattr('services.keyless_market_data_service.biquote_history',
                        AsyncMock(side_effect=market.MarketUnavailable('PROVIDER_HTTP_503')))
    yahoo=AsyncMock(side_effect=market.MarketUnavailable('PROVIDER_HTTP_429'))
    native=price_bars('twelve_data')
    twelve=AsyncMock(return_value=native)
    monkeypatch.setattr(market,'_yahoo_fx',yahoo);monkeypatch.setattr(market,'_twelve',twelve)
    for _ in range(2):
        assert await market._core_route('EURUSD','5m',300,None,None)==native
    assert yahoo.await_count==1 and twelve.await_count==2
    with pytest.raises(market.MarketUnavailable):
        await market._core_route('EURUSD','5m',300,None,'yahoo_fx')
    assert twelve.await_count==2


@pytest.mark.asyncio
async def test_yahoo_drops_off_grid_quote_and_checks_native_ticker(monkeypatch):
    fixture={'chart':{'result':[{'meta':{'symbol':'EURUSD=X','instrumentType':'CURRENCY'},
              'timestamp':[300,600,631], 'indicators':{'quote':[{'open':[1,1,1], 'high':[2,2,2],
              'low':[1,1,1],'close':[1,1,1]}]}}]}}
    monkeypatch.setattr(market,'_request',AsyncMock(return_value=fixture))
    result=await market._yahoo_fx('EURUSD','5m',300,None)
    assert [b.start_ms for b in result]==[300000,600000] and all(b.volume is None for b in result)
    fixture['chart']['result'][0]['meta']['symbol']='GC=F'
    with pytest.raises(market.MarketUnavailable,match='SYMBOL_MISMATCH'):
        await market._yahoo_fx('EURUSD','5m',300,None)
    with pytest.raises(market.MarketUnavailable):
        await market._yahoo_fx('XAUUSD','5m',300,None)


@pytest.mark.asyncio
async def test_chart_and_analysis_share_one_cached_request(monkeypatch):
    market._HISTORY_CACHE.clear();market._INFLIGHT.clear()
    data=price_bars('twelve_data','XAUUSD')
    fetch=AsyncMock(return_value=data)
    monkeypatch.setattr(market,'_historical_bars',fetch)
    result=await asyncio.gather(*(market.historical_bars('XAUUSD','5m') for _ in range(6)))
    assert all(rows==data for rows in result) and fetch.await_count==1
    assert await market.historical_bars('XAUUSD','5m',provider='twelve_data',limit=20)==data[-20:]
    assert fetch.await_count==1
    market._HISTORY_CACHE.clear()


@pytest.mark.asyncio
async def test_priority_cadence_reserves_fast_scans_for_gold_and_fx():
    from services.strategy_scanner_service import due_markets,_SCAN_DUE
    _SCAN_DUE.clear()
    symbols=['BTCUSDT','US30','US100','NAS100','EURUSD','GBPUSD','XAUUSD']
    first=due_markets(symbols,(),0,10000)
    assert first==[('XAUUSD','5m'),('EURUSD','5m'),('GBPUSD','5m'),('XAUUSD','1h')]
    second=due_markets(symbols,(),4,10020)
    assert not set(first)&set(second) and not any(symbol=='NAS100' for symbol,_ in second)
    assert ('XAUUSD','5m') in due_markets(symbols,(),8,10216)


@pytest.mark.asyncio
async def test_gold_reference_preserves_time_caches_and_never_becomes_candle(monkeypatch):
    from services import market_reference_service as references
    references._CACHE.clear();references._INFLIGHT.clear()
    references._COOLDOWNS.clear()
    raw={'symbol':'XAU','currency':'USD','price':'2400.1','updatedAt':'2026-01-01T00:00:00Z'}
    request=AsyncMock(return_value=raw)
    monkeypatch.setattr(references,'get_json',request)
    result=await asyncio.gather(*(references.gold_reference() for _ in range(5)))
    assert request.await_count==1
    assert result[0]['state']=='STALE_OR_SESSION_CLOSED' and not result[0]['execution_eligible']
    assert result[0]['updated_at']=='2026-01-01T00:00:00+00:00' and 'bars' not in result[0]
    references._CACHE.clear()
    raw['symbol']='BTC'
    with pytest.raises(ValueError,match='IDENTITY'):
        await references.gold_reference()


@pytest.mark.asyncio
async def test_core_analysis_uses_observers_and_persists_candles_without_instrument(sqlite_engine,monkeypatch):
    from repositories.v2 import market_evidence
    from services import strategy_analysis_service as service
    data=price_bars('yahoo_fx')
    monkeypatch.setattr(service,'historical_bars',AsyncMock(return_value=data))
    monkeypatch.setattr(service.time,'time',lambda:data[-1].available_ms/1000)
    monkeypatch.setattr(market_evidence,'normalized_engine',lambda:sqlite_engine)
    result=await service.research_analysis('EURUSD','5m')
    assert result['analysis_mode']=='CANDLE_ONLY' and result['is_signal'] is False
    assert len(market_evidence.MarketEvidenceRepository(sqlite_engine).candles('EURUSD','yahoo_fx','5m'))==120
    original=data[10].close
    data[10]=replace(data[10],close=original+D('.01'))
    changed=await service.research_analysis('EURUSD','5m')
    assert changed['reason']=='CLOSED_CANDLE_CORRECTION_REQUIRES_REVIEW' and changed['results']==[]
    assert market_evidence.MarketEvidenceRepository(sqlite_engine).candles('EURUSD','yahoo_fx','5m')[10].close==original


@pytest.mark.asyncio
async def test_retry_attempts_are_charged_and_database_failure_is_fail_closed(sqlite_engine,monkeypatch):
    from core import http_client
    from repositories.v2 import provider_budget
    monkeypatch.setenv('TWELVE_DATA_MINUTE_BUDGET','1')
    monkeypatch.setattr(provider_budget,'normalized_engine',lambda:sqlite_engine)
    request=httpx.Request('GET','https://api.twelvedata.com/price?apikey=fixture-secret')
    failure=httpx.HTTPStatusError('private URL',request=request,response=httpx.Response(429,request=request))
    client=SimpleNamespace(request=AsyncMock(side_effect=failure))
    monkeypatch.setattr(http_client,'get_client',AsyncMock(return_value=client))
    with pytest.raises(ProviderBudgetExceeded):
        await http_client.get_json(str(request.url),params={'apikey':'fixture-secret','symbol':'XAU/USD'},retries=1)
    assert client.request.await_count==1
    def unavailable():raise RuntimeError('database unavailable')
    monkeypatch.setattr(provider_budget,'normalized_engine',unavailable)
    with pytest.raises(RuntimeError,match='database unavailable'):
        await http_client.get_json('https://api.twelvedata.com/price',params={'apikey':'different'})
    assert client.request.await_count==1


def test_batch_symbols_are_charged_per_symbol(sqlite_engine,monkeypatch):
    monkeypatch.setenv('TWELVE_DATA_MINUTE_BUDGET','2')
    reserve_twelve({'apikey':'fixture','symbol':'EUR/USD,GBP/USD'},engine=sqlite_engine,now_ms=100000)
    with pytest.raises(ProviderBudgetExceeded,match='MINUTE'):
        reserve_twelve({'apikey':'fixture','symbol':'XAU/USD'},engine=sqlite_engine,now_ms=100001)


@pytest.mark.asyncio
async def test_malformed_source_can_fail_over_without_splicing_or_leaking(monkeypatch):
    market._SOURCE_COOLDOWNS.clear()
    monkeypatch.setattr('services.keyless_market_data_service.biquote_history',
                        AsyncMock(side_effect=market.MarketUnavailable('PROVIDER_HTTP_503')))
    broken=AsyncMock(side_effect=ValueError('https://secret/?apikey=PRIVATE'))
    data=price_bars('twelve_data')
    monkeypatch.setattr(market,'_yahoo_fx',broken)
    monkeypatch.setattr(market,'_twelve',AsyncMock(return_value=data))
    assert await market._core_route('EURUSD','5m',300,None,None)==data
    with pytest.raises(market.MarketUnavailable,match='INVALID_ANALYSIS_CANDLES'):
        await market._core_route('EURUSD','5m',300,None,'yahoo_fx')


def test_indicator_observer_requires_all_directional_votes_for_each_model(monkeypatch):
    from modules.strategies.indicators import observer
    data=price_bars()
    # A prospective zone below the latest price, no observed later overlap.
    data[-1]=replace(data[-1],open=D(110),high=D(111),low=D(109),close=D(110))
    data[-2]=replace(data[-2],open=D(110),high=D(111),low=D(109),close=D(110))
    swings=[Swing(10,'high',D(105),1),Swing(20,'low',D(97),1),
            Swing(30,'high',D(104),1),Swing(40,'low',D(96),1)]
    monkeypatch.setattr(observer,'safe_swings',lambda *_:swings)
    ma={20:[D(98)]*117+[D(99),D(99),D(100)],50:[D(97)]*117+[D(98),D(98),D(99)],100:[D(96)]*117+[D(97),D(97),D(98)]}
    rsi=[D(55)]*120;rsi[20]=D(40);rsi[40]=D(45)
    stats={'ma':ma,'rsi':rsi,'macd_hist':[D(0)]*117+[D('.1'),D('.2'),D('.3')],
           'plus_di':D(30),'minus_di':D(10),'adx':D(30),'atr':D(1)}
    monkeypatch.setattr(observer,'indicators',lambda *_:stats)
    context=ObservationContext(tuple(data),data[-1].available_ms)
    rows=observer.observe(context)
    assert {r['submodel'] for r in rows}=={'trend_continuation','early_reversal'}
    stats['adx']=D(15)
    assert {'range_reversal','range_breakout'} <= {r['submodel'] for r in observer.observe(context)}
    stats['macd_hist'][-1]=D(-1)
    assert observer.observe(context)==[]


@pytest.mark.asyncio
async def test_private_review_delivery_describes_observation_without_entry():
    from services.strategy_scanner_service import review_message
    _,row=make_observation()
    message=review_message(row)
    assert 'سیگنال ورود نیست' in message and 'yahoo_fx' in message
    assert 'Entry' not in message and 'TP1' not in message

