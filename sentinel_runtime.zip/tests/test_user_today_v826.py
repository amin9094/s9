from datetime import UTC, datetime, timedelta

from modules.user_today import user_today_snapshot


def test_user_today_aggregates_daily_state():
    now = datetime(2026, 9, 25, 10, tzinfo=UTC)
    db = {
        'users': {'1': {'created_at': now.isoformat()}},
        'user_points': {'1': 42},
        'vip_users': {},
        'vip_orders': [], 'education_orders': [], 'education_access': {}, 'lessons': [],
        'tickets': [{'id': 1, 'user_id': '1', 'status': 'open', 'updated_at': now.isoformat()}],
        'user_rewards': [], 'reward_requests': [], 'price_alerts': [{'id': 1, 'user_id': '1', 'status': 'active'}],
        'missions': [], 'user_missions': {}, 'user_referrals': {},
        'signals': [], 'user_signal_choices': {},
        'user_watchlists': {'1': [{'symbol': 'XAUUSD'}]},
        'trade_journal': {'1': []},
        'journal_admin_notes': {},
        'economic_calendar': {'cached_events': [{'title': 'CPI', 'title_fa': 'تورم', 'currency': 'USD', 'datetime': (now + timedelta(hours=2)).isoformat(), 'impact': 'high'}]},
        'economic_calendar_user_preferences': {'1': {'currencies': ['USD'], 'min_impact': 'high'}},
    }
    result = user_today_snapshot(db, 1, now=now)
    assert result['points'] == 42
    assert result['watchlist_count'] == 1
    assert result['open_ticket_count'] == 1
    assert result['active_alert_count'] == 1
    assert result['next_event']['title'] == 'CPI'
