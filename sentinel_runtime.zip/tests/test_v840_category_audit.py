from __future__ import annotations
import ast
import copy
from dataclasses import replace
import json
import re
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest
import bot  # noqa: F401 -- load the real existing runtime/facade
from bot_runtime import navigation as nav, crm_content, system_center, platform_expansion
from modules.admin_access import ALL_PERMISSIONS, LEGACY_PERMISSION_CHILDREN, OWNER_ONLY_PERMISSIONS
from modules.admin_control_center import MODULE_BY_KEY
from modules.platform_registry import CAPABILITIES
from handlers.callback_routes import callback_routes
from telegram.ext import CallbackQueryHandler, ConversationHandler
from tests.test_master_upgrade import state, OWNER  # noqa: F401

ROOT=Path(__file__).resolve().parents[1]
BASELINE=json.loads((ROOT/'tests/menu_access_baseline_839.json').read_text())
CATEGORIES=list(nav._admin_navigation_categories())
TOOLS=list(nav._admin_items_by_callback())


def cbs(rows):return [b.callback_data for row in rows for b in row]


class NS(dict):
    def __missing__(self,key):return key


@pytest.fixture(scope='module')
def registered_routes(tmp_path_factory):
    # Build the actual PTB application: conversation entrypoints are registered
    # separately from the static global callback table.
    from bot_runtime import runtime_jobs
    folder=tmp_path_factory.mktemp('category-route-build')
    settings=replace(runtime_jobs.SETTINGS,bot_token='123456789:'+'A'*32,database_url='',
                     persistence_file=folder/'telegram-state.sqlite3')
    with pytest.MonkeyPatch.context() as patcher:
        patcher.setattr(runtime_jobs,'SETTINGS',settings)
        app=bot.build_application()
    routes=[]
    def scan(handler):
        if isinstance(handler,CallbackQueryHandler) and handler.pattern:
            routes.append((re.compile(handler.pattern),handler.callback))
        elif isinstance(handler,ConversationHandler):
            for child in handler.entry_points:
                scan(child)
    for handlers in app.handlers.values():
        for handler in handlers:
            scan(handler)
    return routes


@pytest.mark.parametrize('callback',TOOLS)
def test_every_advertised_direct_tool_has_a_real_registered_route(callback,registered_routes):
    matched=[(pattern,handler) for pattern,handler in registered_routes if pattern.fullmatch(callback)]
    assert matched,callback
    assert all(callable(handler) for _,handler in matched)
    assert len(callback.encode())<=64


def test_no_previous_feature_entrypoint_or_handler_or_function_removed():
    assert set(BASELINE['root_tools'])<=set(TOOLS)
    routes={(p,fn) for p,fn in callback_routes(NS())}
    # The existing market_v2 module contains a digit. These five patterns are
    # broadened deliberately; all old routes and handlers still remain valid.
    prior={(p.replace('[a-z_]+','[a-z0-9_]+') if p.startswith(('^ecc_','^feature_toggle:')) else p,fn)
           for p,fn in BASELINE['callback_routes']}
    assert prior<=routes
    functions=set()
    for folder in ['bot_runtime','modules','services','core','repositories','handlers','jobs','ui']:
        for p in (ROOT/folder).rglob('*.py'):
            functions.update(p.relative_to(ROOT).as_posix()+':'+node.name for node in ast.parse(p.read_text()).body if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)))
    assert set(BASELINE['all_top_level_functions'])<=functions


@pytest.mark.parametrize('category',CATEGORIES)
def test_category_has_unique_direct_tools_order_and_no_inner_category_buttons(monkeypatch,category):
    monkeypatch.setattr(nav,'_admin_granted_permissions',lambda _:set(ALL_PERMISSIONS))
    monkeypatch.setattr(nav,'_is_owner_admin',lambda _:True)
    rows=nav.admin_category_menu(category,OWNER);data=cbs(rows)
    expected=nav._admin_navigation_categories()[category]['callbacks']
    assert data[:-1]==expected
    assert len(data)==len(set(data)) and len(data)<=100
    assert all(len(row)<=2 for row in rows)
    assert data[-1]=='nb:admin_home'
    assert not any(str(cb).startswith(('admin_cat:','ecc_cat:','feature_group:','admin_ui_mode:')) for cb in data[:-1])
    assert all(nav._admin_category_for_callback(cb)==category for cb in expected)


def test_all_settings_and_platform_details_are_direct_domain_entries():
    all_tools=[key for s in nav._admin_navigation_categories().values() for key in s['callbacks']]
    assert len(all_tools)==len(set(all_tools))==len(TOOLS)
    assert {f'ecc_mod:{key}' for key in MODULE_BY_KEY}<=set(all_tools)
    assert {f'platform_view:{item.key}' for item in CAPABILITIES if item.admin_visible}<=set(all_tools)
    assert {'a_system_center','a_google_sheets_monitor','a_job_control','refreview','a_public_discounts','a_crm_segments','channel_schedules','sig_board:all:0'}<=set(all_tools)
    assert 'crm_dashboard' in nav._admin_navigation_categories()['users']['callbacks']
    assert 'crm_automation_log' in nav._admin_navigation_categories()['automation']['callbacks']


@pytest.mark.parametrize('language',['fa','en'])
def test_all_prior_user_categories_and_tools_remain_available(language):
    current={key:[callback for _,callback in item['items']] for key,item in nav._user_navigation_items(language).items()}
    assert current==BASELINE['user_categories'][language]


@pytest.mark.parametrize('permission',list(LEGACY_PERMISSION_CHILDREN))
def test_menu_permissions_match_real_approved_legacy_role(monkeypatch,state,permission):
    from modules.admin_access import has_permission
    state['delegated_admins']={'99':{'active':True,'approval_status':'approved','permissions':[permission]}}
    monkeypatch.setattr(nav,'load_db',lambda:state)
    monkeypatch.setattr(nav,'is_admin',lambda _:False)
    granted=nav._admin_granted_permissions(99)
    assert granted=={p for p in ALL_PERMISSIONS if has_permission(state,99,p)}
    assert permission in granted
    assert not OWNER_ONLY_PERMISSIONS & granted


@pytest.mark.parametrize('status,active',[('pending',True),('rejected',True),('approved',False)])
def test_inactive_or_unapproved_admin_sees_no_privileged_tools(monkeypatch,state,status,active):
    state['delegated_admins']={'99':{'active':active,'approval_status':status,'permissions':list(ALL_PERMISSIONS)}}
    monkeypatch.setattr(nav,'load_db',lambda:state);monkeypatch.setattr(nav,'is_admin',lambda _:False)
    assert nav._admin_granted_permissions(99)==set()


@pytest.mark.parametrize('granted,expected',[({'reward_points'},False),({'incidents'},False),({'reward_points','incidents'},True)])
def test_referral_review_requires_both_permissions(granted,expected,monkeypatch):
    monkeypatch.setattr(nav,'_is_owner_admin',lambda _:False)
    assert nav._admin_item_allowed('refreview',99,granted)==expected


def test_platform_buttons_use_the_handler_authoritative_permission(monkeypatch):
    monkeypatch.setattr(nav,'_is_owner_admin',lambda _:False)
    assert not nav._admin_item_allowed('platform_view:local_copilot',99,{'ai_command_center'})
    assert nav._admin_item_allowed('platform_view:local_copilot',99,{'ai_copilot'})
    for item in CAPABILITIES:
        assert nav._admin_items_by_callback()[f'platform_view:{item.key}'][2]==platform_expansion._PLATFORM_PERMISSIONS[item.key]


@pytest.mark.parametrize('alias,canonical',[('command','system'),('market','trading'),('analytics','system')])
def test_old_category_links_and_keyboards_keep_access(monkeypatch,alias,canonical):
    monkeypatch.setattr(nav,'_admin_granted_permissions',lambda _:set(ALL_PERMISSIONS))
    monkeypatch.setattr(nav,'_is_owner_admin',lambda _:True)
    assert nav._admin_category_available(alias,set(ALL_PERMISSIONS))
    assert cbs(nav.admin_category_menu(alias,OWNER))==cbs(nav.admin_category_menu(canonical,OWNER))


@pytest.mark.parametrize('key',['signals','crm','subscriptions','rewards','edu','automation','publisher','security'])
def test_configuration_back_uses_its_domain_without_old_control_category(key,state):
    rows=nav._control_module_rows(key,state)
    assert not any(str(cb).startswith(('ecc_cat:','nb:ecc_cat:')) for cb in cbs(rows))
    assert f'nb:admin_cat:{nav._admin_control_domain(key)}' in cbs(rows)
    source=f'ecc_bool:{key}:enabled'
    normalized=nav._normalize_navigation_rows([[nav.InlineKeyboardButton('⬅️ برگشت',callback_data='a_control_center')]],source)
    assert cbs(normalized)==[f'nb:admin_cat:{nav._admin_control_domain(key)}']


def test_feature_management_is_flat_keeps_every_switch_and_safe_group_encoding(state):
    rows=crm_content._feature_group_rows(state)
    data=cbs(rows)
    assert not any(str(cb).startswith(('feature_group:','ecc_cat:')) for cb in data)
    switches=[str(cb).split(':',2) for cb in data if str(cb).startswith('feature_toggle:')]
    assert {parts[2] for parts in switches}==set(crm_content.USER_FEATURE_MODULE_KEYS)
    assert len(switches)==len({p[2] for p in switches})
    assert all(module in crm_content.USER_FEATURE_GROUPS[group][1] for _,group,module in switches)
    assert crm_content._feature_group_rows(state,'core')==rows


def test_every_settings_field_and_feature_switch_has_a_registered_route(state,registered_routes):
    callbacks=cbs(crm_content._feature_group_rows(state))
    for key in MODULE_BY_KEY:
        callbacks+=cbs(nav._control_module_rows(key,state,show_planned=True))
        callbacks+=[f'ecc_mod:{key}',f'ecc_mode:{key}:basic',f'ecc_mode:{key}:advanced']
    for callback in callbacks:
        if str(callback).startswith(('feature_toggle:','ecc_')):
            assert any(pattern.fullmatch(callback) for pattern,_ in registered_routes),callback
            assert len(callback.encode())<=64


def patch(monkeypatch,module,state):
    monkeypatch.setattr(module,'require_admin',AsyncMock(return_value=True))
    monkeypatch.setattr(module,'async_snapshot',AsyncMock(side_effect=lambda:copy.deepcopy(state)))
    monkeypatch.setattr(module,'edit',AsyncMock())


def update(data):
    user=SimpleNamespace(id=OWNER);q=SimpleNamespace(data=data,from_user=user,answer=AsyncMock())
    return SimpleNamespace(callback_query=q,effective_user=user)


@pytest.mark.asyncio
@pytest.mark.parametrize('category',CATEGORIES)
async def test_actual_category_handler_acknowledges_and_shows_complete_tools(monkeypatch,state,category):
    patch(monkeypatch,crm_content,state)
    monkeypatch.setattr(crm_content,'_admin_granted_permissions',lambda _:set(ALL_PERMISSIONS))
    monkeypatch.setattr(nav,'_admin_granted_permissions',lambda _:set(ALL_PERMISSIONS))
    monkeypatch.setattr(nav,'_is_owner_admin',lambda _:True)
    monkeypatch.setattr(nav,'load_db',lambda:state)
    q=update('admin_cat:'+category)
    await crm_content.admin_navigation(q,SimpleNamespace(user_data={}))
    assert q.callback_query.answer.await_count==1
    assert cbs(crm_content.edit.await_args.args[2])[:-1]==nav._admin_navigation_categories()[category]['callbacks']


@pytest.mark.asyncio
async def test_legacy_feature_group_handler_renders_flat_switches(monkeypatch,state):
    patch(monkeypatch,crm_content,state)
    await crm_content.feature_group_view(update('feature_group:core'),SimpleNamespace(user_data={}))
    rows=crm_content.edit.await_args.args[2]
    assert not any(str(cb).startswith('feature_group:') for cb in cbs(rows))
    assert len([cb for cb in cbs(rows) if str(cb).startswith('feature_toggle:')])==len(crm_content.USER_FEATURE_MODULE_KEYS)


def patch_control(monkeypatch,module,state):
    patch(monkeypatch,module,state)
    async def mutate(fn):return fn(state)
    monkeypatch.setattr(module,'async_with_db',mutate)
    monkeypatch.setattr(module,'reply',AsyncMock())


@pytest.mark.asyncio
async def test_numbered_module_opens_edits_toggles_and_resets(monkeypatch,state):
    from modules.admin_control_center import module_state
    patch_control(monkeypatch,nav,state)
    monkeypatch.setattr(nav,'_has_admin_permission',lambda *_:True)
    context=SimpleNamespace(user_data={})
    await nav.control_module_handler(update('ecc_mod:market_v2'),context)
    assert 'nb:admin_cat:trading' in cbs(nav.edit.await_args.args[2])
    await nav.control_boolean_handler(update('ecc_bool:market_v2:freshness'),context)
    assert module_state(state,'market_v2')['freshness'] is False
    await nav.control_module_mode_handler(update('ecc_mode:market_v2:advanced'),context)
    assert 'market_v2' in context.user_data['control_advanced_modules']
    await nav.control_edit_start(update('ecc_edit:market_v2:stale_seconds'),context)
    assert context.user_data['enterprise_control_edit']==('market_v2','stale_seconds')
    message=SimpleNamespace(effective_user=SimpleNamespace(id=OWNER),effective_message=SimpleNamespace(text='2'))
    assert await nav.control_edit_input(message,context)==nav.ENTERPRISE_CONTROL_INPUT
    assert context.user_data['enterprise_control_edit']==('market_v2','stale_seconds')
    assert module_state(state,'market_v2')['stale_seconds']==300
    message.effective_message.text='600'
    assert await nav.control_edit_input(message,context)==ConversationHandler.END
    assert 'enterprise_control_edit' not in context.user_data
    assert module_state(state,'market_v2')['stale_seconds']==600
    await nav.control_reset_handler(update('ecc_reset:market_v2'),context)
    assert module_state(state,'market_v2')['stale_seconds']==300
    assert module_state(state,'market_v2')['freshness'] is True


@pytest.mark.asyncio
@pytest.mark.parametrize('callback,handler',[
    ('ecc_mod:forged2','control_module_handler'),('ecc_bool:market_v2:forged','control_boolean_handler'),
    ('ecc_mode:forged2:advanced','control_module_mode_handler'),('ecc_edit:market_v2:forged','control_edit_start'),
    ('ecc_reset:forged2','control_reset_handler'),('feature_toggle:core:market_v2','feature_toggle_handler'),
    ('feature_toggle:intelligence:forged2','feature_toggle_handler')])
async def test_forged_setting_keys_do_not_change_state(monkeypatch,state,callback,handler):
    module=crm_content if handler=='feature_toggle_handler' else nav
    patch_control(monkeypatch,module,state)
    before=copy.deepcopy(state)
    q=update(callback)
    await getattr(module,handler)(q,SimpleNamespace(user_data={}))
    assert state==before
    assert q.callback_query.answer.await_count>=1
    module.edit.assert_not_awaited()


@pytest.mark.asyncio
async def test_numbered_feature_switch_uses_existing_authorized_mutation(monkeypatch,state):
    from modules.admin_control_center import module_state
    patch_control(monkeypatch,crm_content,state)
    await crm_content.feature_toggle_handler(update('feature_toggle:intelligence:market_v2'),SimpleNamespace(user_data={}))
    assert module_state(state,'market_v2')['enabled'] is False
    rows=crm_content.edit.await_args.args[2]
    assert 'feature_toggle:intelligence:market_v2' in cbs(rows)
    assert not any(str(cb).startswith('feature_group:') for cb in cbs(rows))


@pytest.mark.asyncio
@pytest.mark.parametrize('callback,handler',[
    ('ecc_mod:market_v2','control_module_handler'),('ecc_bool:market_v2:freshness','control_boolean_handler'),
    ('ecc_mode:market_v2:advanced','control_module_mode_handler'),('ecc_edit:market_v2:stale_seconds','control_edit_start'),
    ('ecc_reset:market_v2','control_reset_handler'),('feature_toggle:intelligence:market_v2','feature_toggle_handler')])
async def test_numbered_settings_keep_server_permission_guards(monkeypatch,state,callback,handler):
    module=crm_content if handler=='feature_toggle_handler' else nav
    patch_control(monkeypatch,module,state)
    monkeypatch.setattr(module,'require_admin',AsyncMock(return_value=False))
    before=copy.deepcopy(state)
    await getattr(module,handler)(update(callback),SimpleNamespace(user_data={}))
    assert state==before
    module.async_snapshot.assert_not_awaited()
    module.edit.assert_not_awaited()


@pytest.mark.asyncio
@pytest.mark.parametrize('can_configure',[False,True])
async def test_capability_detail_exposes_settings_only_with_control_permission(monkeypatch,state,can_configure):
    patch(monkeypatch,platform_expansion,state)
    monkeypatch.setattr(platform_expansion,'_has_admin_permission',lambda *_:can_configure)
    await platform_expansion.platform_capability_view(update('platform_view:local_copilot'),SimpleNamespace(user_data={}))
    text,rows=platform_expansion.edit.await_args.args[1:]
    assert ('ecc_mod:copilot' in cbs(rows)) is can_configure
    assert 'nb:admin_cat:trading' in cbs(rows)
    assert 'ai_copilot' in text


@pytest.mark.asyncio
@pytest.mark.parametrize('can_repair',[False,True])
async def test_health_viewer_only_sees_repair_actions_with_control_permission(monkeypatch,state,can_repair):
    from core import google_sheets_backup
    patch(monkeypatch,system_center,state)
    monkeypatch.setattr(system_center,'_has_admin_permission',lambda *_:can_repair)
    monkeypatch.setattr(google_sheets_backup,'normalized_pending_tables',lambda:[])
    monkeypatch.setattr(system_center,'google_sheets_backup_status',lambda:{'enabled':False})
    monkeypatch.setattr(system_center,'runtime_observability_snapshot',lambda:{})
    await system_center.google_sheets_monitor_view(update('a_google_sheets_monitor'),SimpleNamespace(user_data={}))
    rows=system_center.edit.await_args.args[2]
    assert ('gsmon_sync' in cbs(rows)) is can_repair
    assert ('gsmon_full' in cbs(rows)) is can_repair
    assert 'a_google_sheets_monitor' in cbs(rows)
