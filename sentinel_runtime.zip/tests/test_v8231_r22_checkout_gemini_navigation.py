from __future__ import annotations

from pathlib import Path
from types import SimpleNamespace

import pytest

from bot_runtime import navigation
from modules.contest import add_news_direction_answer, end_news_direction_contest, start_news_direction_contest
from modules.gemini_command_router import deterministic_local_plan
from services.actions_v2.registry import action_specs

ROOT = Path(__file__).resolve().parents[1]


def _query(data: str, text: str):
    button = SimpleNamespace(callback_data=data, text=text)
    markup = SimpleNamespace(inline_keyboard=[[button]])
    message = SimpleNamespace(reply_markup=markup)
    return SimpleNamespace(data=data, message=message)


def test_checkout_unwraps_action_envelope_and_keeps_coupon_optional() -> None:
    source = (ROOT / "webapp/src/commerce-support.js").read_text(encoding="utf-8")
    assert "function checkoutActionData(value)" in source
    assert "value.action && value.data" in source
    assert "const q = checkoutActionData(rawQuote)" in source
    assert 'id="hasCoupon" type="checkbox"' in source
    assert "$('#hasCoupon')?.checked ?" in source
    assert "payment_card_number" in source
    assert "payment_card_owner" in source
    assert 'id="receiptFile" type="file"' in source
    assert "receiptLocalPreview" in source
    assert "vip_order_submit" in source


def test_vip_order_telegram_sync_notifies_admin_with_receipt() -> None:
    server = (ROOT / "core/miniapp_server.py").read_text(encoding="utf-8")
    assert 'action in {"vip_order_submit", "vip_order_resubmit"}' in server
    assert "رسید پرداخت VIP جدید" in server
    assert "send_photo" in server
    assert "approve:" in server and "reject:" in server


def test_admin_miniapp_has_vip_plan_and_payment_settings() -> None:
    specs = action_specs()
    assert "admin_vip_settings_update" in specs
    assert specs["admin_vip_settings_update"].admin_only is True
    assert specs["admin_vip_settings_update"].permission == "vip_settings"
    read_service = (ROOT / "services/miniapp_read_service_v2.py").read_text(encoding="utf-8")
    admin_ui = (ROOT / "webapp/src/admin-parity.js").read_text(encoding="utf-8")
    assert '"card_number"' in read_service and '"owner_name"' in read_service
    assert '"price"' in read_service and '"duration_days"' in read_service
    assert "adminVipSettingsModal" in admin_ui
    assert "admin_vip_settings_update" in admin_ui


def test_user_main_menu_has_language_and_no_gemini(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(navigation, "load_db", lambda: {})
    monkeypatch.setattr(navigation, "_language_for_user", lambda _uid: "fa")
    monkeypatch.setattr(navigation, "is_vip", lambda *_args: False)
    monkeypatch.setattr(navigation, "_is_any_admin", lambda _uid: False)
    monkeypatch.setattr(navigation, "_has_any_admin_permission", lambda *_args, **_kwargs: False)
    monkeypatch.setattr(navigation, "with_webapp", lambda rows: rows)
    callbacks = [button.callback_data for row in navigation.main_menu(10) for button in row]
    assert "language_menu" in callbacks
    assert "u_ai_chat_start" not in callbacks
    assert "a_ai_chat_start" not in callbacks


def test_only_subscription_journey_replaces_messages() -> None:
    assert navigation._should_replace_navigation_message(_query("u_vip", "💎 خرید اشتراک")) is True
    assert navigation._should_replace_navigation_message(_query("vip_plan:1", "پلن")) is True
    assert navigation._should_replace_navigation_message(_query("u_calc", "ماشین حساب")) is False
    assert navigation._should_replace_navigation_message(_query("u_edu", "آموزش")) is False
    assert navigation._should_replace_navigation_message(_query("home", "⬅️ برگشت")) is False


def test_discount_command_is_planned_without_risk_fallback() -> None:
    plan = deterministic_local_plan("کد تخفیف ۱۵ درصدی عمومی با انقضا ۷ روزه و کد welcome15 درست کن")
    assert plan.missing_fields == []
    assert plan.calls == [{
        "action": "public_discount_create",
        "payload": {
            "code": "WELCOME15",
            "percent": 15,
            "days": 7,
            "max_uses": 0,
            "one_per_user": True,
        },
        "reason": "فرمان صریح ادمین برای ساخت کد تخفیف عمومی",
    }]


def test_news_direction_contest_supports_range_and_configurable_reward() -> None:
    db: dict = {}
    start_news_direction_contest(db, "US CPI", duration_minutes=30, reward_points=9)
    assert add_news_direction_answer(db, 11, "RANGE") == "OK"
    assert add_news_direction_answer(db, 12, "UP") == "OK"
    _closed, winners = end_news_direction_contest(db, "RANGE")
    assert winners == ["11"]
    assert db["user_points"]["11"] == 9


def test_saved_leverage_signal_back_and_closed_signal_contracts() -> None:
    calc = (ROOT / "bot_runtime/commerce_calculator.py").read_text(encoding="utf-8")
    runtime = (ROOT / "bot_runtime/runtime_jobs.py").read_text(encoding="utf-8")
    wizard = (ROOT / "bot_runtime/growth_campaigns.py").read_text(encoding="utf-8")
    signal_home = (ROOT / "webapp/src/signals-home.js").read_text(encoding="utf-8")
    trade_center = (ROOT / "webapp/src/trade-center.js").read_text(encoding="utf-8")
    assert 'profile.get("forex_leverage" if mode == "forex" else "crypto_leverage")' in calc and "_finish_calculator" in calc
    assert "sig_back:" in runtime
    assert "async def signal_wizard_back" in wizard
    assert "سیگنال بسته شده" in signal_home
    assert "const sell" in signal_home and "final = Boolean" in signal_home
    assert "signalFinal" in trade_center
