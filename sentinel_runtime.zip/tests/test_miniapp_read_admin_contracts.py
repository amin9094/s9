from __future__ import annotations

from types import SimpleNamespace

import pytest

from tests.telegram_test_stub import install as install_telegram_test_stub
install_telegram_test_stub()

from core.webapp_auth import TelegramWebAppIdentity
from services import miniapp_read_service_v2 as read


def ident(uid=1):
    return TelegramWebAppIdentity(uid, "u", "F", "L", 1, "q")


def test_calendar_orders_and_order_detail(monkeypatch) -> None:
    monkeypatch.setattr(read.legacy, "calendar", lambda identity, **kwargs: {"calendar": kwargs})
    assert read.calendar(ident(), limit=5, currency="USD")["calendar"]["limit"] == 5

    class Commerce:
        def list_for_user(self, uid, **kwargs):
            return {"items": [
                {"id": "o1", "plan_name": "VIP", "status": "pending", "amount_toman": 10, "receipt_path": "/secret"},
                {"id": "o2", "plan_name": "Other", "status": "approved"},
            ], "next_cursor": None}
        def get(self, oid, user_id=None):
            return {"id": oid, "user_id": user_id, "status": "pending", "receipt_path": "/secret"} if oid != "missing" else None
    monkeypatch.setattr(read, "CommerceRepository", Commerce)
    page = read.orders(ident(), query="vip")
    assert [row["id"] for row in page["items"]] == ["o1"]
    assert "receipt_path" not in page["items"][0]
    assert read.order(ident(), "o1")["id"] == "o1"
    with pytest.raises(ValueError, match="ORDER_NOT_FOUND"):
        read.order(ident(), "missing")


def test_user_tickets_pagination_detail_and_search(monkeypatch) -> None:
    import services.unified_support_service as support
    rows = [{"id": i, "status": "open", "subject": f"ticket {i}"} for i in range(5)]
    monkeypatch.setattr(support, "list_user_tickets", lambda *a, **k: rows)
    monkeypatch.setattr(support, "get_user_ticket", lambda uid, tid: {"id": tid, "user_id": uid} if str(tid) != "x" else None)
    page = read.tickets(ident(9), cursor="2", limit=2)
    assert [r["id"] for r in page["items"]] == [2, 3]
    assert page["next_cursor"] == "4"
    assert read.tickets(ident(), cursor="bad", limit=999)["limit"] == 100
    assert read.ticket(ident(9), 2)["user_id"] == 9
    with pytest.raises(ValueError, match="TICKET_NOT_FOUND"):
        read.ticket(ident(), "x")

    class Signals:
        def list(self, **kwargs): return {"items": [{"id": "s1", "symbol": "XAUUSD", "display_number": 1, "status": "open"}]}
    class Journal:
        def list_for_user(self, *args, **kwargs): return {"items": [{"id": "j1", "symbol": "XAUUSD", "side": "BUY", "status": "closed", "note": "gold"}]}
    monkeypatch.setattr(read, "SignalRepository", Signals)
    monkeypatch.setattr(read, "JournalRepository", Journal)
    assert read.global_search(ident(), "x")["items"] == []
    search = read.global_search(ident(), "gold")
    assert {item["type"] for item in search["items"]} == {"signal", "journal"}


def test_track_record_and_revisions_proxy(monkeypatch) -> None:
    class Signals:
        def track_record(self, **kwargs): return {"kind": "track", **kwargs}
        def revisions(self, signal_id, **kwargs): return {"kind": "revisions", "signal_id": signal_id, **kwargs}
    monkeypatch.setattr(read, "SignalRepository", Signals)
    assert read.track_record(ident(), symbol="BTCUSD")["symbol"] == "BTCUSD"
    assert read.revisions(ident(), signal_id="s1")["signal_id"] == "s1"


def test_admin_permission_and_order_sanitization(monkeypatch) -> None:
    monkeypatch.setattr(read, "_safe_shell", lambda _i: {"admin": {"available": False, "permissions": []}})
    with pytest.raises(PermissionError, match="ADMIN_PERMISSION_REQUIRED"):
        read._require_admin_permission(ident(), "payments")
    monkeypatch.setattr(read, "_safe_shell", lambda _i: {"admin": {"available": True, "permissions": ["payments"]}})
    assert read._require_admin_permission(ident(), "payments")["admin"]["available"]

    class Commerce:
        def list_all_orders(self, **kwargs):
            return {"items": [{"id": "o1", "user_id": "2", "status": "pending", "receipt_key": "r1", "storage_path": "/secret"}]}
        def get(self, oid, user_id=None): return {"id": oid, "user_id": "2", "status": "pending", "receipt_key": "r1"} if oid != "x" else None
        def get_receipt_admin(self, rid): return {"id": rid, "mime_type": "image/webp", "size_bytes": 10, "checksum": "sha", "status": "available"}
    monkeypatch.setattr(read, "CommerceRepository", Commerce)
    page = read.admin_orders(ident(), status="pending")
    assert page["items"][0]["receipt_attached"] is True
    assert "storage_path" not in page["items"][0]
    detail = read.admin_order(ident(), "o1")
    assert detail["receipt"]["view_url"].endswith("/receipt")
    with pytest.raises(ValueError, match="ORDER_NOT_FOUND"):
        read.admin_order(ident(), "x")


def test_admin_ticket_pagination_and_detail(monkeypatch) -> None:
    monkeypatch.setattr(read, "_require_admin_permission", lambda *_a: {})
    import services.unified_support_service as support
    rows = [{"id": i} for i in range(4)]
    monkeypatch.setattr(support, "list_admin_tickets", lambda **kwargs: rows)
    monkeypatch.setattr(support, "get_admin_ticket", lambda tid: {"id": tid} if str(tid) != "x" else None)
    page = read.admin_tickets(ident(), cursor="1", limit=2, priority="high", overdue_only=True)
    assert [r["id"] for r in page["items"]] == [1, 2] and page["next_cursor"] == "3"
    assert read.admin_tickets(ident(), cursor="bad", limit=200)["limit"] == 100
    assert read.admin_ticket(ident(), 1)["id"] == 1
    with pytest.raises(ValueError, match="TICKET_NOT_FOUND"):
        read.admin_ticket(ident(), "x")


def test_signal_job_dto_list_detail(monkeypatch) -> None:
    monkeypatch.setattr(read, "_require_admin_permission", lambda *_a: {})
    snapshot = {
        "scheduled_signals": [
            {"id": 1, "signal_id": "s1", "status": "failed", "target": "private", "created_at": "2", "payload": {"symbol": "BTCUSD", "side": "buy", "entry": 1, "targets": [2]}},
            {"id": 2, "status": "sent", "created_at": "1", "payload": {"symbol": "XAUUSD"}},
        ],
        "signals": [{"id": "s1", "delivered_channels": ["private"], "deliveries": [{"message_id": 1}]}],
    }
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: snapshot)
    page = read.admin_signal_jobs(ident(), status="failed", query="btc")
    assert page["items"][0]["can_retry"] is True
    assert page["items"][0]["side"] == "BUY"
    detail = read.admin_signal_job(ident(), 1)
    assert detail["delivered_channels"] == ["private"]
    with pytest.raises(ValueError, match="SIGNAL_JOB_NOT_FOUND"):
        read.admin_signal_job(ident(), 99)
    dto = read._signal_job_dto({"id": 3, "status": "pending", "payload": {"entry": 5}})
    assert dto["entries"] == [5] and dto["can_cancel"] is True


def test_admin_legacy_proxies_and_campaigns(monkeypatch) -> None:
    monkeypatch.setattr(read.legacy, "admin_operations", lambda i: {"op": i.user_id})
    monkeypatch.setattr(read.legacy, "admin_audit_logs", lambda i, **k: {"audit": k})
    monkeypatch.setattr(read.legacy, "admin_experiments", lambda i: {"experiments": []})
    monkeypatch.setattr(read.legacy, "admin_experiment_detail", lambda i, eid: {"id": eid})
    assert read.admin_operations(ident())["op"] == 1
    assert read.admin_audit_logs(ident(), query="x")["audit"]["query"] == "x"
    assert read.admin_experiments(ident())["experiments"] == []
    assert read.admin_experiment_detail(ident(), 2)["id"] == 2

    monkeypatch.setattr(read, "_require_campaign_admin", lambda _i: {"campaigns": True})
    import modules.campaign_studio as campaigns
    monkeypatch.setattr(campaigns, "campaign_studio_summary", lambda db: {"active": 1, "latest": [{"id": "c1"}, {"id": "bad"}]})
    def report(db, cid):
        if cid == "bad": raise ValueError("bad")
        return {"campaign": {"id": cid, "name": "C"}, "audience_size": 10, "sent": 8, "measurement": {"source": "x"}}
    monkeypatch.setattr(campaigns, "marketing_campaign_report", report)
    page = read.admin_campaigns(ident())
    assert page["summary"]["active"] == 1 and len(page["items"]) == 1
    detail = read.admin_campaign_detail(ident(), "c1")
    assert detail["id"] == "c1" and detail["metrics"]["sent"] == 8


def test_expansion_degrades_individual_builders(monkeypatch) -> None:
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: {})
    import modules.platform_registry as registry
    import modules.platform_expansion as expansion
    import services.risk_coach_service as risk_coach
    monkeypatch.setattr(registry, "platform_matrix", lambda db: {"ok": True})
    monkeypatch.setattr(risk_coach, "consolidated_behavioral_report", lambda uid: {"uid": uid})
    monkeypatch.setattr(expansion, "paper_arena_snapshot", lambda db, uid: {"accounts": [{"id": "a1", "title": "A"}, {"id": "bad", "title": "B"}]})
    monkeypatch.setattr(expansion, "local_market_intelligence", lambda db: {"market": True})
    monkeypatch.setattr(expansion, "verified_public_performance", lambda db: (_ for _ in ()).throw(ValueError("unavailable")))
    monkeypatch.setattr(expansion, "prop_guardian_snapshot", lambda db, uid, aid: {"status": "safe"} if aid == "a1" else (_ for _ in ()).throw(ValueError("bad")))
    result = read.expansion(ident(8))
    assert result["matrix"]["ok"] is True
    assert result["public_performance"]["status"] == "unavailable"
    assert result["prop_guardian"]["accounts"][0]["status"] == "safe"
    assert result["prop_guardian"]["accounts"][1]["status"] == "unavailable"


def test_admin_integration_platform_and_capabilities_permissions(monkeypatch) -> None:
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: {})
    monkeypatch.setattr(read, "is_any_admin", lambda *_a: False)
    with pytest.raises(PermissionError):
        read.admin_integration(ident())
    with pytest.raises(PermissionError):
        read.admin_platform(ident())

    monkeypatch.setattr(read, "is_any_admin", lambda *_a: True)
    import modules.admin_access as access
    import services.integration_health_service as health
    import modules.platform_expansion as expansion
    monkeypatch.setattr(access, "has_permission", lambda *_a: True)
    monkeypatch.setattr(health, "integration_snapshot", lambda: {"healthy": True})
    monkeypatch.setattr(expansion, "platform_dashboard", lambda db: {"platform": True})
    assert read.admin_integration(ident())["healthy"] is True
    assert read.admin_platform(ident())["platform"] is True

    monkeypatch.setattr(read, "_safe_shell", lambda _i: {"admin": {"available": False}})
    with pytest.raises(PermissionError, match="ADMIN_REQUIRED"):
        read.admin_capabilities(ident())


def test_admin_named_signal_period_reads(monkeypatch) -> None:
    snapshot = {
        "signal_cycle": {
            "current_id": 1,
            "name": "کمپین فعال",
            "status": "active",
            "started_at": "2026-01-01T00:00:00+00:00",
            "started_by": "1",
            "next_number": 2,
            "next_numbers": {"forex": 2, "crypto": 1},
            "periods": [{"id": 1, "name": "کمپین فعال", "status": "active"}],
            "reset_history": [],
        },
        "signals": [{"id": 1, "cycle_id": 1, "display_number": 1, "symbol": "XAUUSD", "market_category": "forex"}],
        "signal_archive": [],
        "scheduled_signals": [],
    }
    monkeypatch.setattr(read, "read_db_sections", lambda _sections: snapshot)
    monkeypatch.setattr(read, "is_any_admin", lambda *_a: True)
    monkeypatch.setattr(read, "has_permission", lambda *_a: True)

    page = read.admin_signal_cycles(ident(), limit=20)
    assert page["current"]["name"] == "کمپین فعال"
    assert page["items"][0]["stats"]["total"] == 1
    detail = read.admin_signal_cycle_detail(ident(), 1, limit=20)
    assert detail["total"] == 1
    assert detail["items"][0]["symbol"] == "XAUUSD"
