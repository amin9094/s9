from __future__ import annotations

import pytest

from modules import portfolio


def test_journal_create_validate_find_and_audit() -> None:
    db = {}
    row = portfolio.add_journal_entry(
        db, 1, symbol="XAU/USD", side="BUY", entry_price=2400, actual_stop=2390,
        volume=1, entry_reason_type="personal_analysis", entry_reason="breakout",
        tags=["gold", "london"], note="test",
    )
    assert row["symbol"] == "XAUUSD"
    assert row["initial_risk_unit"] == 10
    assert row["audit"][0]["event"] == "created"
    assert portfolio.find_journal_entry(db, 1, row["id"])["id"] == row["id"]
    assert portfolio.find_journal_entry(db, 1, "bad") is None
    with pytest.raises(ValueError, match="INVALID_TRADE_SIDE"):
        portfolio.add_journal_entry(db, 1, symbol="EURUSD", side="HOLD")
    with pytest.raises(ValueError, match="INVALID_JOURNAL_STATUS"):
        portfolio.add_journal_entry(db, 1, symbol="EURUSD", status="bad")
    from modules.admin_control_center import module_state
    module_state(db, "journal")["enabled"] = False
    with pytest.raises(ValueError, match="JOURNAL_DISABLED"):
        portfolio.add_journal_entry(db, 1, symbol="EURUSD")


def test_signal_journal_idempotency_and_void(monkeypatch) -> None:
    db = {}
    signal = {"id": 12, "display_number": 7, "symbol": "BTCUSD", "side": "BUY", "entry": 60000, "stop": 59000}
    monkeypatch.setattr("modules.trading_os.parse_signal_entries", lambda _signal: {"planned_entry": 60000})
    first = portfolio.ensure_signal_journal_entry(db, 2, signal)
    assert first["source"] == "channel_signal"
    assert portfolio.ensure_signal_journal_entry(db, 2, signal)["id"] == first["id"]
    assert portfolio.void_signal_journal_entry(db, 2, 12, reason="skipped") == 1
    assert first["status"] == "voided"
    assert portfolio.void_signal_journal_entry(db, 2, 12) == 0

    position = {"id": 9, "account_id": 1, "symbol": "BTCUSD", "side": "BUY", "planned_entry": 60000, "actual_entry": 60100, "actual_stop": 59000, "actual_volume": 0.5}
    second = portfolio.ensure_signal_journal_entry(db, 2, {**signal, "id": 13}, position=position)
    assert second["position_id"] == 9 and second["actual_entry"] == 60100


def test_journal_result_partial_archive_stats_and_csv() -> None:
    db = {}
    win = portfolio.add_journal_entry(db, 3, symbol="EURUSD", side="BUY", entry_price=1.1, actual_stop=1.09, volume=2, entry_reason_type="personal_analysis", entry_reason="trend")
    partial = portfolio.add_partial_close(db, 3, win["id"], volume=0.5, exit_price=1.11, pnl_amount=20)
    assert partial["status"] == "partial" and partial["remaining_volume"] == 1.5
    closed = portfolio.add_partial_close(db, 3, win["id"], volume=1.5, exit_price=1.12, pnl_amount=80)
    assert closed["status"] == "closed" and closed["pnl_amount"] == 100
    closed = portfolio.update_journal_result(db, 3, win["id"], pnl_percent=2, exit_price=1.12, pnl_amount=100)
    assert closed["result_r"] == 2

    loss = portfolio.add_journal_entry(db, 3, symbol="XAUUSD", side="SELL", entry_price=2400, actual_stop=2410, volume=1, entry_reason_type="channel_signal", entry_reason="signal")
    updated = portfolio.update_journal_result(db, 3, loss["id"], pnl_percent=-1, exit_price=2410, pnl_amount=-100, fees=2, commission=1, swap=0.5)
    assert updated["result_r"] == -1
    stats = portfolio.journal_stats(db, 3)
    assert stats["closed"] == 2
    assert stats["losses"] == 1
    assert stats["costs"] == pytest.approx(3.5)
    assert b"EURUSD" in portfolio.journal_csv(db, 3)
    assert portfolio.delete_journal_entry(db, 3, loss["id"]) is True
    assert portfolio.delete_journal_entry(db, 3, loss["id"]) is False
    with pytest.raises(ValueError, match="JOURNAL_ENTRY_NOT_OPEN"):
        portfolio.add_partial_close(db, 3, loss["id"], volume=1, exit_price=1, pnl_amount=0)
    with pytest.raises(ValueError, match="INVALID_PNL_PERCENT"):
        portfolio.update_journal_result(db, 3, win["id"], pnl_percent=200000)


def test_market_scoped_views_import_and_admin_summary() -> None:
    db = {}
    portfolio.toggle_watchlist_symbol(db, 4, "BTCUSD")
    portfolio.toggle_watchlist_symbol(db, 4, "XAUUSD")
    assert [r["symbol"] for r in portfolio.watchlist_by_market(db, 4, "crypto")] == ["BTCUSD"]
    assert portfolio.clear_watchlist_market(db, 4, "forex") == 1

    csv_content = "symbol,side,entry_price,volume,entry_reason_type,entry_reason,result_r\nBTCUSD,BUY,60000,1,personal_analysis,trend,2\n,BUY,1,1,manual,bad,\n"
    imported = portfolio.import_journal_csv(db, 4, csv_content)
    assert imported["imported"] == 1 and imported["errors"]
    crypto_rows = portfolio.journal_entries_by_market(db, 4, "crypto")
    assert len(crypto_rows) == 1
    assert portfolio.journal_stats_by_market(db, 4, "crypto")["total"] == 1
    assert b"BTCUSD" in portfolio.journal_csv_by_market(db, 4, "crypto")
    summary = portfolio.portfolio_admin_summary(db)
    assert summary["watchlist_users"] == 1
    assert summary["journal_entries"] == 1


def test_admin_notes_and_limits() -> None:
    db = {}
    note = portfolio.add_journal_admin_note(db, 5, 99, "reviewed")
    assert note["admin_id"] == "99"
    with pytest.raises(ValueError, match="EMPTY_NOTE"):
        portfolio.add_journal_admin_note(db, 5, 99, "  ")
    from modules.admin_control_center import module_state
    module_state(db, "journal")["max_entries"] = 1
    portfolio.add_journal_entry(db, 5, symbol="EURUSD")
    with pytest.raises(ValueError, match="JOURNAL_LIMIT_REACHED"):
        portfolio.add_journal_entry(db, 5, symbol="GBPUSD")
