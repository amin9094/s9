from __future__ import annotations

from types import SimpleNamespace
from copy import deepcopy

from core.db import DEFAULT_DB
from modules.advanced_features import reset_signal_result
from modules.management_suite import set_signal_result_media, set_signal_result_media_deliveries
from services.actions_v2.trading import signal_choice_update
from services.signal_projection_service import canonical_signal_event, project_signal_update


class _Signals:
    def __init__(self, row):
        self.row = row

    def get(self, _signal_id):
        return dict(self.row)

    def upsert(self, row):
        self.row = dict(row)
        return dict(row)


class _Preferences:
    def __init__(self):
        self.values = {}

    def get(self, user_id, key, default=None):
        return self.values.get((str(user_id), key), default)

    def set(self, user_id, key, value):
        self.values[(str(user_id), key)] = value


class _Events:
    def __init__(self):
        self.calls = []

    def append(self, user_id, event_type, payload, **kwargs):
        self.calls.append((user_id, event_type, payload, kwargs))
        return {"event_id": "evt-1"}


def test_signal_projection_normalizes_final_and_live_events() -> None:
    assert canonical_signal_event({"status": "tp1"}, "signal.lifecycle_updated") == "signal.updated"
    assert canonical_signal_event({"status": "stopped"}, "signal.result_updated") == "signal.closed"

    events = _Events()
    row = project_signal_update(
        {"id": "41", "symbol": "XAUUSD", "status": "manual_close", "updated_at": "2026-08-05T12:00:00Z"},
        "signal.tracker_confirmed",
        signals=_Signals({}),
        events=events,
    )
    assert row["id"] == "41"
    assert events.calls[0][1] == "signal.closed"
    assert events.calls[0][2]["source_event"] == "signal.tracker_confirmed"


def test_closed_signal_choice_is_retrospective_and_never_opens_a_position(sqlite_engine) -> None:
    preferences = _Preferences()
    context = SimpleNamespace(
        engine=sqlite_engine,
        user_id="77",
        payload={"signal_id": "41", "choice": "taken", "retrospective": True},
        signals=_Signals({"id": "41", "symbol": "XAUUSD", "status": "closed"}),
        preferences=preferences,
    )
    result = signal_choice_update(context)
    assert result["retrospective"] is True
    assert result["position"] is None
    assert result["journal"] is None
    assert result["choice"]["choice"] == "taken"
    assert preferences.get("77", "user_signal_choices")["41"]["retrospective"] is True


def test_miniapp_source_has_closed_tense_and_all_signal_sync_events() -> None:
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    experience = (root / "webapp" / "src" / "experience-v2.js").read_text(encoding="utf-8")
    events = (root / "webapp" / "src" / "shell-events.js").read_text(encoding="utf-8")
    assert 'data-retro-choice="taken">گرفتم' in experience
    assert 'data-retro-choice="skipped">نگرفتم' in experience
    for name in ("signal.updated", "signal.lifecycle_updated", "signal.result_updated", "signal.partial_closed"):
        assert name in events


def test_terminal_signal_result_requires_and_persists_chart_evidence() -> None:
    db = deepcopy(DEFAULT_DB)
    db["signals"] = [{
        "id": 91,
        "display_number": 7,
        "symbol": "XAUUSD",
        "side": "buy",
        "entry": "2300",
        "stop": "2290",
        "targets": ["2310", "2320"],
        "status": "open",
        "risk": 1,
    }]
    row = set_signal_result_media(
        db,
        91,
        5,
        photo_file_id="photo-result-1",
        photo_unique_id="unique-1",
        width=1280,
        height=720,
        caption="فول تی پی تأیید شد",
        lifecycle_status="tp2",
    )
    assert row["status"] == "target_complete"
    assert row["result_chart_photo_file_id"] == "photo-result-1"
    assert row["result_chart_caption"] == "فول تی پی تأیید شد"
    assert row["result_chart_added_by"] == "5"
    row = set_signal_result_media_deliveries(db, 91, [{"chat_id": "-1001", "message_id": 44}])
    assert row["result_chart_deliveries"][0]["message_id"] == 44

    reset = reset_signal_result(db, 91, 5)
    assert reset["status"] == "open"
    assert "result_chart_photo_file_id" not in reset
    assert reset["result_history"][-1]["result_chart_photo_file_id"] == "photo-result-1"


def test_result_chart_bot_and_miniapp_contract_is_wired() -> None:
    from pathlib import Path

    root = Path(__file__).resolve().parents[1]
    runtime = (root / "bot_runtime" / "runtime_jobs.py").read_text(encoding="utf-8")
    miniapp = (root / "services" / "miniapp_read_service_v2.py").read_text(encoding="utf-8")
    server = (root / "core" / "miniapp_server.py").read_text(encoding="utf-8")
    frontend = (root / "webapp" / "src" / "signals-home.js").read_text(encoding="utf-8")
    assert "SIGNAL_RESULT_MEDIA_INPUT" in runtime
    assert "signal_result_media_start" in runtime
    assert "result_chart_available" in miniapp
    assert '/api/v1/signals/{signal_id}/result-chart' in server
    assert "result_chart_caption" in frontend
