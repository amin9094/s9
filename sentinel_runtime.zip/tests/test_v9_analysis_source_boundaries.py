"""Source identity and research/execution boundaries using synthetic HTTP data."""
from dataclasses import replace
from decimal import Decimal as D
from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from modules.canonical_market import Candle,Quote
from modules.strategies.common import Parameters
from repositories.v2.market_evidence import MarketEvidenceRepository
from services import canonical_market_service as market,strategy_analysis_service as analysis
from tests.test_v9_strategy_engines import bars


@pytest.mark.asyncio
@pytest.mark.parametrize('symbol,product,native',[('XAUUSD','spot','XAU/USD'),('EURUSD','spot','EUR/USD'),('US30','cash_index','DJI')])
async def test_twelve_native_utc_identity_never_authenticates_reported_fx_volume(monkeypatch,symbol,product,native):
    clock=[1767312000000]
    monkeypatch.setattr(market.time,'time',lambda:clock[0]/1000)
    monkeypatch.setenv('TWELVE_DATA_API_KEY','SYNTHETIC_ONLY')
    request=AsyncMock(return_value={'values':[
        {'datetime':'2026-01-01 00:10:00','open':'100','high':'102','low':'99','close':'101','volume':'999'},
        {'datetime':'2026-01-01 00:05:00','open':'100','high':'102','low':'99','close':'101','volume':'999'}]})
    monkeypatch.setattr(market,'_request',request)
    result=await market._twelve(symbol,'5m',300,None)
    assert len(result)==2 and result[0].start_ms<result[1].start_ms
    assert all(b.provider=='twelve_data' and b.product==product and b.volume is None and b.volume_kind=='unavailable' for b in result)
    params=request.call_args.args[1]
    assert params['symbol']==native and params['timezone']=='UTC' and params['interval']=='5min'
    clock[0]+=1000
    earlier=await market._twelve(symbol,'5m',300,result[1].start_ms)
    assert len(earlier)==1 and replace(earlier[0],available_ms=result[0].available_ms)==result[0]
    assert earlier[0].available_ms==clock[0]>result[0].available_ms
    assert request.call_args.args[1]['end_date']=='2026-01-01 00:09:59'


@pytest.mark.asyncio
async def test_twelve_missing_key_and_empty_history_have_distinct_failures(monkeypatch):
    request=AsyncMock(return_value={'values':[]})
    monkeypatch.setattr(market,'_request',request)
    monkeypatch.delenv('TWELVE_DATA_API_KEY',raising=False)
    with pytest.raises(market.MarketUnavailable,match='API_KEY_MISSING'):
        await market._twelve('XAUUSD','5m',300,None)
    request.assert_not_awaited()
    monkeypatch.setenv('TWELVE_DATA_API_KEY','SYNTHETIC_ONLY')
    with pytest.raises(market.MarketUnavailable,match='BARS_UNAVAILABLE'):
        await market._twelve('XAUUSD','5m',300,None)


@pytest.mark.asyncio
async def test_cash_index_native_session_offset_delay_and_cursor_are_preserved(monkeypatch):
    raw={'chart':{'result':[{'meta':{'symbol':'^DJI','exchangeDataDelayedBy':15},
        'timestamp':[5400,9000], 'indicators':{'quote':[{'open':[100,101], 'high':[102,103], 'low':[99,100],'close':[101,102]}]}}]}}
    request=AsyncMock(return_value=raw)
    monkeypatch.setattr(market,'_request',request)
    monkeypatch.setattr(market.time,'time',lambda:9000)
    result=await market._yahoo_index('US30','1h',300,None)
    assert len(result)==2 and result[0].start_ms==5400000 and result[0].alignment_offset_ms==1800000
    assert result[0].is_closed and not result[-1].is_closed
    assert result[0].product=='cash_index' and 'DELAYED_INDEX_FEED' in result[0].quality_flags
    assert 'SESSION_CALENDAR_CONFIRMATION_REQUIRED' in result[0].quality_flags
    assert request.call_args.args[1]['range']=='3mo'
    assert len(await market._yahoo_index('US30','1h',300,9000000))==1
    with pytest.raises(market.MarketUnavailable,match='4H_UNAVAILABLE'):
        await market._yahoo_index('US30','4h',300,None)
    raw['chart']['result'][0]['meta']['symbol']='YM=F'
    with pytest.raises(market.MarketUnavailable,match='SOURCE_SYMBOL_MISMATCH'):
        await market._yahoo_index('US30','1h',300,None)


def native_bars(provider):
    return [replace(b,symbol='BTCUSDT',provider=provider,venue=provider+'_spot_USDT',source_id=f'{provider}-synthetic-{i}') for i,b in enumerate(bars())]


def metadata_request(provider,now,*,bad=False):
    async def request(url,params=None,headers=None):
        if provider=='kraken':
            if url.endswith('/AssetPairs'):
                return {'result':{'XBTUSDT':{'tick_size':'.01'}}}
            return {'result':{'XBTUSDT':{'a':['99' if bad else '101'],'b':['100']}}}
        if url.endswith('/instruments'):
            return {'code':'0','data':[{'instId':'BTC-USDT','state':'live','tickSz':'.01'}]}
        return {'code':'0','data':[{'instId':'BTC-USDT','askPx':'101','bidPx':'100','ts':str(now-6001 if bad else now)}]}
    return request


@pytest.mark.asyncio
@pytest.mark.parametrize('provider',['kraken','okx'])
async def test_native_crypto_research_still_requires_matching_metadata_and_never_claims_fill(sqlite_engine,monkeypatch,provider):
    from services import strategy_quote_owner
    from repositories.v2 import market_evidence
    data=native_bars(provider);now=data[-1].available_ms
    async def history(symbol,tf,**kwargs):
        assert symbol=='BTCUSDT'
        if tf=='1m':
            assert kwargs['provider']==provider
            return []
        return data
    monkeypatch.setattr(analysis,'historical_bars',history)
    monkeypatch.setattr(analysis.time,'time',lambda:now/1000)
    monkeypatch.setattr(market,'_request',metadata_request(provider,now))
    monkeypatch.setattr(strategy_quote_owner,'current_owner',lambda:None)
    monkeypatch.setattr(market_evidence,'normalized_engine',lambda:sqlite_engine)
    result=await analysis.research_analysis('BTCUSDT','5m',engine_parameters=(('order_block',Parameters()),))
    assert result['production_qualified'] is False and result.get('analysis_mode')!='CANDLE_ONLY'
    assert not any(row.get('state')=='VERIFIED_ENTRY' for row in result['results'])
    assert len(MarketEvidenceRepository(sqlite_engine).candles('BTCUSDT',provider,'5m'))==120
    monkeypatch.setattr(market,'_request',metadata_request(provider,now,bad=True))
    blocked=await analysis.research_analysis('BTCUSDT','5m')
    assert blocked['reason']=='MATCHING_SPREAD_AND_TICK_SIZE_UNVERIFIED'


@pytest.mark.asyncio
async def test_profile_receipt_refreshes_same_market_and_only_live_non_snapshot_quote_enters_context(sqlite_engine,monkeypatch):
    from services import strategy_quote_owner
    from modules import strategy_engines
    from repositories.v2 import market_evidence
    data=native_bars('kraken');now=data[-1].available_ms+1000
    minute=[]
    for i in range(10):
        start=data[0].start_ms+i*60000
        minute.append(Candle('BTCUSDT','kraken','kraken_spot_USDT','spot','1m',start,start+60000,
                             100,101,99,100,10,'traded',True,now,f'profile-synthetic-{i}'))
    quote=Quote('BTCUSDT','kraken','kraken_spot_USDT','spot',now,now,D(100),D('100.01'),D('.01'),'SYNTHETIC_ONLY')
    journal=SimpleNamespace(failure=None,rows=[SimpleNamespace(quote=quote,snapshot=False)])
    owner=SimpleNamespace(ensure=AsyncMock(return_value=True),journal_for=lambda *args:journal)
    monkeypatch.setattr(strategy_quote_owner,'current_owner',lambda:owner)
    monkeypatch.setattr(analysis.time,'time',lambda:now/1000)
    async def history(symbol,tf,**kwargs):return minute if tf=='1m' else data
    monkeypatch.setattr(analysis,'historical_bars',history)
    refreshed=AsyncMock(return_value=data)
    monkeypatch.setattr(market,'_historical_bars',refreshed)
    monkeypatch.setattr(market_evidence,'normalized_engine',lambda:sqlite_engine)
    original=strategy_engines.evaluate_all;seen=[]
    def evaluate(context):
        seen.append(context)
        return original(context)
    monkeypatch.setattr(strategy_engines,'evaluate_all',evaluate)
    instrument={'verified':True,'provider':'kraken','tick_size':'.01','spread':'.5','pip_size':'.01'}
    result=await analysis.research_analysis('BTCUSDT','5m',instrument=instrument)
    context=seen[0]
    assert context.profile_candles==tuple(minute) and context.current_quote is quote and context.spread==D('.01')
    assert context.cutoff_ms==now and refreshed.call_args.kwargs['provider']=='kraken'
    assert result['production_qualified'] is False
    assert len(MarketEvidenceRepository(sqlite_engine).candles('BTCUSDT','kraken','1m'))==10
    journal.rows[0].snapshot=True
    seen.clear()
    await analysis.research_analysis('BTCUSDT','5m',instrument=instrument)
    assert seen[0].current_quote is None


@pytest.mark.asyncio
@pytest.mark.parametrize('mode,reason',[('warmup','INDICATOR_WARMUP_INCOMPLETE'),('stale','MARKET_DATA_STALE_OR_SESSION_CLOSED'),('mixed','INVALID_ANALYSIS_CANDLES')])
async def test_candle_only_unusable_source_becomes_review_not_generic_server_error(monkeypatch,mode,reason):
    from tests.test_v9_combined_free_sources import price_bars
    data=price_bars();now=data[-1].available_ms
    if mode=='warmup':data=data[-50:]
    if mode=='stale':now+=1200000
    if mode=='mixed':data[10]=replace(data[10],product='futures')
    monkeypatch.setattr(analysis,'historical_bars',AsyncMock(return_value=data))
    monkeypatch.setattr(analysis.time,'time',lambda:now/1000)
    result=await analysis.research_analysis('EURUSD','5m')
    assert result['state']=='NEEDS_REVIEW' and result['reason']==reason and result['results']==[]


@pytest.mark.asyncio
@pytest.mark.parametrize('reference_failed',[False,True])
async def test_gold_reference_failure_does_not_replace_or_disable_gold_candle_analysis(sqlite_engine,monkeypatch,reference_failed):
    from tests.test_v9_combined_free_sources import price_bars
    from repositories.v2 import market_evidence
    from services import market_reference_service
    data=price_bars('twelve_data','XAUUSD');now=data[-1].available_ms
    monkeypatch.setattr(analysis,'historical_bars',AsyncMock(return_value=data))
    monkeypatch.setattr(analysis.time,'time',lambda:now/1000)
    monkeypatch.setattr(market_evidence,'normalized_engine',lambda:sqlite_engine)
    reference=AsyncMock(side_effect=RuntimeError('SYNTHETIC FAILURE')) if reference_failed else AsyncMock(return_value={'price':'100.1','execution_eligible':False})
    monkeypatch.setattr(market_reference_service,'gold_reference',reference)
    result=await analysis.research_analysis('XAUUSD','5m')
    assert result['analysis_mode']=='CANDLE_ONLY' and result['provider']=='twelve_data'
    assert not result['independent_reference']['execution_eligible']
    if reference_failed:assert result['independent_reference']['state']=='UNAVAILABLE'

