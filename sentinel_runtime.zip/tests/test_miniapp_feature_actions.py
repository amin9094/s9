from __future__ import annotations

from types import SimpleNamespace

import pytest

from tests.telegram_test_stub import install as install_telegram_test_stub
install_telegram_test_stub()

from core.webapp_auth import TelegramWebAppIdentity
from repositories.v2.accounts import AccountRepository
from repositories.v2.journal import JournalRepository
from repositories.v2.positions import PositionRepository
from repositories.v2.preferences import PreferenceRepository
from services.actions_v2.context import create_context
from services.actions_v2 import preferences as preference_actions
from services.actions_v2 import journal as journal_actions
from services.actions_v2 import trading as trading_actions


def identity(uid: int = 55) -> TelegramWebAppIdentity:
    return TelegramWebAppIdentity(uid, "u", "F", "L", 1, "q")


def context(sqlite_engine, action: str, payload: dict):
    return create_context(identity(), request_id=f"req-{action}", action=action, payload=payload, engine=sqlite_engine)


def test_language_rules_and_notification_preferences(sqlite_engine, monkeypatch) -> None:
    import copy
    from core.db import DEFAULT_DB
    from core.storage import engine as storage
    from modules.rules import publish_rules
    db = copy.deepcopy(DEFAULT_DB)
    monkeypatch.setattr(storage, "_ENGINE", sqlite_engine)
    monkeypatch.setattr(preference_actions, "with_db", lambda fn: fn(db))
    ctx = context(sqlite_engine, "language_update", {"language": "en"})
    assert preference_actions.language_update(ctx)["language"] == "en"
    assert db["user_profiles"][str(ctx.user_id)]["language"] == "en"
    ctx.payload = {"language": "xx"}
    with pytest.raises(ValueError, match="INVALID_LANGUAGE"):
        preference_actions.language_update(ctx)

    ctx.payload = {"signals": True, "quiet": False}
    values = preference_actions.notification_preferences_update(ctx)
    assert values["signals"] is True and values["quiet_enabled"] is False
    ctx.payload = {"impact": "high"}
    assert preference_actions.calendar_preferences_update(ctx)["impact"] == "high"

    rule = publish_rules(db, "Current published terms", 354678485, "fa")
    ctx.payload = {"version": rule["version"], "content_hash": rule["content_hash"], "language": "fa"}
    accepted = preference_actions.rules_accept(ctx)
    assert accepted["source"] == "telegram_miniapp"
    assert db["rules_acceptances"][str(ctx.user_id)]["fa"]["version"] == rule["version"]
    ctx.payload = {"version": 0, "content_hash": ""}
    with pytest.raises(ValueError, match="RULES_VERSION_CHANGED"):
        preference_actions.rules_accept(ctx)


def test_onboarding_creates_and_updates_default_account(sqlite_engine) -> None:
    payload = {
        "experience": "professional", "goal": "prop", "market": "both",
        "risk_tolerance": "balanced", "balance": 10_000, "equity": 9_900,
        "account_name": "Main", "currency": "USD",
    }
    ctx = context(sqlite_engine, "onboarding_update", payload)
    result = preference_actions.onboarding_update(ctx)
    assert result["completed"] is True
    assert result["onboarding"]["professional"] is True
    assert result["account"]["default_risk_percent"] == 1.0
    assert result["account"]["max_daily_risk_percent"] == 3.0
    assert result["account"]["max_open_risk_percent"] == 5.0
    account_id = result["account"]["id"]

    ctx.payload = {**payload, "experience": "advanced", "risk_tolerance": "conservative", "balance": 11_000, "equity": 11_100}
    updated = preference_actions.onboarding_update(ctx)
    assert updated["account"]["id"] == account_id
    assert updated["account"]["default_risk_percent"] == 0.5
    assert updated["onboarding"]["completed_at"] == result["onboarding"]["completed_at"]

    invalid_cases = [
        ({**payload, "experience": "invalid"}, "INVALID_EXPERIENCE"),
        ({**payload, "goal": "invalid"}, "INVALID_GOAL"),
        ({**payload, "market": "stocks"}, "INVALID_MARKET"),
        ({**payload, "risk_tolerance": "wild"}, "INVALID_RISK_TOLERANCE"),
        ({**payload, "balance": 0}, "ACCOUNT_BALANCE_REQUIRED"),
    ]
    for bad, code in invalid_cases:
        ctx.payload = bad
        with pytest.raises(ValueError, match=code):
            preference_actions.onboarding_update(ctx)


def test_account_creation_uses_active_rule_templates(sqlite_engine) -> None:
    personal = context(sqlite_engine, "account_upsert", {"name": "Main", "type": "personal", "balance": 10_000, "equity": 10_000})
    personal_row = trading_actions.account_upsert(personal)
    assert personal_row["rule_template_id"] == "personal-standard"

    prop = context(sqlite_engine, "account_upsert", {"name": "Challenge", "type": "prop_challenge", "balance": 25_000, "equity": 25_000})
    prop_row = trading_actions.account_upsert(prop)
    assert prop_row["rule_template_id"] == "prop-static-5-10"

    invalid = context(sqlite_engine, "account_upsert", {"name": "Broken", "type": "personal", "rule_template_id": "missing-template"})
    with pytest.raises(ValueError, match="PROP_RULE_TEMPLATE_NOT_FOUND"):
        trading_actions.account_upsert(invalid)


def test_watchlist_actions_project_legacy_and_normalized(sqlite_engine, monkeypatch) -> None:
    db = {}
    monkeypatch.setattr(preference_actions, "with_db", lambda fn: fn(db))
    ctx = context(sqlite_engine, "watchlist_toggle", {"symbol": "BTC/USDT"})
    added = preference_actions.watchlist_toggle(ctx)
    assert added["added"] is True
    assert added["item"]["symbol"] == "BTCUSD"
    assert ctx.preferences.get(ctx.user_id, "user_watchlists")[0]["symbol"] == "BTCUSD"

    ctx.payload = {"symbol": "BTCUSD", "enabled": False}
    alerts = preference_actions.watchlist_alerts(ctx)
    assert alerts["alerts_enabled"] is False
    ctx.payload = {"symbol": "BTCUSD"}
    removed = preference_actions.watchlist_remove(ctx)
    assert removed["removed"] is True and removed["items"] == []
    ctx.payload = {"symbol": ""}
    with pytest.raises(ValueError, match="INVALID_SYMBOL"):
        preference_actions.watchlist_toggle(ctx)


def test_journal_add_result_partial_archive_lifecycle(sqlite_engine, monkeypatch) -> None:
    mirrors = []
    monkeypatch.setattr(journal_actions, "mirror_normalized_journal_create", lambda uid, row: mirrors.append(("create", uid, row["id"])) or {"id": 900})
    monkeypatch.setattr(journal_actions, "mirror_normalized_journal_result", lambda uid, row: mirrors.append(("result", uid, row["id"])))
    monkeypatch.setattr(journal_actions, "mirror_normalized_journal_partial", lambda uid, row, **kwargs: mirrors.append(("partial", uid, row["id"], kwargs)))
    monkeypatch.setattr(journal_actions, "mirror_normalized_journal_archive", lambda uid, row: mirrors.append(("archive", uid, row["id"])))

    ctx = context(sqlite_engine, "journal_add", {
        "id": "j-1", "symbol": "XAU/USD", "side": "BUY", "volume": 1,
        "entry_price": 2400, "actual_stop": 2390, "entry_reason_type": "personal_analysis",
        "entry_reason": "breakout",
    })
    added = journal_actions.journal_add(ctx)
    assert added["legacy_journal_id"] == 900
    assert added["stop_loss"] == 2390
    assert mirrors[0][0] == "create"

    ctx.payload = {"id": added["id"], "pnl_amount": 100, "pnl_percent": 1, "exit_price": 2420, "fees": 1}
    closed = journal_actions.journal_result_update(ctx)
    assert closed["status"] == "closed"
    assert closed["result_r"] == 2.0
    assert any(item[0] == "result" for item in mirrors)

    ctx.payload = {"id": "missing"}
    with pytest.raises(ValueError, match="JOURNAL_ENTRY_NOT_FOUND"):
        journal_actions.journal_result_update(ctx)
    with pytest.raises(ValueError, match="JOURNAL_ENTRY_NOT_FOUND"):
        journal_actions.journal_delete(ctx)

    ctx.payload = {"id": added["id"]}
    archived = journal_actions.journal_delete(ctx)
    assert archived["status"] == "archived"
    assert any(item[0] == "archive" for item in mirrors)


def test_journal_partial_close_without_position_and_validation(sqlite_engine, monkeypatch) -> None:
    monkeypatch.setattr(journal_actions, "mirror_normalized_journal_create", lambda uid, row: {"id": 1})
    monkeypatch.setattr(journal_actions, "mirror_normalized_journal_partial", lambda *a, **k: None)
    ctx = context(sqlite_engine, "journal_add", {"id": "j2", "symbol": "EURUSD", "side": "SELL", "volume": 2, "entry_price": 1.1, "stop_loss": 1.11, "entry_reason_type": "personal_analysis", "entry_reason": "trend"})
    row = journal_actions.journal_add(ctx)
    ctx.payload = {"id": row["id"], "volume": 0.5, "pnl_amount": 20, "exit_price": 1.09}
    partial = journal_actions.journal_partial_close(ctx)
    assert partial["journal"]["status"] == "partial"
    assert partial["journal"]["remaining_volume"] == pytest.approx(1.5)
    ctx.payload = {"id": row["id"], "volume": 0}
    with pytest.raises(ValueError, match="INVALID_CLOSE_VOLUME"):
        journal_actions.journal_partial_close(ctx)
    ctx.payload = {"id": "missing", "volume": 1}
    with pytest.raises(ValueError, match="JOURNAL_ENTRY_NOT_FOUND"):
        journal_actions.journal_partial_close(ctx)


def test_csv_and_broker_import_bounded_and_error_tolerant(sqlite_engine, monkeypatch) -> None:
    monkeypatch.setattr(journal_actions, "mirror_normalized_journal_create", lambda uid, row: {"id": row["id"]})
    ctx = context(sqlite_engine, "journal_import_csv", {
        "content": "symbol,side,volume,entry_price,stop_loss\nBTCUSD,BUY,1,60000,59000\n,BUY,1,1,0\n"
    })
    result = journal_actions.journal_import_csv(ctx)
    assert result["parsed"] == 2
    assert result["imported"] == 1
    assert result["errors"]

    monkeypatch.setattr(journal_actions, "parse_broker_statement", lambda content, filename: [{"symbol": "ETHUSD", "side": "SELL", "volume": 1, "entry_price": 3000, "stop_loss": 3100}])
    ctx.payload = {"content": "statement", "filename": "mt5.csv", "broker": "MT5"}
    broker = journal_actions.broker_import(ctx)
    assert broker["imported"] == 1 and broker["broker"] == "MT5"

    ctx.payload = {"content": "x" * 5_000_001}
    with pytest.raises(ValueError, match="IMPORT_TOO_LARGE"):
        journal_actions.journal_import_csv(ctx)
    with pytest.raises(ValueError, match="IMPORT_TOO_LARGE"):
        journal_actions.broker_import(ctx)
