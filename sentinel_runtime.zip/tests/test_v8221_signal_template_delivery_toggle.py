from __future__ import annotations

import asyncio
from pathlib import Path
from types import SimpleNamespace

from modules.admin_control_center import module_state, toggle_control_value
from modules.signal import send_signal_with_receipts


class _Bot:
    def __init__(self) -> None:
        self.media_group_calls: list[dict] = []
        self.photo_calls: list[tuple] = []
        self.message_calls: list[tuple] = []

    async def send_media_group(self, *, chat_id, media):
        self.media_group_calls.append({"chat_id": chat_id, "media": media})
        return [SimpleNamespace(message_id=101), SimpleNamespace(message_id=102)]

    async def send_photo(self, *args, **kwargs):
        self.photo_calls.append((args, kwargs))
        return SimpleNamespace(message_id=201)

    async def send_message(self, *args, **kwargs):
        self.message_calls.append((args, kwargs))
        return SimpleNamespace(message_id=301)


def test_signal_template_delivery_setting_defaults_on_and_toggles() -> None:
    db: dict = {}
    assert module_state(db, "signals")["send_template_image"] is True
    assert toggle_control_value(db, "signals", "send_template_image", 123) is False
    assert module_state(db, "signals")["send_template_image"] is False
    assert toggle_control_value(db, "signals", "send_template_image", 123) is True


def test_template_off_with_chart_sends_only_admin_chart(tmp_path: Path) -> None:
    poster = tmp_path / "poster.png"
    poster.write_bytes(b"generated-template")
    bot = _Bot()

    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot,
            {
                "text": "<b>SELL</b>",
                "image_path": str(poster),
                "chart_photo_file_id": "chart-file-id",
                "send_template_image": False,
            },
            "public",
            public_channel_id=-100123,
            private_channel_id=0,
        )
    )

    assert errors == []
    assert bot.media_group_calls == []
    assert len(bot.photo_calls) == 1
    args, kwargs = bot.photo_calls[0]
    assert args == (-100123, "chart-file-id")
    assert kwargs["caption"] == "<b>SELL</b>"
    assert deliveries[0]["message_type"] == "chart_photo"
    assert deliveries[0]["chart_message_id"] == 201
    assert not poster.exists(), "unused generated template must still be cleaned"


def test_template_off_without_chart_sends_text_only(tmp_path: Path) -> None:
    poster = tmp_path / "poster.png"
    poster.write_bytes(b"generated-template")
    bot = _Bot()

    errors, deliveries = asyncio.run(
        send_signal_with_receipts(
            bot,
            {
                "text": "signal text",
                "image_path": str(poster),
                "send_template_image": False,
            },
            "public",
            public_channel_id=-100456,
            private_channel_id=0,
        )
    )

    assert errors == []
    assert bot.media_group_calls == []
    assert bot.photo_calls == []
    assert len(bot.message_calls) == 1
    assert deliveries[0]["message_type"] == "text"
    assert deliveries[0]["message_id"] == 301
    assert not poster.exists()


def test_template_toggle_button_and_route_are_registered() -> None:
    growth = Path("bot_runtime/growth_campaigns.py").read_text(encoding="utf-8")
    routes = Path("handlers/callback_routes.py").read_text(encoding="utf-8")
    controls = Path("modules/admin_control_center.py").read_text(encoding="utf-8")

    assert 'B("send_template_image", "ارسال تصویر قالب همراه سیگنال", True)' in controls
    assert 'callback_data="sig_tpl_delivery_toggle"' in growth
    assert "async def signal_template_delivery_toggle" in growth
    assert "signal[\"send_template_image\"] = send_template_image" in growth
    assert "'^sig_tpl_delivery_toggle$'" in routes
