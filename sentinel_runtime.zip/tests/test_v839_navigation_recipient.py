from types import SimpleNamespace
from unittest.mock import AsyncMock
import copy

import pytest
import bot  # noqa: F401 -- initialize the existing shared feature facade
from config import SETTINGS
from bot_runtime import navigation as nav, account_support, creation as runtime
from modules import admin_creation as wizard
from modules.admin_access import ALL_PERMISSIONS, PERMISSION_CRM_VIEW
from modules.reward_wallet import wallet_items, wallet_unread_keys
from tests.test_master_upgrade import state, OWNER  # noqa: F401


def callbacks(rows):
    return [button.callback_data for row in rows for button in row]


@pytest.mark.parametrize('language',['fa','en'])
def test_rewards_have_one_entry_and_keep_priority(monkeypatch,language):
    db={'users':{'1':{}},'user_rewards':[{'id':1,'user_id':'1','type':'points'}]}
    monkeypatch.setattr(nav,'load_db',lambda:db)
    monkeypatch.setattr(nav,'_language_for_user',lambda _:language)
    monkeypatch.setattr(nav,'is_vip',lambda *_:False)
    monkeypatch.setattr(nav,'_is_any_admin',lambda _:False)
    monkeypatch.setattr(nav,'_has_any_admin_permission',lambda *_:False)
    monkeypatch.setattr(nav,'with_webapp',lambda rows:rows)
    rows=nav.main_menu(1);data=callbacks(rows)
    assert [callbacks(row and [row]) for row in rows[:4]]==[['u_vip'],['u_edu','u_calc'],['u_price','u_account'],['u_contests','u_missions']]
    assert data.count('u_rewards')==1
    assert not {'u_my_rewards','nav_user:club'} & set(data)
    assert '🔴 1' in next(b.text for row in rows for b in row if b.callback_data=='u_rewards')


def test_admin_tools_partition_once_without_category_chains(monkeypatch):
    monkeypatch.setattr(nav,'_admin_granted_permissions',lambda _:set(ALL_PERMISSIONS))
    monkeypatch.setattr(nav,'_is_owner_admin',lambda _:True)
    categories=nav._admin_navigation_categories();tools=[key for group in categories.values() for key in group['callbacks']]
    assert len(tools)==len(set(tools))
    assert set(tools)==set(nav._admin_items_by_callback())
    assert {'a_signal','sig_tpl_home','a_signal_cycle','channel_schedules','sig_board:all:0'}<=set(categories['trading']['callbacks'])
    assert {'a_crm','crm_pipeline'}<=set(categories['users']['callbacks'])
    assert {'a_campaigns','a_broadcast'}<=set(categories['content']['callbacks'])
    assert {'a_vip_plans','a_pending','a_disc'}<=set(categories['sales']['callbacks'])
    assert {'a_admins','a_approvals'}<=set(categories['system']['callbacks'])
    for category in categories:
        assert all(not key.startswith('admin_cat:') for key in callbacks(nav.admin_category_menu(category,OWNER)))


def test_limited_admin_and_owner_approval_visibility(monkeypatch):
    monkeypatch.setattr(nav,'_admin_granted_permissions',lambda _: {PERMISSION_CRM_VIEW,'two_step_approvals'})
    monkeypatch.setattr(nav,'_is_owner_admin',lambda _:False)
    root=callbacks(nav.admin_menu(9))
    assert 'admin_cat:users' in root and 'admin_cat:trading' not in root
    assert 'a_approvals' not in callbacks(nav.admin_category_menu('system',9))
    assert {'a_crm','crm_pipeline'}<=set(callbacks(nav.admin_category_menu('users',9)))


@pytest.mark.parametrize('source,category',[('a_signal','trading'),('a_crm','users'),('a_campaigns','content'),('a_vip_plans','sales'),('a_admins','system'),('a_milestones','engagement')])
def test_module_exit_returns_to_own_category(source,category):
    rows=nav._normalize_navigation_rows([[nav.InlineKeyboardButton('⬅️ برگشت',callback_data='admin_home')]],source)
    assert callbacks(rows)==[f'nb:admin_cat:{category}']
    assert callbacks(nav._normalize_navigation_rows([[nav.InlineKeyboardButton('⬅️ برگشت',callback_data='admin_home')]],f'admin_cat:{category}'))==['nb:admin_home']


def patch_handler(monkeypatch,module,db):
    async def mutate(fn):return fn(db)
    monkeypatch.setattr(module,'async_with_db',mutate)
    monkeypatch.setattr(module,'async_snapshot',AsyncMock(side_effect=lambda:copy.deepcopy(db)))
    monkeypatch.setattr(module,'edit',AsyncMock())


def update(data,uid=OWNER):
    u=SimpleNamespace(id=uid)
    q=SimpleNamespace(data=data,from_user=u,answer=AsyncMock())
    return SimpleNamespace(callback_query=q,effective_user=u)


@pytest.mark.asyncio
async def test_rewards_subpages_have_deterministic_parent(monkeypatch):
    db={'users':{'1':{}},'user_points':{'1':8},'user_rewards':[]}
    patch_handler(monkeypatch,account_support,db)
    monkeypatch.setattr(account_support,'_language_for_user',lambda _:'fa')
    await account_support.u_rewards(update('u_rewards',1),SimpleNamespace(user_data={}))
    text,rows=account_support.edit.await_args.args[1:]
    assert '<b>جوایز</b>' in text
    assert {'u_my_rewards','u_reward_catalog','u_score','u_leaderboard','nb:home'}<=set(callbacks(rows))
    await account_support.u_my_rewards(update('u_my_rewards',1),SimpleNamespace(user_data={}))
    rows=account_support.edit.await_args.args[2]
    assert 'nb:u_rewards' in callbacks(rows)


@pytest.mark.parametrize('kind',['reward','points'])
def test_selected_draft_omits_recipient_search_and_is_inactive(state,kind):
    row=wizard.create_draft(state,OWNER,kind,selected_user='1')
    assert row['selected_user']=='1' and row['values']['users']==['1']
    assert 'users' not in wizard.fields(row)
    assert row['status']=='draft'
    assert not wallet_items(state,'1')
    with pytest.raises(ValueError):wizard.answer(state,OWNER,row['id'],'users','everyone')
    if kind=='reward':
        with pytest.raises(ValueError):wizard.answer(state,OWNER,row['id'],'claim','claim')
        wizard.answer(state,OWNER,row['id'],'claim','assign')


@pytest.mark.parametrize('kind,prize',[('points',None),('reward','points'),('reward','vip_days'),('reward','discount_coupon'),('reward','combined')])
def test_selected_publish_is_targeted_visible_and_idempotent(state,kind,prize):
    row=wizard.create_draft(state,OWNER,kind,mode='quick',selected_user='1')
    live=state['admin_creation_drafts'][row['id']]
    live['values'].update(value=10,reward_type=prize or 'points',prize_points=15,prize_vip=2,prize_coupon=20)
    before=copy.deepcopy(state.get('users',{}).get('2',{}))
    summary=wizard.review(state,OWNER,row['id'])
    assert any(key=='گیرنده انتخاب‌شده' and '1' in value for key,value in summary)
    result=wizard.publish(state,OWNER,row['id'],live['revision'])
    assert result['recipients']==1
    rewards=wallet_items(state,'1');assert rewards and wallet_unread_keys(state,'1')
    assert not wallet_items(state,'2') and state.get('users',{}).get('2',{})==before
    snapshot=copy.deepcopy(state)
    assert wizard.publish(state,OWNER,row['id'],live['revision'])==result
    assert state==snapshot


@pytest.mark.parametrize('tamper',['other_user','bulk','claim'])
def test_selected_publish_rejects_tampering_before_economic_changes(state,tamper):
    row=wizard.create_draft(state,OWNER,'reward',mode='quick',selected_user='1')
    wizard.review(state,OWNER,row['id']);live=state['admin_creation_drafts'][row['id']]
    if tamper=='claim':live['values']['claim']='claim'
    else:live['values']['users']=['2'] if tamper=='other_user' else ['1','2']
    before=copy.deepcopy(state)
    with pytest.raises(ValueError):wizard.publish(state,OWNER,row['id'],live['revision'])
    assert state==before


@pytest.mark.asyncio
@pytest.mark.parametrize('parent,suffix',[('crm_pipeline_stage:new:4',':p:new:4'),('crm_segment:vip:2',':s:vip:2'),('funnel_users:abandoned:30:3',':f:abandoned:30:3')])
async def test_crm_draft_preserves_case_through_save_resume_publish(monkeypatch,state,parent,suffix):
    patch_handler(monkeypatch,runtime,state)
    context=SimpleNamespace(user_data={'crm_case_context':{'uid':'1','parent':parent}})
    await runtime.creation_callback(update('cw:user:reward:1'),context)
    key=context.user_data['creation_draft_id'];row=state['admin_creation_drafts'][key]
    assert row['return_callback']=='crm_open:1'+suffix
    assert 'گیرنده' in runtime.edit.await_args.args[1]
    row['step']=wizard.fields(row).index('claim')
    await runtime.creation_screen(update('cw:resume:'+key),context,key)
    buttons=[b for r in runtime.edit.await_args.args[2] for b in r]
    answers=[b for b in buttons if str(b.callback_data).startswith('cw:answer:')]
    assert len(answers)==1 and answers[0].callback_data.endswith(':claim:1')
    await runtime.creation_callback(update('cw:save:'+key),context)
    assert 'crm_open:1'+suffix in callbacks(runtime.edit.await_args.args[2])
    await runtime.creation_callback(update('cw:resume:'+key),context)
    row['step']='review'
    await runtime.creation_screen(update('cw:review:'+key),context,key)
    await runtime.creation_callback(update(f'cw:publish:{key}:{row["revision"]}'),context)
    assert 'crm_open:1'+suffix in callbacks(runtime.edit.await_args.args[2])
    assert wallet_items(state,'1') and not wallet_items(state,'2')


def test_selected_missing_user_or_unauthorized_actor_is_rejected(state):
    with pytest.raises(ValueError):wizard.create_draft(state,OWNER,'reward',selected_user='404')
    with pytest.raises(PermissionError):wizard.create_draft(state,999999,'reward',selected_user='1')


@pytest.mark.parametrize('actor,expected',[(OWNER,True),(999999,False)])
def test_every_crm_case_render_has_authorized_selected_user_shortcuts(monkeypatch,state,actor,expected):
    from bot_runtime import growth_campaigns
    monkeypatch.setattr(growth_campaigns,'load_db',lambda:state)
    monkeypatch.setattr(growth_campaigns,'with_db',lambda fn:fn(state))
    monkeypatch.setattr(growth_campaigns,'_admin_user_profile_text',lambda *_:'Profile')
    text,rows=growth_campaigns._crm_view_payload('1',actor_id=actor,parent_callback='crm_pipeline_stage:lead:3')
    data=callbacks(rows)
    assert ('cw:user:points:1' in data)==expected
    assert ('cw:user:reward:1' in data)==expected
    assert 'nb:crm_pipeline_stage:lead:3' in data
