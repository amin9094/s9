"""Fault injection for transaction aborts, HTTP isolation, locks and build proof."""
from __future__ import annotations

import asyncio
import contextlib
import json
import sqlite3
import threading
import time
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace
from unittest.mock import AsyncMock

import httpx
import pytest

from core.storage.engine import DatabaseEngine


class PoolConnection:
    def __init__(self):
        self.pending = []
        self.committed = []
        self.rolled_back = 0
        self.closed = False
        self.exits = []

    def cursor(self):
        return self

    def execute(self, sql, params=()):
        if sql.startswith("INSERT"):
            self.pending.append(params)
        return self

    def commit(self):
        self.committed.extend(self.pending)
        self.pending.clear()

    def rollback(self):
        self.rolled_back += 1
        self.pending.clear()

    def close(self):
        self.closed = True


@pytest.fixture
def pooled_engine(tmp_path, monkeypatch):
    engine = DatabaseEngine(database_url="postgresql://unused", sqlite_path=tmp_path / "unused")
    connection = PoolConnection()

    @contextlib.contextmanager
    def connection_scope(**kwargs):
        try:
            yield connection
        except BaseException as exc:
            connection.exits.append(type(exc))
            connection.rollback()
            raise
        else:
            connection.exits.append(None)
            connection.commit()

    monkeypatch.setattr(engine, "_postgres_pool", lambda: SimpleNamespace(connection=connection_scope))
    monkeypatch.setattr(engine, "_activate_google_failover", lambda error: False)
    return engine, connection


@pytest.mark.parametrize("abort", [RuntimeError, asyncio.CancelledError, KeyboardInterrupt, SystemExit])
def test_pool_rolls_back_every_abort(pooled_engine, abort):
    engine, connection = pooled_engine
    with pytest.raises(abort):
        with engine.transaction() as cursor:
            cursor.execute("INSERT INTO v8_points VALUES (?)", (50,))
            raise abort("injected abort")
    assert connection.committed == []
    assert connection.rolled_back >= 1
    assert connection.closed


def test_successful_pool_transaction_commits(pooled_engine):
    engine, connection = pooled_engine
    with engine.transaction() as cursor:
        cursor.execute("INSERT INTO v8_points VALUES (?)", (50,))
    assert connection.committed == [(50,)]


@pytest.mark.parametrize("backend", ["engine", "store", "persistence"])
def test_sqlite_setup_failure_closes_connection(tmp_path, monkeypatch, backend):
    from core.db import SQLiteStore
    from core.persistence import SafeSQLitePersistence
    connection = PoolConnection()
    connection.execute = lambda *a: (_ for _ in ()).throw(sqlite3.OperationalError("injected pragma failure"))
    monkeypatch.setattr(sqlite3, "connect", lambda *a, **kw: connection)
    if backend == "engine":
        instance = DatabaseEngine(database_url="", sqlite_path=tmp_path / "db")
        call = instance._sqlite_connection
    else:
        cls = SQLiteStore if backend == "store" else SafeSQLitePersistence
        instance = object.__new__(cls)
        instance.path = tmp_path / "db"
        call = instance._connect
    with pytest.raises(sqlite3.OperationalError):
        call()
    assert connection.closed


@pytest.mark.asyncio
@pytest.mark.parametrize("endpoint", ["/api/v1/auth/session", "/api/v1/overview", "/api/v1/auth/logout"])
async def test_api_database_and_redis_checks_run_off_event_loop(monkeypatch, endpoint):
    from core import miniapp_server as server
    from core.webapp_auth import TelegramWebAppIdentity
    identity = TelegramWebAppIdentity(42, "", "Audit", "", int(time.time()), "")
    monkeypatch.setattr(server, "SETTINGS", replace(server.SETTINGS, webapp_api_enabled=True))
    monkeypatch.setattr(server, "_request_identity", lambda request: (identity, {"exp": int(time.time())+300}))
    event_thread = threading.get_ident()
    visited = []

    def checked(*args):
        visited.append(threading.get_ident())
        assert threading.get_ident() != event_thread, "blocking dependency ran on HTTP loop"
        return True

    monkeypatch.setattr(server, "_miniapp_access_allowed", checked)
    monkeypatch.setattr(server, "rate_limit_allow", checked)
    monkeypatch.setattr(server.v2, "overview", lambda identity: {"ok": True})
    app = server.create_app()
    async with httpx.AsyncClient(transport=httpx.ASGITransport(app=app), base_url="https://test") as client:
        response = await (client.post(endpoint) if endpoint.endswith("logout") else client.get(endpoint))
    assert response.status_code == 200, response.text
    assert visited


def test_rate_limiter_cap_cannot_be_exceeded(monkeypatch):
    from core import rate_limit as limiter
    limiter.reset_for_tests()
    monkeypatch.setattr(limiter, "_MAX_ENTRIES", 3)
    monkeypatch.setattr(limiter, "_redis_client", lambda: None)
    monkeypatch.setattr(limiter, "_production_fail_closed", lambda: False)
    try:
        assert all(limiter.allow(uid, "test", 10000) for uid in range(3))
        assert not limiter.allow(100, "test", 10000)
        assert len(limiter._LAST_SEEN) <= 3
        assert not limiter.allow(0, "test", 10000)
    finally:
        limiter.reset_for_tests()


def test_expired_rate_limit_entries_allow_recovery(monkeypatch):
    from core import rate_limit as limiter
    limiter.reset_for_tests()
    clock = [100.0]
    monkeypatch.setattr(limiter.time, "monotonic", lambda: clock[0])
    monkeypatch.setattr(limiter, "_MAX_ENTRIES", 2)
    monkeypatch.setattr(limiter, "_redis_client", lambda: None)
    monkeypatch.setattr(limiter, "_production_fail_closed", lambda: False)
    try:
        assert limiter.allow(1, "a", 5) and limiter.allow(2, "a", 5)
        clock[0] += 6
        assert limiter.allow(3, "a", 5)
        assert len(limiter._LAST_SEEN) <= 2
    finally:
        limiter.reset_for_tests()


@pytest.mark.asyncio
async def test_distributed_redis_creation_is_single_and_failed_candidates_close(monkeypatch):
    from core import distributed_jobs as jobs
    import redis.asyncio as redis
    monkeypatch.setattr(jobs, "SETTINGS", SimpleNamespace(redis_url="redis://unused"))
    await jobs.close_distributed_jobs()
    clients = []

    def create(*args, **kwargs):
        client = SimpleNamespace(ping=AsyncMock(), aclose=AsyncMock())
        clients.append(client)
        return client

    monkeypatch.setattr(redis.Redis, "from_url", create)
    try:
        results = await asyncio.gather(*(jobs._redis_client() for _ in range(20)))
        assert len(clients) == 1
        assert all(client is clients[0] for client in results)
    finally:
        await jobs.close_distributed_jobs()
    clients.clear()
    failed = SimpleNamespace(ping=AsyncMock(side_effect=ConnectionError("offline")), aclose=AsyncMock())
    monkeypatch.setattr(redis.Redis, "from_url", lambda *a, **kw: failed)
    assert await jobs._redis_client() is None
    failed.aclose.assert_awaited_once()
    await jobs.close_distributed_jobs()


def test_finalizer_does_not_reuse_failed_coverage_by_timestamp(tmp_path, monkeypatch):
    import sys
    monkeypatch.syspath_prepend(str(Path(__file__).resolve().parents[1] / "scripts"))
    from scripts import finalize_quality_proof as finalizer
    monkeypatch.setattr(finalizer, "ROOT", tmp_path)
    (tmp_path / "quality-artifacts").mkdir()
    state = {"overall_threshold": 19, "critical_threshold": 75, "test_targets": []}
    state_path = tmp_path / "state.json"
    state_path.write_text(json.dumps(state))
    (tmp_path / ".coverage").write_text("newer data from failed run")
    calls = []

    def fail(command, **kwargs):
        calls.append(command)
        return SimpleNamespace(returncode=1)

    monkeypatch.setattr(finalizer, "_run_isolated", fail)
    monkeypatch.setattr(finalizer, "_run_coverage_worker_inprocess", lambda args: pytest.fail("failed tests were replaced by a report"))
    for _ in range(2):
        with pytest.raises(RuntimeError, match="coverage test worker failed"):
            finalizer.finalize_state(state_path)
    assert len(calls) == 2


def test_watchdog_stop_does_not_revive_slow_previous_worker(monkeypatch):
    from core import runtime_watchdog as watchdog
    old = threading.Event()
    monkeypatch.setattr(watchdog, "_STOP", old)
    monkeypatch.setattr(watchdog, "_THREAD", SimpleNamespace(join=lambda **kw: None))
    watchdog.stop_runtime_watchdog()
    assert old.is_set()


def test_watchdog_evidence_write_is_bounded(monkeypatch):
    from core import runtime_watchdog as watchdog, observability
    release = threading.Event()
    entered = threading.Event()

    def blocked(*args):
        entered.set()
        release.wait(3)

    monkeypatch.setattr(observability, "record_error", blocked)
    monkeypatch.setattr(observability, "persist", lambda: None)
    started = time.monotonic()
    try:
        watchdog._persist_recovery_evidence("test")
        assert entered.is_set()
        assert time.monotonic() - started < 1.5
    finally:
        release.set()


def test_blocked_watchdog_probe_cannot_block_recovery():
    from core.runtime_watchdog import _bounded_probe
    release = threading.Event()
    try:
        with pytest.raises(TimeoutError):
            _bounded_probe(lambda: release.wait(3), timeout=0.02)
    finally:
        release.set()


def test_blocked_log_handler_cannot_block_watchdog(monkeypatch):
    from core import runtime_watchdog as watchdog
    release = threading.Event()
    monkeypatch.setattr(watchdog.logger, "log", lambda *args: release.wait(3))
    started = time.monotonic()
    try:
        watchdog._bounded_log(50, "test")
        assert time.monotonic() - started < 0.5
    finally:
        release.set()


@pytest.mark.parametrize("fault", ["none", "application", "application_error", "heartbeat_missing", "heartbeat_stale", "server", "pool", "delivery", "delivery_error"])
def test_watchdog_recovers_only_confirmed_repeated_failures(monkeypatch, tmp_path, fault):
    from core import runtime_watchdog as watchdog, async_runtime, miniapp_server
    threads = []
    exits = []
    readings = [0]

    class ClockEvent:
        def __init__(self):
            self.ticks = 0
            self.stopped = False

        def wait(self, timeout):
            self.ticks += 1
            return self.stopped or self.ticks > 3

        def set(self):
            self.stopped = True

    class Thread:
        def __init__(self, target, **kwargs):
            self.target = target
            self.name = kwargs.get("name")
            threads.append(self)

        def start(self):
            if self.name != "sentinel-runtime-watchdog":
                self.target()

        def is_alive(self):
            return False

        def join(self, **kwargs):
            pass

    def clock():
        readings[0] += 1
        return 0 if readings[0] == 1 else 1000

    def running():
        if fault == "application_error":
            raise ValueError("probe failed")
        return fault != "application"

    def delivery():
        if fault == "delivery_error":
            raise ValueError("probe failed")
        return {"pending": 0, "completed": 1, "processor_healthy": fault != "delivery"}

    monkeypatch.setenv("RUNTIME_WATCHDOG_FAILURE_LIMIT", "2")
    monkeypatch.setenv("RUNTIME_WATCHDOG_ENABLED", "true")
    monkeypatch.setattr(watchdog, "_THREAD", None)
    monkeypatch.setattr(watchdog.threading, "Thread", Thread)
    monkeypatch.setattr(watchdog.threading, "Event", ClockEvent)
    monkeypatch.setattr(watchdog.time, "monotonic", clock)
    monkeypatch.setattr(watchdog, "_heartbeat_age_seconds", lambda p: None if fault == "heartbeat_missing" else (10000 if fault == "heartbeat_stale" else 1))
    monkeypatch.setattr(watchdog, "_persist_recovery_evidence", lambda reason: None)
    monkeypatch.setattr(watchdog, "_terminate_for_recovery", exits.append)
    monkeypatch.setattr(miniapp_server, "is_running", lambda: fault != "server")
    monkeypatch.setattr(async_runtime, "blocking_executor_snapshot", lambda: {"capacity": 2, "outstanding": 2 if fault == "pool" else 0, "oldest_seconds": 10000})
    watchdog.start_runtime_watchdog(heartbeat_file=tmp_path / "beat", heartbeat_max_age_seconds=120, application_running=running, delivery_probe=delivery)
    threads[0].target()
    assert bool(exits) is (fault != "none")
    watchdog.stop_runtime_watchdog()


@pytest.mark.asyncio
@pytest.mark.parametrize("revoked", [False, True])
async def test_event_stream_rechecks_vip_and_keeps_lease_until_rotation(monkeypatch, revoked):
    from core import miniapp_server as server
    from core.webapp_auth import TelegramWebAppIdentity
    from starlette.requests import Request
    identity = TelegramWebAppIdentity(42, "", "Audit", "", int(time.time()), "")
    monkeypatch.setattr(server, "_request_identity", lambda request: (identity, {"exp": int(time.time()) + 300}))
    monkeypatch.setattr(server, "_miniapp_access_allowed", lambda uid: True)
    monkeypatch.setenv("SSE_ROTATE_SECONDS", "300")
    monkeypatch.setenv("SSE_CONNECTION_TTL_SECONDS", "30")
    grant = [True]
    monkeypatch.setattr(server.v2, "access_context", lambda identity: {"vip_active": grant[0]})
    release = AsyncMock()
    limits = AsyncMock(return_value=SimpleNamespace(release=release))
    monkeypatch.setattr(server, "acquire_connection_limits", limits)
    sequence = [0]

    async def read(*args, **kwargs):
        sequence[0] += 1
        grant[0] = not revoked
        return SimpleNamespace(events=[{"sequence": sequence[0], "event_type": "signal.created", "payload": {"access_tier": "vip"}}])

    monkeypatch.setattr(server, "EventStreamService", lambda: SimpleNamespace(read=read))
    app = server.create_app()
    endpoint = next(route.endpoint for route in app.routes if route.path == "/api/v1/events")
    request = Request({"type": "http", "method": "GET", "path": "/api/v1/events", "headers": [], "query_string": b""})
    # One batch, then a disconnect; avoid waiting for a real streaming timeout.
    disconnected = iter([False, True])
    monkeypatch.setattr(Request, "is_disconnected", AsyncMock(side_effect=lambda: next(disconnected)))
    response = await endpoint(request, last_id=0, last_event_id="")
    chunks = [chunk async for chunk in response.body_iterator]
    assert limits.call_args.kwargs["ttl_seconds"] >= 330
    assert any(b"signal.created" in chunk for chunk in chunks) is (not revoked)
    release.assert_awaited_once()


def test_session_expiration_is_exclusive(monkeypatch):
    from core import miniapp_server as server
    from core.webapp_auth import TelegramWebAppIdentity
    monkeypatch.setattr(server, "SETTINGS", replace(server.SETTINGS, webapp_session_secret="a" * 64, session_key_version="v1", session_previous_keys=()))
    monkeypatch.setattr(server, "_SESSION_SECRET_CACHE", None)
    now = int(time.time())
    monkeypatch.setattr(server.time, "time", lambda: now)
    token, _ = server._session_token(TelegramWebAppIdentity(42, "", "Audit", "", now, ""))
    monkeypatch.setattr(server.time, "time", lambda: now + server._SESSION_TTL)
    from fastapi import HTTPException
    with pytest.raises(HTTPException):
        server._identity_from_session(token)


@pytest.mark.parametrize("value,expected", [("-1", 1), ("0", 1), ("6", 6), ("100", 20), ("", 6)])
def test_startup_retry_budget_is_finite(monkeypatch, value, expected):
    from core.telegram_bootstrap import bootstrap_attempts
    monkeypatch.setenv("TELEGRAM_BOOTSTRAP_ATTEMPTS", value)
    assert bootstrap_attempts() == expected


def test_slow_heartbeat_read_never_holds_telegram_metrics_lock(monkeypatch):
    from core import observability
    entered = threading.Event()
    release = threading.Event()

    def slow_read():
        entered.set()
        release.wait(1)
        return True

    monkeypatch.setattr(observability, "_heartbeat_healthy", slow_read)
    worker = threading.Thread(target=observability.snapshot)
    worker.start()
    assert entered.wait(1)
    started = time.monotonic()
    try:
        observability.increment("heartbeat_lock_regression")
        assert time.monotonic() - started < 0.1
    finally:
        release.set()
        worker.join(2)
    assert not worker.is_alive()


def test_concurrent_metrics_snapshots_are_atomic(monkeypatch, tmp_path, caplog):
    from concurrent.futures import ThreadPoolExecutor
    from core import observability
    path = tmp_path / "metrics.json"
    monkeypatch.setattr(observability, "_METRICS_FILE", path)
    monkeypatch.setattr(observability, "_heartbeat_healthy", lambda: True)
    with ThreadPoolExecutor(max_workers=8) as executor:
        list(executor.map(lambda _: observability.persist(), range(64)))
    assert json.loads(path.read_text())["heartbeat_healthy"]
    assert list(tmp_path.iterdir()) == [path]
    assert path.stat().st_mode & 0o077 == 0
    assert "Could not persist metrics" not in caplog.text


@pytest.mark.asyncio
async def test_update_lock_registry_tracks_only_active_users(monkeypatch):
    from core.update_processor import KeyedUpdateProcessor
    processor = KeyedUpdateProcessor(8)
    monkeypatch.setattr(processor, "_key", lambda user: f"user:{user}")

    async def work():
        await asyncio.sleep(0)

    for batch in range(50):
        await asyncio.gather(*(processor.process_update(batch * 8 + uid, work()) for uid in range(8)))
    assert processor._locks == {}
    assert processor._active == {}
    assert processor.is_healthy()
    await processor.shutdown()


@pytest.mark.asyncio
async def test_same_user_stays_serialized_during_registry_cleanup(monkeypatch):
    from core.update_processor import KeyedUpdateProcessor
    processor = KeyedUpdateProcessor(8)
    monkeypatch.setattr(processor, "_key", lambda user: "same-user")
    active = [0]
    peak = [0]

    async def work():
        active[0] += 1
        peak[0] = max(peak[0], active[0])
        await asyncio.sleep(0.001)
        active[0] -= 1

    await asyncio.gather(*(processor.process_update(1, work()) for _ in range(30)))
    assert peak[0] == 1
    assert processor._locks == {}
    await processor.shutdown()


@pytest.mark.asyncio
async def test_group_discount_queues_the_selected_segment(monkeypatch):
    import bot  # binds shared globals to current feature modules
    from bot_runtime import admin_operations as admin
    state = {"discount_codes": {"VIP15": {"scope": "public", "status": "active", "percent": 15}}, "users": {}}
    monkeypatch.setattr(admin, "require_admin", AsyncMock(return_value=True))
    monkeypatch.setattr(admin, "_has_admin_permission", lambda *args: True)
    monkeypatch.setattr(admin, "async_snapshot", AsyncMock(return_value=state))
    monkeypatch.setattr(admin, "public_discount_codes", lambda db: None)
    monkeypatch.setattr(admin, "crm_segment_snapshot", lambda db: {"vip": ["11", "22", "invalid"]})
    monkeypatch.setattr(admin, "audit", lambda *args: None)
    queued = []

    def enqueue(db, **kwargs):
        queued.append(kwargs)
        return {"id": "broadcast-test", "recipients_count": len(kwargs["recipients"])}

    monkeypatch.setattr(admin, "enqueue_broadcast", enqueue)

    async def with_db(callback):
        return callback(state)

    monkeypatch.setattr(admin, "async_with_db", with_db)
    monkeypatch.setattr(admin, "edit", AsyncMock())
    query = SimpleNamespace(data="pdcseg:VIP15:vip", from_user=SimpleNamespace(id=354678485), answer=AsyncMock())
    await admin.public_discount_segment_do(SimpleNamespace(callback_query=query), SimpleNamespace(user_data={}))
    assert queued[0]["recipients"] == [11, 22]
    assert queued[0]["segment"] == "crm:vip:public_discount:VIP15"


def test_async_bot_handlers_do_not_call_known_blocking_helpers_directly():
    import ast
    from pathlib import Path
    root = Path(__file__).resolve().parents[1]
    blocking = {"load_db", "_language_for_user", "_has_admin_permission", "_has_any_admin_permission", "_is_any_admin", "main_menu", "admin_menu", "rate_limit_allow"}
    violations = []

    class Scan(ast.NodeVisitor):
        def visit_Call(self, node):
            if isinstance(node.func, ast.Name) and node.func.id in blocking:
                violations.append(node.lineno)
            self.generic_visit(node)

        def visit_FunctionDef(self, node):
            pass

        def visit_AsyncFunctionDef(self, node):
            pass

        def visit_Lambda(self, node):
            pass

    for file in (root / "bot_runtime").glob("*.py"):
        for node in ast.parse(file.read_text()).body:
            if isinstance(node, ast.AsyncFunctionDef):
                scan = Scan()
                for stmt in node.body:
                    scan.visit(stmt)
    assert violations == []


def test_real_miniapp_stream_recovery_javascript():
    import shutil
    import subprocess
    script = Path(__file__).with_name("miniapp_stream841.mjs")
    node = shutil.which("node")
    assert node, "Node is required for the Mini App release checks"
    result = subprocess.run([node, str(script)], capture_output=True, text=True, timeout=15)
    assert result.returncode == 0, result.stderr
    assert "4 scenarios passed" in result.stdout


@pytest.mark.asyncio
async def test_background_tasks_are_cancelled_on_their_owner_loop(monkeypatch):
    from core import miniapp_server as server
    ready = threading.Event()
    cancelled = threading.Event()
    owner = asyncio.new_event_loop()
    tasks = set()
    monkeypatch.setattr(server, "_BACKGROUND_TASKS", tasks)

    async def pending():
        ready.set()
        try:
            await asyncio.Event().wait()
        finally:
            assert asyncio.get_running_loop() is owner
            cancelled.set()

    def worker():
        asyncio.set_event_loop(owner)
        task = owner.create_task(pending())
        tasks.add(task)
        owner.run_forever()

    thread = threading.Thread(target=worker, daemon=True)
    thread.start()
    assert ready.wait(1)
    try:
        await server.drain_background_tasks(timeout=1)
        assert cancelled.is_set()
        assert all(task.done() for task in tasks)
    finally:
        owner.call_soon_threadsafe(owner.stop)
        thread.join(2)
        owner.close()
    assert not thread.is_alive()
