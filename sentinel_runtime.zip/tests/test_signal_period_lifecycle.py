from __future__ import annotations

from copy import deepcopy
from pathlib import Path

import pytest

from core.db import DEFAULT_DB
from modules.signal_portal import (
    close_signal_cycle,
    ensure_signal_portal,
    list_signal_cycles,
    rename_signal_cycle,
    reserve_signal_identity,
    rollover_signal_cycle,
    signal_cycle_detail,
    signal_cycle_summary,
    start_signal_cycle,
)
from services.signal_cycle_pdf_service import build_signal_cycle_pdf


def _db() -> dict:
    db = deepcopy(DEFAULT_DB)
    db.setdefault("next_ids", {})["signal"] = 3
    ensure_signal_portal(db)
    db["signals"] = [
        {
            "id": 1,
            "cycle_id": 1,
            "display_number": 1,
            "market_category": "forex",
            "symbol": "XAUUSD",
            "side": "buy",
            "entry": "2300",
            "stop": "2290",
            "targets": ["2310", "2320"],
            "risk": 1,
            "status": "target_complete",
            "profit_percent": 2.0,
            "created_at": "2026-01-01T10:00:00+00:00",
        },
        {
            "id": 2,
            "cycle_id": 1,
            "display_number": 1,
            "market_category": "crypto",
            "symbol": "BTCUSDT",
            "side": "sell",
            "entry": "100000",
            "stop": "101000",
            "targets": ["99000"],
            "risk": 1,
            "status": "stop",
            "profit_percent": -1.0,
            "created_at": "2026-01-02T10:00:00+00:00",
        },
    ]
    db["scheduled_signals"] = [
        {"id": 1, "status": "pending", "payload": {"symbol": "EURUSD"}},
        {"id": 2, "status": "sent", "payload": {"symbol": "GBPUSD"}},
        {"id": 3, "status": "retrying", "payload": {"symbol": "USDJPY"}},
    ]
    return db


def test_close_preserves_signals_and_is_idempotent() -> None:
    db = _db()
    closed = close_signal_cycle(db, 91)

    assert closed["status"] == "closed"
    assert closed["stats"]["total"] == 2
    assert closed["stats"]["wins"] == 1
    assert closed["stats"]["losses"] == 1
    assert closed["stats"]["profit_percent_sum"] == 1.0
    assert db["signals"] == []
    assert len(db["signal_archive"]) == 2
    assert db["scheduled_signals"][0]["status"] == "cancelled"
    assert db["scheduled_signals"][1]["status"] == "sent"
    assert db["scheduled_signals"][2]["status"] == "cancelled"

    repeated = close_signal_cycle(db, 91)
    assert repeated["already_closed"] is True
    assert len(db["signal_archive"]) == 2
    assert signal_cycle_detail(db, 1)["total"] == 2


def test_start_named_period_keeps_closed_period_reviewable() -> None:
    db = _db()
    close_signal_cycle(db, 91)
    started = start_signal_cycle(db, 91, "کمپین تبدیل ۱۰۰ به ۱۰۰۰")

    assert started["id"] == 2
    assert started["name"] == "کمپین تبدیل ۱۰۰ به ۱۰۰۰"
    assert started["status"] == "active"
    assert started["stats"]["total"] == 0
    assert signal_cycle_summary(db, 1)["status"] == "closed"
    assert signal_cycle_detail(db, 1)["total"] == 2
    assert [(row["id"], row["status"]) for row in list_signal_cycles(db)] == [(2, "active"), (1, "closed")]

    forex = reserve_signal_identity(db, "forex")
    crypto = reserve_signal_identity(db, "crypto")
    assert forex["cycle_id"] == crypto["cycle_id"] == 2
    assert forex["display_number"] == crypto["display_number"] == 1


def test_rollover_and_rename_do_not_touch_historical_signals() -> None:
    db = _db()
    result = rollover_signal_cycle(db, 7, new_name="کمپین تابستان")
    assert result["closed"]["id"] == 1
    assert result["started"]["id"] == 2
    assert result["started"]["name"] == "کمپین تابستان"

    renamed = rename_signal_cycle(db, 1, "دوره قبل از کمپین", 7)
    assert renamed["name"] == "دوره قبل از کمپین"
    assert signal_cycle_detail(db, 1)["total"] == 2
    assert len(db["signal_archive"]) == 2



def test_close_refreshes_existing_archive_mirror_from_live_signal() -> None:
    db = _db()
    db["signal_archive"] = [{
        "id": 1, "cycle_id": 1, "display_number": 1, "market_category": "forex",
        "symbol": "XAUUSD", "status": "open", "profit_percent": 0,
    }]
    close_signal_cycle(db, 22)
    archived = next(row for row in db["signal_archive"] if row.get("id") == 1)
    assert archived["status"] == "target_complete"
    assert archived["profit_percent"] == 2.0
    assert len([row for row in db["signal_archive"] if row.get("id") == 1]) == 1


def test_invalid_rollover_name_does_not_close_active_period() -> None:
    db = _db()
    with pytest.raises(ValueError, match="نام دوره"):
        rollover_signal_cycle(db, 7, new_name=" ")
    assert db["signal_cycle"]["status"] == "active"
    assert len(db["signals"]) == 2

def test_no_new_signal_can_be_reserved_while_period_is_closed() -> None:
    db = _db()
    close_signal_cycle(db, 1)
    with pytest.raises(ValueError, match="دوره فعالی وجود ندارد"):
        reserve_signal_identity(db, "forex")


def test_legacy_reset_history_migrates_to_named_closed_periods() -> None:
    db = deepcopy(DEFAULT_DB)
    db["signal_cycle"] = {
        "current_id": 3,
        "next_number": 1,
        "started_at": "2026-03-01T00:00:00+00:00",
        "started_by": "5",
        "reset_history": [
            {"cycle_id": 1, "ended_at": "2026-01-31T00:00:00+00:00", "archived_signals": 12},
            {"cycle_id": 2, "name": "کمپین قبلی", "ended_at": "2026-02-28T00:00:00+00:00", "archived_signals": 9},
        ],
    }
    cycle = ensure_signal_portal(db)
    periods = {row["id"]: row for row in cycle["periods"]}
    assert periods[1]["status"] == "closed"
    assert periods[2]["name"] == "کمپین قبلی"
    assert periods[3]["status"] == "active"


def test_period_pdf_is_searchable_pdf_and_contains_all_rows() -> None:
    db = _db()
    close_signal_cycle(db, 91)
    payload = build_signal_cycle_pdf(db, 1, language="fa")
    assert payload.startswith(b"%PDF-")
    assert len(payload) > 10_000


def test_frontend_and_api_expose_period_management() -> None:
    root = Path(__file__).resolve().parents[1]
    source = "\n".join(
        (root / "webapp" / "src" / name).read_text(encoding="utf-8")
        for name in ("core.js", "shell-events.js", "admin-parity.js")
    )
    server = (root / "core" / "miniapp_server.py").read_text(encoding="utf-8")
    catalog = (root / "services" / "admin_action_catalog.py").read_text(encoding="utf-8")
    for token in (
        "adminSignalCycles",
        "signal_cycle_rollover",
        "signal_cycle_close",
        "signal_cycle_start",
        "signal_cycle_rename",
        "downloadSignalCyclePdf",
    ):
        assert token in source or token in catalog
    assert '/api/v1/admin/signal-cycles/{cycle_id}/export.pdf' in server
