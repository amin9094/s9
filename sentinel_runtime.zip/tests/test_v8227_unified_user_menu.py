from __future__ import annotations

from pathlib import Path

from bot_runtime import navigation, signals_portfolio


def _callbacks(rows):
    return [[getattr(button, "callback_data", None) for button in row] for row in rows]


def test_account_dashboard_has_reachable_settings_and_rewards(monkeypatch):
    monkeypatch.setattr(signals_portfolio, "_language_for_user", lambda _uid: "fa")
    rows = signals_portfolio._account_rows(1001)
    callbacks = _callbacks(rows)
    assert callbacks == [["u_settings", "u_rewards"], ["u_account", "home"]]
    flattened = {callback for row in callbacks for callback in row}
    assert not {
        "account_vip", "account_education", "account_rewards", "account_activity",
        "account_notifications", "account_privacy", "u_rules", "u_referral",
    } & flattened


def test_webapp_is_appended_after_primary_menu_rows(monkeypatch):
    marker = [object()]
    monkeypatch.setattr(navigation, "webapp_row", lambda: marker)
    rows = [[object()], [object()]]
    assert navigation.with_webapp(rows) == rows + [marker]


def test_legacy_account_route_is_direct_not_category_submenu():
    source = Path("handlers/callback_routes.py").read_text(encoding="utf-8")
    assert "('^nav_user:account$', namespace['u_account'])" in source
    generic = next(line for line in source.splitlines() if "nav_user:(?:more" in line)
    assert "account" not in generic


def test_release_version_v8227():
    assert Path("VERSION").read_text(encoding="utf-8").strip() == "9.0.0-candidate.14"
