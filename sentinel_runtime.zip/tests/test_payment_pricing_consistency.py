from __future__ import annotations

from pathlib import Path

import pytest

from modules.miniapp_product import _usdt_amount as miniapp_usdt_amount
from modules.payment_pricing import calculate_usdt_amount, format_usdt_amount, normalize_toman

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.parametrize(
    "toman,rate,expected",
    [
        (1_000_000, 100_000, "10.000000"),
        (1, 3, "0.333333"),
        (999_999, "61234.5", "16.330647"),
        (0, 100_000, "0.000000"),
    ],
)
def test_bot_and_miniapp_use_identical_exact_usdt_quotes(toman, rate, expected):
    shared = calculate_usdt_amount(toman, rate)
    assert format(shared, ".6f") == expected
    assert miniapp_usdt_amount(toman, rate) == shared
    assert format_usdt_amount(toman, rate) == expected


@pytest.mark.parametrize("invalid", [0, -1, "", "nan", "inf"])
def test_invalid_usdt_rate_fails_closed(invalid):
    with pytest.raises(ValueError):
        calculate_usdt_amount(1_000_000, invalid)


def test_toman_rounding_is_explicit_and_integer_only():
    assert normalize_toman("1000") == 1000
    assert normalize_toman("1000.49") == 1000
    assert normalize_toman("1000.50") == 1001
    with pytest.raises(ValueError, match="TOMAN_AMOUNT_NEGATIVE"):
        normalize_toman(-1)


def test_frontend_has_both_manual_payment_choices_and_no_automatic_language():
    text = (ROOT / "webapp/src/commerce-support.js").read_text(encoding="utf-8")
    bot_text = (ROOT / "bot_runtime/commerce_calculator.py").read_text(encoding="utf-8")
    assert "return calculate_usdt_amount(toman_amount, rate_toman)" in bot_text
    assert '<option value="card">Card to card</option>' in text
    assert '<option value="usdt">USDT</option>' in text
    assert "بررسی دستی ادمین" in text
    assert "تأیید خودکار" not in text
