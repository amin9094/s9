from __future__ import annotations

import importlib.util
import asyncio
import json
import os
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

import pytest

ROOT = Path(__file__).resolve().parents[1]


@pytest.mark.asyncio
async def test_webhook_initialization_retries_network_failure(monkeypatch):
    from core import telegram_bootstrap
    from telegram.error import NetworkError

    attempts = []

    async def initialize():
        attempts.append(True)
        if len(attempts) == 1:
            raise NetworkError("temporary disconnect")

    async def fast_wait(awaitable, timeout):
        awaitable.close()
        raise TimeoutError

    monkeypatch.setattr(telegram_bootstrap.asyncio, "wait_for", fast_wait)
    assert await telegram_bootstrap.initialize_with_retry(SimpleNamespace(initialize=initialize), asyncio.Event())
    assert len(attempts) == 2


@pytest.mark.asyncio
async def test_webhook_initialization_does_not_retry_invalid_credentials():
    from core.telegram_bootstrap import initialize_with_retry

    async def initialize():
        raise ValueError("invalid credentials")

    with pytest.raises(ValueError, match="invalid credentials"):
        await initialize_with_retry(SimpleNamespace(initialize=initialize), asyncio.Event())


@pytest.mark.asyncio
async def test_webhook_initialization_retry_stops_on_shutdown():
    from core.telegram_bootstrap import initialize_with_retry
    from telegram.error import NetworkError

    stop = asyncio.Event()

    async def initialize():
        stop.set()
        raise NetworkError("temporary disconnect")

    assert not await initialize_with_retry(SimpleNamespace(initialize=initialize), stop)


def test_collection_count_does_not_count_warning_line_numbers(monkeypatch):
    monkeypatch.syspath_prepend(str(ROOT / "scripts"))
    from scripts.quality_gate import _collected_total

    output = "tests/test_one.py: 2\ntests/test_two.py: 3\n"
    output += "../site-packages/starlette/testclient.py:45\n"
    output += "  /site-packages/starlette/testclient.py:45: DeprecationWarning: old API\n"
    assert _collected_total(output) == 5


def test_market_retains_live_quotes_if_cache_recovery_fails(monkeypatch):
    from services import live_market_service, miniapp_read_service_v2 as service

    result = {"quotes": [{"symbol": "EURUSD", "price": 1.1}], "failed_quotes": [{"symbol": "XAUUSD"}]}
    monkeypatch.setattr(live_market_service, "live_market_snapshot", lambda *a, **k: result)

    def unavailable(*args):
        raise ConnectionError("cache unavailable")

    monkeypatch.setattr(service.legacy, "market", unavailable)
    assert service.market(SimpleNamespace(user_id=123)) is result


@pytest.mark.parametrize("port,expected", [("9001", 9001), (None, 8080)])
def test_railway_health_listener_uses_router_port(monkeypatch, port, expected):
    from config import _health_port

    monkeypatch.setenv("RAILWAY_SERVICE_ID", "test-service")
    monkeypatch.setenv("HEALTH_PORT", "8080")
    if port is None:
        monkeypatch.delenv("PORT", raising=False)
    else:
        monkeypatch.setenv("PORT", port)
    assert _health_port() == expected


@pytest.mark.parametrize("port", ["0", "65536", "-1"])
def test_invalid_railway_port_fails_explicitly(monkeypatch, port):
    from config import _health_port

    monkeypatch.setenv("RAILWAY_SERVICE_ID", "test-service")
    monkeypatch.setenv("PORT", port)
    with pytest.raises(RuntimeError, match="HTTP health port"):
        _health_port()


@pytest.mark.parametrize("mount_variable", ["PERSISTENT_DATA_DIR", "RAILWAY_VOLUME_MOUNT_PATH", "VOLUME_MOUNT_PATH"])
def test_entrypoint_prepares_actual_volume_paths(tmp_path, mount_variable):
    app = tmp_path / "app"
    app.mkdir()
    volume = tmp_path / "volume"
    fake_bin = tmp_path / "bin"
    fake_bin.mkdir()
    calls = tmp_path / "calls"
    for command in ("chown", "chmod"):
        file = fake_bin / command
        file.write_text('#!/bin/sh\nprintf "%s\\n" "$*" >> "$CALLS"\n')
        file.chmod(0o755)
    (fake_bin / "id").write_text('#!/bin/sh\nprintf "0\\n"\n')
    (fake_bin / "id").chmod(0o755)
    (fake_bin / "gosu").write_text('#!/bin/sh\nshift\nexec "$@"\n')
    (fake_bin / "gosu").chmod(0o755)
    script = tmp_path / "entrypoint.sh"
    script.write_text((ROOT / "scripts/docker-entrypoint.sh").read_text().replace("/app", str(app)))
    env = {"PATH": f"{fake_bin}:/usr/bin:/bin", "CALLS": str(calls), mount_variable: str(volume),
           "SENTINEL_ALLOWED_STORAGE_ROOTS": f"{app}/data:{app}/logs:{volume}"}
    subprocess.run(["sh", str(script), "true"], env=env, check=True, timeout=10)
    for name in ("backups", "payment_receipts", "support_attachments", "signal_templates"):
        assert (volume / name).is_dir()
    assert f"sentinel:sentinel {volume}\n" in calls.read_text()
    assert not (app / "data/backups").exists()


def test_live_http_listener_reports_readiness_and_ignores_proxy(tmp_path):
    if importlib.util.find_spec("telegram.request") is None:
        pytest.skip("requires real Telegram dependencies")
    env = os.environ.copy()
    for key in ("DATABASE_URL", "POSTGRES_URL", "RAILWAY_PROJECT_ID", "RAILWAY_SERVICE_ID", "RAILWAY_ENVIRONMENT",
                "PERSISTENT_DATA_DIR", "RAILWAY_VOLUME_MOUNT_PATH", "VOLUME_MOUNT_PATH"):
        env.pop(key, None)
    env.update({"DB_FILE": str(tmp_path / "state.sqlite3"), "WEBAPP_API_ENABLED": "false",
                "WEBAPP_SESSION_SECRET": "test-http-listener-unique-secret-1234567890",
                "HTTP_PROXY": "http://127.0.0.1:1", "HTTPS_PROXY": "http://127.0.0.1:1"})
    code = '''
import json, socket, tempfile
from pathlib import Path
from core import observability, miniapp_server
from core.heartbeat import write_heartbeat
from scripts.healthcheck import _http_liveness
with tempfile.TemporaryDirectory() as directory:
    root = Path(directory)
    observability.configure(root / "metrics.json", root / "heartbeat.json", 120)
    observability.set_readiness_state("bootstrap_complete", False)
    with socket.socket() as sock:
        sock.bind(("127.0.0.1", 0))
        port = sock.getsockname()[1]
    try:
        miniapp_server.start("127.0.0.1", port)
        try:
            _http_liveness("127.0.0.1", port, 2)
        except RuntimeError as exc:
            assert "bootstrap_complete" in str(exc), str(exc)
        else:
            raise AssertionError("uninitialized runtime reported healthy")
        write_heartbeat(root / "heartbeat.json")
        observability.set_readiness_state("bootstrap_complete", True)
        _http_liveness("127.0.0.1", port, 2)
        observability.set_readiness_state("database", False)
        try:
            _http_liveness("127.0.0.1", port, 2)
        except RuntimeError as exc:
            assert "database" in str(exc), str(exc)
        else:
            raise AssertionError("failed database reported healthy")
        print(json.dumps({"listener": True, "startup_503": True, "ready_200": True, "failure_503": True}))
    finally:
        miniapp_server.stop()
'''
    result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stdout + result.stderr
    assert json.loads(result.stdout.strip().splitlines()[-1])["ready_200"]


def test_full_polling_startup_reaches_readiness_with_mock_telegram(tmp_path):
    if importlib.util.find_spec("telegram.request") is None:
        pytest.skip("requires real Telegram dependencies")
    env = os.environ.copy()
    for key in list(env):
        if key.startswith("RAILWAY_") or key.lower().endswith("_proxy"):
            env.pop(key, None)
    env.update({
        "BOT_TOKEN": "123456789:" + "A" * 32, "ADMIN_IDS": "123456789", "PRIMARY_ADMIN_ID": "123456789",
        "RUN_MODE": "polling", "DATABASE_URL": "", "POSTGRES_URL": "", "REDIS_URL": "",
        "DB_FILE": str(tmp_path / "state.sqlite3"), "PERSISTENT_DATA_DIR": str(tmp_path),
        "LOG_DIR": str(tmp_path / "logs"), "WEBAPP_API_ENABLED": "false", "GEMINI_ENABLED": "false",
        "GOOGLE_SHEETS_BACKUP_ENABLED": "false", "ENABLE_PROCESS_LOCK": "false",
        "WEBAPP_SESSION_SECRET": "test-startup-session-unique-secret-1234567890",
        "RUNTIME_WATCHDOG_ENABLED": "false",
    })
    code = '''
import asyncio, json, os, socket, threading, time
from urllib.request import build_opener, ProxyHandler
with socket.socket() as sock:
    sock.bind(("127.0.0.1", 0))
    port = sock.getsockname()[1]
os.environ["HEALTH_PORT"] = str(port)
os.environ["HEALTH_HOST"] = "127.0.0.1"
from telegram.request import HTTPXRequest
async def fake_request(self, url, method, **kwargs):
    operation = url.rsplit("/", 1)[-1].lower()
    if operation == "getme":
        result = {"id": 123456789, "is_bot": True, "first_name": "Test", "username": "sentinel_test_bot"}
    elif operation == "getupdates":
        await asyncio.sleep(0.05)
        result = []
    elif operation in {"deletewebhook", "setmycommands", "setchatmenubutton"}:
        result = True
    else:
        raise AssertionError("unexpected Telegram method: " + operation)
    return 200, json.dumps({"ok": True, "result": result}).encode()
HTTPXRequest.do_request = fake_request
import bot
from core.miniapp_server import _telegram_application
ready = []
def monitor():
    opener = build_opener(ProxyHandler({}))
    deadline = time.monotonic() + 20
    while time.monotonic() < deadline:
        try:
            with opener.open(f"http://127.0.0.1:{port}/readyz", timeout=1) as response:
                payload = json.load(response)
            if payload["ready"]:
                ready.append(payload)
                app, loop = _telegram_application()
                loop.call_soon_threadsafe(app.stop_running)
                return
        except Exception:
            time.sleep(0.05)
thread = threading.Thread(target=monitor, daemon=True)
thread.start()
bot.main()
thread.join(timeout=1)
assert ready, "full startup never became ready"
print("FULL_STARTUP_OK " + json.dumps(ready[0]))
'''
    result = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, result.stdout[-6000:] + result.stderr[-6000:]
    assert "FULL_STARTUP_OK" in result.stdout
