"""Private delivery, initial-volume management, and durable retry contracts."""

from __future__ import annotations

from types import SimpleNamespace
from unittest.mock import AsyncMock

import pytest

from repositories.v2.setup_proposals import SetupRepository
from repositories.v2.strategy_outbox import StrategyOutboxRepository
from repositories.v2.strategy_reviews import StrategyReviewRepository
from tests.test_v9_strategy_feedback import seed


def case():
    return {"engine": "order_block", "symbol": "BTCUSDT", "timeframe": "5m", "state": "NEEDS_REVIEW",
            "available_ms": 1000, "reason": "POC_OUTSIDE_ORIGINAL_OB", "ob_source_id": "fixture-ob",
            "title_fa": "نیازمند بررسی: POC خارج از اوردر بلاک", "original_zone": ["99", "101"],
            "poc": {"price": "105", "volume_kind": "tick_proxy"}}


def pending(sqlite_engine):
    review_id = StrategyReviewRepository(sqlite_engine).store([case()])[0]
    outbox = StrategyOutboxRepository(sqlite_engine)
    outbox.enqueue([review_id], [123])
    outbox.enqueue([review_id], [123])
    return outbox


def test_outbox_dedupes_and_uncertain_delivery_is_never_resent(sqlite_engine):
    outbox = pending(sqlite_engine)
    claimed = outbox.claim()
    assert len(claimed) == 1 and outbox.claim() == []
    outbox.finish(claimed[0]["id"], "UNCERTAIN")
    assert StrategyOutboxRepository(sqlite_engine).claim() == []


@pytest.mark.asyncio
async def test_delivery_is_private_and_permissions_are_rechecked(sqlite_engine, monkeypatch):
    from services import strategy_scanner_service as service

    outbox = pending(sqlite_engine)
    monkeypatch.setattr(service, "StrategyOutboxRepository", lambda: outbox)
    bot = SimpleNamespace(send_message=AsyncMock(return_value=SimpleNamespace(message_id=99)))
    await service.deliver_reviews(bot, [])
    bot.send_message.assert_not_awaited()


@pytest.mark.asyncio
async def test_native_admin_case_header_is_sent_once(sqlite_engine, monkeypatch):
    from services import strategy_scanner_service as service

    outbox = pending(sqlite_engine)
    monkeypatch.setattr(service, "StrategyOutboxRepository", lambda: outbox)
    bot = SimpleNamespace(send_message=AsyncMock(return_value=SimpleNamespace(message_id=99)))
    await service.deliver_reviews(bot, [123])
    await service.deliver_reviews(bot, [123])
    bot.send_message.assert_awaited_once()
    assert bot.send_message.call_args.kwargs["chat_id"] == 123
    assert "POC خارج از اوردر بلاک" in bot.send_message.call_args.kwargs["text"]


def test_two_fifty_percent_exits_close_initial_volume_not_seventy_five_percent(sqlite_engine):
    seed(sqlite_engine, "a", manual=True)
    repository = SetupRepository(sqlite_engine)
    args = dict(version=1, actor="fixture-admin", reason="explicit management", confirmed_ms=2000)
    first = repository.record_admin_exit("a", percentage_original="50", reference_price="125", request_id="exit-first-fixture", **args)
    assert repository.record_admin_exit("a", percentage_original="50", reference_price="125", request_id="exit-first-fixture", **args) == first
    repository.record_admin_exit("a", percentage_original="50", reference_price="95", request_id="exit-final-fixture", **{**args, "confirmed_ms": 3000})
    report = repository.feedback()
    group = next(family for family in report["families"] if family["engine"] == "sweep_fvg")["groups"][0]
    assert group["admin_managed_closed"] == 1
    assert group["admin_declared_gross_win_rate_percent"] == 100
    assert group["admin_declared_net_win_rate_percent"] is None
    assert group["admin_declared_gross_r_sum"] == "0.5"
    with pytest.raises(ValueError, match="EXCEEDS_INITIAL_VOLUME"):
        repository.record_admin_exit("a", percentage_original="1", reference_price="95", request_id="exit-overflow-fixture", **{**args, "confirmed_ms": 4000})


def test_exit_changes_never_rewrite_plan_or_merge_unentered_setups(sqlite_engine):
    seed(sqlite_engine, "a", manual=True)
    repository = SetupRepository(sqlite_engine)
    original = repository.get("a")["payload"]["plan_hash"]
    repository.record_admin_exit("a", version=1, actor="fixture-admin", percentage_original="100", reference_price="125",
                                 reason="complete exit", request_id="exit-complete-fixture", confirmed_ms=2000, cost_in_initial_r="3")
    assert repository.get("a")["payload"]["plan_hash"] == original
    group = next(family for family in repository.feedback()["families"] if family["engine"] == "sweep_fvg")["groups"][0]
    assert group["admin_declared_gross_win_rate_percent"] == 100 and group["admin_declared_net_win_rate_percent"] == 0
