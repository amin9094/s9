"""Synthetic subscription contracts, not native execution-continuity evidence."""

import asyncio
import json
from unittest.mock import AsyncMock

import pytest

from modules import iran_equities as domain
from services import biquote_stream_check as stream, iran_equity_service as equities
from tests.test_v9_market_api import client as authenticated_client
from tests.test_v9_iran_equities import identity, CODE

client = authenticated_client
NOW = 1791989835000


def metadata(**changes):
    return {
        "name": "EURUSD",
        "source": "MetaTrader 5 (Broker 1)",
        "exchange": "FOREX",
        "digits": 5,
        "tickSize": "0.00001",
        **changes,
    }


def event(stamp="2026-10-14T14:57:12Z", **changes):
    return {
        "type": 1,
        "target": "ReceiveTick",
        "arguments": [
            {
                "symbol": "EURUSD",
                "source": "MetaTrader 5 (Broker 1)",
                "exchange": "FOREX",
                "bid": "1.11186",
                "ask": "1.11192",
                "spread": "0.00006",
                "mid": "1.11189",
                "timestamp": stamp,
                **changes,
            }
        ],
    }


def state(**changes):
    return {
        "type": 1,
        "target": "ReceiveSubscriptionState",
        "arguments": [[{"symbol": "EURUSD", "state": "open", "seeded": True, **changes}]],
    }


def send(check, *rows):
    check.receive("".join(json.dumps(row) + "\x1e" for row in rows), NOW)


def primed():
    check = stream.StreamCheck("EURUSD", metadata())
    send(check, event(), state(), {"type": 3, "invocationId": "1", "result": None})
    return check


def test_initial_seed_and_ack_do_not_claim_live_updates_or_continuity():
    check = primed()
    result = check.report()
    assert result["state"] == "INITIAL_QUOTES_ONLY" and result["timestamp_advancing_updates"] == 0
    assert result["subscription_acknowledged"] and result["initial_state_received"]
    assert not result["execution_eligible"] and not result["continuous_pretouch_proof"]


def test_timestamp_advancing_updates_are_only_a_bounded_indicative_sample():
    check = primed()
    send(check, event("2026-10-14T14:57:13Z"), event("2026-10-14T14:57:14Z"), event("2026-10-14T14:57:14Z"))
    report = check.report()
    assert report["timestamp_advancing_updates"] == 2 and report["quotes_received"] == 4
    assert report["state"] == "UPDATES_OBSERVED" and report["reported_grid_consistent"]
    assert not report["native_sequence_verified"] and not report["execution_eligible"]
    with pytest.raises(ValueError, match="REGRESSION"):
        send(check, event())


@pytest.mark.parametrize(
    "mutation",
    [
        {"symbol": "XAUUSD"},
        {"source": "Another broker"},
        {"exchange": "OTHER"},
        {"bid": "1.2", "ask": "1.1"},
        {"bid": "NaN"},
        {"mid": "1.5"},
        {"spread": "0.1"},
        {"timestamp": "2026-10-14T14:57:16Z"},
        {"timestamp": "2026-10-14T14:57:00Z"},
        {"timestamp": "2026-10-14T14:57:12"},
    ],
)
def test_wrong_source_prices_and_time_never_enter_the_sample(mutation):
    check = stream.StreamCheck("EURUSD", metadata())
    with pytest.raises((ValueError, ArithmeticError)):
        send(check, event(**mutation))


@pytest.mark.parametrize(
    "changes",
    [
        {"name": "XAUUSD"},
        {"source": None},
        {"exchange": None},
        {"tickSize": 0},
        {"digits": True},
        {"tickSize": "0.000001", "digits": 5},
    ],
)
def test_bad_metadata_does_not_supply_a_guessed_price_grid(changes):
    with pytest.raises(ValueError):
        stream.StreamCheck("EURUSD", metadata(**changes))


def test_off_grid_quotes_are_reported_without_rounding_or_execution():
    check = stream.StreamCheck("EURUSD", metadata(tickSize="0.0001", digits=4))
    send(check, event())
    assert check.report()["reported_grid_consistent"] is False
    assert check.report()["reported_tick_size"] == "0.0001"
    assert not check.report()["execution_eligible"]


def test_fragmented_records_ping_and_bounded_parser():
    check = stream.StreamCheck("EURUSD", metadata())
    raw = json.dumps(event()) + "\x1e"
    check.receive(raw[:15], NOW)
    assert check.report()["quotes_received"] == 0
    check.receive(raw[15:], NOW)
    send(check, {"type": 6})
    assert check.report()["quotes_received"] == 1
    for raw in [b"bytes", "x" * 128001, "[]\x1e", "not-json\x1e"]:
        with pytest.raises(ValueError):
            stream.StreamCheck("EURUSD", metadata()).receive(raw, NOW)
    for row in [
        {"type": 7},
        {"type": 3, "invocationId": "1", "error": "PRIVATE_ERROR"},
        {"type": 1, "target": "ReceiveTick", "arguments": []},
        state(symbol="XAUUSD"),
        state(state="closed"),
        state(seeded=False),
    ]:
        with pytest.raises(ValueError):
            send(stream.StreamCheck("EURUSD", metadata()), row)


@pytest.mark.asyncio
async def test_stream_transport_subscribes_read_only_and_closes_after_sample(monkeypatch):
    from services import canonical_market_service as market
    import websockets.asyncio.client as ws

    sent = []
    closed = []
    messages = iter(
        [
            "{}\x1e",
            json.dumps(event()) + "\x1e",
            json.dumps(state()) + "\x1e",
            json.dumps({"type": 3, "invocationId": "1", "result": None}) + "\x1e",
            json.dumps(event("2026-10-14T14:57:13Z")) + "\x1e",
            json.dumps(event("2026-10-14T14:57:14Z")) + "\x1e",
        ]
    )

    class Socket:
        async def __aenter__(self):
            return self

        async def __aexit__(self, *args):
            closed.append(True)

        async def send(self, raw):
            sent.append(raw)

        async def recv(self):
            return next(messages)

    monkeypatch.setattr(ws, "connect", lambda *args, **kwargs: Socket())
    monkeypatch.setattr(market, "_request", AsyncMock(return_value=metadata()))
    monkeypatch.setattr(stream.time, "time", lambda: NOW / 1000)
    result = await stream._sample("EURUSD")
    assert result["state"] == "UPDATES_OBSERVED" and closed == [True]
    assert len(sent) == 2 and json.loads(sent[1][:-1])["target"] == "Subscribe"
    assert not result["continuous_pretouch_proof"]


@pytest.mark.asyncio
async def test_stream_timeout_and_private_errors_are_safe(monkeypatch):
    from services import canonical_market_service as market

    monkeypatch.setattr(market, "_request", AsyncMock(side_effect=TimeoutError()))
    assert (await stream._sample("EURUSD"))["state"] == "SAMPLE_TIMEOUT"
    monkeypatch.setattr(market, "_request", AsyncMock(side_effect=RuntimeError("PRIVATE_TOKEN_VALUE")))
    result = await stream._sample("EURUSD")
    assert result["state"] == "STREAM_UNAVAILABLE_OR_INVALID" and "PRIVATE" not in json.dumps(result)


@pytest.mark.asyncio
async def test_stream_checks_coalesce_cache_and_reject_unapproved_markets(monkeypatch):
    monkeypatch.setattr(stream, "_CACHE", {})
    monkeypatch.setattr(stream, "_INFLIGHT", {})

    async def sample(symbol):
        await asyncio.sleep(0)
        return {"symbol": symbol, "state": "INITIAL_QUOTES_ONLY", "execution_eligible": False}

    mock = AsyncMock(side_effect=sample)
    monkeypatch.setattr(stream, "_sample", mock)
    a, b = await asyncio.gather(stream.sample_stream("eur/usd"), stream.sample_stream("EURUSD"))
    assert a == b and mock.await_count == 1
    assert await stream.sample_stream("EURUSD") == a and mock.await_count == 1
    with pytest.raises(ValueError):
        await stream.sample_stream("unapproved://host")
    assert not stream._INFLIGHT


@pytest.mark.asyncio
async def test_partial_search_candidates_are_preserved_but_not_classified(monkeypatch):
    partial = identity()
    partial.pop("yVal")
    partial.pop("flow")
    monkeypatch.setattr(equities, "_fetch", AsyncMock(return_value={"instrumentSearch": [partial]}))
    result = await equities.search_instruments("فولاد")
    assert result["items"][0]["ins_code"] == CODE
    assert result["classification_required_before_chart"]
    assert result["items"][0]["classification_verified"] is False
    with pytest.raises(ValueError, match="CLASSIFICATION_UNVERIFIED"):
        domain.instrument(partial)


@pytest.mark.asyncio
@pytest.mark.parametrize("changes", [{"yVal": "400"}, {"yVal": ""}, {"insCode": "123"}])
async def test_invalid_instrument_is_rejected_before_history_network_request(monkeypatch, changes):
    fetch = AsyncMock(return_value={"instrumentInfo": identity(**changes)})
    monkeypatch.setattr(equities, "_fetch", fetch)
    with pytest.raises(equities.IranEquityUnavailable):
        await equities.equity_chart(CODE)
    assert fetch.await_count == 1 and "GetInstrumentInfo" in fetch.call_args.args[0]


def test_admin_stream_sample_is_optional_private_and_does_not_modify_cached_report(client, monkeypatch):
    from core import miniapp_server as server
    from services import setup_review_service, strategy_readiness_service as readiness

    report = {
        "provider": "biquote",
        "symbol": "EURUSD",
        "timeframe": "5m",
        "deployment_only_remaining": False,
        "execution_eligible": False,
    }
    monkeypatch.setattr(readiness, "inspect_market_readiness", AsyncMock(return_value=report))
    sample = AsyncMock(return_value={"state": "UPDATES_OBSERVED", "execution_eligible": False})
    monkeypatch.setattr(stream, "sample_stream", sample)
    url = "/api/v1/market/readiness?symbol=EURUSD"
    assert client.get(url + "&stream_sample=true").status_code == 403
    sample.assert_not_awaited()
    monkeypatch.setattr(setup_review_service, "can_review_setups", lambda _: True)
    monkeypatch.setattr(server, "rate_limit_allow", lambda *args: True)
    assert client.get(url).status_code == 200
    sample.assert_not_awaited()
    result = client.get(url + "&stream_sample=true")
    assert result.status_code == 200 and not result.json()["data"]["execution_eligible"]
    assert "stream_probe" not in report and result.json()["data"]["stream_probe"]["state"] == "UPDATES_OBSERVED"
    monkeypatch.setattr(server, "rate_limit_allow", lambda *args: False)
    assert client.get(url + "&stream_sample=true").status_code == 429
    assert sample.await_count == 1


@pytest.mark.parametrize(
    "reason,status",
    [
        ("IR_CASH_EQUITY_REQUIRED", 422),
        ("IR_EQUITY_CLASSIFICATION_UNVERIFIED", 503),
        ("IR_EQUITY_IDENTITY_MISMATCH", 503),
    ],
)
def test_equity_errors_distinguish_unsupported_and_unverified_data(client, monkeypatch, reason, status):
    from core import miniapp_server as server
    from services import setup_review_service

    monkeypatch.setattr(setup_review_service, "can_review_setups", lambda _: True)
    monkeypatch.setattr(server, "rate_limit_allow", lambda *args: True)
    monkeypatch.setattr(equities, "equity_chart", AsyncMock(side_effect=equities.IranEquityUnavailable(reason)))
    response = client.get("/api/v1/admin/iran-equities/chart?ins_code=" + CODE)
    assert response.status_code == status and response.json()["error"]["code"] == reason
