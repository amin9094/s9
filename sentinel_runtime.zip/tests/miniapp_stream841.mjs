import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';

const source = fs.readFileSync(new URL('../webapp/src/shell-events.js', import.meta.url), 'utf8');
const code = source.slice(source.indexOf('function connectEvents()'), source.indexOf('\nfunction startPolling()'));
const streams = [], timers = new Map();
let sequence = 0, renewals = 0, polling = 0, failRenewal = false;
class EventSource {
    constructor() { this.handlers = new Map(); streams.push(this); }
    addEventListener(name, handler) { this.handlers.set(name, handler); }
    close() { this.closed = true; }
}
const state = {preview: false, lastEventId: 0, eventFailureCount: 0, page: 'home'};
const context = vm.createContext({
    state, window: {EventSource}, EventSource,
    clearTimeout: id => timers.delete(id), clearInterval: () => {},
    setTimeout: (callback, delay) => { const id = ++sequence; timers.set(id, {callback, delay}); return id; },
    startPolling: () => { polling++; },
    renewAuthenticatedSession: async () => { renewals++; if (failRenewal) throw new Error('offline'); },
    sessionStorage: {setItem: () => {}},
});
vm.runInContext(code, context);
const connect = () => vm.runInContext('connectEvents()', context);
async function nextTimer() {
    assert.equal(timers.size, 1, 'only one reconnect may be scheduled');
    const [id, timer] = [...timers.entries()][0];
    timers.delete(id);
    await timer.callback();
    return timer.delay;
}

connect();
streams.at(-1).handlers.get('stream.rotate')();
assert.equal(await nextTimer(), 250);
assert.equal(renewals, 0, 'normal rotation must not renew authentication');
assert.equal(state.eventFailureCount, 0);

streams.at(-1).handlers.get('stream.auth_required')();
assert.equal(await nextTimer(), 4000);
assert.equal(renewals, 1, 'expired stream must explicitly refresh the signed session');
assert.equal(state.eventFailureCount, 0);

const previous = streams.at(-1);
connect();
previous.onerror();
assert.equal(timers.size, 0, 'a late event from an old stream must not replace the current stream');

failRenewal = true;
const delays = [];
for (let i = 0; i < 8; i++) {
    streams.at(-1).onerror();
    delays.push(await nextTimer());
}
assert.deepEqual(delays, [2000, 4000, 8000, 16000, 30000, 30000, 30000, 30000]);
assert.equal(polling, 9, 'fallback polling remains available during reconnect attempts');
console.log('Mini App stream reliability: 4 scenarios passed');
